﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.GeneralLayer;
using Seguridad.Entity.DataAccess;
using Seguridad.Entity.BusinessEntity.Seguridad;
using SGTH.Entity.BusinessEntity.SGTH;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
namespace SGTH.Entity.DataAccess.SGTH
{
    class DAPersonaXHobbie : DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();
        String strConREN = ConfigurationManager.AppSettings["RENConexion"].ToString();
        String strDBSeguridad = ConfigurationManager.AppSettings["SEGBDNAME"].ToString();
        Int32 RDAAA = Convert.ToInt32(ConfigurationManager.AppSettings["RDAAA"]);

        public GenericEntityDAResponse fnDARegistro(BEPersonaXHobbie obj)
        {
            GenericEntityDAResponse sRes1 = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "[USP_GCH_MNT_PersonaXHobbies_TEST]";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nPrsId", obj.pnPrsId == 0 ? 0 : obj.pnPrsId, DbType.String);
                pAddParameter(cmdSQL, "@nHobbie", obj.pnHobbieId == 0 ? 0 : obj.pnHobbieId, DbType.Int32);
                pAddParameter(cmdSQL, "@nFrecuencia", obj.pnFrecuenciaId == 0 ? 0 : obj.pnFrecuenciaId, DbType.String);
                pAddParameter(cmdSQL, "@nNivel", obj.pnNivelId == 0 ? 0 : obj.pnNivelId, DbType.String);
                pAddParameter(cmdSQL, "@cEstado", obj.pcEstado == "" ? "" : obj.pcEstado, DbType.String);
                pAddParameter(cmdSQL, "@vMvmId", obj.pvMvmId == 0 ? 0 : obj.pvMvmId, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", obj.strOpcion == "" ? "" : obj.strOpcion, DbType.String);
              
                SqlDataReader drSQL = fLeer(cmdSQL);
                while (drSQL.Read())
                {
                    sRes1.cAttr2 = (drSQL["msjTransaction"].Equals(System.DBNull.Value) ? "-No msj-" : drSQL["msjTransaction"].ToString());
                }
            }
            catch (Exception ex)
            {
                sRes1.cError = ex.ToString();
                sRes1.cAttr4 = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return sRes1;
        }



        public GenericEntityDAResponse fnDALista(BEPersonaXHobbie obj)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "[USP_GCH_MNT_PersonaXHobbies_TEST]";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@cOpcion", obj.strOpcion == "" ? "" : obj.strOpcion, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

    }
}
