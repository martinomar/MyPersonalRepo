﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SGTH.Entity.GeneralLayer;
using Seguridad.Entity.DataAccess;
using Seguridad.Entity.BusinessEntity.Seguridad;
using SGTH.Entity.BusinessEntity.SGTH;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAPersonaXTratamientoEnfermedad: DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();
        String strConREN = ConfigurationManager.AppSettings["RENConexion"].ToString();
        String strDBSeguridad = ConfigurationManager.AppSettings["SEGBDNAME"].ToString();
        Int32 RDAAA = Convert.ToInt32(ConfigurationManager.AppSettings["RDAAA"]);

        public GenericEntityDAResponse fnDARegistro(BEPersonaXTratamientoEnfermedad obj)
        {
            GenericEntityDAResponse sRes1 = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "[USP_GCH_MNT_PersonaXTratamientoEnfermedad_TEST]";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@cOpcion", obj.strOpcion == "" ? "" : obj.strOpcion, DbType.String);
                pAddParameter(cmdSQL, "@nPrsId", obj.pnPrsId == 0 ? 0 : obj.pnPrsId, DbType.Int32);
                pAddParameter(cmdSQL, "@cTratmnto_enfermd", obj.pcTratmnto_enfermd == "" ? "" : obj.pcTratmnto_enfermd, DbType.String);
                pAddParameter(cmdSQL, "@cInstituto", obj.pcInstituto == "" ? "" : obj.pcInstituto, DbType.String);
                pAddParameter(cmdSQL, "@cTiempoPreexistencia", obj.pcTiempoPreexistencia == "" ? "" : obj.pcTiempoPreexistencia, DbType.String);
                pAddParameter(cmdSQL, "@nAnioInicio", obj.pnAnioInicio == 0 ? 0 : obj.pnAnioInicio, DbType.Int32);
                pAddParameter(cmdSQL, "@cEstado", obj.pcEstado == "" || obj.pcEstado ==null ? "0" : obj.pcEstado, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                while (drSQL.Read())
                {
                    sRes1.cAttr2 = (drSQL["msjTransaction"].Equals(System.DBNull.Value) ? "-No msj-" : drSQL["msjTransaction"].ToString());
                }
            }
            catch (Exception ex)
            {
                sRes1.cError = ex.ToString();
                sRes1.cAttr4 = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return sRes1;
        }



        public GenericEntityDAResponse fnDALista(BEPersonaXTratamientoEnfermedad obj)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "[USP_GCH_MNT_PersonaXTratamientoEnfermedad_TEST]";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@cOpcion", obj.strOpcion == "" ? "" : obj.strOpcion, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }
    }
}
