﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;


using Seguridad.Entity.DataAccess;
using SGTH.Entity.GeneralLayer;
using System.Data;
using System.Data.SqlClient;
using SGTH.Entity.DataAccess;
using SGTH.Entity.BusinessEntity.SGTH;
namespace SGTH.Entity.DataAccess.SGTH
{
    public class DASubLineaServicio: DBOBaseDA
    {

        SqlCommand cmdSQL = new SqlCommand();
        SqlConnection conn = new SqlConnection();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();
        Int32 RDAAA = Convert.ToInt32(ConfigurationManager.AppSettings["RDAAA"].ToString());


        public GenericEntityDAResponse fListarSubLineaServicioDL(BESubLineaServicio objELSubLineaServicio)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                if (objELSubLineaServicio == null)
                {
                    objELSubLineaServicio = new BESubLineaServicio();
                    objELSubLineaServicio.pcSubLineaServicioNombre = "";
                }
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                cmdSQL.CommandText = "USP_RDA_SEL_SubLineaServicio";
                pAddParameter(cmdSQL, "@nSubLineaServicioCodigo", objELSubLineaServicio.pnSubLineaServicioCodigo, DbType.Int32);
                pAddParameter(cmdSQL, "@nLineaServicioCodigo", objELSubLineaServicio.pnLineaServicioCodigo, DbType.Int32);
                pAddParameter(cmdSQL, "@cSubLineaServicioNombre", objELSubLineaServicio.pcSubLineaServicioNombre, DbType.String);
                pAddParameter(cmdSQL, "@cSubLineaServicioAbreviatura", objELSubLineaServicio.pcSubLineaServicioAbreviatura, DbType.String);
                SqlDataReader sqlDr = fLeer(cmdSQL);
                _out.dTable1.Load(sqlDr);
                _out.cAttr1 = "OK";
            }
            catch (Exception ex)
            {
                _out.cAttr1 = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

    }
}
