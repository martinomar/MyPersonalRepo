﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SGTH.Entity.GeneralLayer;
using Seguridad.Entity.DataAccess;
using Seguridad.Entity.BusinessEntity.Seguridad;
using SGTH.Entity.BusinessEntity.SGTH;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SGTH.Entity.DataAccess.SGTH
{

    public class DAConsolidadoAsistenciaPlanilla : DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();
        String strConREN = ConfigurationManager.AppSettings["RENConexion"].ToString();
        String strDBSeguridad = ConfigurationManager.AppSettings["SEGBDNAME"].ToString();
        Int32 RDAAA = Convert.ToInt32(ConfigurationManager.AppSettings["RDAAA"]);
        public GenericEntityDAResponse fnDAListAsistenciaPlanilla(BEConsolidadoAsistenciaPlanillaRequest objRequest)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_ConsolidadoAsistenciaPlanilla";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nPeriodo", objRequest.nPeriodo , DbType.Int32);
                pAddParameter(cmdSQL, "@nGerencia", objRequest.nGerencia, DbType.Int32);
                pAddParameter(cmdSQL, "@nEstado", objRequest.nEstado, DbType.Int32);
                pAddParameter(cmdSQL, "@cNombre", objRequest.cNombre , DbType.String);

                DataSet drSQL = fDSEjecutar(cmdSQL);
                List<BEConsolidadoAsistenciaPlanilla> objListado = new List<BEConsolidadoAsistenciaPlanilla>();

                if (drSQL != null) {
                    if (drSQL.Tables[0].Rows.Count > 0) {
                        foreach (DataRow item in drSQL.Tables[0].Rows)
                        {
                            BEConsolidadoAsistenciaPlanilla objItem = new BEConsolidadoAsistenciaPlanilla();
                            objItem.nConsAsistPlaId = Convert.ToInt32(item["nConsAsistPlaId"] == DBNull.Value ? "0" : item["nConsAsistPlaId"]);
                            objItem.nPeriodo = Convert.ToInt32(item["nPeriodo"] == DBNull.Value ? "0" : item["nPeriodo"]);
                            objItem.nAreaId = Convert.ToInt32(item["nAreaId"] == DBNull.Value ? "0" : item["nAreaId"]);
                            objItem.cAreaNombre = Convert.ToString(item["cAreaNombre"] == DBNull.Value ? "" : item["cAreaNombre"]);
                            objItem.vCodPrs = Convert.ToInt32(item["vCodPrs"] == DBNull.Value ? "0" : item["vCodPrs"]);
                            objItem.cNombres = Convert.ToString(item["cNombres"] == DBNull.Value ? "": item["cNombres"]);
                            objItem.nTpoColab = Convert.ToInt32(item["nTpoColab"] == DBNull.Value ? "0" : item["nTpoColab"]);
                            objItem.nTpoModalidad = Convert.ToInt32((item["nTpoModalidad"] == DBNull.Value ? "0" : item["nTpoModalidad"]));
                            objItem.cTpoColab = Convert.ToString(item["cTpoColab"] == DBNull.Value ? "" : item["cTpoColab"]);
                            objItem.dtFechaInicio = Convert.ToDateTime(item["dtFechaInicio"] == DBNull.Value ? objItem.dtFechaInicio : item["dtFechaInicio"]);
                            objItem.dtFechaFin = Convert.ToDateTime(item["dtFechaFin"] == DBNull.Value ? objItem.dtFechaFin : item["dtFechaFin"]);
                            objItem.nDias = Convert.ToInt32(item["nDias"] == DBNull.Value ? "0" : item["nDias"]);
                            objItem.cHorasTarde = Convert.ToString(item["cHorasTarde"] == DBNull.Value ? "" : item["cHorasTarde"]);
                            objItem.cHorasPorRecuperar = Convert.ToString(item["cHorasPorRecuperar"] == DBNull.Value ? "" : item["cHorasPorRecuperar"]);
                            objItem.nTipoAus = Convert.ToInt32(item["nTipoAus"] == DBNull.Value ? "0" : item["nTipoAus"]);
                            objItem.cTipoAus = Convert.ToString(item["cTipoAus"] == DBNull.Value ? "" : item["cTipoAus"]);
                            objItem.nAplica = Convert.ToInt32(item["nAplica"] == DBNull.Value ? "0" : item["nAplica"]);
                            objItem.cHorasAplica = Convert.ToString(item["cHorasAplica"] == DBNull.Value ? "" : item["cHorasAplica"]);
                            objItem.nEstadoReg = Convert.ToInt32(item["nEstadoReg"] == DBNull.Value ? "0" : item["nEstadoReg"]);
                            objItem.cObservacion = Convert.ToString(item["cObservacion"] == DBNull.Value ? "" : item["cObservacion"]);
                            objItem.cEstadoReg = Convert.ToString(item["cEstadoReg"] == DBNull.Value ? "" : item["cEstadoReg"]);
                            List<BEConsolidadoAsistenciaPlanillaObservacion> objListaObs = new List<BEConsolidadoAsistenciaPlanillaObservacion>();
                            var vDataObs = (from DataRow fila in drSQL.Tables[1].Rows
                                            where Convert.ToInt32(fila["nConsAsistPlaId"]) == Convert.ToInt32(item["nConsAsistPlaId"])
                                            orderby Convert.ToDateTime(fila["dtFechaReg"]) descending
                                            select new {
                                                nid = Convert.ToInt32(fila["nid"]),
                                                cObservacion = Convert.ToString(fila["cObservacion"]),
                                                cAbreUsuario = Convert.ToString(fila["cAbreUsuario"]),
                                                dtFechaReg = Convert.ToDateTime(fila["dtFechaReg"]),
                                                cNombreUsuario = Convert.ToString(fila["cNombreUsuario"])
                                            });
                            foreach (var xitem in vDataObs) {
                                BEConsolidadoAsistenciaPlanillaObservacion itemObs = new BEConsolidadoAsistenciaPlanillaObservacion();
                                itemObs.nId = xitem.nid;
                                itemObs.cObservacion = xitem.cObservacion;
                                itemObs.cAbreUsuario = xitem.cAbreUsuario;
                                itemObs.dtFechaReg = xitem.dtFechaReg;
                                itemObs.cNombreUsuario = xitem.cNombreUsuario;
                                objListaObs.Add(itemObs);
                            }
                            objItem.LisObs = objListaObs;
                            objListado.Add(objItem);
                        }
                    }
                    
                    _out.nAttr1 = Convert.ToInt32(drSQL.Tables[2].Rows[0]["nCantidad"] == DBNull.Value ? "-1" : drSQL.Tables[2].Rows[0]["nCantidad"]);
                } 
                _out.gList1 = objListado.ToList<Object>();
                
            }
            catch (Exception ex)
            {
                _out.nAttr1 = -1;
                _out.cError = ex.ToString();
                _out.oTraceError = new System.Diagnostics.StackTrace(ex);
            }
            finally
            {

                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;

        }

        public GenericEntityDAResponse fnDAFiltroAsistenciaPlanilla(BEConsolidadoAsistenciaPlanillaRequest objRequest)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            List<BECombo> objListado = new List<BECombo>();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_FiltrosConsolidadoAsistenciaPlanilla";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nOpcion", objRequest.nOpcion, DbType.Int32);

                SqlDataReader drSQL = fLeer(cmdSQL);

                if (drSQL.HasRows)
                {
                    _out.dTable1.Load(drSQL);
                    //objListado = (List<BECombo>)ConvertirDataReaderALista<BECombo>(drSQL);
                }

                //_out.gList1 = objListado.ToList<Object>();
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                _out.oTraceError = new System.Diagnostics.StackTrace(ex);
            }
            finally
            {

                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;

        }

        public GenericEntityDAResponse fnDAGenerarAsistenciaPlanilla(BEConsolidadoAsistenciaPlanillaRequest objRequest)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            int strResultado = 0;
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_GEN_ConsolidadoAsitenciaPlanilla";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nPeriodoId", objRequest.nPeriodo == 0 ? 0 : objRequest.nPeriodo, DbType.Int32);
                pAddParameter(cmdSQL, "@nAreaId", objRequest.nGerencia == 0 ? 0 : objRequest.nGerencia, DbType.Int32);
                pAddParameter(cmdSQL, "@nPersonaId", objRequest.nPersonaId == 0 ? 0 : objRequest.nPersonaId, DbType.Int32);

                DataTable dt = fSeleccionar(cmdSQL);

                strResultado = Convert.ToInt32(dt.Rows[0]["nCantidad"] == DBNull.Value ? 0 : dt.Rows[0]["nCantidad"]);
            }
            catch (Exception ex)
            {
                strResultado = -1;
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            _out.nAttr1 = strResultado;
            return _out;
        }

        public string fnMntObservacionDL(BEConsolidadoAsistenciaPlanillaRequest objRequest)
        {            
            string _output = "";
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_ObservacionConsolidadoAsistenciaPlanilla";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@cObservacion", objRequest.texto, DbType.String);
                pAddParameter(cmdSQL, "@nUsuReg", objRequest.nUsuId, DbType.Int32);
                pAddParameter(cmdSQL, "@nConsAsistPlaId", objRequest.nId, DbType.Int32);
                
                SqlDataReader drSQL = fLeer(cmdSQL);

                if (drSQL.Read())
                {
                    _output = Convert.ToString(drSQL["CODIGO"]) + "|" + Convert.ToString(drSQL["MSG"] + "|" + Convert.ToString(drSQL["ID"]));
                }

            }
            catch (Exception ex)
            {
                _output = ex.ToString();
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _output;
        }

    }
}
