﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using Seguridad.Entity.DataAccess;
using SGTH.Entity.GeneralLayer;

using SGTH.Entity.DataAccess;
using SGTH.Entity.BusinessEntity.SGTH;

namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAPostulante: DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();
        String strConREN = ConfigurationManager.AppSettings["RENConexion"].ToString();
        String strDBSeguridad = ConfigurationManager.AppSettings["SEGBDNAME"].ToString();
        Int32 RDAAA = Convert.ToInt32(ConfigurationManager.AppSettings["RDAAA"]);

        //Registrar Ficha Postulante - Modalidad Virtual
        public GenericEntityDAResponse fnDARegistroVirtualPostulante(BEPostulante objPostulante)
        {
            GenericEntityDAResponse sRes1 = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_Postulante";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@vNombres", objPostulante.pvNombres == "" ? "" : objPostulante.pvNombres, DbType.String);
                pAddParameter(cmdSQL, "@vApePaterno", objPostulante.pvApePaterno == "" ? "" : objPostulante.pvApePaterno, DbType.String);
                pAddParameter(cmdSQL, "@vApeMaterno", objPostulante.pvApeMaterno == "" ? "" : objPostulante.pvApeMaterno, DbType.String);
                pAddParameter(cmdSQL, "@cSexo", objPostulante.pcSexo == "" ? "" : objPostulante.pcSexo, DbType.String);
                pAddParameter(cmdSQL, "@nNacionalidad", objPostulante.pnNacionalidad == 0 ? 0 : objPostulante.pnNacionalidad, DbType.Int32);
                pAddParameter(cmdSQL, "@dtFchNacimiento", objPostulante.pdtFchNacimiento == "" ? "" : objPostulante.pdtFchNacimiento, DbType.String);

                pAddParameter(cmdSQL, "@vDocNro", objPostulante.pvDocNro == "" ? "" : objPostulante.pvDocNro, DbType.String);
                pAddParameter(cmdSQL, "@dtFchVenDoc", objPostulante.pdtFchVenDoc == "" ? "" : objPostulante.pdtFchVenDoc, DbType.String);
                pAddParameter(cmdSQL, "@nDstNacId", objPostulante.pnDstNacId == 0 ? 0 : objPostulante.pnDstNacId, DbType.Int32);
                pAddParameter(cmdSQL, "@nEstCivil", objPostulante.pnEstCivil == 0 ? 0 : objPostulante.pnEstCivil, DbType.Int32);
                pAddParameter(cmdSQL, "@nHijos", objPostulante.pnHijos == 0 ? 0 : objPostulante.pnHijos, DbType.Int32);
                pAddParameter(cmdSQL, "@vReligion", objPostulante.pvReligion == "" ? "" : objPostulante.pvReligion, DbType.String);
                pAddParameter(cmdSQL, "@vDmcDireccion", objPostulante.pvDmcDireccion == "" ? "" : objPostulante.pvDmcDireccion, DbType.String);

                pAddParameter(cmdSQL, "@nDstDmcId", objPostulante.pnDstDmcId == 0 ? 0 : objPostulante.pnDstDmcId, DbType.Int32);
                pAddParameter(cmdSQL, "@vDmcReferencia", objPostulante.pvDmcReferencia == "" ? "" : objPostulante.pvDmcReferencia, DbType.String);
                pAddParameter(cmdSQL, "@vTelefono", objPostulante.pvTelefono == "" ? "" : objPostulante.pvTelefono, DbType.String);
                pAddParameter(cmdSQL, "@vTelefonoCelular", objPostulante.pvTelefonoCelular == "" ? "" : objPostulante.pvTelefonoCelular, DbType.String);
                pAddParameter(cmdSQL, "@vCorreo", objPostulante.pvCorreo == "" ? "" : objPostulante.pvCorreo, DbType.String);
                pAddParameter(cmdSQL, "@nCanalId", objPostulante.pnCanalId == 0 ? 0 : objPostulante.pnCanalId, DbType.Int32);

                pAddParameter(cmdSQL, "@nCrgPrsId", objPostulante.pnCrgPresentarseId == 0 ? 0 : objPostulante.pnCrgPresentarseId, DbType.Int32);
                pAddParameter(cmdSQL, "@vReferencia", objPostulante.pvReferencia == "" ? "" : objPostulante.pvReferencia, DbType.String);
                pAddParameter(cmdSQL, "@vNombreApellido", objPostulante.pvApellidosNombres == "" ? "" : objPostulante.pvApellidosNombres, DbType.String);
                pAddParameter(cmdSQL, "@nCtrEstId", objPostulante.pnCtrEstId == 0 ? 0 : objPostulante.pnCtrEstId, DbType.Int32);
                pAddParameter(cmdSQL, "@nEstId", objPostulante.pnCarreraProfId == 0 ? 0 : objPostulante.pnCarreraProfId, DbType.Int32);
                pAddParameter(cmdSQL, "@nTpoGrado", objPostulante.pnGrdInstruccionId == 0 ? 0 : objPostulante.pnGrdInstruccionId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPersonaId", objPostulante.pnPersonaId == 0 ? 0 : objPostulante.pnPersonaId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPntClnId", objPostulante.pnPntClnId == 0 ? 0 : objPostulante.pnPntClnId, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objPostulante.strOpcion == "" ? "" : objPostulante.strOpcion, DbType.String);
                pAddParameter(cmdSQL, "@cdbSeguridad", strDBSeguridad, SqlDbType.NVarChar);//usado para el listado, cOpcion=2
                pAddParameter(cmdSQL, "@nSisId", RDAAA, SqlDbType.Int);//usado para el listado, cOpcion=2

                /*2018.10.03 martin.delgado - cambios*/
                pAddParameter(cmdSQL, "@cEnfermedad", objPostulante.pcEnfermedad == "" ? "0" : objPostulante.pcEnfermedad, DbType.String);
                pAddParameter(cmdSQL, "@cEmbarazo", objPostulante.pcEmbarazo == "" ? "0" : objPostulante.pcEmbarazo, DbType.String);
                pAddParameter(cmdSQL, "@nTmpEmbarazo",  objPostulante.pnTmpEmbarazo , DbType.Int32);
                pAddParameter(cmdSQL, "@cAntPenales", objPostulante.pcAntPenales == "" ? "0" : objPostulante.pcAntPenales, DbType.String);
                pAddParameter(cmdSQL, "@cAntPoliciales", objPostulante.pcAntPoliciales == "" ? "0" : objPostulante.pcAntPoliciales, DbType.String);
                pAddParameter(cmdSQL, "@cDeudor", objPostulante.pcDeudor == "" ? "0" : objPostulante.pcDeudor, DbType.String);

                pAddParameter(cmdSQL, "@cModalidaRegistro", objPostulante.pcModalidaRegistro == "" ? "" : objPostulante.pcModalidaRegistro, DbType.String);

                pAddParameter(cmdSQL, "@cContactFamTelef", objPostulante.pvContactFamTelef == "" ? "" : objPostulante.pvContactFamTelef, DbType.String);
                pAddParameter(cmdSQL, "@cContactFamNombr", objPostulante.pvContactFamNombr == "" ? "" : objPostulante.pvContactFamNombr, DbType.String);

               
                SqlDataReader drSQL = fLeer(cmdSQL);
                if (drSQL.Read())
                {
                    sRes1.nAttr1 = drSQL["nPrsId"].Equals(System.DBNull.Value) ? -1 : Convert.ToInt32(drSQL["nPrsId"]);
                    //sRes1.cAttr2 = (drSQL["msjTransaction"].Equals(System.DBNull.Value) ? "-No msj-" : drSQL["msjTransaction"].ToString());
                }
              
            }
            catch (Exception ex)
            {
                sRes1.cError = ex.ToString();
                sRes1.cAttr4 = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return sRes1;
        }




        public GenericEntityDAResponse fnBLListarPostulante(BEPostulante objPostulante)
        {
            GenericEntityDAResponse sRes1 = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_Postulante";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@vNombres", objPostulante.pvNombres == "" ? "" : objPostulante.pvNombres, DbType.String);
                pAddParameter(cmdSQL, "@vApePaterno", objPostulante.pvApePaterno == "" ? "" : objPostulante.pvApePaterno, DbType.String);
                pAddParameter(cmdSQL, "@vApeMaterno", objPostulante.pvApeMaterno == "" ? "" : objPostulante.pvApeMaterno, DbType.String);
                pAddParameter(cmdSQL, "@cSexo", objPostulante.pcSexo == "" ? "" : objPostulante.pcSexo, DbType.String);
                pAddParameter(cmdSQL, "@nNacionalidad", objPostulante.pnNacionalidad == 0 ? 0 : objPostulante.pnNacionalidad, DbType.Int32);
                pAddParameter(cmdSQL, "@dtFchNacimiento", objPostulante.pdtFchNacimiento == "" ? "" : objPostulante.pdtFchNacimiento, DbType.String);

                pAddParameter(cmdSQL, "@vDocNro", objPostulante.pvDocNro == "" ? "" : objPostulante.pvDocNro, DbType.String);
                pAddParameter(cmdSQL, "@dtFchVenDoc", objPostulante.pdtFchVenDoc == "" ? "" : objPostulante.pdtFchVenDoc, DbType.String);
                pAddParameter(cmdSQL, "@nDstNacId", objPostulante.pnDstNacId == 0 ? 0 : objPostulante.pnDstNacId, DbType.Int32);
                pAddParameter(cmdSQL, "@nEstCivil", objPostulante.pnEstCivil == 0 ? 0 : objPostulante.pnEstCivil, DbType.Int32);
                pAddParameter(cmdSQL, "@nHijos", objPostulante.pnHijos == 0 ? 0 : objPostulante.pnHijos, DbType.Int32);
                pAddParameter(cmdSQL, "@vReligion", objPostulante.pvReligion == "" ? "" : objPostulante.pvReligion, DbType.String);
                pAddParameter(cmdSQL, "@vDmcDireccion", objPostulante.pvDmcDireccion == "" ? "" : objPostulante.pvDmcDireccion, DbType.String);

                pAddParameter(cmdSQL, "@nDstDmcId", objPostulante.pnDstDmcId == 0 ? 0 : objPostulante.pnDstDmcId, DbType.Int32);
                pAddParameter(cmdSQL, "@vDmcReferencia", objPostulante.pvDmcReferencia == "" ? "" : objPostulante.pvDmcReferencia, DbType.String);
                pAddParameter(cmdSQL, "@vTelefono", objPostulante.pvTelefono == "" ? "" : objPostulante.pvTelefono, DbType.String);
                pAddParameter(cmdSQL, "@vTelefonoCelular", objPostulante.pvTelefonoCelular == "" ? "" : objPostulante.pvTelefonoCelular, DbType.String);
                pAddParameter(cmdSQL, "@vCorreo", objPostulante.pvCorreo == "" ? "" : objPostulante.pvCorreo, DbType.String);
                pAddParameter(cmdSQL, "@nCanalId", objPostulante.pnCanalId == 0 ? 0 : objPostulante.pnCanalId, DbType.Int32);
                pAddParameter(cmdSQL, "@nCrgPrsId", objPostulante.pnCrgPresentarseId == 0 ? 0 : objPostulante.pnCrgPresentarseId, DbType.Int32);



                // REFERENCIA LABORALES
                pAddParameter(cmdSQL, "@vReferencia", objPostulante.pvReferencia == "" || objPostulante.pvReferencia == null ? "" : objPostulante.pvReferencia, DbType.String);
                pAddParameter(cmdSQL, "@vNombreApellido", objPostulante.pvApellidosNombres == "" || objPostulante.pvApellidosNombres == null ? "" : objPostulante.pvApellidosNombres, DbType.String);

                // ESTUDIOS SUPERIORES
                pAddParameter(cmdSQL, "@nCtrEstId", objPostulante.pnCtrEstId == 0 ? 0 : objPostulante.pnCtrEstId, DbType.Int32);
                pAddParameter(cmdSQL, "@nEstId", objPostulante.pnCarreraProfId == 0 ? 0 : objPostulante.pnCarreraProfId, DbType.Int32);
                pAddParameter(cmdSQL, "@nTpoGrado", objPostulante.pnGrdInstruccionId == 0 ? 0 : objPostulante.pnGrdInstruccionId, DbType.Int32);

                pAddParameter(cmdSQL, "@nPersonaId", objPostulante.pnPersonaId == 0 ? 0 : objPostulante.pnPersonaId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPntClnId", objPostulante.pnPntClnId == 0 ? 0 : objPostulante.pnPntClnId, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objPostulante.strOpcion == "" || objPostulante.strOpcion == null ? "" : objPostulante.strOpcion, DbType.String);
                pAddParameter(cmdSQL, "@cdbSeguridad", strDBSeguridad, SqlDbType.NVarChar);//usado para el listado, cOpcion=2
                pAddParameter(cmdSQL, "@nSisId", RDAAA, SqlDbType.Int);//usado para el listado, cOpcion=2

                /*2018.10.03 martin.delgado - cambios*/
                pAddParameter(cmdSQL, "@cEnfermedad", objPostulante.pcEnfermedad == "" || objPostulante.pcEnfermedad == null ? "0" : objPostulante.pcEnfermedad, DbType.String);
                pAddParameter(cmdSQL, "@cEmbarazo", objPostulante.pcEmbarazo == "" || objPostulante.pcEmbarazo == null ? "0" : objPostulante.pcEmbarazo, DbType.String);
                pAddParameter(cmdSQL, "@nTmpEmbarazo", objPostulante.pnTmpEmbarazo, DbType.Int32);
                pAddParameter(cmdSQL, "@cAntPenales", objPostulante.pcAntPenales == "" || objPostulante.pcAntPenales == null ? "0" : objPostulante.pcAntPenales, DbType.String);
                pAddParameter(cmdSQL, "@cAntPoliciales", objPostulante.pcAntPoliciales == "" || objPostulante.pcAntPoliciales == null ? "0" : objPostulante.pcAntPoliciales, DbType.String);
                pAddParameter(cmdSQL, "@cDeudor", objPostulante.pcDeudor == "" || objPostulante.pcDeudor == null ? "0" : objPostulante.pcDeudor, DbType.String);

                pAddParameter(cmdSQL, "@cModalidaRegistro", objPostulante.pcModalidaRegistro == "" ? "" : objPostulante.pcModalidaRegistro, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);
                while (drSQL.Read())
                {
                    sRes1.nAttr1 = drSQL["nPrsId"].Equals(System.DBNull.Value) ? -1 : Convert.ToInt32(drSQL["nPrsId"]);
                    //sRes1.cAttr2 = (drSQL["msjTransaction"].Equals(System.DBNull.Value) ? "-No msj-" : drSQL["msjTransaction"].ToString());
                }
            }
            catch (Exception ex)
            {
                sRes1.cError = ex.ToString();
                sRes1.cAttr4 = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return sRes1;
        }

        //Listado de Postulantes
        public GenericEntityDAResponse fListaPostulantesDL(BEPostulante objPostulante)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_Postulante";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@vNombres", objPostulante.pvNombres == "" || objPostulante.pvNombres == null ? "" : objPostulante.pvNombres, DbType.String);
                pAddParameter(cmdSQL, "@vApePaterno", objPostulante.pvApePaterno == "" || objPostulante.pvApePaterno == null ? "" : objPostulante.pvApePaterno, DbType.String);
                pAddParameter(cmdSQL, "@vApeMaterno", objPostulante.pvApeMaterno == "" || objPostulante.pvApeMaterno == null ? "" : objPostulante.pvApeMaterno, DbType.String);
                pAddParameter(cmdSQL, "@cSexo", objPostulante.pcSexo == "" || objPostulante.pcSexo == null ? "" : objPostulante.pcSexo, DbType.String);
                pAddParameter(cmdSQL, "@nNacionalidad", objPostulante.pnNacionalidad == 0 ? 0 : objPostulante.pnNacionalidad, DbType.Int32);
                pAddParameter(cmdSQL, "@dtFchNacimiento", objPostulante.pdtFchNacimiento == "" || objPostulante.pdtFchNacimiento == null ? "" : objPostulante.pdtFchNacimiento, DbType.String);
                pAddParameter(cmdSQL, "@nDstNacId", objPostulante.pnDstNacId == 0 ? 0 : objPostulante.pnDstNacId, DbType.Int32);
                pAddParameter(cmdSQL, "@nEstCivil", objPostulante.pnEstCivil == 0 ? 0 : objPostulante.pnEstCivil, DbType.Int32);
                pAddParameter(cmdSQL, "@nHijos", objPostulante.pnHijos == 0 ? 0 : objPostulante.pnHijos, DbType.Int32);
                pAddParameter(cmdSQL, "@vDocNro", objPostulante.pvDocNro == "" || objPostulante.pvDocNro == null ? "" : objPostulante.pvDocNro, DbType.String);
                pAddParameter(cmdSQL, "@vReligion", objPostulante.pvReligion == "" || objPostulante.pvReligion == null ? "" : objPostulante.pvReligion, DbType.String);
                pAddParameter(cmdSQL, "@vDmcDireccion", objPostulante.pvDmcDireccion == "" || objPostulante.pvDmcDireccion == null ? "" : objPostulante.pvDmcDireccion, DbType.String);
                pAddParameter(cmdSQL, "@nDstDmcId", objPostulante.pnDstDmcId == 0 ? 0 : objPostulante.pnDstDmcId, DbType.Int32);
                pAddParameter(cmdSQL, "@vDmcReferencia", objPostulante.pvDmcReferencia == "" || objPostulante.pvDmcReferencia == null ? "" : objPostulante.pvDmcReferencia, DbType.String);
                pAddParameter(cmdSQL, "@vTelefono", objPostulante.pvTelefono == "" || objPostulante.pvTelefono == null ? "" : objPostulante.pvTelefono, DbType.String);
                pAddParameter(cmdSQL, "@vTelefonoCelular", objPostulante.pvTelefonoCelular == "" || objPostulante.pvTelefonoCelular == null ? "" : objPostulante.pvTelefonoCelular, DbType.String);
                pAddParameter(cmdSQL, "@vCorreo", objPostulante.pvCorreo == "" || objPostulante.pvCorreo == null ? "" : objPostulante.pvCorreo, DbType.String);
                pAddParameter(cmdSQL, "@nCanalId", objPostulante.pnCanalId == 0 ? 0 : objPostulante.pnCanalId, DbType.Int32);
                pAddParameter(cmdSQL, "@nCrgPrsId", objPostulante.pnCrgPresentarseId == 0 ? 0 : objPostulante.pnCrgPresentarseId, DbType.Int32);
                pAddParameter(cmdSQL, "@vReferencia", objPostulante.pvReferencia == "" || objPostulante.pvReferencia == null ? "" : objPostulante.pvReferencia, DbType.String);
                pAddParameter(cmdSQL, "@vNombreApellido", objPostulante.pvApellidosNombres == "" || objPostulante.pvApellidosNombres == null ? "" : objPostulante.pvApellidosNombres, DbType.String);
                pAddParameter(cmdSQL, "@nTpoAceptacion", objPostulante.pnTpoAceptacion == 0 ? 0 : objPostulante.pnTpoAceptacion, DbType.Int32);
                pAddParameter(cmdSQL, "@nCtrEstId", objPostulante.pnCtrEstId == 0 ? 0 : objPostulante.pnCtrEstId, DbType.Int32);
                pAddParameter(cmdSQL, "@nEstId", objPostulante.pnCarreraProfId == 0 ? 0 : objPostulante.pnCarreraProfId, DbType.Int32);
                pAddParameter(cmdSQL, "@nTpoGrado", objPostulante.pnGrdInstruccionId == 0 ? 0 : objPostulante.pnGrdInstruccionId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPersonaId", objPostulante.pnPersonaId == 0 ? 0 : objPostulante.pnPersonaId, DbType.Int32);
                pAddParameter(cmdSQL, "@nFichaId", objPostulante.pnFicId == 0 ? 0 : objPostulante.pnFicId, DbType.Int32);
                pAddParameter(cmdSQL, "@nAnexo", objPostulante.pnAnexo == 0 ? 0 : objPostulante.pnAnexo, DbType.Int32);
                pAddParameter(cmdSQL, "@nPntClnId", objPostulante.pnPntClnId == 0 ? 0 : objPostulante.pnPntClnId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPageNumber", objPostulante.PageNumber == 0 ? 0 : objPostulante.PageNumber, DbType.Int32);
                pAddParameter(cmdSQL, "@nPageZize", objPostulante.PageSize == 0 ? 0 : objPostulante.PageSize, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objPostulante.strOpcion == "" || objPostulante.strOpcion == null ? "" : objPostulante.strOpcion, DbType.String);

                pAddParameter(cmdSQL, "@cModalidaRegistro", objPostulante.pcModalidaRegistro == "" || objPostulante.pcModalidaRegistro == null? "0" : objPostulante.pcModalidaRegistro, DbType.String);
                pAddParameter(cmdSQL, "@cdbSeguridad", strDBSeguridad, SqlDbType.NVarChar);
                pAddParameter(cmdSQL, "@nSisId", RDAAA, SqlDbType.Int);


                SqlDataReader drSQL = fLeer(cmdSQL);

                if (drSQL.HasRows)
                {
                    _out.dTable1.Load(drSQL);

                    //objLista = (List<ElPostulante>)ConvertirDataReaderALista<ElPostulante>(drSQL);
                }
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }








        public GenericEntityDAResponse fnDAListaCargoPresentarse(BECargoPresentarse objCargoPresentarse)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_CargoPresentarse";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
                //objListCargoPresentarse = (List<BECargoPresentarse>)ConvertirDataReaderALista<BECargoPresentarse>(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

        //Canal reclutamiento
        public GenericEntityDAResponse fnDAListaCanal(BECanal objCanal)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_mnt_Canal";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nCanalId", 0, DbType.Int32);
                pAddParameter(cmdSQL, "@vDescripcion", "", DbType.String);
                pAddParameter(cmdSQL, "@cEstado", "", DbType.String);
                pAddParameter(cmdSQL, "@cOpcion", "4", DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

        //Departamento
        public GenericEntityDAResponse fnDAListaDepartamento(BEDepartamento objDepartamento)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_LUGAR";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nNacionalidadId", objDepartamento.pnIdNacionalidad == 0 ? 0 : objDepartamento.pnIdNacionalidad, DbType.Int32);
                pAddParameter(cmdSQL, "@nDptId", objDepartamento.pnDptId == 0 ? 0 : objDepartamento.pnDptId, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objDepartamento.strOpcion == "" ? "" : objDepartamento.strOpcion, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }
            return _out;
        }

        //Provincia
        public GenericEntityDAResponse fnDAListaProvincia(BEProvincia objProvincia)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_LUGAR";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nPrvId", objProvincia.pnPrvId == 0 ? 0 : objProvincia.pnDptId, DbType.Int32);
                pAddParameter(cmdSQL, "@nDptId", objProvincia.pnDptId == 0 ? 0 : objProvincia.pnDptId, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objProvincia.strOpcion == "" ? "" : objProvincia.strOpcion, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {

                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }
            return _out;
        }

        //Distrito
        public GenericEntityDAResponse fnDAListaDistrito(BEDistrito objDistrito)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_LUGAR";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nPrvId", objDistrito.pnPrvId == 0 ? 0 : objDistrito.pnPrvId, DbType.Int32);
                pAddParameter(cmdSQL, "@nDstId", objDistrito.pnDstId == 0 ? 0 : objDistrito.pnDstId, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objDistrito.strOpcion == "" ? "" : objDistrito.strOpcion, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
                //objListDistrito = (List<BEDistrito>)ConvertirDataReaderALista<BEDistrito>(drSQL);
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message, ex);
            }
            finally
            {

                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }
            return _out;
        }

        //Estudio
        public GenericEntityDAResponse fnDAListaEstudio(BEEstudio objEstudio)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_ListaEstudios";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nEstId", objEstudio.pnEstId == 0 ? 0 : objEstudio.pnEstId, DbType.Int32);
                pAddParameter(cmdSQL, "@nTipo", objEstudio.pnTipo == 0 ? 0 : objEstudio.pnTipo, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objEstudio.pcOpcion == "" ? "" : objEstudio.pcOpcion, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
                //objListEstudio = (List<BEEstudio>)ConvertirDataReaderALista<BEEstudio>(drSQL);

            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message, ex);
            }
            finally
            {

                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }
            return _out;
        }

        //Centro de Estudio
        public GenericEntityDAResponse fnDAListaCentroEstudio(BECentroEstudio objCentroEstudio)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_ListaCentroEstudios";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nCtrEstId", objCentroEstudio.pnCtrEstId == 0 ? 0 : objCentroEstudio.pnCtrEstId, DbType.Int32);
                pAddParameter(cmdSQL, "@nTpoCentro", objCentroEstudio.pnTpoCentro == 0 ? 0 : objCentroEstudio.pnTpoCentro, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objCentroEstudio.pcOpcion == "" ? "" : objCentroEstudio.pcOpcion, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1 = new DataTable();
                _out.dTable1.Load(drSQL);
                //objListCentroEstudio = (List<BECentroEstudio>)ConvertirDataReaderALista<BECentroEstudio>(drSQL);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }
            return _out;
        }

        //Tecnología
        public GenericEntityDAResponse FnDAListaTecnologia(BETecnologia objTecnologia)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_ListaTecnologias";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nTcnId", objTecnologia.pnTcnId == 0 ? 0 : objTecnologia.pnTcnId, DbType.Int32);
                pAddParameter(cmdSQL, "@nTpoTecnologia", objTecnologia.pnTpoTecnologia == 0 ? 0 : objTecnologia.pnTpoTecnologia, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objTecnologia.pcOpcion == "" ? "" : objTecnologia.pcOpcion, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1 = new DataTable();
                _out.dTable1.Load(drSQL);
                //objListTecnologia = (List<BETecnologia>)ConvertirDataReaderALista<BETecnologia>(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

        //Lista de estudios
        public GenericEntityDAResponse fILEstudios_carreras(BEEstudio objEstudio)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_ListaEstudios";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nEstId", objEstudio.pnEstId == 0 ? 0 : objEstudio.pnEstId, DbType.Int32);
                pAddParameter(cmdSQL, "@nTipo", objEstudio.pnTipo == 0 ? 0 : objEstudio.pnTipo, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objEstudio.pcOpcion == "" ? "" : objEstudio.pcOpcion, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1 = new DataTable();
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }




        //Lista TODOS los postulantes (vista DataTable-sin paginado)
        public GenericEntityDAResponse fnListPostulantes_todos()
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_Postulante";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
               
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1 = new DataTable();
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }


        //TpoAceptacionXMotivo
        public GenericEntityDAResponse FListaMotivoDL(BETipoAceptacionXMotivo objMotivo)
        {

            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_MotivoAceptacion";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nTpoAceptacion", objMotivo.pnTpoAceptacion == 0 ? 0 : objMotivo.pnTpoAceptacion, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objMotivo.strOpcion == "" ? "" : objMotivo.strOpcion, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
                //objListMotivo = (List<ELTipoAceptacionXMotivo>)ConvertirDataReaderALista<ELTipoAceptacionXMotivo>(drSQL);

            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {

                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }
            return _out;
        }


        public GenericEntityDAResponse fRegistraMotivoDL(BETipoAceptacionXMotivo objMotivo)
        {

            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_MotivoAceptacion";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nMtvId", objMotivo.pnMtvId == 0 ? 0 : objMotivo.pnMtvId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPrsId", objMotivo.pnPersonaId == 0 ? 0 : objMotivo.pnPersonaId, DbType.Int32);
                pAddParameter(cmdSQL, "@nFicId", objMotivo.pnFicId == 0 ? 0 : objMotivo.pnFicId, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objMotivo.strOpcion == "" ? "0" : objMotivo.strOpcion, DbType.String);

                _out.cAttr1 = fEjecutar(cmdSQL);
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }


        //Modifica Ficha Postulante
        public GenericEntityDAResponse fPaseColaborador(BEPostulante objPostulante)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {

                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_Postulante";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                //pAddParameter(cmdSQL, "@vNombres", objPostulante.pvNombres == "" ? "" : objPostulante.pvNombres, DbType.String);
                //pAddParameter(cmdSQL, "@vApePaterno", objPostulante.pvApePaterno == "" ? "" : objPostulante.pvApePaterno, DbType.String);
                //pAddParameter(cmdSQL, "@vApeMaterno", objPostulante.pvApeMaterno == "" ? "" : objPostulante.pvApeMaterno, DbType.String);
                //pAddParameter(cmdSQL, "@cSexo", objPostulante.pcSexo == "" ? "" : objPostulante.pcSexo, DbType.String);
                //pAddParameter(cmdSQL, "@nNacionalidad", objPostulante.pnNacionalidad == 0 ? 0 : objPostulante.pnNacionalidad, DbType.Int32);
                //pAddParameter(cmdSQL, "@dtFchNacimiento", objPostulante.pdtFchNacimiento == "" ? "" : objPostulante.pdtFchNacimiento, DbType.String);

                /*BEGIN (2018.08.06) MODQ */
                //pAddParameter(cmdSQL, "@dtFchVenDoc", objPostulante.pdtFchVenDoc == "" ? "" : objPostulante.pdtFchVenDoc, DbType.String);
                /*END (2018.08.06) MODQ */

                //pAddParameter(cmdSQL, "@nDstNacId", objPostulante.pnDstNacId == 0 ? 0 : objPostulante.pnDstNacId, DbType.Int32);
                //pAddParameter(cmdSQL, "@nEstCivil", objPostulante.pnEstCivil == 0 ? 0 : objPostulante.pnEstCivil, DbType.Int32);
                //pAddParameter(cmdSQL, "@nHijos", objPostulante.pnHijos == 0 ? 0 : objPostulante.pnHijos, DbType.Int32);
                //pAddParameter(cmdSQL, "@vDocNro", objPostulante.pvDocNro == "" ? "" : objPostulante.pvDocNro, DbType.String);
                //pAddParameter(cmdSQL, "@vReligion", objPostulante.pvReligion == "" ? "" : objPostulante.pvReligion, DbType.String);
                //pAddParameter(cmdSQL, "@vDmcDireccion", objPostulante.pvDmcDireccion == "" ? "" : objPostulante.pvDmcDireccion, DbType.String);
                //pAddParameter(cmdSQL, "@nDstDmcId", objPostulante.pnDstDmcId == 0 ? 0 : objPostulante.pnDstDmcId, DbType.Int32);
                //pAddParameter(cmdSQL, "@vDmcReferencia", objPostulante.pvDmcReferencia == "" ? "" : objPostulante.pvDmcReferencia, DbType.String);
                //pAddParameter(cmdSQL, "@vTelefono", objPostulante.pvTelefono == "" ? "" : objPostulante.pvTelefono, DbType.String);
                //pAddParameter(cmdSQL, "@vTelefonoCelular", objPostulante.pvTelefonoCelular == "" ? "" : objPostulante.pvTelefonoCelular, DbType.String);
                //pAddParameter(cmdSQL, "@vCorreo", objPostulante.pvCorreo == "" ? "" : objPostulante.pvCorreo, DbType.String);
                //pAddParameter(cmdSQL, "@nCanalId", objPostulante.pnCanalId == 0 ? 0 : objPostulante.pnCanalId, DbType.Int32);
                //pAddParameter(cmdSQL, "@nCrgPrsId", objPostulante.pnCrgPresentarseId == 0 ? 0 : objPostulante.pnCrgPresentarseId, DbType.Int32);
                //pAddParameter(cmdSQL, "@vReferencia", objPostulante.pvReferencia == "" ? "" : objPostulante.pvReferencia, DbType.String);
                //pAddParameter(cmdSQL, "@vNombreApellido", objPostulante.pvApellidosNombres == "" ? "" : objPostulante.pvApellidosNombres, DbType.String);
                //pAddParameter(cmdSQL, "@nTpoAceptacion", objPostulante.pnTpoAceptacion == 0 ? 0 : objPostulante.pnTpoAceptacion, DbType.Int32);
                //pAddParameter(cmdSQL, "@nCtrEstId", objPostulante.pnCtrEstId == 0 ? 0 : objPostulante.pnCtrEstId, DbType.Int32);
                //pAddParameter(cmdSQL, "@nEstId", objPostulante.pnCarreraProfId == 0 ? 0 : objPostulante.pnCarreraProfId, DbType.Int32);
                //pAddParameter(cmdSQL, "@nTpoGrado", objPostulante.pnGrdInstruccionId == 0 ? 0 : objPostulante.pnGrdInstruccionId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPersonaId", objPostulante.pnPersonaId == 0 ? 0 : objPostulante.pnPersonaId, DbType.Int32);
                //pAddParameter(cmdSQL, "@nFichaId", objPostulante.pnFicId == 0 ? 0 : objPostulante.pnFicId, DbType.Int32);
                pAddParameter(cmdSQL, "@nAnexo", objPostulante.pnAnexo == 0 ? 0 : objPostulante.pnAnexo, DbType.Int32);
                pAddParameter(cmdSQL, "@dtFchIngreso", objPostulante.pdtFchIngreso == "" ? "" : objPostulante.pdtFchIngreso, DbType.String);
                pAddParameter(cmdSQL, "@nPntClnId", objPostulante.pnPntClnId == 0 ? 0 : objPostulante.pnPntClnId, DbType.Int32);
                //pAddParameter(cmdSQL, "@nPageNumber", objPostulante.PageNumber == 0 ? 0 : objPostulante.PageNumber, DbType.Int32);
                //pAddParameter(cmdSQL, "@nPageZize", objPostulante.PageSize == 0 ? 0 : objPostulante.PageSize, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objPostulante.strOpcion == "" ? "" : objPostulante.strOpcion, DbType.String); /*parámetro Nullable, pero IMPORTANTE<<<*/
                pAddParameter(cmdSQL, "@cdbSeguridad", strDBSeguridad, SqlDbType.NVarChar); /*NO USABLE, pero el parámetro no esta definido para permitir valores nulos..*/
                ////INI JGA 10-03-2017 - SESNEW
                pAddParameter(cmdSQL, "@nTpoColab", objPostulante.pnTpoColab == 0 ? 0 : objPostulante.pnTpoColab, DbType.Int32);
                pAddParameter(cmdSQL, "@nModForm", objPostulante.pnModForm == 0 ? 0 : objPostulante.pnModForm, DbType.Int32);
                ////FIN JGA 10-03-2017 - SESNEW
                //pAddParameter(cmdSQL, "@nSisId", RDAAA, SqlDbType.Int);
                pAddParameter(cmdSQL, "@nUsuarioRegistraId", objPostulante.pnUsuarioRegistraId, DbType.Int32);

                _out.cAttr1 = fEjecutar(cmdSQL);

            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

        //Obtener Postulante
        public GenericEntityDAResponse fObtienePostulanteDL(BEPostulante objPostulante)
        {

            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_Postulante";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@vNombres", objPostulante.pvNombres == "" ? "" : objPostulante.pvNombres, DbType.String);
                pAddParameter(cmdSQL, "@vApePaterno", objPostulante.pvApePaterno == "" ? "" : objPostulante.pvApePaterno, DbType.String);
                pAddParameter(cmdSQL, "@vApeMaterno", objPostulante.pvApeMaterno == "" ? "" : objPostulante.pvApeMaterno, DbType.String);
                pAddParameter(cmdSQL, "@cSexo", objPostulante.pcSexo == "" ? "" : objPostulante.pcSexo, DbType.String);
                pAddParameter(cmdSQL, "@nNacionalidad", objPostulante.pnNacionalidad == 0 ? 0 : objPostulante.pnNacionalidad, DbType.Int32);
                pAddParameter(cmdSQL, "@dtFchNacimiento", objPostulante.pdtFchNacimiento == "" ? "" : objPostulante.pdtFchNacimiento, DbType.String);
                pAddParameter(cmdSQL, "@nDstNacId", objPostulante.pnDstNacId == 0 ? 0 : objPostulante.pnDstNacId, DbType.Int32);
                pAddParameter(cmdSQL, "@nEstCivil", objPostulante.pnEstCivil == 0 ? 0 : objPostulante.pnEstCivil, DbType.Int32);
                pAddParameter(cmdSQL, "@nHijos", objPostulante.pnHijos == 0 ? 0 : objPostulante.pnHijos, DbType.Int32);
                pAddParameter(cmdSQL, "@vDocNro", objPostulante.pvDocNro == "" ? "" : objPostulante.pvDocNro, DbType.String);
                pAddParameter(cmdSQL, "@vReligion", objPostulante.pvReligion == "" ? "" : objPostulante.pvReligion, DbType.String);
                pAddParameter(cmdSQL, "@vDmcDireccion", objPostulante.pvDmcDireccion == "" ? "" : objPostulante.pvDmcDireccion, DbType.String);
                pAddParameter(cmdSQL, "@nDstDmcId", objPostulante.pnDstDmcId == 0 ? 0 : objPostulante.pnDstDmcId, DbType.Int32);
                pAddParameter(cmdSQL, "@vDmcReferencia", objPostulante.pvDmcReferencia == "" ? "" : objPostulante.pvDmcReferencia, DbType.String);
                pAddParameter(cmdSQL, "@vTelefono", objPostulante.pvTelefono == "" ? "" : objPostulante.pvTelefono, DbType.String);
                pAddParameter(cmdSQL, "@vTelefonoCelular", objPostulante.pvTelefonoCelular == "" ? "" : objPostulante.pvTelefonoCelular, DbType.String);
                pAddParameter(cmdSQL, "@vCorreo", objPostulante.pvCorreo == "" ? "" : objPostulante.pvCorreo, DbType.String);
                pAddParameter(cmdSQL, "@nCanalId", objPostulante.pnCanalId == 0 ? 0 : objPostulante.pnCanalId, DbType.Int32);
                pAddParameter(cmdSQL, "@nCrgPrsId", objPostulante.pnCrgPresentarseId == 0 ? 0 : objPostulante.pnCrgPresentarseId, DbType.Int32);
                pAddParameter(cmdSQL, "@vReferencia", objPostulante.pvReferencia == "" ? "" : objPostulante.pvReferencia, DbType.String);
                pAddParameter(cmdSQL, "@vNombreApellido", objPostulante.pvApellidosNombres == "" ? "" : objPostulante.pvApellidosNombres, DbType.String);
                pAddParameter(cmdSQL, "@nTpoAceptacion", objPostulante.pnTpoAceptacion == 0 ? 0 : objPostulante.pnTpoAceptacion, DbType.Int32);
                pAddParameter(cmdSQL, "@nCtrEstId", objPostulante.pnCtrEstId == 0 ? 0 : objPostulante.pnCtrEstId, DbType.Int32);
                pAddParameter(cmdSQL, "@nEstId", objPostulante.pnCarreraProfId == 0 ? 0 : objPostulante.pnCarreraProfId, DbType.Int32);
                pAddParameter(cmdSQL, "@nTpoGrado", objPostulante.pnGrdInstruccionId == 0 ? 0 : objPostulante.pnGrdInstruccionId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPersonaId", objPostulante.pnPersonaId == 0 ? 0 : objPostulante.pnPersonaId, DbType.Int32);
                pAddParameter(cmdSQL, "@nFichaId", objPostulante.pnFicId == 0 ? 0 : objPostulante.pnFicId, DbType.Int32);
                pAddParameter(cmdSQL, "@nAnexo", objPostulante.pnAnexo == 0 ? 0 : objPostulante.pnAnexo, DbType.Int32);
                pAddParameter(cmdSQL, "@nPntClnId", objPostulante.pnPntClnId == 0 ? 0 : objPostulante.pnPntClnId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPageNumber", objPostulante.PageNumber == 0 ? 0 : objPostulante.PageNumber, DbType.Int32);
                pAddParameter(cmdSQL, "@nPageZize", objPostulante.PageSize == 0 ? 0 : objPostulante.PageSize, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objPostulante.strOpcion == "" ? "" : objPostulante.strOpcion, DbType.String);
                pAddParameter(cmdSQL, "@cdbSeguridad", strDBSeguridad, SqlDbType.NVarChar);
                pAddParameter(cmdSQL, "@nSisId", RDAAA, SqlDbType.Int);
                //INI DDD 15-02-2017 SESNEW
                pAddParameter(cmdSQL, "@dtFchVenDoc", objPostulante.pdtFchVenDoc == "" ? "" : objPostulante.pdtFchVenDoc, DbType.String);
                //FIN DDD 15-02-2017 SESNEW
                SqlDataReader drSQL = fLeer(cmdSQL);
                if (drSQL.HasRows)
                {
                    //_out.nAttr1 = drSQL["nPrsId"].Equals(System.DBNull.Value) ? -1 : Convert.ToInt32(drSQL["nPrsId"]);
                    _out.dTable1.Load(drSQL);
                    _out.obj1 =  _out.dTable1.Rows[0];
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

    }
}
