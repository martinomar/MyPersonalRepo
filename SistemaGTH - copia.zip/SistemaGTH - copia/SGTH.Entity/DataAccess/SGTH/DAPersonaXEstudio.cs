﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using Seguridad.Entity.DataAccess;
using SGTH.Entity.GeneralLayer;

using SGTH.Entity.DataAccess;
using SGTH.Entity.BusinessEntity.SGTH;

namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAPersonaXEstudio: DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();
        String strConREN = ConfigurationManager.AppSettings["RENConexion"].ToString();
        String strDBSeguridad = ConfigurationManager.AppSettings["SEGBDNAME"].ToString();
        Int32 RDAAA = Convert.ToInt32(ConfigurationManager.AppSettings["RDAAA"]);

        public GenericEntityDAResponse fnDARegistro(BEPersonaXEstudio obj)
        {
            GenericEntityDAResponse sRes1 = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "[USP_GCH_MNT_EstudiosSuperiores_TEST]";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nTipoId", obj.pnTipoId== 0 ? 0 : obj.pnTipoId, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", obj.strOpcion == "" ? "" : obj.strOpcion, DbType.String);
                pAddParameter(cmdSQL, "@nPrsId", obj.pnPrsId == 0 ? 0 : obj.pnPrsId, DbType.Int32);
                pAddParameter(cmdSQL, "@nCtrEstId", obj.pnCtrEstId == 0 ? 0 : obj.pnCtrEstId, DbType.String);
                pAddParameter(cmdSQL, "@nEstId", obj.pnEstId == 0 ? 0 : obj.pnEstId, DbType.Int32);
                pAddParameter(cmdSQL, "@vPrdInicio", obj.pvPrdInicio== "" ? "" : obj.pvPrdInicio, DbType.String);
                pAddParameter(cmdSQL, "@vPrdFin", obj.pvPrdFin == "" ? "" : obj.pvPrdFin, DbType.String);
                pAddParameter(cmdSQL, "@nTpoGrado", obj.pnTpoGradoId == 0 ? 0 : obj.pnTpoGradoId, DbType.Int32);
                pAddParameter(cmdSQL, "@vMvmId", obj.pvMvmId == 0 ? 0 : obj.pvMvmId, DbType.String);/*??*/
                pAddParameter(cmdSQL, "@cDocAdjunto", obj.pcDocAdjunto == "" || obj.pcDocAdjunto == null ? "" : obj.pcDocAdjunto, DbType.String);/*??*/
                pAddParameter(cmdSQL, "@cEstado", obj.pcEstado == "" || obj.pcEstado == null ? "" : obj.pcEstado, DbType.String);/*??*/

                SqlDataReader drSQL = fLeer(cmdSQL);
                while (drSQL.Read())
                {
                    sRes1.cAttr2 = (drSQL["msjTransaction"].Equals(System.DBNull.Value) ? "-No msj-" : drSQL["msjTransaction"].ToString());
                }
            }
            catch (Exception ex)
            {
                sRes1.cError = ex.ToString();
                sRes1.cAttr4 = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return sRes1;
        }



        public GenericEntityDAResponse fnDALista(BEPersonaXEstudio obj)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_EstudiosSuperiores_TEST";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@cOpcion", obj.strOpcion == "" ? "" : obj.strOpcion, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
                //objListCargoPresentarse = (List<BECargoPresentarse>)ConvertirDataReaderALista<BECargoPresentarse>(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

    }
}
