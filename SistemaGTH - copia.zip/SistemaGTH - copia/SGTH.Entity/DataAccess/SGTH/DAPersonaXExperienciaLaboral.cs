﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SGTH.Entity.GeneralLayer;
using Seguridad.Entity.DataAccess;
using Seguridad.Entity.BusinessEntity.Seguridad;
using SGTH.Entity.BusinessEntity.SGTH;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAPersonaXExperienciaLaboral: DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();
        String strConREN = ConfigurationManager.AppSettings["RENConexion"].ToString();
        String strDBSeguridad = ConfigurationManager.AppSettings["SEGBDNAME"].ToString();
        Int32 RDAAA = Convert.ToInt32(ConfigurationManager.AppSettings["RDAAA"]);

        public GenericEntityDAResponse fnDARegistro(BEPersonaXExperienciaLaboral obj)
        {
            GenericEntityDAResponse sRes1 = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "[USP_GCH_MNT_ExperienciaLaboral_TEST]";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@cOpcion", obj.strOpcion == "" ? "" : obj.strOpcion, DbType.String);
                pAddParameter(cmdSQL, "@nPrsId", obj.pnPrsId == 0 ? 0 : obj.pnPrsId, DbType.Int32);
                pAddParameter(cmdSQL, "@vEmpresa", obj.pvEmpresa == "" ? "" : obj.pvEmpresa, DbType.String);
                pAddParameter(cmdSQL, "@vPuesto", obj.pvPuesto == "" ? "" : obj.pvPuesto, DbType.String);

                pAddParameter(cmdSQL, "@dtFchInicio", obj.pcFchInicio_parsed == "" ? "" : obj.pcFchInicio_parsed, DbType.String); //NO NULL
                pAddParameter(cmdSQL, "@dtFchFin", obj.pcFchFin_parsed == "" ? "" : obj.pcFchFin_parsed, DbType.String); //NO NULL

                pAddParameter(cmdSQL, "@nSueldo", obj.pnSueldo == 0 ? 0 : obj.pnSueldo, DbType.Double);
                pAddParameter(cmdSQL, "@nTipoContratoId", obj.pnTipoContratoID == 0 ? 0 : obj.pnTipoContratoID, DbType.Int32);

                pAddParameter(cmdSQL, "@cPlanilla", obj.pcEnPlanilla == "" ? "" : obj.pcEnPlanilla, DbType.String);
                pAddParameter(cmdSQL, "@vMtvCese", obj.pvMtvCese == "" ? "" : obj.pvMtvCese, DbType.String);
                pAddParameter(cmdSQL, "@nRfrNumero", obj.pnRfrNumero == "" || obj.pnRfrNumero == null? "" : obj.pnRfrNumero, DbType.String);
                pAddParameter(cmdSQL, "@vRfrNombre", obj.pvRfrNombre == "" || obj.pvRfrNombre == null ? "" : obj.pvRfrNombre, DbType.String);
                pAddParameter(cmdSQL, "@vMvmId", obj.pvMvmId == "" || obj.pvMvmId == null ? "" : obj.pvMvmId, DbType.String);
                pAddParameter(cmdSQL, "@cFchInicio", obj.pcFchInicio == "" ? "" : obj.pcFchInicio, DbType.String);
                pAddParameter(cmdSQL, "@cFchFin", obj.pcFchFin == "" ? "" : obj.pcFchFin, DbType.String);
                pAddParameter(cmdSQL, "@cHerramientaUsada", obj.pcHerramientaUsada == "" ? "" : obj.pcHerramientaUsada, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                while (drSQL.Read())
                {
                    sRes1.cAttr2 = (drSQL["msjTransaction"].Equals(System.DBNull.Value) ? "-No msj-" : drSQL["msjTransaction"].ToString());
                }
            }
            catch (Exception ex)
            {
                sRes1.cError = ex.ToString();
                sRes1.cAttr4 = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return sRes1;
        }



        public GenericEntityDAResponse fnDALista(BEPersonaXExperienciaLaboral obj)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "[USP_GCH_MNT_ExperienciaLaboral_TEST]";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@cOpcion", obj.strOpcion == "" ? "" : obj.strOpcion, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

    }
}
