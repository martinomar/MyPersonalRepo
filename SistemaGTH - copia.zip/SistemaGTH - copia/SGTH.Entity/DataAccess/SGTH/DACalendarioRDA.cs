﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Seguridad.Entity.DataAccess;
using SGTH.Entity.GeneralLayer;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using SGTH.Entity.DataAccess;
using SGTH.Entity.BusinessEntity.SGTH;
namespace SGTH.Entity.DataAccess.SGTH 
{
    public class DACalendarioRDA: DBOBaseDA
    {

        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();
        String strDBSeguridad = ConfigurationManager.AppSettings["SEGBDNAME"].ToString();
        Int32 RDAAA = Convert.ToInt32(ConfigurationManager.AppSettings["RDAAA"]);

        public GenericEntityDAResponse FILListaClnPntMrc(BECalendarioXPuntoRDA objCalendario)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_CalendariosXPtosMarcacion";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nPntMrcId", objCalendario.pnPntMrcId == 0 ? 0 : objCalendario.pnPntMrcId, DbType.Int32);
                pAddParameter(cmdSQL, "@nClnId", objCalendario.pnClnId == 0 ? 0 : objCalendario.pnClnId, DbType.Int32);

                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
                _out.cAttr1 = "OK";

            }
            catch (Exception e)
            {
                _out.cError = e.ToString();
                throw new Exception(e.Message, e);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }
    }
}
