﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using Seguridad.Entity.DataAccess;
using SGTH.Entity.GeneralLayer;

using SGTH.Entity.DataAccess;
using SGTH.Entity.BusinessEntity.SGTH;


namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAFichaPostulante : DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();

        //public GenericEntityDAResponse DL_fnRegistrarFicha(BEPostulante obj)
        //{
        //    GenericEntityDAResponse _out = new GenericEntityDAResponse();
        //    try
        //    {
        //        cmdSQL.Connection = NewConnection(strCon);
        //        cmdSQL.CommandText = "USP_RDA_FP_MNT_POSTULANTE";
        //        cmdSQL.CommandType = CommandType.StoredProcedure;
        //        cmdSQL.Parameters.Clear();
        //        pAddParameter(cmdSQL, "@nidarea", obj.cNombre, DbType.Int32);
        //        SqlDataReader drSQL = fLeer(cmdSQL);
        //        if (drSQL.Read())
        //        {
        //            _out.cAttr1 = Convert.ToString(drSQL["CODIGO"]) + "|" + Convert.ToString(drSQL["MSG"]);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        _out.cError = ex.ToString();
        //    }
        //    finally
        //    {
        //        if (cmdSQL.Connection.State == ConnectionState.Open)
        //        {
        //            cmdSQL.Connection.Close();
        //        }
        //    }
        //    return _out;
        //}
        public GenericEntityDAResponse DL_fnConsultaDNI(string DNI)
        {
            GenericEntityDAResponse _outDA = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                //cmdSQL.CommandText = "USP_RDA_SEL_FichaPostulante";//devolver al api el tipodeRegistro, si = 2.2, redirecciona al sitio oficila de la empresa...
                cmdSQL.CommandText = "USP_GCH_SEL_FichaPostulante";//devolver al api el tipodeRegistro, si = 2.2, redirecciona al sitio oficila de la empresa...
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@vDocNro", DNI, DbType.String);

                DataSet dss = new DataSet();
                dss = fDSEjecutar(cmdSQL);
                DataRow dtRw = dss.Tables[0].Rows[0];

                _outDA.cMsg1 = dtRw["state"].ToString();
                _outDA.nAttr1= int.Parse(dtRw["N_msg"].ToString());
                _outDA.cMsg2 = dtRw["msg"].ToString();

                if (_outDA.cMsg1 == "OK" && _outDA.nAttr1 == 1)
                {
                    _outDA.cAttr1 = DNI;
                    _outDA.cAttr2 = dtRw["vApePaterno"].ToString();
                    _outDA.cAttr3 = dtRw["vApeMaterno"].ToString();
                    _outDA.cAttr4 = dtRw["vNombres"].ToString();
                    _outDA.cAttr5 = dtRw["cModalidaRegistro"].ToString();
                    _outDA.dTable2 = dss.Tables[1];
                }
               
            }
            catch (Exception ex)
            {
                _outDA.cMsg1 = "NO";
                _outDA.nAttr1 = -1;
                _outDA.cMsg2 = ex.ToString();
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _outDA;
        }


    }
}
