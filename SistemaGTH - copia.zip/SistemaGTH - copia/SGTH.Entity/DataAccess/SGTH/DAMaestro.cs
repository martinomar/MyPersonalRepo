﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SGTH.Entity.GeneralLayer;
using Seguridad.Entity.DataAccess;
using Seguridad.Entity.BusinessEntity.Seguridad;
using SGTH.Entity.BusinessEntity.SGTH;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAMaestro : DBOBaseDA
    {

        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["SGDDesarrollo"].ToString();


        public GenericEntityDAResponse fnDAListMaestro(SegMaestroBE objSegMaestro)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ListaSegMaestro_Filter_multi";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nSisId", objSegMaestro.nSisId == 0 ? 0 : objSegMaestro.nSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@cMaeIds", objSegMaestro.cMaeId, DbType.String);


                SqlDataReader drSQL = fLeer(cmdSQL);
                //_out.gList1 = drSQL.Cast<object>().ToList();
                _out.dTable1 = new DataTable();
                _out.dTable1.Load(drSQL);

            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                _out.oTraceError = new System.Diagnostics.StackTrace(ex);
            }
            finally
            {

                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;

        }

    }
}
