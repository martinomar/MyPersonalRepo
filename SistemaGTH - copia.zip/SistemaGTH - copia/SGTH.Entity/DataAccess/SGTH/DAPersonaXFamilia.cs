﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.GeneralLayer;
using Seguridad.Entity.DataAccess;
using Seguridad.Entity.BusinessEntity.Seguridad;
using SGTH.Entity.BusinessEntity.SGTH;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAPersonaXFamilia: DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();
        String strConREN = ConfigurationManager.AppSettings["RENConexion"].ToString();
        String strDBSeguridad = ConfigurationManager.AppSettings["SEGBDNAME"].ToString();
        Int32 RDAAA = Convert.ToInt32(ConfigurationManager.AppSettings["RDAAA"]);

        public GenericEntityDAResponse fnDARegistro(BEPersonaXFamilia obj)
        {
            GenericEntityDAResponse sRes1 = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_FamiliaAux";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nAuxId", obj.pnAuxId == "" ? "" : obj.pnAuxId, DbType.String);
                pAddParameter(cmdSQL, "@nPrsId", obj.pnPrsId == 0 ? 0 : obj.pnPrsId, DbType.Int32);
                pAddParameter(cmdSQL, "@vNombres", obj.pvNombres == "" ? "" : obj.pvNombres, DbType.String);
                pAddParameter(cmdSQL, "@vApePaterno", obj.pvApePaterno == "" ? "" : obj.pvApePaterno, DbType.String);
                pAddParameter(cmdSQL, "@vApeMaterno", obj.pvApeMaterno == "" ? "" : obj.pvApeMaterno, DbType.String);
                pAddParameter(cmdSQL, "@nParentesco", obj.pnParentesco == 0 ? 0 : obj.pnParentesco, DbType.Int32);
                pAddParameter(cmdSQL, "@cVive", obj.pcVive == "" ? "" : obj.pcVive, DbType.String);
                pAddParameter(cmdSQL, "@nGenero", obj.pnGenero == 0 ? 0 : obj.pnGenero, DbType.Int32);
                pAddParameter(cmdSQL, "@dtFchNac", obj.pdtFchNac == new DateTime(0001, 1, 1) ? new DateTime(1900, 1, 1) : obj.pdtFchNac, DbType.Date);
                pAddParameter(cmdSQL, "@vDocNro", obj.pvDocNro == "" ? "" : obj.pvDocNro, DbType.String);
                pAddParameter(cmdSQL, "@nOcupacion", obj.pnOcupacion == 0 ? 0 : obj.pnOcupacion, DbType.String);
                pAddParameter(cmdSQL, "@cDerHab", obj.pcDerHab == "" ? "" : obj.pcDerHab, DbType.String);
                pAddParameter(cmdSQL, "@cOpcion", obj.pcOpcion == "" ? "" : obj.pcOpcion, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);
                while (drSQL.Read())
                {
                    sRes1.cAttr2 = (drSQL["msjTransaction"].Equals(System.DBNull.Value) ? "-No msj-" : drSQL["msjTransaction"].ToString());
                }
            }
            catch (Exception ex)
            {
                sRes1.cError = ex.ToString();
                sRes1.cAttr4 = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return sRes1;
        }



        public GenericEntityDAResponse fnDALista(BEPersonaXFamilia obj)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "[USP_RDA_MNT_FamiliaAux]";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@cOpcion", obj.pcOpcion == "" ? "" : obj.pcOpcion, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }
    }
}
