﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using Seguridad.Entity.DataAccess;
using SGTH.Entity.GeneralLayer;

using SGTH.Entity.DataAccess;
using SGTH.Entity.BusinessEntity.SGTH;

namespace SGTH.Entity.DataAccess.SGTH
{
    
        public class DAConocimientoNegocio : DBOBaseDA
        {
            SqlCommand cmdSQL = new SqlCommand();
            String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();
            Int32 RDAAA = Convert.ToInt32(ConfigurationManager.AppSettings["RDAAA"]);

            //public GenericEntityDAResponse fMntConocimientoNegocioDL(BEConocimientoNegocio obj)
            //{
            //GenericEntityDAResponse res = new GenericEntityDAResponse();
            //    try
            //    {
            //        cmdSQL.Connection = NewConnection(strCon);
            //        cmdSQL.CommandText = "USP_RDA_MNT_ConocimientoNegocio";
            //        cmdSQL.CommandType = CommandType.StoredProcedure;
            //        cmdSQL.Parameters.Clear();
            //        pAddParameter(cmdSQL, "@nConNegocioId", obj.pnConNegocioId == 0 ? 0 : obj.pnConNegocioId, DbType.Int32);
            //        pAddParameter(cmdSQL, "@vDesConNegocio", obj.pvDesConNegocio == "" ? "" : obj.pvDesConNegocio, DbType.String);
            //        pAddParameter(cmdSQL, "@nTpoConNegocioId", obj.pnTpoConNegocioId == 0 ? 0 : obj.pnTpoConNegocioId, DbType.Int32);
            //        pAddParameter(cmdSQL, "@cOpcion", obj.pcOpcion == "" ? "" : obj.pcOpcion, DbType.String);
            //        res = fEjecutar(cmdSQL);
            //    }
            //    catch (Exception e)
            //    {
            //        throw new Exception(e.Message, e);
            //    }
            //    finally
            //    {
            //        if (cmdSQL.Connection.State == ConnectionState.Open)
            //        {
            //            cmdSQL.Connection.Close();
            //        }
            //    }
            //    return res;
            //}

            public GenericEntityDAResponse fnDAListaConocimientoNegocio(BEConocimientoNegocio obj)
            {
            GenericEntityDAResponse lstConNegocio = new GenericEntityDAResponse();
                try 
                {
                    cmdSQL.Connection = NewConnection(strCon);
                    cmdSQL.CommandText = "USP_RDA_SEL_ConocimientoNegocio";
                    cmdSQL.CommandType = CommandType.StoredProcedure;
                    cmdSQL.Parameters.Clear();
                    pAddParameter(cmdSQL, "@nTpoConNegocioId", obj.pnTpoConNegocioId == 0 ? 0 : obj.pnTpoConNegocioId, DbType.Int32);
                    pAddParameter(cmdSQL, "@nSisId", obj.pnSisId == 0 ? 0 : obj.pnSisId, DbType.Int32);
                    pAddParameter(cmdSQL, "@nPageNumber", obj.PageNumber == 0 ? 0 : obj.PageNumber, DbType.Int32);
                    pAddParameter(cmdSQL, "@nPageSize", obj.PageSize == 0 ? 0 : obj.PageSize, DbType.Int32);
                    pAddParameter(cmdSQL, "@cOpcion", obj.pcOpcion == "" ? "" : obj.pcOpcion, DbType.String);
                    SqlDataReader drSQL = fLeer(cmdSQL);
                    lstConNegocio.dTable1.Load(drSQL);
                }
                catch (Exception e)
                {
                    throw new Exception(e.Message, e);
                }
                finally
                {
                    if (cmdSQL.Connection.State == ConnectionState.Open)
                    {
                        cmdSQL.Connection.Close();
                    }
                }
                return lstConNegocio;
            }

        }
    }

