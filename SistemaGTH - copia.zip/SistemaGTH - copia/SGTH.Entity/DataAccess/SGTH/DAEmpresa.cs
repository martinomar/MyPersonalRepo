﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

using System.Data;
using Seguridad.Entity.DataAccess;
using SGTH.Entity.GeneralLayer;
using System.Data.SqlClient;
using SGTH.Entity.DataAccess;
using SGTH.Entity.BusinessEntity.SGTH;
namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAEmpresa: DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();
        String strDBFacturacion = ConfigurationManager.AppSettings["FACBDNAME"].ToString();

        public GenericEntityDAResponse FListaEmpresaDL(BEEmpresa objEmpresa)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_Empresas";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@cdbFacturacion", strDBFacturacion, SqlDbType.NVarChar);
                //pAddParameter(cmdSQL, "@CODEMP", objEmpresa.pnEmpresa == 0 ? 0 : objEmpresa.pnEmpresa, DbType.Int32);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
                _out.cAttr1 = "OK";
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                //objELSistema = null;
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }

            return _out;
        }

    }
}
