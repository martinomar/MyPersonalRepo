﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Seguridad.Entity.DataAccess;
using SGTH.Entity.GeneralLayer;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using SGTH.Entity.DataAccess;
using SGTH.Entity.BusinessEntity.SGTH;
namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAServicio: DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        SqlConnection conn = new SqlConnection();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();
        Int32 RDAAA = Convert.ToInt32(ConfigurationManager.AppSettings["RDAAA"].ToString());

        public GenericEntityDAResponse fListarServicioDL(BEServicio objELServicio)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                cmdSQL.CommandText = "USP_RDA_SEL_Servicio";
                pAddParameter(cmdSQL, "@nServicioCodigo", objELServicio.pnCodProyecto, DbType.Int32);
                pAddParameter(cmdSQL, "@nSubLineaServicioCodigo", objELServicio.pnCodServicio, DbType.Int32);
                pAddParameter(cmdSQL, "@cNombreServicio", objELServicio.pcNombreProyecto, DbType.String);
                pAddParameter(cmdSQL, "@cAliasServicio", objELServicio.pcAliasProyecto, DbType.String);
                SqlDataReader sqlDr = fLeer(cmdSQL);
                _out.dTable1.Load(sqlDr);
                _out.cAttr1 = "OK";
                
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }
    }
}
