﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using Seguridad.Entity.DataAccess;
using SGTH.Entity.GeneralLayer;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using SGTH.Entity.DataAccess;
using SGTH.Entity.BusinessEntity.SGTH;

namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAProyecto: DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();


        public GenericEntityDAResponse fRegistraDatosProyectoDL(BEProyecto objProyecto)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_INS_ProyectosXCliente";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nPrsId", objProyecto.pnPrsId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPryId", objProyecto.pnProyectoId, DbType.Int32);
                pAddParameter(cmdSQL, "@dtFchInicio", objProyecto.pdtFchInicio, DbType.DateTime);
                pAddParameter(cmdSQL, "@dtFchFin", objProyecto.pdtFchFin, DbType.DateTime);
                pAddParameter(cmdSQL, "@nGrpId", objProyecto.pnGrpId, DbType.Int32);

                _out.cAttr1 = fEjecutar(cmdSQL);
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }
    }
}
