﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Seguridad.Entity.DataAccess;
using SGTH.Entity.GeneralLayer;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using SGTH.Entity.DataAccess;
using SGTH.Entity.BusinessEntity.SGTH;
namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAArea: DBOBaseDA
    {

        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();



        public GenericEntityDAResponse fListarAreaxOrganigramaDL(string cOpcion, int nAreaId)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {

                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                cmdSQL.CommandText = "USP_RDA_SEL_ListarAreaOrganigrama";
                pAddParameter(cmdSQL, "@cOpcion", cOpcion == "" ? "" : cOpcion, DbType.String);
                pAddParameter(cmdSQL, "@nAreaID", nAreaId == 0 ? 0 : nAreaId, DbType.Int32);

                SqlDataReader sqlDr = fLeer(cmdSQL);
                _out.dTable1.Load(sqlDr);
                _out.cAttr1 = "OK";
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw;
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

        public GenericEntityDAResponse fListarAreaxUsuarioDL(Int32 nUsuId)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.CommandText = "USP_RDA_SEL_ComboAreaxUsuario";
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nUsuId", nUsuId, DbType.Int32);
                SqlDataReader sqlDr = fLeer(cmdSQL);
                _out.dTable1.Load(sqlDr);
                _out.cAttr1 = "OK";
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

        public GenericEntityDAResponse fListarAreaDL(BEArea objBEArea)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.CommandText = "USP_RDA_SEL_Area";
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nEmpId", objBEArea.pnEmpresaId == 0 ? 0 : objBEArea.pnEmpresaId, DbType.Int32);
                SqlDataReader sqlDr = fLeer(cmdSQL);
                _out.dTable1.Load(sqlDr);
                _out.cAttr1 = "OK";
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }
    }
}
