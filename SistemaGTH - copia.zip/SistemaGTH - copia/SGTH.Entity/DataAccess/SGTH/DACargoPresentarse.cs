﻿
using SGTH.Entity.GeneralLayer;
using Seguridad.Entity.DataAccess;
using Seguridad.Entity.BusinessEntity.Seguridad;
using SGTH.Entity.BusinessEntity.SGTH;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System;

namespace SGTH.Entity.DataAccess.SGTH
{
    public class DACargoPresentarse : DBOBaseDA
    {

        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();



        //public GenericEntityDAResponse fnList(BECargoPresentarse obj)
        public GenericEntityDAResponse fnList()
        {

            // "obj" No usable...

            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_CargoPresentarse";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1 = new DataTable();
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                _out.oTraceError = new System.Diagnostics.StackTrace(ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;

        }

    }
}
