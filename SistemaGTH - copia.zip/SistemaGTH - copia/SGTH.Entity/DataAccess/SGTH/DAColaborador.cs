﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Seguridad.Entity.DataAccess;
using SGTH.Entity.GeneralLayer;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using SGTH.Entity.DataAccess;
using SGTH.Entity.BusinessEntity.SGTH;
namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAColaborador: DBOBaseDA
    {

        SqlCommand cmdSQL = new SqlCommand();
        //INI AAB 20160706 SES - NEW
        //SqlConnection conn = new SqlConnection();
        //FIN AAB 20160706 SES - NEW
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();

        String strDBSeguridad = ConfigurationManager.AppSettings["SEGBDNAME"].ToString();
        String strDBFacturacion = ConfigurationManager.AppSettings["FACBDNAME"].ToString();

        Int32 RDAAA = Convert.ToInt32(ConfigurationManager.AppSettings["RDAAA"]);

        public GenericEntityDAResponse fListaColaborador(BEColaborador objELColaborador)
        {
            //INI AAB 20160706 SES - NEW
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            //FIN AAB 20160706 SES - NEW
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_COLABORADOR";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nClienteId", objELColaborador.pnCliId == 0 ? 0 : objELColaborador.pnCliId, DbType.Int32);
                pAddParameter(cmdSQL, "@nGrpId", objELColaborador.pnGrpId == 0 ? 0 : objELColaborador.pnGrpId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPrsId", objELColaborador.pnPrsId == 0 ? 0 : objELColaborador.pnPrsId, DbType.Int32);
                pAddParameter(cmdSQL, "@vColaborador", objELColaborador.pPersona == "" ? "" : objELColaborador.pPersona, DbType.String);
                pAddParameter(cmdSQL, "@nPageNumber", objELColaborador.PageNumber == 0 ? 0 : objELColaborador.PageNumber, DbType.Int32);
                pAddParameter(cmdSQL, "@nPageSize", objELColaborador.PageSize == 0 ? 0 : objELColaborador.PageSize, DbType.Int32);
                pAddParameter(cmdSQL, "@nPersonaId", objELColaborador.pPersonaId == 0 ? 0 : objELColaborador.pPersonaId, DbType.Int32);
                pAddParameter(cmdSQL, "@nIdSeguridad", objELColaborador.pnIdSeguridad == 0 ? 0 : objELColaborador.pnIdSeguridad, DbType.Int32);
                pAddParameter(cmdSQL, "@vCodPrs", objELColaborador.pvCodPrs == 0 ? 0 : objELColaborador.pvCodPrs, DbType.Int32);
                pAddParameter(cmdSQL, "@nIdRDA", objELColaborador.pnIdRda == 0 ? 0 : objELColaborador.pnIdRda, DbType.Int32);
                pAddParameter(cmdSQL, "@nAnexo", objELColaborador.pnAnexo == 0 ? 0 : objELColaborador.pnAnexo, DbType.Int32);
                pAddParameter(cmdSQL, "@vCorreoSES", objELColaborador.pvCorColaborador == "" ? "" : objELColaborador.pvCorColaborador, DbType.String);
                pAddParameter(cmdSQL, "@cOpcion", objELColaborador.strOpcion == "" ? "" : objELColaborador.strOpcion, DbType.String);
                pAddParameter(cmdSQL, "@cdbFacturacion", strDBFacturacion, SqlDbType.NVarChar);
                pAddParameter(cmdSQL, "@nSisId", RDAAA, DbType.Int32);
                pAddParameter(cmdSQL, "@nBancoId", objELColaborador.pnBancoId == 0 ? 0 : objELColaborador.pnBancoId, DbType.Int32);
                pAddParameter(cmdSQL, "@cNroCuenta", objELColaborador.pcNroCuenta == "" ? "" : objELColaborador.pcNroCuenta, DbType.String);
                pAddParameter(cmdSQL, "@cNroCtaInter", objELColaborador.pcNroCtaInter == "" ? "" : objELColaborador.pcNroCtaInter, DbType.String);
                pAddParameter(cmdSQL, "@cEstado", objELColaborador.pcEstado == "0" ? "0" : objELColaborador.pcEstado, DbType.String);
                pAddParameter(cmdSQL, "@cVigente", objELColaborador.pVigente == "" ? "0" : objELColaborador.pVigente, DbType.String);
                //INI DDD 14-02-2017 SESNEW
                pAddParameter(cmdSQL, "@nTpoColab", objELColaborador.pnTpoColab == 0 ? 0 : objELColaborador.pnTpoColab, DbType.Int32);
                pAddParameter(cmdSQL, "@nTiemPrac", objELColaborador.pnTiemPrac == 0 ? 0 : objELColaborador.pnTiemPrac, DbType.Int32);
                pAddParameter(cmdSQL, "@nModForm", objELColaborador.pnModForm == 0 ? 0 : objELColaborador.pnModForm, DbType.Int32);
                //FIN DDD 14-02-2017 SESNEW

                SqlDataReader drSQL = fLeer(cmdSQL);
                //objListaColaborador = (List<ELColaborador>)ConvertirDataReaderALista<ELColaborador>(drSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception e)
            {
                _out.cError = e.ToString();
                throw new Exception(e.Message, e);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

        //FIN DDD 17-03-2017 SESNEW
        public GenericEntityDAResponse fListaColaboradoresAutocompleteLista(BEColaborador objELColaborador)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                cmdSQL.CommandText = "USP_RDA_SEL_Colaborador";
                pAddParameter(cmdSQL, "@vNombres", objELColaborador.pPersona == "" ? "" : objELColaborador.pPersona, DbType.String);
                pAddParameter(cmdSQL, "@nPersonaId", objELColaborador.pPersonaId == 0 ? 0 : objELColaborador.pPersonaId, DbType.Int32);
                pAddParameter(cmdSQL, "@nGrpId", objELColaborador.pnGrpId == 0 ? 0 : objELColaborador.pnGrpId, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objELColaborador.strOpcion == "" ? "" : objELColaborador.strOpcion, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                //objLista = (List<ELColaborador>)ConvertirDataReaderALista<ELColaborador>(drSQL);
                _out.dTable1.Load(drSQL);

            }
            catch (Exception e)
            {
                _out.cError = e.ToString();
                throw new Exception(e.Message, e);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }
    }
}
