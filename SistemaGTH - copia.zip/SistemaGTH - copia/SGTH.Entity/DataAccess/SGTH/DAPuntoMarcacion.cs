﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Seguridad.Entity.DataAccess;
using SGTH.Entity.GeneralLayer;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using SGTH.Entity.DataAccess;
using SGTH.Entity.BusinessEntity.SGTH;
namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAPuntoMarcacion: DBOBaseDA
    {

        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();

        public GenericEntityDAResponse FListaPuntosMarcaciones(BEPuntoMarcacion objPuntoMarcacion)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_PuntoMarcacion";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@cOpcion", objPuntoMarcacion.strOpcion == "" ? "6" : objPuntoMarcacion.strOpcion, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
                _out.cAttr1 = "OK";
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }
    }
}
