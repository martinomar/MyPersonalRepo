﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using Seguridad.Entity.DataAccess;
using SGTH.Entity.GeneralLayer;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using SGTH.Entity.DataAccess;
using SGTH.Entity.BusinessEntity.SGTH;

namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAProvision: DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();


      
        public GenericEntityDAResponse fValidarProvision(BEProvision oELProvision)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEL_VAL_PROVISION";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nPrsId", oELProvision.pnPrsId == 0 ? 0 : oELProvision.pnPrsId, DbType.Int32);
                _out.cAttr1  = fObtenerValor(cmdSQL).ToString();
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }

            return _out;
        }

        public GenericEntityDAResponse fInsProvVacPaseCol(BEProvision oELProvision)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_INS_ProvVacPaseColab";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nPrsId", oELProvision.pnPrsId == 0 ? 0 : oELProvision.pnPrsId, DbType.Int32);
                pAddParameter(cmdSQL, "@dtFchIni", oELProvision.pdtFchIni == null ? DateTime.Now : oELProvision.pdtFchIni, DbType.Date);
                pAddParameter(cmdSQL, "@dtFchFin", oELProvision.pdtFechaFin == null ? DateTime.Now.AddDays(-1).AddYears(1) : oELProvision.pdtFechaFin, DbType.Date);
                _out.cAttr1 = fEjecutar(cmdSQL);
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;

        }

    }
}
