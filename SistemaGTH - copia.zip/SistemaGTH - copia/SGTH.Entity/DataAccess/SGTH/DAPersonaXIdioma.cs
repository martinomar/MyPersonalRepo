﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using Seguridad.Entity.DataAccess;
using SGTH.Entity.GeneralLayer;

using SGTH.Entity.DataAccess;
using SGTH.Entity.BusinessEntity.SGTH;

namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAPersonaXIdioma : DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();
        String strConREN = ConfigurationManager.AppSettings["RENConexion"].ToString();
        String strDBSeguridad = ConfigurationManager.AppSettings["SEGBDNAME"].ToString();
        Int32 RDAAA = Convert.ToInt32(ConfigurationManager.AppSettings["RDAAA"]);

        public GenericEntityDAResponse fnDARegistro(BEPersonaXIdioma obj)
        {
            GenericEntityDAResponse sRes1 = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "[USP_GCH_MNT_PersonaXIdioma_TEST]";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@cOpcion", obj.strOpcion == "" ? "" : obj.strOpcion, DbType.String);
                pAddParameter(cmdSQL, "@nPrsId", obj.pnPrsId == 0 ? 0 : obj.pnPrsId, DbType.Int32);
                pAddParameter(cmdSQL, "@nIdioma", obj.pnIdiomaId == 0 ? 0 : obj.pnIdiomaId, DbType.Int32);
                pAddParameter(cmdSQL, "@nNivelEscrito", obj.pnNivelEscritoId == 0 ? 0 : obj.pnNivelEscritoId, DbType.Int32);
                pAddParameter(cmdSQL, "@nNivelOral", obj.pnNivelOralId == 0 ? 0 : obj.pnNivelOralId, DbType.Int32);
                pAddParameter(cmdSQL, "@cEstado", obj.pcEstado == "" ? "0" : obj.pcEstado, DbType.String);

                //pAddParameter(cmdSQL, "@vMvmId", obj == 0 ? 0 : obj.pnEstId, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);
                while (drSQL.Read())
                {
                    sRes1.cAttr2 = (drSQL["msjTransaction"].Equals(System.DBNull.Value) ? "-No msj-" : drSQL["msjTransaction"].ToString());
                }
            }
            catch (Exception ex)
            {
                sRes1.cError = ex.ToString();
                sRes1.cAttr4 = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return sRes1;
        }



        public GenericEntityDAResponse fnDALista(BEPersonaXIdioma obj)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "[USP_GCH_MNT_PersonaXIdioma_TEST]";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@cOpcion", obj.strOpcion == "" ? "" : obj.strOpcion, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }
    }
}
