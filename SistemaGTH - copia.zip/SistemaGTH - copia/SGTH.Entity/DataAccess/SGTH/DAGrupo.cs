﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

using SGTH.Entity.GeneralLayer;
using Seguridad.Entity.DataAccess;
using Seguridad.Entity.BusinessEntity.Seguridad;
using SGTH.Entity.BusinessEntity.SGTH;
using System.Data;
using System.Data.SqlClient;
namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAGrupo: DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();
        String strDBFacturacion = ConfigurationManager.AppSettings["FACBDNAME"].ToString();

        public GenericEntityDAResponse FListaGrupoDL(BEGrupo objGrupo)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                if (objGrupo == null)
                {
                    objGrupo = new BEGrupo();
                    objGrupo.pvDescripcion = "";
                }
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_Grupo";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@vDescripcion", objGrupo.pvDescripcion == "" ? "" : objGrupo.pvDescripcion, DbType.String);
                pAddParameter(cmdSQL, "@nGrpId", objGrupo.pnGrpId == 0 ? 0 : objGrupo.pnGrpId, DbType.Int32);
                pAddParameter(cmdSQL, "@nUsuId", objGrupo.pnUsuId == 0 ? 0 : objGrupo.pnUsuId, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objGrupo.pcOpcion == "" ? "" : objGrupo.pcOpcion, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
                _out.cAttr1 = "OK";
            }
            catch (Exception ex)
            {
                _out.cAttr1 = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }
    }
}
