﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SGTH.Entity.GeneralLayer;
using Seguridad.Entity.DataAccess;
using Seguridad.Entity.BusinessEntity.Seguridad;
using SGTH.Entity.BusinessEntity.SGTH;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAPersonaXConocimientoTecnico: DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"].ToString();
        String strConREN = ConfigurationManager.AppSettings["RENConexion"].ToString();
        String strDBSeguridad = ConfigurationManager.AppSettings["SEGBDNAME"].ToString();
        Int32 RDAAA = Convert.ToInt32(ConfigurationManager.AppSettings["RDAAA"]);

        public GenericEntityDAResponse fnDARegistro(BEPersonaXConocimientoTecnico obj)
        {
            GenericEntityDAResponse sRes1 = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_PersonaXTecnologia";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nPrsId", obj.pnPrsId == 0 ? 0 : obj.pnPrsId, DbType.Int32);
                pAddParameter(cmdSQL, "@nTcnId", obj.pnTcnId == 0 ? 0 : obj.pnTcnId, DbType.Int32);
                pAddParameter(cmdSQL, "@nNivel", obj.pnNivelId == 0 ? 0 : obj.pnNivelId, DbType.Int32);
                pAddParameter(cmdSQL, "@cEstado", obj.pcEstado == "" ? "1" : obj.pcEstado, DbType.String);
                pAddParameter(cmdSQL, "@cOpcion", obj.strOpcion == "" ? "0" : obj.strOpcion, DbType.String);
                pAddParameter(cmdSQL, "@cdbSeguridad", strDBSeguridad, SqlDbType.NVarChar);
                pAddParameter(cmdSQL, "@nSisId", RDAAA, SqlDbType.Int);
                SqlDataReader drSQL = fLeer(cmdSQL);
                while (drSQL.Read())
                {
                    sRes1.cAttr2 = (drSQL["msjTransaction"].Equals(System.DBNull.Value) ? "-No msj-" : drSQL["msjTransaction"].ToString());
                }
            }
            catch (Exception ex)
            {
                sRes1.cError = ex.ToString();
                sRes1.cAttr4 = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return sRes1;
        }


        public GenericEntityDAResponse fnDALista(BEPersonaXConocimientoTecnico obj)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_PersonaXTecnologia";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nPrsId", obj.pnPrsId == 0 ? 0 : obj.pnPrsId, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", obj.strOpcion == "" ? "2" : obj.strOpcion, DbType.String);
                pAddParameter(cmdSQL, "@cdbSeguridad", strDBSeguridad, SqlDbType.NVarChar);
                pAddParameter(cmdSQL, "@nSisId", RDAAA, SqlDbType.Int);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
                //objListCargoPresentarse = (List<BECargoPresentarse>)ConvertirDataReaderALista<BECargoPresentarse>(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }
    }
}
