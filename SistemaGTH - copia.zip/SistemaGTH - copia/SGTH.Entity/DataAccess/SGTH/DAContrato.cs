﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using SGTH.Entity.GeneralLayer;
using Seguridad.Entity.DataAccess;
using Seguridad.Entity.BusinessEntity.Seguridad;
using SGTH.Entity.BusinessEntity.SGTH;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
namespace SGTH.Entity.DataAccess.SGTH
{
    public class DAContrato: DBOBaseDA
    {

        SqlCommand cmdSQL = new SqlCommand();
        //INI AAB 20160711 - SESNEW
        String strCon = ConfigurationManager.AppSettings["RDABDConexion"];
        String strDBSeguridad = ConfigurationManager.AppSettings["SEGBDNAME"];
        String strDBFacturacion = ConfigurationManager.AppSettings["FACBDNAME"];

        public GenericEntityDAResponse fListaCargoContrato(Int32 nAreaId)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            //FIN AAB 20160711 - SESNEW
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_CargoContrato";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nAreaId", nAreaId == 0 ? 0 : nAreaId, DbType.Int32);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
                _out.cAttr1 = "OK";
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }


        public GenericEntityDAResponse fObtenerCorreoDL(BEContrato objContrato)
        {
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_OBT_CorreoColaborador";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nPrsId", objContrato.pnPersonaId == 0 ? 0 : objContrato.pnPersonaId, DbType.Int32);
                pAddParameter(cmdSQL, "@nEmpId", objContrato.pnEmpId == 0 ? 0 : objContrato.pnEmpId, DbType.Int32);
                _out.cAttr1 = fObtenerValor(cmdSQL).ToString();
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }


        public GenericEntityDAResponse fListaCorreoPracticas(int empId)
        {
            GenericEntityDAResponse _out  = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_SEL_ListaCorreoPracticas";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nEmpId", empId == 0 ? 0 : empId, DbType.Int32);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception e)
            {
                _out.cError = e.ToString();
                throw new Exception(e.Message, e);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }


        public GenericEntityDAResponse fRegistraContratoDL(BEContrato objContrato)
        {
            
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_RDA_MNT_Contrato";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nPrsId", objContrato.pnPersonaId == 0 ? 0 : objContrato.pnPersonaId, DbType.Int32);
                pAddParameter(cmdSQL, "@nEmpId", objContrato.pnEmpId == 0 ? 0 : objContrato.pnEmpId, DbType.Int32);
                pAddParameter(cmdSQL, "@nTipoContratoId", objContrato.pnTipoContratoId == 0 ? 0 : objContrato.pnTipoContratoId, DbType.Int32); //MAT
                pAddParameter(cmdSQL, "@nArea", objContrato.pnAreaId == 0 ? 0 : objContrato.pnAreaId, DbType.Int32);
                pAddParameter(cmdSQL, "@nModalidad", objContrato.pnModalidadId == 0 ? 0 : objContrato.pnModalidadId, DbType.Int32);
                pAddParameter(cmdSQL, "@nCrgContrato", objContrato.pnCargoId == 0 ? 0 : objContrato.pnCargoId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPerfil", objContrato.pnPerfilId == 0 ? 0 : objContrato.pnPerfilId, DbType.Int32);
                pAddParameter(cmdSQL, "@dtFchInicio", objContrato.pdtFchInicio == "" ? "" : objContrato.pdtFchInicio, DbType.String);
                pAddParameter(cmdSQL, "@dtFchFin", objContrato.pdtFchFin == "" ? "" : objContrato.pdtFchFin, DbType.String);
                pAddParameter(cmdSQL, "@cMinTra", objContrato.pcMinTra == "" ? "" : objContrato.pcMinTra, DbType.String);
                pAddParameter(cmdSQL, "@cRenovable", objContrato.pcRenovable == "" ? "" : objContrato.pcRenovable, DbType.String);
                pAddParameter(cmdSQL, "@cOpcion", objContrato.strOpcion == "" ? "" : objContrato.strOpcion, DbType.String);
                pAddParameter(cmdSQL, "@cdbFacturacion", strDBFacturacion, SqlDbType.NVarChar);
                pAddParameter(cmdSQL, "@cdbSeguridad", strDBSeguridad, SqlDbType.NVarChar);
                pAddParameter(cmdSQL, "@nUsuId", objContrato.pnUsuID, DbType.Int32);
                pAddParameter(cmdSQL, "@vCorreo", objContrato.pvCorreo == "" ? "" : objContrato.pvCorreo, DbType.String);

                _out.cAttr1 = fEjecutar(cmdSQL);
            }
            catch (Exception ex)
            {
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

    }


}
