﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.GeneralLayer;
namespace Seguridad.Entity.DataAccess.Seguridad
{
    public class SistemaDA : DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["SEGBDConexion"].ToString();

        public GenericEntityDAResponse fListaSistemaDL(SistemaBE objSistema)
        {
            //List<SistemaBE> objListaSistema = new List<SistemaBE>();

            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_WOR_SEL_ListaSistema_Filter";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@cSisDescripcion", objSistema.pcSisDescripcion == "" ? "" : objSistema.pcSisDescripcion, DbType.String);
                pAddParameter(cmdSQL, "@cSisNombre", objSistema.pcSisNombre == "" ? "" : objSistema.pcSisNombre, DbType.String);
                pAddParameter(cmdSQL, "@nSisId", objSistema.pnSisId == 0 ? 0 : objSistema.pnSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objSistema.strOpcion == "" ? "" : objSistema.strOpcion, DbType.String);
                pAddParameter(cmdSQL, "@nUsuId", objSistema.pnUsuId == 0 ? 0 : objSistema.pnUsuId, DbType.Int32);

                SqlDataReader drSQL = fLeer(cmdSQL);

                //objListaSistema = (List<SistemaBE>)ConvertirDataReaderALista<SistemaBE>(drSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

        public GenericEntityDAResponse fILCargaComboSistemaDL(SistemaBE objSistema)
        {
            //List<SistemaBE> objListaSistema = new List<SistemaBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_CLD_SEL_ListaSistemas";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                SqlDataReader drSQL = fLeer(cmdSQL);

                _out.dTable1.Load(drSQL);
                //objListaSistema = (List<SistemaBE>)ConvertirDataReaderALista<SistemaBE>(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }
            return _out;
        }

        public GenericEntityDAResponse fListaSistemaPaginacionDL()
        {
            //List<SistemaBE> objLista = new List<SistemaBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_WOR_SEL_ListaSistemaPaginacion_Filter";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                SqlDataReader drSQL = fLeer(cmdSQL);
                //objLista = (List<SistemaBE>)ConvertirDataReaderALista<SistemaBE>(drSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

        public String fMantenimientoSistemaDL(SistemaBE objSistema)
        {
            String strResultado = "";

            try
            {

                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_Sistema";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nSisId", objSistema.pnSisId == 0 ? 0 : objSistema.pnSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@cSisNombre", objSistema.pcSisNombre == "" ? "" : objSistema.pcSisNombre, DbType.String);
                pAddParameter(cmdSQL, "@cSisDescripcion", objSistema.pcSisDescripcion == "" ? "" : objSistema.pcSisDescripcion, DbType.String);
                pAddParameter(cmdSQL, "@bTipoEjecucion", objSistema.pbTipoEjecucion == false ? false : objSistema.pbTipoEjecucion, DbType.Boolean);
                pAddParameter(cmdSQL, "@Accion", objSistema.strOpcion == "0" ? "0" : objSistema.strOpcion, DbType.String);
                pAddParameter(cmdSQL, "@cSisUrl", objSistema.SisUrl == "0" ? "0" : objSistema.SisUrl, DbType.String);
                strResultado = fEjecutar(cmdSQL);
            }
            catch (Exception ex)
            {
                strResultado = "";
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }

            return strResultado;
        }

        public GenericEntityDAResponse fListaVerificarSistemaDL(SistemaBE objSistema)
        {
            //List<SistemaBE> objListaSistema = new List<SistemaBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_VerificarSistema";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@cSisNombre", objSistema.pcSisNombre == "" ? "" : objSistema.pcSisNombre, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                //objListaSistema = (List<SistemaBE>)ConvertirDataReaderALista<SistemaBE>(drSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

        public GenericEntityDAResponse fListaValidarSistemaDL(SistemaBE objSistema)
        {
            //List<SistemaBE> objListaSistema = new List<SistemaBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_ValidarSistema";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nSisId", objSistema.pnSisId == 0 ? 0 : objSistema.pnSisId, DbType.Int32);
                SqlDataReader drSQL = fLeer(cmdSQL);
                //objListaSistema = (List<SistemaBE>)ConvertirDataReaderALista<SistemaBE>(drSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }



        public GenericEntityDAResponse fListaSistemasxRolesAsignandosXUsuarioSessionDL(UsuarioBE objUsuario)
        {
            //List<SistemaBE> objListaSistema = new List<SistemaBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEGURIDAD_ListaSistemasRolesAsignadoXUsuarioSession";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nUsuId", objUsuario.nUsuId == 0 ? 0 : objUsuario.nUsuId, DbType.Int32);
                pAddParameter(cmdSQL, "@nSisId", objUsuario.nSisId == 0 ? 0 : objUsuario.nSisId, DbType.Int32);

                SqlDataReader drSQL = fLeer(cmdSQL);

                if (drSQL.HasRows)
                {
                    //objListaSistema = (List<SistemaBE>)ConvertirDataReaderALista<SistemaBE>(drSQL);
                    _out.dTable1.Load(drSQL);
                }

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }

            return _out;
        }

        public GenericEntityDAResponse fListaSistemasAsignadoXUsuarioDL(UsuarioBE objUsuario)
        {
            //List<SistemaBE> objListaSistema = new List<SistemaBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ListaSistemasAsignadoXUsuario";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nUsuId", objUsuario.nUsuId == 0 ? 0 : objUsuario.nUsuId, DbType.Int32);

                SqlDataReader drSQL = fLeer(cmdSQL);

                if (drSQL.HasRows)
                {
                    //objListaSistema = (List<SistemaBE>)ConvertirDataReaderALista<SistemaBE>(drSQL);
                    _out.dTable1.Load(drSQL);
                    
                }

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }

            return _out;
        }

        public GenericEntityDAResponse fObtenerSistemaxUrlDL(SistemaBE objSistemaBE)
        {
            //List<SistemaBE> objLista = new List<SistemaBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_LIS_ObtenerSistemaxUrl";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@SisUrl", objSistemaBE.SisUrl == "" ? "" : objSistemaBE.SisUrl, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                //objLista = (List<SistemaBE>)ConvertirDataReaderALista<SistemaBE>(drSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

    }
}
