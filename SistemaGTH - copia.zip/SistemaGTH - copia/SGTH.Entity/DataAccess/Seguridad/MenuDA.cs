﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.GeneralLayer;

namespace Seguridad.Entity.DataAccess.Seguridad
{
    public class MenuDA : DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["SEGBDConexion"].ToString();

        public GenericEntityDAResponse fListaMenusSitemapDL(RolBE objUsuario)
        {
            //List<MenuBE> objListaMenus = new List<MenuBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEGURIDAD_ListaMenu_Sitemap";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@Sistema", objUsuario.nSisId == 0 ? 0 : objUsuario.nSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@nUsuId", objUsuario.nUsuId == 0 ? 0 : objUsuario.nUsuId, DbType.Int32);
                pAddParameter(cmdSQL, "@nRolId", objUsuario.nRolId == 0 ? 0 : objUsuario.nRolId, DbType.Int32);
                SqlDataReader drSQL = fLeer(cmdSQL);
                //objListaMenus = (List<MenuBE>)ConvertirDataReaderALista<MenuBE>(drSQL);
                _out.dTable1.Load(drSQL);
             
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }
            //return _out.gList1.Cast<RolBE>().ToList();
            return _out;
        }
        public GenericEntityDAResponse fListaMenusXPerfilDL(MenuBE objMenu)
        {
            //List<MenuBE> objListaMenus = new List<MenuBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ListaMenuXPrefil_Filter";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nSisId", objMenu.pnSisId == 0 ? 0 : objMenu.pnSisId, DbType.Int32);
                SqlDataReader drSQL = fLeer(cmdSQL);
                //objListaMenus = (List<MenuBE>)ConvertirDataReaderALista<MenuBE>(drSQL);
                _out.dTable1.Load(drSQL);
                
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }


        public GenericEntityDAResponse fListaMenusXPerfilAsignadosDL(MenuBE objMenu)
        {
            //List<MenuBE> objListaMenus = new List<MenuBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_MenuXPerfil";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nSisId", objMenu.pnSisId == 0 ? 0 : objMenu.pnSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPerId", objMenu.pnPerId == 0 ? 0 : objMenu.pnPerId, DbType.Int32);
                SqlDataReader drSQL = fLeer(cmdSQL);

                //objListaMenus = (List<MenuBE>)ConvertirDataReaderALista<MenuBE>(drSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }
            return _out;
        }
        public GenericEntityDAResponse fListaMenusDL(MenuBE objMenu)
        {
            //List<MenuBE> objListaMenus = new List<MenuBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ListaMenu_Filter";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nMenuId", objMenu.pnMenuId == 0 ? 0 : objMenu.pnMenuId, DbType.Int32);
                pAddParameter(cmdSQL, "@nSisId", objMenu.pnSisId == 0 ? 0 : objMenu.pnSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@cMenuNom", objMenu.pcMenuNom == "" ? "" : objMenu.pcMenuNom, DbType.String);
                pAddParameter(cmdSQL, "@cMenuArch", objMenu.pcMenuArch == "" ? "" : objMenu.pcMenuArch, DbType.String);
                pAddParameter(cmdSQL, "@bMenuCab", objMenu.pbMenuCab, DbType.Byte);
                pAddParameter(cmdSQL, "@nMenuGrupo", objMenu.pnMenuGrupo == 0 ? 0 : objMenu.pnMenuGrupo, DbType.Int32);
                pAddParameter(cmdSQL, "@nMenuOrden", objMenu.pnMenuOrden == 0 ? 0 : objMenu.pnMenuOrden, DbType.Int32);
                pAddParameter(cmdSQL, "@nMenuNivel", objMenu.pnMenuNivel == 0 ? 0 : objMenu.pnMenuNivel, DbType.Int32);
                pAddParameter(cmdSQL, "@cMnuEliminado", objMenu.pcMnuEliminado == "" ? "" : objMenu.pcMnuEliminado, DbType.String);
                pAddParameter(cmdSQL, "@cSisEliminado", objMenu.pcSisEliminado == "" ? "" : objMenu.pcSisEliminado, DbType.String);


                SqlDataReader drSQL = fLeer(cmdSQL);
                //objListaMenus = (List<MenuBE>)ConvertirDataReaderALista<MenuBE>(drSQL);
                _out.dTable1.Load(drSQL);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }

            return _out;
        }

        public String fMantenimientoMenuXPerfilDL(MenuBE objMenu)
        {
            String strResultado = "";
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_MenuXPerfil";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nSisId", objMenu.pnSisId == 0 ? 0 : objMenu.pnSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPerId", objMenu.pnPerId == 0 ? 0 : objMenu.pnPerId, DbType.Int32);
                pAddParameter(cmdSQL, "@cMenus", objMenu.pcMenusxPerfil == "0" ? "0" : objMenu.pcMenusxPerfil, DbType.String);
                strResultado = fEjecutar(cmdSQL);
            }
            catch (Exception ex)
            {
                strResultado = "";
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return strResultado;
        }
        public GenericEntityDAResponse fListarMenuXPerfilSelectedDL(MenuBE oMenuBE)
        {

            //List<MenuBE> oliMenuBE = new List<MenuBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ListaMenuXPrefil_Selected";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nSisId", oMenuBE.pnSisId == 0 ? 0 : oMenuBE.pnSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPerId", oMenuBE.pnPerId == 0 ? 0 : oMenuBE.pnPerId, DbType.Int32);
                SqlDataReader drSQL = fLeer(cmdSQL);
            
                //oliMenuBE = (List<MenuBE>)ConvertirDataReaderALista<MenuBE>(drSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }

            return _out;
            //USP_SEG_SEL_ListaMenuXPrefil_Selected
        }

        public GenericEntityDAResponse fListaGruposDL(MenuBE objMenu)
        {
            //List<MenuBE> objListaMenus = new List<MenuBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ListaMenuGrupos_Filter";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nSisId", objMenu.pnSisId == 0 ? 0 : objMenu.pnSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@nMenuId", objMenu.pnMenuId, DbType.Int32);
                pAddParameter(cmdSQL, "@cMnuEliminado", objMenu.pcMnuEliminado == "" ? "" : objMenu.pcMnuEliminado, DbType.String);
                pAddParameter(cmdSQL, "@cSisEliminado", objMenu.pcSisEliminado == "" ? "" : objMenu.pcSisEliminado, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);
                //objListaMenus = (List<MenuBE>)ConvertirDataReaderALista<MenuBE>(drSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }
            return _out;
        }

        public String fMantenimientoMenuDL(MenuBE objMenu, String strOpcion)
        {
            String strResultado = "";

            try
            {

                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_Menu";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nMenuId", objMenu.pnMenuId == 0 ? 0 : objMenu.pnMenuId, DbType.Int32);
                pAddParameter(cmdSQL, "@nSisId", objMenu.pnSisId == 0 ? 0 : objMenu.pnSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@cMenuNom", objMenu.pcMenuNom == "" ? "" : objMenu.pcMenuNom, DbType.String);
                pAddParameter(cmdSQL, "@cMenuArch", objMenu.pcMenuArch == "" ? "" : objMenu.pcMenuArch, DbType.String);
                pAddParameter(cmdSQL, "@bMenuCab", objMenu.pbMenuCab, DbType.Byte);
                pAddParameter(cmdSQL, "@nMenuGrupo", objMenu.pnMenuGrupo == 0 ? 0 : objMenu.pnMenuGrupo, DbType.Int32);
                pAddParameter(cmdSQL, "@nMenuOrden", objMenu.pnMenuOrden == 0 ? 0 : objMenu.pnMenuOrden, DbType.Int32);
                pAddParameter(cmdSQL, "@cMnuEliminado", objMenu.pcMnuEliminado == "" ? "" : objMenu.pcMnuEliminado, DbType.String);
                pAddParameter(cmdSQL, "@nMenuNivel", objMenu.pnMenuNivel == 0 ? 0 : objMenu.pnMenuNivel, DbType.Int32);
                //pAddParameter(cmdSQL, "@cSisEliminado", objMenu.pcSisEliminado == "" ? "" : objMenu.pcSisEliminado, DbType.String);
                pAddParameter(cmdSQL, "@cOpcion", strOpcion == "" ? "0" : strOpcion, DbType.String);


                strResultado = fEjecutar(cmdSQL);

            }
            catch (Exception ex)
            {
                strResultado = "";
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }

            return strResultado;
        }

        public MenuBE fContarHijosPorCodigoDL(MenuBE objMenu)
        {

            List<MenuBE> objListaMenus = new List<MenuBE>();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ContarHijosMenu";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nMenuId", objMenu.pnMenuId, DbType.Int32);
                pAddParameter(cmdSQL, "@cMnuEliminado", objMenu.pcMnuEliminado, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);

                while (drSQL.Read())
                {
                    objMenu.pnMenuHijos = drSQL["cMenuHijos"].Equals(System.DBNull.Value) ? 0 : Convert.ToInt32(drSQL["cMenuHijos"]);
                }

            }
            catch (Exception ex)
            {
                objMenu = null;
                throw new Exception(ex.Message, ex);
            }
            finally
            {

                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }

            return objMenu;
        }
        public List<MenuEstructura> fListaMenusSitemapGeneralDL(int idusuario)
        {
            List<MenuEstructura> objListaMenus = new List<MenuEstructura>();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEGURIDAD_LISTA_MENU_GENERAL";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nUsuId", idusuario == 0 ? 0 : idusuario, DbType.Int32);
                SqlDataReader drSQL = fLeer(cmdSQL);

                while (drSQL.Read())
                {
                    MenuEstructura item = new MenuEstructura();
                    item.nMenuId = drSQL["nMenuId"].Equals(System.DBNull.Value) ? 0 : Convert.ToInt32(drSQL["nMenuId"]);
                    item.cMenuNom = drSQL["cMenuNom"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cMenuNom"]);
                    item.nMenuGrupo = drSQL["nMenuGrupo"].Equals(System.DBNull.Value) ? 0 : Convert.ToInt32(drSQL["nMenuGrupo"]);
                    item.cMenuArch = drSQL["cMenuArch"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cMenuArch"]);
                    item.nMenuNivel = drSQL["nMenuNivel"].Equals(System.DBNull.Value) ? 0 : Convert.ToInt32(drSQL["nMenuNivel"]);
                    item.nMenuOrden = drSQL["nMenuOrden"].Equals(System.DBNull.Value) ? 0 : Convert.ToInt32(drSQL["nMenuOrden"]);
                    item.nSisId = drSQL["nSisId"].Equals(System.DBNull.Value) ? 0 : Convert.ToInt32(drSQL["nSisId"]);
                    item.cSisUrl = drSQL["cSisUrl"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cSisUrl"]);
                    item.vant = drSQL["vant"].Equals(System.DBNull.Value) ? 0 : Convert.ToInt32(drSQL["vant"]);
                    objListaMenus.Add(item);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }
            return objListaMenus;
        }
        public GenericEntityDAResponse fListaMenusSistemasGeneralDL(RolBE objUsuario)
        {
            //List<MenuBE> objListaMenus = new List<MenuBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEGURIDAD_ListaMenu_Sitemap_general";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                //pAddParameter(cmdSQL, "@Sistema", objUsuario.nSisId == 0 ? 0 : objUsuario.nSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@nUsuId", objUsuario.nUsuId == 0 ? 0 : objUsuario.nUsuId, DbType.Int32);
                //pAddParameter(cmdSQL, "@nRolId", objUsuario.nRolId == 0 ? 0 : objUsuario.nRolId, DbType.Int32);
                SqlDataReader drSQL = fLeer(cmdSQL);
                //objListaMenus = (List<MenuBE>)ConvertirDataReaderALista<MenuBE>(drSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }
            return _out;
        }
    }
}
