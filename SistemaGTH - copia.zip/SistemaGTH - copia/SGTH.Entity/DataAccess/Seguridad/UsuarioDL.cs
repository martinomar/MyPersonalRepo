﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.GeneralLayer;

namespace Seguridad.Entity.DataAccess.Seguridad
{
    public class UsuarioDL : DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["SEGBDConexion"].ToString();
        String strSar = ConfigurationManager.AppSettings["SARBDConexion"].ToString();

        public GenericEntityDAResponse fListaUsuarioIntranetDL(UsuarioBE objElUsuario)
        {
            //List<UsuarioBE> objLista = new List<UsuarioBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_LIS_ObtenerUsuarioIntranet";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nombre", objElUsuario.cUsuNombres == "" ? "" : objElUsuario.cUsuNombres, DbType.String);
                pAddParameter(cmdSQL, "@MaeItem", objElUsuario.Item == 0 ? 0 : objElUsuario.Item, DbType.Int32);
                SqlDataReader drSQL = fLeer(cmdSQL);
                //objLista = (List<UsuarioBE>)ConvertirDataReaderALista<UsuarioBE>(drSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

        public String fMantenimientoPerfilXUsuarioDL(PerfilBE objPerfil)
        {
            String strResultado = "";

            try
            {

                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_PerfilXUsuario";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nSisId", objPerfil.pnSisId == 0 ? 0 : objPerfil.pnSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPerId", objPerfil.pnPerId == 0 ? 0 : objPerfil.pnPerId, DbType.Int32);
                pAddParameter(cmdSQL, "@nUsuId", objPerfil.pnUsuId == 0 ? 0 : objPerfil.pnUsuId, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objPerfil.strOpcion == "" ? "0" : objPerfil.strOpcion, DbType.String);


                strResultado = fEjecutar(cmdSQL);

            }
            catch (Exception ex)
            {
                strResultado = "";
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }

            return strResultado;
        }

        public GenericEntityDAResponse fValidaUsuarioxGrupoDL(UsuarioBE objUsuario)
        {
            //List<UsuarioBE> objLista = new List<UsuarioBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strSar);
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.CommandText = "USP_UsuarioxGrupoGeneral";
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nUsuId", objUsuario.nUsuId, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                if (drSQL.HasRows)
                {
                    _out.dTable1.Load(drSQL);
                    //objLista = (List<UsuarioBE>)ConvertirDataReaderALista<UsuarioBE>(drSQL);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

        public GenericEntityDAResponse fBuscarUsuarioRDADL(UsuarioBE objUsuario)
        {

            //List<UsuarioBE> objLista = new List<UsuarioBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SAR_BUSCAR_USUARIO";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@vCodPrs", objUsuario.nCodPrs == 0 ? 0 : objUsuario.nCodPrs, DbType.Int32);
                SqlDataReader drSQL = fLeer(cmdSQL);
                //objLista = (List<UsuarioBE>)ConvertirDataReaderALista<UsuarioBE>(drSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            //return objLista;
            return _out;
        }


        public int fLoginUsuarioDL(string usuario, string password, string eliminado)
        {
            int respuesta = -4;
            //string u, p, e;

            //u = objUsuario.pcUsuLogin;
            //p = objPassword.pcPassword;
            //e = objUsuario.pcEliminado;

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ValidaLogin";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@cUsuLogin", usuario, DbType.String);
                pAddParameter(cmdSQL, "@cPassword", password, DbType.String);
                pAddParameter(cmdSQL, "@cEliminado", eliminado, DbType.String);


                SqlDataReader drSQL = fLeer(cmdSQL);

                while (drSQL.Read())
                {
                    respuesta = drSQL["r"].Equals(System.DBNull.Value) ? 0 : Convert.ToInt32(drSQL["r"]);
                }

            }
            catch (Exception ex)
            {
                respuesta = -3;
            }
            finally
            {

                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }

            return respuesta;
        }

        public UsuarioBE fObtenerUsuarioPorCodigoDL(int nUsuId)
        {
            UsuarioBE objUsuario = new UsuarioBE();


            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_UsuarioPorCodigo_v2"; //js 04-06-2018
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nUsuId", nUsuId, DbType.Int32);
                pAddParameter(cmdSQL, "@cEliminado", "0", DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);

                while (drSQL.Read())
                {
                    objUsuario = new UsuarioBE();

                    objUsuario.nUsuId = drSQL["nUsuId"].Equals(System.DBNull.Value) ? 0 : Convert.ToInt32(drSQL["nUsuId"]);
                    objUsuario.cUsuLogin = drSQL["cUsuLogin"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuLogin"]);
                    objUsuario.cUsuNombres = drSQL["cUsuNombres"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuNombres"]);
                    objUsuario.cUsuApePat = drSQL["cUsuApePat"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuApePat"]);
                    objUsuario.cUsuApeMat = drSQL["cUsuApeMat"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuApeMat"]);
                    objUsuario.cUsuCorreo = drSQL["cUsuCorreo"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuCorreo"]);
                    objUsuario.cUsuPrgSecreta = drSQL["cUsuPrgSecreta"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuPrgSecreta"]);
                    objUsuario.cUsuRptSecreta = drSQL["cUsuRptSecreta"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuRptSecreta"]);
                    objUsuario.cEliminado = drSQL["cEliminado"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cEliminado"]);
                    objUsuario.cImgUsuario = drSQL["cImgUsuario"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cImgUsuario"]);
                }

            }
            catch (Exception ex)
            {
                objUsuario = null;
                throw new Exception(ex.Message, ex);
            }
            finally
            {

                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }

            return objUsuario;
        }


        public List<UsuarioBE> fListaUsuariosDL(UsuarioBE objUsuario)
        {
            List<UsuarioBE> objListaUsuarios = new List<UsuarioBE>();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ListaUsuarios_Filter";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nSisId", objUsuario.nSisId == 0 ? 0 : objUsuario.nSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@cUsuLogin", objUsuario.cUsuLogin == "" ? "" : objUsuario.cUsuLogin, DbType.String);
                pAddParameter(cmdSQL, "@cUsuNombres", objUsuario.cUsuNombres == "" ? "" : objUsuario.cUsuNombres, DbType.String);
                pAddParameter(cmdSQL, "@cUsuApePat", objUsuario.cUsuApePat == "" ? "" : objUsuario.cUsuApePat, DbType.String);
                pAddParameter(cmdSQL, "@cUsuApeMat", objUsuario.cUsuApeMat == "" ? "" : objUsuario.cUsuApeMat, DbType.String);
                pAddParameter(cmdSQL, "@cUsuCorreo", objUsuario.cUsuCorreo == "" ? "" : objUsuario.cUsuCorreo, DbType.String);
                pAddParameter(cmdSQL, "@cUsuEliminado", objUsuario.cEliminado == "" ? "" : objUsuario.cEliminado, DbType.String);
                pAddParameter(cmdSQL, "@cSisEliminado", objUsuario.cSisEliminado == "" ? "" : objUsuario.cSisEliminado, DbType.String);
                pAddParameter(cmdSQL, "@cUsuSisEliminado", objUsuario.cUsuSisEliminado == "" ? "" : objUsuario.cUsuSisEliminado, DbType.String);
                pAddParameter(cmdSQL, "@cOpcion", objUsuario.pcOpcion == "" ? "00" : objUsuario.pcOpcion, DbType.String);
                pAddParameter(cmdSQL, "@nGruId", objUsuario.nGruId == 0 ? 0 : objUsuario.nGruId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPageNumber", objUsuario.PageNumber == 0 ? 0 : objUsuario.PageNumber, DbType.Int32);
                pAddParameter(cmdSQL, "@nPageSize", objUsuario.PageSize == 0 ? 0 : objUsuario.PageSize, DbType.Int32);


                SqlDataReader drSQL = fLeer(cmdSQL);

                if (drSQL.HasRows)
                {
                    // objListaUsuarios = (List<UsuarioBE>)ConvertirDataReaderALista<UsuarioBE>(drSQL);
                    while (drSQL.Read())
                    {
                        objUsuario = new UsuarioBE();

                        objUsuario.Item = drSQL["RowNumber"].Equals(System.DBNull.Value) ? 0 : Convert.ToInt32(drSQL["RowNumber"]);
                        objUsuario.nUsuId = drSQL["nUsuId"].Equals(System.DBNull.Value) ? 0 : Convert.ToInt32(drSQL["nUsuId"]);
                        objUsuario.cUsuLogin = drSQL["cUsuLogin"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuLogin"]);
                        objUsuario.cUsuNombres = drSQL["cUsuNombres"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuNombres"]);
                        objUsuario.cUsuApePat = drSQL["cUsuApePat"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuApePat"]);
                        objUsuario.cUsuApeMat = drSQL["cUsuApeMat"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuApeMat"]);
                        objUsuario.cUsuCorreo = drSQL["cUsuCorreo"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuCorreo"]);
                        objUsuario.cUsuPrgSecreta = drSQL["cUsuPrgSecreta"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuPrgSecreta"]);
                        objUsuario.cUsuRptSecreta = drSQL["cUsuRptSecreta"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuRptSecreta"]);
                        objUsuario.cEliminado = drSQL["cEliminado"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cEliminado"]);
                        objUsuario.nCodPrs = drSQL["nCodPrs"].Equals(System.DBNull.Value) ? 0 : Convert.ToInt32(drSQL["nCodPrs"]);

                        objListaUsuarios.Add(objUsuario);
                    }
                }

            }
            catch (Exception ex)
            {
                objListaUsuarios = null;
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }

            return objListaUsuarios;
        }

        public String fMantenimientoUsuario(UsuarioBE objUsuario)
        {
            String strResultado;

            try
            {

                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_Usuario";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nUsuId", objUsuario.nUsuId == 0 ? 0 : objUsuario.nUsuId, DbType.Int32);
                pAddParameter(cmdSQL, "@vCodPrs", objUsuario.nCodPrs == 0 ? 0 : objUsuario.nCodPrs, DbType.Int32);
                pAddParameter(cmdSQL, "@cUsuLogin", objUsuario.cUsuLogin == "" ? "" : objUsuario.cUsuLogin, DbType.String);
                pAddParameter(cmdSQL, "@cUsuNombres", objUsuario.cUsuNombres == "" ? "" : objUsuario.cUsuNombres, DbType.String);
                pAddParameter(cmdSQL, "@cUsuApePat", objUsuario.cUsuApePat == "" ? "" : objUsuario.cUsuApePat, DbType.String);
                pAddParameter(cmdSQL, "@cUsuApeMat", objUsuario.cUsuApeMat == "" ? "" : objUsuario.cUsuApeMat, DbType.String);
                pAddParameter(cmdSQL, "@cUsuCorreo", objUsuario.cUsuCorreo == "" ? "" : objUsuario.cUsuCorreo, DbType.String);
                pAddParameter(cmdSQL, "@cUsuPrgSecreta", objUsuario.cUsuPrgSecreta == "" ? "" : objUsuario.cUsuPrgSecreta, DbType.String);
                pAddParameter(cmdSQL, "@cUsuRptSecreta", objUsuario.cUsuRptSecreta == "" ? "" : objUsuario.cUsuRptSecreta, DbType.String);
                pAddParameter(cmdSQL, "@cPassword", objUsuario.cPassword == "" ? "" : objUsuario.cPassword, DbType.String);
                pAddParameter(cmdSQL, "@cUsuEliminado", objUsuario.cEliminado == "" ? "" : objUsuario.cEliminado, DbType.String);
                pAddParameter(cmdSQL, "@cOpcion", objUsuario.pcOpcion == "" ? "0" : objUsuario.pcOpcion, DbType.String);

                strResultado = fEjecutar(cmdSQL);

            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }

            return strResultado;

        }
        public UsuarioBE fLoginAutenticacionDL(string usuario, string password)
        {
            UsuarioBE objUsuario = new UsuarioBE();


            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_LoginAutenticacion";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@cUsuLogin", usuario, DbType.String);
                pAddParameter(cmdSQL, "@cPassword", password, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);

                while (drSQL.Read())
                {
                    objUsuario = new UsuarioBE();

                    objUsuario.nUsuId = drSQL["nUsuId"].Equals(System.DBNull.Value) ? 0 : Convert.ToInt32(drSQL["nUsuId"]);
                    objUsuario.nProId = drSQL["codigo"].Equals(System.DBNull.Value) ? 0 : Convert.ToInt32(drSQL["codigo"]);
                    objUsuario.cEliminado = drSQL["cEliminado"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cEliminado"]);
                    objUsuario.cUsuApePat = drSQL["cUsuApePat"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuApePat"]);
                    objUsuario.cUsuApeMat = drSQL["cUsuApeMat"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuApeMat"]);
                    objUsuario.cUsuCorreo = drSQL["cusucorreo"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cusucorreo"]);
                    objUsuario.cUsuLogin = drSQL["cUsuLogin"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuLogin"]);
                    objUsuario.cUsuNombres = drSQL["cUsuNombres"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuNombres"]);
                    objUsuario.cUsuPrgSecreta = drSQL["cUsuPrgSecreta"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuPrgSecreta"]);
                    objUsuario.cUsuRptSecreta = drSQL["cUsuRptSecreta"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cUsuRptSecreta"]);

                }

            }
            catch (Exception ex)
            {
                objUsuario = null;
                throw new Exception(ex.Message, ex);
            }
            finally
            {

                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }

            return objUsuario;
        }
        public String fMantDatosUsuarioDL(int nUsuId, string crutaimg, string cOpcion)
        {
            String strResultado = "";

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_DatosUsuario";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nUsuId", nUsuId == 0 ? 0 : nUsuId, DbType.Int32);
                pAddParameter(cmdSQL, "@crutaimg", crutaimg == "" ? "0" : crutaimg, DbType.String);
                pAddParameter(cmdSQL, "@cOpcion", cOpcion == "" ? "0" : cOpcion, DbType.String);

                strResultado = fEjecutar(cmdSQL);

            }
            catch (Exception ex)
            {
                strResultado = "";
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }

            return strResultado;
        }
    }
}
