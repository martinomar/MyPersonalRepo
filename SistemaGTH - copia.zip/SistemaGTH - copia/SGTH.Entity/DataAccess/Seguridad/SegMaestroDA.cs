﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.GeneralLayer;
namespace Seguridad.Entity.DataAccess.Seguridad
{
    public class SegMaestroDA : DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["SEGBDConexion"].ToString();

        public GenericEntityDAResponse fListaSegMaestrosDA(SegMaestroBE objSegMaestro)
        {
            //List<SegMaestroBE> objListaSegMaestros = new List<SegMaestroBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ListaSegMaestro_Filter";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nSisId", objSegMaestro.nSisId == 0 ? 0 : objSegMaestro.nSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@nMaeId", objSegMaestro.nMaeId, DbType.Int32);
                pAddParameter(cmdSQL, "@nMaeItem", objSegMaestro.nMaeItem, DbType.Int32);
                pAddParameter(cmdSQL, "@cMaeDenom", objSegMaestro.cMaeDenom == "" ? "" : objSegMaestro.cMaeDenom, DbType.String);
                pAddParameter(cmdSQL, "@cMaeDesc", objSegMaestro.cMaeDesc == "" ? "" : objSegMaestro.cMaeDesc, DbType.String);
                pAddParameter(cmdSQL, "@cMaeValor", objSegMaestro.cMaeValor == "" ? "" : objSegMaestro.cMaeValor, DbType.String);
                pAddParameter(cmdSQL, "@cMaeActivo", objSegMaestro.cMaeActivo == "" ? "" : objSegMaestro.cMaeActivo, DbType.String);
                pAddParameter(cmdSQL, "@cMaesEliminado", objSegMaestro.cSegMaeEliminado == "" ? "" : objSegMaestro.cSegMaeEliminado, DbType.String);
                pAddParameter(cmdSQL, "@cSisEliminado", objSegMaestro.cSisEliminado == "" ? "" : objSegMaestro.cSisEliminado, DbType.String);
                pAddParameter(cmdSQL, "@nPageNumber", objSegMaestro.PageNumber == 0 ? 0 : objSegMaestro.PageNumber, DbType.Int32);
                pAddParameter(cmdSQL, "@nPageSize", objSegMaestro.PageSize == 0 ? 0 : objSegMaestro.PageSize, DbType.Int32);

                SqlDataReader drSQL = fLeer(cmdSQL);

                if (drSQL.HasRows)
                {
                    //objListaSegMaestros = (List<SegMaestroBE>)ConvertirDataReaderALista<SegMaestroBE>(drSQL);
                    _out.dTable1.Load(drSQL);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }

            return _out;
        }
        public GenericEntityDAResponse fListaTablasMaestroDL(SegMaestroBE objSegMaestro)
        {
            //List<SegMaestroBE> objListaSegMaestroBE = new List<SegMaestroBE>();
            //SegMaestroBE objEntSegMaestroBE;
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ListaTablasMaestro_Filter";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nSisId", objSegMaestro.nSisId == 0 ? 0 : objSegMaestro.nSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@cSegMaeEliminado", objSegMaestro.cSegMaeEliminado == "" ? "" : objSegMaestro.cSegMaeEliminado, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
                //while (drSQL.Read())
                //{
                    
                //    objEntSegMaestroBE = new SegMaestroBE();
                //    objEntSegMaestroBE.nMaeItem = drSQL["nMaeItem"].Equals(System.DBNull.Value) ? 0 : Convert.ToInt32(drSQL["nMaeItem"]);
                //    objEntSegMaestroBE.cMaeDenom = drSQL["cMaeDenom"].Equals(System.DBNull.Value) ? "" : Convert.ToString(drSQL["cMaeDenom"]);
                //    objListaSegMaestroBE.Add(objEntSegMaestroBE);
                //    objEntSegMaestroBE = null;
                //}

            }
            catch (Exception ex)
            {
                //objEntSegMaestroBE = null;
                _out.cError = ex.ToString();
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                //objEntSegMaestroBE = null;
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }

            return _out;
        }
        public String fMantenimientoSegMaestroDL(SegMaestroBE objSegMaestro, String strOpcion)
        {
            String strResultado = "";

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_SegMaestro";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nSisId", objSegMaestro.nSisId == 0 ? 0 : objSegMaestro.nSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@nMaeId", objSegMaestro.nMaeId == 0 ? 0 : objSegMaestro.nMaeId, DbType.Int32);
                pAddParameter(cmdSQL, "@nMaeItem", objSegMaestro.nMaeItem == 0 ? 0 : objSegMaestro.nMaeItem, DbType.Int32);
                pAddParameter(cmdSQL, "@cMaeDenom", objSegMaestro.cMaeDenom == "" ? "" : objSegMaestro.cMaeDenom, DbType.String);
                pAddParameter(cmdSQL, "@cMaeDesc", objSegMaestro.cMaeDesc == "" ? "" : objSegMaestro.cMaeDesc, DbType.String);
                pAddParameter(cmdSQL, "@cMaeValor", objSegMaestro.cMaeValor == "" ? "" : objSegMaestro.cMaeValor, DbType.String);
                pAddParameter(cmdSQL, "@cMaeActivo", objSegMaestro.cMaeActivo == "" ? "" : objSegMaestro.cMaeActivo, DbType.String);
                pAddParameter(cmdSQL, "@cEliminado", objSegMaestro.cSegMaeEliminado == "" ? "" : objSegMaestro.cSegMaeEliminado, DbType.String);
                pAddParameter(cmdSQL, "@cOpcion", strOpcion == "" ? "0" : strOpcion, DbType.String);

                strResultado = fEjecutar(cmdSQL);

            }
            catch (Exception ex)
            {
                strResultado = "";
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }

            return strResultado;
        }
    }
}