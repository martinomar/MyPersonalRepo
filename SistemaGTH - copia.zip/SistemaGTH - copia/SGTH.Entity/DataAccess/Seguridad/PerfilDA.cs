﻿/*--------------------------------------------------------------------------
SISTEMA : Seguridad
SUBSISTEMA : Seguridad
NOMBRE : PerfilBL.js
DESCRIPCIÓN : 
AUTOR : --- - SES Practicante
FECHA CREACIÓN : 17-05-2018
-----------------------------------------------------------------------------------------------------------
FECHA                EMPLEADO             MODIFICACIÓN  
------------------   -----------------    --------------------------------------------------------------------------------------
Juevez 17/05/2018/   martin.delgado       creacion y definicion de metodos(la clase requeria implementar mas metodos...)
---------------------------------------------------------------------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Seguridad.Entity.BusinessEntity.Seguridad;
using SGTH.Entity.GeneralLayer;


namespace Seguridad.Entity.DataAccess.Seguridad
{
    public class PerfilDA : DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        //ANTERIOR...
        //String strCon = ConfigurationManager.AppSettings["SARBDConexion"].ToString();

        //BEGIN. Cambio martin.delgado...
        String strCon = ConfigurationManager.AppSettings["SEGBDConexion"].ToString();
        //END. Cambio martin.delgado...

        public GenericEntityDAResponse fListaPerfilesAsignadosXUsuarioDL(PerfilBE objPerfil)
        {
            //List<PerfilBE> objListaPerfil = new List<PerfilBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ListaPerfilAsignadoXUsuario_Filter";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nSisId", objPerfil.pnSisId == 0 ? 0 : objPerfil.pnSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@nUsuId", objPerfil.pnUsuId == 0 ? 0 : objPerfil.pnUsuId, DbType.Int32);
                pAddParameter(cmdSQL, "@cPerEliminado", objPerfil.pcPerEliminado == "" ? "" : objPerfil.pcPerEliminado, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);

                if (drSQL.HasRows)
                {
                    //objListaPerfil = (List<PerfilBE>)ConvertirDataReaderALista<PerfilBE>(drSQL);
                    _out.dTable1.Load(drSQL);
                }

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }

            return _out;
        }


        #region(Cambios martin.delgado ...)

        public String fMantenimientoPerfilXUsuarioDL(PerfilBE objPerfil, String strOpcion)
        {
            String strResultado = "";

            try
            {

                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_PerfilXUsuario";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nSisId", objPerfil.pnSisId == 0 ? 0 : objPerfil.pnSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPerId", objPerfil.pnPerId == 0 ? 0 : objPerfil.pnPerId, DbType.Int32);
                pAddParameter(cmdSQL, "@nUsuId", objPerfil.pnUsuId == 0 ? 0 : objPerfil.pnUsuId, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", strOpcion == "" ? "0" : strOpcion, DbType.String);


                strResultado = fEjecutar(cmdSQL);

            }
            catch (Exception ex)
            {
                strResultado = "";
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }

            return strResultado;
        }

        public GenericEntityDAResponse fListaPerfilDL(PerfilBE objSistema)
        {
            //List<PerfilBE> objListaPerfil = new List<PerfilBE>();
            //ELSistema objELSistema;
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ListaPerfil_Filter";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
                //objListaPerfil = (List<PerfilBE>)ConvertirDataReaderALista<PerfilBE>(drSQL);

            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message, ex);
            }
            finally
            {

                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }

            return _out;
        }

        public String fMantenimientoPerfilDL(PerfilBE objPerfil)
        {
            String strResultado = "";
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_Perfil_new";//js
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nPerId", objPerfil.pnPerId == 0 ? 0 : objPerfil.pnPerId, DbType.Int32);
                pAddParameter(cmdSQL, "@nSisId", objPerfil.pnSisId == 0 ? 0 : objPerfil.pnSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@cPerNom", objPerfil.pcPerNom == "" ? "" : objPerfil.pcPerNom, DbType.String);
                pAddParameter(cmdSQL, "@cPerNem", objPerfil.pcPerNem == "" ? "" : objPerfil.pcPerNem, DbType.String);
                pAddParameter(cmdSQL, "@cPerDesc", objPerfil.pcPerDesc == "" ? "" : objPerfil.pcPerDesc, DbType.String);
                pAddParameter(cmdSQL, "@cOpcion", objPerfil.strOpcion == "0" ? "0" : objPerfil.strOpcion, DbType.String);
                //pAddParameter(cmdSQL, "@cEstado", objPerfil.pcEstado == "0" ? "0" : objPerfil.pcEstado, DbType.String);
                pAddParameter(cmdSQL, "@cEstado", objPerfil.pcEstado, DbType.Boolean);
                pAddParameter(cmdSQL, "@cEliminado", objPerfil.pcEliminado, DbType.Boolean);

                strResultado = fEjecutar(cmdSQL);
                //strResultado = "OK";
            }
            catch (Exception ex)
            {
                strResultado = "";
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return strResultado;
        }

        public GenericEntityDAResponse fListaPerfilesDL(PerfilBE objPerfil)
        {
            //List<PerfilBE> objListaPerfil = new List<PerfilBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ListaPerfil_new"; //js
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nSisId", objPerfil.pnSisId == 0 ? 0 : objPerfil.pnSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@nPageNumber", objPerfil.PageNumber == 0 ? 0 : objPerfil.PageNumber, DbType.Int32);
                pAddParameter(cmdSQL, "@nPageZize", objPerfil.PageSize == 0 ? 0 : objPerfil.PageSize, DbType.Int32);
                pAddParameter(cmdSQL, "@cEliminado", objPerfil.cfEliminado == null ? "" : objPerfil.cfEliminado, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);

                //DataTable dataTable = new DataTable();
                //dataTable.Load(drSQL);

                //objListaPerfil = (List<PerfilBE>)ConvertirDataReaderALista<PerfilBE>(drSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

        public GenericEntityDAResponse fListaValidarPerfilDL(PerfilBE objPerfil)
        {//ya se cambio
            //List<PerfilBE> objLista = new List<PerfilBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_ValidarPerfil";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nPerId", objPerfil.pnPerId == 0 ? 0 : objPerfil.pnPerId, DbType.Int32);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
                //objLista = (List<PerfilBE>)ConvertirDataReaderALista<PerfilBE>(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

        public GenericEntityDAResponse fListaVerificarPerfilDL(PerfilBE objPerfil)
        {
            //List<PerfilBE> objListaPerfil = new List<PerfilBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {//ya se cambio
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_VerificarPerfil";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@cPerNom", objPerfil.pcPerNom == "" ? "" : objPerfil.pcPerNom, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);
                //objListaPerfil = (List<PerfilBE>)ConvertirDataReaderALista<PerfilBE>(drSQL);
                _out.dTable1.Load(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }


        #endregion

    }
}
