﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.GeneralLayer;
namespace Seguridad.Entity.DataAccess.Seguridad
{
    public class RolDA : DBOBaseDA
    {
        SqlCommand cmdSQL = new SqlCommand();
        String strCon = ConfigurationManager.AppSettings["SEGBDConexion"].ToString();

        public GenericEntityDAResponse fListaRolesDL(RolBE objRol)
        {
            //List<RolBE> objListaRol = new List<RolBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_WOR_SEL_ListaRol_NEW";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nSisId", objRol.nSisId == 0 ? 0 : objRol.nSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@cEliminado", objRol.cRolEliminado == "" ? "" : objRol.cRolEliminado, DbType.String);
                SqlDataReader drSQL = fLeer(cmdSQL);

                if (drSQL.HasRows)
                {
                    //objListaRol = (List<RolBE>)ConvertirDataReaderALista<RolBE>(drSQL);
                    _out.dTable1.Load(drSQL);                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }

            return _out;
        }


        public GenericEntityDAResponse fListaRolesAsigandosXUsuarioDL(RolBE objRol)
        {
            //List<RolBE> objListaRol = new List<RolBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ListaRolesAsignadoXUsuario_Filter";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nSisId", objRol.nSisId == 0 ? 0 : objRol.nSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@nUsuId", objRol.nUsuId == 0 ? 0 : objRol.nUsuId, DbType.Int32);
                pAddParameter(cmdSQL, "@cRolEliminado", objRol.cRolEliminado == "" ? "" : objRol.cRolEliminado, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);

                if (drSQL.HasRows)
                {
                    //objListaRol = (List<RolBE>)ConvertirDataReaderALista<RolBE>(drSQL);
                    _out.dTable1.Load(drSQL);
                }

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }

            return _out;
        }



        public GenericEntityDAResponse fListaValidarRolDL(RolBE objRol)
        {
            //List<RolBE> objLista = new List<RolBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_ValidarRol";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nRolId", objRol.nRolId == 0 ? 0 : objRol.nRolId, DbType.Int32);
                SqlDataReader drSQL = fLeer(cmdSQL);
                _out.dTable1.Load(drSQL);
                //objLista = (List<RolBE>)ConvertirDataReaderALista<RolBE>(drSQL);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return _out;
        }

        public String fMantenimientoRolDL(RolBE objRol)
        {
            String strResultado = "";
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_Rol_new";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nRolId", objRol.nRolId == 0 ? 0 : objRol.nRolId, DbType.Int32);
                pAddParameter(cmdSQL, "@nSisId", objRol.nSisId == 0 ? 0 : objRol.nSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@cRolNom", objRol.cRolNom == "" ? "" : objRol.cRolNom, DbType.String);
                pAddParameter(cmdSQL, "@cRolNem", objRol.cRolNem == "" ? "" : objRol.cRolNem, DbType.String);
                pAddParameter(cmdSQL, "@cRolDesc", objRol.cRolDesc == "" ? "" : objRol.cRolDesc, DbType.String);
                pAddParameter(cmdSQL, "@Accion", objRol.strOpcion == "0" ? "0" : objRol.strOpcion, DbType.String);
                pAddParameter(cmdSQL, "@cEliminado", objRol.cRolEliminado == "0" ? "0" : objRol.cRolEliminado, DbType.String);
                strResultado = fEjecutar(cmdSQL);
            }
            catch (Exception ex)
            {
                strResultado = "";
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }
            return strResultado;
        }

        public GenericEntityDAResponse fListaRolesAsigandosXUsuarioSessionDL(RolBE objRol)
        {
            //List<RolBE> objListaRol = new List<RolBE>();
            GenericEntityDAResponse _out = new GenericEntityDAResponse();

            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_SEL_ListaRolesAsignadoXUsuarioSession_Filter";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();

                pAddParameter(cmdSQL, "@nSisId", objRol.nSisId == 0 ? 0 : objRol.nSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@nUsuId", objRol.nUsuId == 0 ? 0 : objRol.nUsuId, DbType.Int32);
                pAddParameter(cmdSQL, "@cOpcion", objRol.strOpcion == "" ? "" : objRol.strOpcion, DbType.String);
                pAddParameter(cmdSQL, "@cRolEliminado", objRol.cRolEliminado == "" ? "" : objRol.cRolEliminado, DbType.String);

                SqlDataReader drSQL = fLeer(cmdSQL);

                if (drSQL.HasRows)
                {
                    _out.dTable1.Load(drSQL);
                    //objListaRol = (List<RolBE>)ConvertirDataReaderALista<RolBE>(drSQL);
                }

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();

                }
            }

            return _out;
        }

        public String fMantenimientoRolXUsuarioDL(RolBE objRol)
        {
            String strResultado = "";
            try
            {
                cmdSQL.Connection = NewConnection(strCon);
                cmdSQL.CommandText = "USP_SEG_MNT_RolXUsuario";
                cmdSQL.CommandType = CommandType.StoredProcedure;
                cmdSQL.Parameters.Clear();
                pAddParameter(cmdSQL, "@nSisId", objRol.nSisId == 0 ? 0 : objRol.nSisId, DbType.Int32);
                pAddParameter(cmdSQL, "@nRolId", objRol.nRolId == 0 ? 0 : objRol.nRolId, DbType.Int32);
                pAddParameter(cmdSQL, "@nUsuId", objRol.nUsuId == 0 ? 0 : objRol.nUsuId, DbType.Int32);
                pAddParameter(cmdSQL, "@bRolFav", objRol.bRolFav == false ? false : objRol.bRolFav, DbType.Boolean);
                pAddParameter(cmdSQL, "@cOpcion", objRol.strOpcion == "" ? "0" : objRol.strOpcion, DbType.String);
                strResultado = fEjecutar(cmdSQL);
            }
            catch (Exception ex)
            {
                strResultado = "";
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                if (cmdSQL.Connection.State == ConnectionState.Open)
                {
                    cmdSQL.Connection.Close();
                }
            }

            return strResultado;
        }
    }
}
