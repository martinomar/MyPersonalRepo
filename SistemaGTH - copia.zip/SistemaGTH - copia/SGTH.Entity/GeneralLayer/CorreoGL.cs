﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace Seguridad.Entity.GeneralLayer
{
    public class CorreoGL
    {

        string HOST_MAIL = ConfigurationManager.AppSettings["HOST_MAIL"].ToString();
        string IP_HOST_MAIL = ConfigurationManager.AppSettings["IP_HOST_MAIL"].ToString();
        string USER_MAIL = ConfigurationManager.AppSettings["USER_MAIL"].ToString();
        string PASS_MAIL = ConfigurationManager.AppSettings["PASS_MAIL"].ToString();

        public void enviar(List<UsuarioBE> destinatarios, string sAsunto, string sCuerpo)
        {


            MailMessage mMailMessage = new MailMessage();
            mMailMessage.IsBodyHtml = true;
            mMailMessage.From = new MailAddress(HOST_MAIL, "Atención SAR");
            mMailMessage.To.Add(new MailAddress(destinatarios.First().pcUsuCorreo));
            mMailMessage.Subject = sAsunto;
            mMailMessage.Body = ArmaBody(sCuerpo);
            SmtpClient mSmtpClient = new SmtpClient(IP_HOST_MAIL);
            mSmtpClient.Credentials = new System.Net.NetworkCredential(USER_MAIL, PASS_MAIL);
            mSmtpClient.EnableSsl = false;
            try
            {
                mSmtpClient.Send(mMailMessage);
                return;
            }
            catch (Exception ex)
            {
                //Label5.Text = ex.InnerException.Message;
            }

        }

        public string ArmaBody(string cuerpo)
        {
            string body = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>";
            body += "<html xmlns='http://www.w3.org/1999/xhtml'><head><meta http-equiv='Content-Type' content='text/html; charset=utf-8' />";
            body += "<title>Correo SAR</title>";
            body += "<style>	.tabla_footer {		width:100%;		background-color:Transparent;		margin:auto;		border-width:0px;		border-style:solid;		border-color:#FFFFFF;	}		.footer 	{		width:100%;		height:250px;		vertical-align:bottom;		border-width:0px;		border-style:solid;		border-color:#FFFFFF;	}		.espacio	{		padding-top:0px;		border-width:0px;		border-style:solid;		border-color:#FFFFFF;	}		.footer_hr	{		width:350px;		color:#AAA;	}		.footer_div	{		width:auto;		text-align:center;		color:#777;		border-width:0px;		border-style:solid;		border-color:#FFFFFF;	}	.tabla_contenedor {		width:100%;		height:100%;		border-width:0px;		border-style:solid;		border-color:#FFFFFF;		margin:auto;		vertical-align:middle;	}		.logo {		width:50%;		height:69px;		border-width:0px;		border-style:solid;		border-color:#FFFFFF;		margin:auto;	}	.tabla_maestra {		width:100%;		height:100%;		border-width:0px;		border-style:solid;		border-color:#FFFFFF; background-repeat:no-repeat;	}</style>";
            body += "</head><body><table class='tabla_maestra' cellpadding=0 cellspacing=0>";
            body += "<tr><td align='center'><img src='http://www.sessarperu.com/App_Themes/Imagenes/logo.png' /></td></tr>";
            body += "<tr><td>";
            body += cuerpo;
            body += "</td></tr><tr><td><div class='footer_div'>© " + DateTime.Now.Year.ToString() + " SES - SAR 4.0 - Todos los derechos reservados.</div></td></tr><tr></table></body></html>";

            return body;
        }

    }
}
