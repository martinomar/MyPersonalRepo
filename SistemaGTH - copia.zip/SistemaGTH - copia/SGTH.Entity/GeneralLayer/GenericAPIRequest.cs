﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.GeneralLayer
{
    public class GenericAPIRequest
    {
        public int nPrm_1 { get; set; }
        public int nPrm_2 { get; set; }
        public int nPrm_3 { get; set; }
        public int nPrm_4 { get; set; }

        public string cPrm_1 { get; set; }
        public string cPrm_2 { get; set; }
        public string cPrm_3 { get; set; }
        public string cPrm_4 { get; set; }
    }
}
