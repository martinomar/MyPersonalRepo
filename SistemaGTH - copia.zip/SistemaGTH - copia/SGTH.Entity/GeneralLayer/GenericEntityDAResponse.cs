﻿/*-------------------------------------------------------------------------------------------------*
* SISTEMA		: Ficha Postulante
* SUBSISTEMA	: FP
* NOMBRE		: GenericDAListResponse.cs
* DESCRIPCIÓN	: contiene los metodos API de mantenimiento
* AUTOR		    : Martin Delgado
* FECHA		    : 2018-09-14 (yyyy-mm-dd)
* 
*====================┬=============================┬========================================================*
* FECHA (yyyy-mm-dd)   EMPLEADO                       MODIFICACIÓN
*====================┼=============================┼========================================================*
* 2018-09-14           Martin.Delgado                   creacion y DefiniciÓn de propiedades
*--------------------┼-----------------------------┼--------------------------------------------------------*
*
*--------------------┴-----------------------------┴--------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace SGTH.Entity.GeneralLayer
{
    public class GenericEntityDAResponse
    {
        public List<object> gList1;
        public List<object> gList2;
        public List<object> gList3;
        public List<object> gList4;
        public DataTable dTable1;
        public DataTable dTable2;
        public DataTable dTable3;
        public DataTable dTable4;
        public string cMsg1;
        public string cMsg2;
        public string cMsg3;
        public string cMsg4;
        public string cError;
        public int nAttr1;
        public int nAttr2;
        public int nAttr3;
        public int nAttr4;
        public string cAttr1;
        public string cAttr2;
        public string cAttr3;
        public string cAttr4;
        public string cAttr5;
        public object obj1;
        public System.Diagnostics.StackTrace oTraceError;

        public GenericEntityDAResponse()
        {
            this.gList1 = new List<object>();
            this.gList2 = new List<object>();
            this.gList3 = new List<object>();
            this.gList4 = new List<object>();
            this.dTable1 = new DataTable();
            this.dTable2 = new DataTable();
            this.dTable3 = new DataTable();
            this.dTable4 = new DataTable();
            this.cMsg1 = "";
            this.cMsg2 = "";
            this.cMsg3 = "";
            this.cMsg4 = "";
            this.cError = "";
            nAttr1 = 0;
            nAttr2 = 0;
            nAttr3 = 0;
            nAttr4 = 0;
            this.cAttr1 = "";
            this.cAttr2 = "";
            this.cAttr3 = "";
            this.cAttr4 = "";
            this.cAttr5 = "";
            this.obj1 = new object();
    }
    }
}
