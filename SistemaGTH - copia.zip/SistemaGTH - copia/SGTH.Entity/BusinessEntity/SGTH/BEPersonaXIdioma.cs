﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEPersonaXIdioma
    {
        public int pnPrsId { get; set; }

        public int pnIdiomaId { get; set; }
        public String pcIdioma { get; set; }

        public int pnNivelEscritoId { get; set; }
        public String pcNivelEscrito { get; set; }

        public int pnNivelOralId { get; set; }
        public String pcNivelOral { get; set; }

        public string strOpcion { get; set; }
        public string pcEstado { get; set; }
    }
}
