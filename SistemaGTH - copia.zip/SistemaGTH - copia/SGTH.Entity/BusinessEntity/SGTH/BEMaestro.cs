﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEMaestro
    {

        public Int32 pnSisId { get; set; }

        public Int32 pnMaeId { get; set; }

        public Int32 pnMaeItem { get; set; }

        public String pcMaeDenom { get; set; }

        public String pcMaeDesc { get; set; }

        public String pcMaeValor { get; set; }

        public String pcMaeActivo { get; set; }

        public String pcSegMaeEliminado { get; set; }

        public String pcSisEliminado { get; set; }

        //Enpaginado

        public Int32 PageNumber { get; set; }

        public Int32 PageSize { get; set; }

        public Int32 TotalPages { get; set; }

        public Int32 pnTotalRows { get; set; }

        // Fechas


        public DateTime pdFechaIni { get; set; }
        public DateTime pdFechaFin { get; set; }


        public Int32 pnCodTipo { get; set; }

        public Int32 pnCodPeriodo { get; set; }
    }
}
