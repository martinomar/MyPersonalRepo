﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEPersonaXTratamientoEnfermedad
    {
        public int pnPrsId { get; set; }
        public string pcTratmnto_enfermd { get; set; }
        public string pcInstituto { get; set; }
        public string pcTiempoPreexistencia { get; set; }
        public int pnAnioInicio { get; set; }
        public string strOpcion { get; set; }
        public string pcEstado { get; set; }
    }
}
