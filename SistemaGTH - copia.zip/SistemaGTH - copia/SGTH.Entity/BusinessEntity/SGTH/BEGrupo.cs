﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEGrupo
    {

        public int pnGrpId { get; set; }


        public int pnRpsId { get; set; }


        public string pvRpsNom { get; set; }


        public string pvDescripcion { get; set; }


        public int pnItg { get; set; }


        public int pnClienteId { get; set; }


        public string pvCliNom { get; set; }

        //Nuevo campo para controlar si el grupo está habilitado para los correos

        public string pcEnvCorreo { get; set; }


        public int pnUsuId { get; set; }

        //Enpaginado
        public Int32 Opcion { get; set; }

        public String pcOpcion { get; set; }

        public Int32 PageNumber { get; set; }

        public Int32 PageSize { get; set; }

        public Int32 TotalPages { get; set; }


        public Int32 pnTotalRows { get; set; }


        //----------------------------

        public int pnPrsId { get; set; }


        public string pvPrsNom { get; set; }



        public Int32 pnPersonaId { get; set; }


        public String pvNombres { get; set; }


        public Int32 pnPntMrcId { get; set; }


        public String pcEnvCorreoTexto { get; set; }

        //----Campos reporte----

        public DateTime pdtFechaInicio { get; set; }
        public DateTime pdtFechaFin { get; set; }

        public String pcEstado { get; set; }
        public int pnRespGrpId { get; set; }
        public DateTime pdtFchRegistro { get; set; }
        public DateTime pdtFchModificacion { get; set; }
    }
}
