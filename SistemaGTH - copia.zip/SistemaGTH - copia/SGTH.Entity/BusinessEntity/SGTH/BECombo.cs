﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BECombo
    {
      
        public string cCodigo { get; set; }
        public string cTexto { get; set; }
    }
}
