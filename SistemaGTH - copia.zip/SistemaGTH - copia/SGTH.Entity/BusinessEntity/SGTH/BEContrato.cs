﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEContrato
    {

        public int pnContratoId { get; set; }


        public int pnPersonaId { get; set; }


        public int pnEmpId { get; set; }

        //MAT INI

        public int pnTipoContratoId { get; set; }
        //MAT FIN


        public string pvEmpRazSoc { get; set; }


        public int pnProyectoId { get; set; }


        public string pvProyectoDesc { get; set; }


        public int pnCargoId { get; set; }


        public string pvCargoDesc { get; set; }


        public int pnPerfilId { get; set; }


        public string pvPerfilDesc { get; set; }


        public int pnModalidadId { get; set; }


        public string pvModalidadDesc { get; set; }


        public int pnAreaId { get; set; }


        public String pvAreaDesc { get; set; }


        public string pcEstado { get; set; }


        public string pdtFchInicio { get; set; }


        public string pdtFchFin { get; set; }


        public string pcRenovable { get; set; }


        public string pvMotRenovable { get; set; }


        public string pcMinTra { get; set; }


        public DateTime pdtFecVenContratoIni { get; set; }


        public DateTime pdtFecVenContratoFin { get; set; }

        //JBT

        public String pvCorreo { get; set; }

        //INI AAB 20160711 - SESNEW

        public string pcOpcionElimina { get; set; }
        //FIN AAB 20160711 - SESNEW

        public int pnUsuID { get; set; }
        public int pnOrden { get; set; }
        public int pnIncluirRenovados { get; set; }
        public string strOpcion { get; set; }

        //INI AAB 20160801 - SESNEW
        public int pnPagina { get; set; }

        public int pnTotalFilas { get; set; }

        public int pnFila { get; set; }
        public int pnFilaInicio { get; set; }
        public int pnFilaFin { get; set; }
        public int pnPageSize { get; set; }
        //FIN AAB 20160801 - SESNEW


        public int pnTipoAreaId { get; set; }


        public String pvTipoAreaDesc { get; set; }

        //INI JBT 20160907 - SESNEW
        public Int32 pnGrupoId { get; set; }
        //FIN JBT 20160907 - SESNEW
    }
}
