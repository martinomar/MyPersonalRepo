﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEPaseColaborador
    {
        public BEPostulante objPostulante { get; set; }
        public BEContrato objContrato { get; set; }
        public BEProyecto objProyecto { get; set; }
        public BEProvision objProvision { get; set; }

    }
}
