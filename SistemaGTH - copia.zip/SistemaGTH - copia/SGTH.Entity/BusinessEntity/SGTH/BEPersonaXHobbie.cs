﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEPersonaXHobbie
    {
        public Int32 pnPrsId { get; set; }

        //Hobbie 25/14
        public Int32 pnHobbieId { get; set; }

        public String pvHobbie { get; set; }

        //Frecuencia 25/30
        public Int32 pnFrecuenciaId { get; set; }

        public String pvFrecuencia { get; set; }

        //Nivel cod 25/5
        public Int32 pnNivelId { get; set; }

        public String pvNivel { get; set; }

        //0 inactivo, 1 activo
        public string pcEstado { get; set; }
        public string strOpcion { get; set; }
        public Int32 pvMvmId { get; set; }

    }
}
