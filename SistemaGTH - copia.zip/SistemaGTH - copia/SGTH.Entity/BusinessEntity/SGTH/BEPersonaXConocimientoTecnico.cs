﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEPersonaXConocimientoTecnico
    {
        public BEPersonaXConocimientoTecnico()
        {
            pnPrsId = 0;
            pnTpoTecnologiaId = 0;
            pvTpoTecnologia = "";
            pnTcnId = 0;
            pvTecnologia = "";
            pnNivelId = 0;
            pvNivel = "";
            pcEstado = "";
            PageNumber = 1;
            PageSize = 1;
        }

        //JBT

        public Int32 pnRowId { get; set; }


        public String pnAuxId { get; set; }
        //JBT


        public Int32 pnPrsId { get; set; }

        //Tipo Tecnología cod 25/15

        public Int32 pnTpoTecnologiaId { get; set; }


        public String pvTpoTecnologia { get; set; }

        //Tecnología

        public Int32 pnTcnId { get; set; }


        public String pvTecnologia { get; set; }

        //Nivel cod 25/5

        public Int32 pnNivelId { get; set; }


        public String pvNivel { get; set; }

        //0 inactivo, 1 activo

        public string pcEstado { get; set; }

        public Int32 PageNumber { get; set; }
        public Int32 PageSize { get; set; }
        public Int32 TotalPages { get; set; }

        public string strOpcion { get; set; }
    }
}
