﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEPersonaXFamilia
    {
        public String pnAuxId { get; set; }


        public Int32 pnPrsId { get; set; }


        public String pvNombres { get; set; }


        public String pvApePaterno { get; set; }


        public String pvApeMaterno { get; set; }


        public Int32 pnParentesco { get; set; }


        public String pvParentesco { get; set; }


        public String pcVive { get; set; }


        public Int32 pnGenero { get; set; }


        public String pvGenero { get; set; }


        public DateTime pdtFchNac { get; set; }


        public String pvDocNro { get; set; }


        public String pvOcupacion { get; set; }



        public Int32 pnOcupacion { get; set; }


        public String pcDerHab { get; set; }

        public String pcOpcion { get; set; }



        public int pnEdad { get; set; }
        public int pnGradoInstruccionID { get; set; }
        public string pcGradoInstruccion { get; set; }

    }
}
