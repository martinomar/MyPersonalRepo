﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BESubLineaServicio
    {
        public Int32 pnSubLineaServicioCodigo { get; set; }
        public Int32 pnLineaServicioCodigo { get; set; }
        public string pcSubLineaServicioNombre { get; set; }
        public string pcSubLineaServicioAbreviatura { get; set; }
        public string pcEliminado { get; set; }
    }
}
