﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEPuntoMarcacion
    {
        //----------Consulta de Puntos de Marcacion---------

        public Int32 pnPntMrcId { get; set; }


        public String pvDescripcion { get; set; }


        public Int32 pnSedeId { get; set; }


        public String pvEstado { get; set; }

        public String pcEstado { get; set; }


        //Nombre Sede y Nombre Calendario

        public String pvNombre { get; set; }

        //Calendario

        public int pnClnId { get; set; }

        // paginacion
        public Int32 PageNumber { get; set; }
        public Int32 TotalPages { get; set; }
        public Int32 PageSize { get; set; }

        public Int32 pnTotalRows { get; set; }


        public Int32 Opcion { get; set; }
        public string cOpcion { get; set; }
        //pnCalendarioId
        public Int32 pnCalendarioId { get; set; }


        //Id de Asociacion entre Punto de Marcacion y Calendario
        public Int32 pnPntClnId { get; set; }

        public string strOpcion { get; set; }



        //Id del dispositivo para extraer las marcaciones
        public Int32 pnDeviceId { get; set; }

        //Para una persona
        public Int32 pnPrsId { get; set; }

        public Boolean pbCheck { get; set; }

        public DateTime pdtFechaInicio { get; set; }

        public Int32 pnUsuId { get; set; }

        public String pcPuntos { get; set; }

        public String pcFechaInicio { get; set; }
    }
}
