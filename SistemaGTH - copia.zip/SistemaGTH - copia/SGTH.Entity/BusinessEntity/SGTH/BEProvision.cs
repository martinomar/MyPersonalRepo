﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEProvision
    {
        //INI JGA 02-03-2017 - SESNEW
        public DateTime pdtFchIni { get; set; }
        //FIN JGA 02-03-2017 - SESNEW

        public Int32 pnPrsId { get; set; }

        public DateTime pdtFechaIngreso { get; set; }

        //INI DDD 07-02-2017 SESNEW
        public DateTime pdtFechaFin { get; set; }

        public Int32 pnMesesProv { get; set; }

        public Int32 pnMesPeriodo { get; set; }

        public Int32 pnAnioPeriodo { get; set; }

        public Decimal pnDiasPendientes { get; set; }

        public Decimal pnDiasPendProvision { get; set; }

        public Int32 pnDiasTomados { get; set; }

        public Int32 pnDiasPeriodo { get; set; }


        public Int32 pnProVacId { get; set; }


        public Int32 pnAnioPer { get; set; }
        //FIN DDD 07-02-2017 SESNEW


        //INI DDD 16-02-2017 SESNEW

        public Int32 pnIdSeguridad { get; set; }


        public DateTime pdtFchInicioContrato { get; set; }


        public DateTime pdtFchFinContrato { get; set; }


        public DateTime pdtFchActual { get; set; }


        public String pvNombreCompleto { get; set; }

        //FIN DDD 16-02-2017 SESNEW



        public DateTime pdtFechaProvision { get; set; }

        public Decimal pnDiasVacaciones { get; set; }

        public Decimal pnDiasProvision { get; set; }

        public Int32 pnUsuId { get; set; }

        public Int32 pnGrupoId { get; set; }

        public String pvColaboradorNombre { get; set; }

        public Int32 pnColaboradorId { get; set; }

        public Int32 pnRolId { get; set; }

        public Int32 pnPageSize { get; set; }

        public Int32 pnPage { get; set; }

        //INI DDD 20-12-2017 SES NEW
        public Int32 pnCliente { get; set; }
        public Int32 pnLinServ { get; set; }
        public DateTime pdtFchCorte { get; set; }
        public Int32 pnLiderId { get; set; }


        public String pvCorreo { get; set; }


        public String pvLider { get; set; }


        public Int32 pnTotColaboradores { get; set; }


        public Int32 pnPrsIdLider { get; set; }


        public String pvLiderComp { get; set; }

        public String pvVP { get; set; }
        public String pvVPP { get; set; }
    }
}
