﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEPostulante
    {
        public BEPostulante()
        { }

        public BEPostulante(int nFicId, int nPersonaId, string vNombresApellidos, int nCrgPrsId, string vCrgPresentarse, string vTecnologiaMas, int nTpoAceptacionId, string vTpoAceptacion, int nMtvAceptacion, string vMtvAceptacion, bool bObservado)
        {
            pnPersonaId = nPersonaId;
            pnFicId = nFicId;
            pvApellidosNombres = vNombresApellidos;
            pnCrgPresentarseId = nCrgPrsId;
            pvCrgPresentarse = vCrgPresentarse;
            pvTecnologia = vTecnologiaMas;
            pnTpoAceptacion = nTpoAceptacionId;
            pvTpoAceptacion = vTpoAceptacion;
            //pnMtvAceptacion = nMtvAceptacion;
            pvMtvAceptacion = vMtvAceptacion;
            //pbObservado = bObservado;
        }

        public Int32 pnPersonaId { get; set; }

        //Código Del Postulante o Colaborador
        public Int32 pvCodPrs { get; set; }

        //Pendiente que Shely cambie el tipo de FichaId de Int a Char(#)
        public Int32 pnFicId { get; set; }

        //Persona que dio referencia de SES
        public string pvReferencia { get; set; }

        public string pvNombres { get; set; }

        public string pvApePaterno { get; set; }

        public string pvApeMaterno { get; set; }

        //Apellidos y Nombres (Concatenado)
        public string pvApellidosNombres { get; set; }

        public Int32 pnNacionalidad { get; set; }

        public string pdtFchNacimiento { get; set; }

        //INI DDD 14-02-2017 SESNEW
        public string pdtFchVenDoc { get; set; }
        //FIN DDD 14-02-2017 SESNEW

        public Int32 pnEdad { get; set; }

        //Distrito Nacimiento
        public Int32 pnDstNacId { get; set; }

        //Provincia Nacimiento
        public Int32 pnPrvNacId { get; set; }

        //Departamento Nacimiento
        public Int32 pnDptNacId { get; set; }


        public Int32 pnEstCivil { get; set; }

        public Decimal pnHijos { get; set; }

        public string pvDocNro { get; set; }

        public string pvReligion { get; set; }

        //Distrito Domicilio
        public Int32 pnDstDmcId { get; set; }

        //Provincia Domicilio
        public Int32 pnPrvDmcId { get; set; }

        //Departamento Domicilio
        public Int32 pnDptDmcId { get; set; }

        public string pvDmcDireccion { get; set; }

        public string pvDmcReferencia { get; set; }

        public string pvTelefono { get; set; }

        public string pvTelefonoCelular { get; set; }

        public string pvContactFamTelef { get; set; }

        public string pvContactFamNombr { get; set; }

        public string pvOtroTelefono { get; set; }

        public string pvCorreo { get; set; }

        public string pvTecnologia { get; set; }

        public string pvTecMasCnc { get; set; }

        public string pcSexo { get; set; }

        //----------Datos de Cargo a Presentarse----------

        public Int32 pnCrgPresentarseId { get; set; }

        //
        public string pvCrgPresentarse { get; set; }

        //---------Datos Canal Reclutamiento
        public Int32 pnCanalId { get; set; }

        public string pvCanalReclutamiento { get; set; }

        //---------Datos de Tipo de Aceptación ------------

        public Int32 pnTpoAceptacion { get; set; }

        public string pvTpoAceptacion { get; set; }

        public Int32 pnMtvAceptacionId { get; set; }

        public string pvMtvAceptacion { get; set; }

        public string pcObservado { get; set; }

        //---------Datos de Grado de Instrucción ------------

        public Int32 pnGrdInstruccionId { get; set; }

        public string pvGrado { get; set; }

        //---------Datos de Centro de Estudios --------------

        public Int32 pnCtrEstId { get; set; }

        public string pvCtrEstDesc { get; set; }

        //--------Datos de la Carrera Profesional------------

        public Int32 pnCarreraProfId { get; set; }

        public string pvCarreraProf { get; set; }


        //Salud
        public string pcEnfermedad { get; set; }

        public string pcEmbarazo { get; set; }

        public int pnTmpEmbarazo { get; set; }

        public string pcEstado { get; set; }

        //--------Datos de Tipo Persona (Postulante/Colaborador)-----

        //Tipo Persona: Postulante (1), Colaborador (2) 
        public Int32 pnTpoPersonaId { get; set; }

        public string pvTipoPersona { get; set; }

        //--------Datos del Colaborador-----------------------------
        public string pvCorColaborador { get; set; }

        public Int32 pnAnexo { get; set; }

        public int pnPntClnId { get; set; }

        public Int32 pnIdRDA { get; set; }

        public Int32 pnIdSeguridad { get; set; }

        public string pdtFchIngreso { get; set; }



        public Int32 pnEquipoId { get; set; }

        public Int64 pcValidacion { get; set; }

        public Int32 pnTotalRows { get; set; }

        public String pcUsuNomCompleto { get; set; }

        public Int32 pnSisSarFabricaId { get; set; }
        public Int32 PageNumber { get; set; }
        public Int32 PageSize { get; set; }
        public Int32 TotalPages { get; set; }
        public string strOpcion { get; set; }

        public String pcEquipoNombre { get; set; }
        public string pcAreaNombre { get; set; }

        public Int32 pnBancoId { get; set; }

        public String pcNroCuenta { get; set; }

        public String pcNroCtaInter { get; set; }

        //INI JGA 10-03-2017 - SESNEW
        public Int32 pnTpoColab { get; set; }

        public Int32 pnModForm { get; set; }
        //FIN JGA 10-03-2017 - SESNEW



        //Antecedentes--------------

        public string pcAntPenales { get; set; }


        public string pcAntPoliciales { get; set; }

        public string pcDeudor { get; set; }


        //----------------------Datos Auditoria--------------------------

        public Int32 pnUsuarioRegistraId { get; set; }


        public string pcPrimrTrbj { get; set; }

        public string pcModalidaRegistro { get; set; }
        /* id = 1, manual:registra al postulante 
        * id = 2.1, virtual: registro por el postulante(pre-registro), el analista de selección registra al postulante" con sus datos minimos
        * id = 2.2, virtual: el postulante "actualiza" su registro a través de la "ficha de postulante", al cual el postulante accede por medio de la URL encriptada
        *
        */


        /*LISTADOS ---*/
        public List<BEPersonaXEstudio> pLisEstSupe { get; set; }
        public List<BEPersonaXCertificacion> pListCertif { get; set; }
        public List<BEPersonaXConocimientoTecnico> pListConcTe { get; set; }
        public List<BEPersonaXIdioma> pListIdioma { get; set; }

        public List<BEPersonaXExperienciaLaboral> pListExpLbs { get; set; }
        public List<BEPersonaXReferencia> pListRefLab { get; set; }
        public List<BEPersonaXReferencia> pListRefFam { get; set; }

        public List<BEPersonaXDeuda> pListDeudas { get; set; }
        public List<BEPersonaXAntecedente> pListAntPen { get; set; }
        public List<BEPersonaXAntecedente> pListAntPol { get; set; }

        public List<BEPersonaXTratamientoEnfermedad> pListEnferm { get; set; }

        public List<BEPersonaXFamilia> pListCrgFam { get; set; }
        public List<BEPersonaXHobbie> pListHobbie { get; set; }

    }
}
