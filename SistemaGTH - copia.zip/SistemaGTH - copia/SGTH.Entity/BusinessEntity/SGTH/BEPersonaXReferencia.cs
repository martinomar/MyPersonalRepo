﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEPersonaXReferencia
    {
        public int pnPrsId { get; set; }
        public int pnTipoRef { get; set; }
        public string pvTipoRef { get; set; }
        public string pvEmpresa { get; set; }
        public string pcNombrRepresentante { get; set; }
        public string pcCargoRepresentante { get; set; }
        public string pcTelefRepresentante { get; set; }

        public string strOpcion { get; set; }
        public string pcEstado { get; set; }
    }
}
