﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BELineaServicio
    {
        public Int32 pnLineaServicioCodigo { set; get; }

        public string pcLineaServicioNombre { set; get; }

        public string pcLineaServicioAbreviatura { set; get; }

        public string pcEliminado { set; get; }

        public Int32 pnTipoGrupo { set; get; }

    }
}
