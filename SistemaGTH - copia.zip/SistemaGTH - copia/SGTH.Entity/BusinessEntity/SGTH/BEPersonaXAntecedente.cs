﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEPersonaXAntecedente
    {
        //TABLA "AntecedentesPenales"


        public Int32 pnPrsId { get; set; }


        public Int32 nAntcdntId { get; set; }

        //Aquí avisar a DBA

        public String pcFchProceso { get; set; }


        public string pvMotivo { get; set; }


        public string pvResultado { get; set; }

        public Int32 pnTipoAnt { get; set; } //1="Penal", 2="Policial"

        public string pcTipoAnt { get; set; } //1="Penal", 2="Policial"

        //0 inactivo, 1 activo

        public string pcEstado { get; set; }


        public string strOpcion { get; set; }
    }
}
