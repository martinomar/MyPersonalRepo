﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEEmpresa
    {
        public String pvRznSocial { get; set; }

        public Int32 pnEmpId { get; set; }

        //INI DDD 24-02-2017 SESNEW
        public string pcAliasEmp { get; set; }
    }
}
