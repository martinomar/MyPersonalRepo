﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEProvincia
    {

        public Int32 pnPrvId { get; set; }


        public String pvProvincia { get; set; }


        public String pcEstado { get; set; }


        public Int32 pnDptId { get; set; }

        public string strOpcion { get; set; }
    }
}
