﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BESalud
    {
        public int nSldId { get; set; }
        public int nPrsId { get; set; }
        public string vDescripcion { get; set; }
        public string vInstituto { get; set; }
        public int vTiempo { get; set; }
        public DateTime dtFchInicio { get; set; }
        public DateTime dtFchFin { get; set; }
        public string cEstado { get; set; }
        public string vMvmId { get; set; }
    }
}
