﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BECalendarioXPuntoRDA
    {
       
        public int pnSdeId { get; set; }

     
        public string pvSdeNombre { get; set; }

        public int pnPntMrcId { get; set; }

        public string pvPntDescripcion { get; set; }

        public int pnPntClnId { get; set; }

        public int pnClnId { get; set; }

        public string pvClnNombre { get; set; }

        //Nombre del calendario
        public string pvNombre { get; set; }

        //Paginacion
        public Int32 PageNumber { get; set; }
        public Int32 TotalPages { get; set; }
        public Int32 PageSize { get; set; }

        public Int32 pnTotalRows { get; set; }
    }
}
