﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEConocimientoNegocio

    {
        public String pnAuxId { get; set; }


        public Int32 pnRowId { get; set; }


        public Int32 pnPrsId { get; set; }

        public Int32 pnConNegocioId { get; set; }


        public String pvDesConNegocio { get; set; }


        public Int32 pnTpoConNegocioId { get; set; }

        public String pvTpoConNegocio { get; set; }


        public String pcEstado { get; set; }


        public Int32 pnNivel { get; set; }


        public String pvNivel { get; set; }


        public Int32 pnTotalRows { get; set; }


        public Int32 pnSisId { get; set; }

        public String pcOpcion { get; set; }

        //Paginacion
        public Int32 PageNumber { get; set; }
        public Int32 TotalPages { get; set; }
        public Int32 PageSize { get; set; }
    }
}