﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEArea
    {

        public Int32 pnAreaId { get; set; }

        public string pcAreaNombre { get; set; }

        public string pcAreaDescripcion { get; set; }

        public string pcAreaAbreviatura { get; set; }

        public string pcAreaApoyo { get; set; }

        public Int32 pnAreaSuperiorId { get; set; }

        public Int32 pnEmpresaId { get; set; }

        public string pcEliminado { get; set; }
    }
}
