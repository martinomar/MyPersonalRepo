﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEProyecto
    {

        public Int32 pnProyectoId { get; set; }


        public String pvDescripcion { get; set; }


        public Int32 pnTipCalendarioId { get; set; }


        public Int32 pnSedeId { get; set; }


        public Int32 pnPrsId { get; set; }


        public Int32 pnCliId { get; set; }


        public DateTime pdtFchInicio { get; set; }


        public DateTime pdtFchFin { get; set; }


        public Int32 pnGrpId { get; set; }
    }
}
