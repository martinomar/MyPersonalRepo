﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BETipoAceptacionXMotivo
    {

        public Int32 pnMtvId { get; set; }


        public String pvMotivo { get; set; }


        public Int32 pnTpoAceptacion { get; set; }


        public String pcEstado { get; set; }


        public Int32 pnPersonaId { get; set; }


        public Int32 pnFicId { get; set; }

        public string strOpcion { get; set; }
    }
}
