﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEDepartamento
    {

        public Int32 pnDptId { get; set; }


        public String pvDepartamento { get; set; }


        public String pcEstado { get; set; }


        public Int32 pnIdNacionalidad { get; set; }

        public string strOpcion { get; set; }
    }
}
