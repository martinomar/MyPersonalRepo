﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEDistrito
    {

        public Int32 pnDstId { get; set; }


        public String pvDistrito { get; set; }


        public String pcEstado { get; set; }

        //Provincia _Id

        public Int32 pnPrvId { get; set; }

        //Zona _Id

        public Int32 pnZona { get; set; }

        public string strOpcion { get; set; }
    }
}
