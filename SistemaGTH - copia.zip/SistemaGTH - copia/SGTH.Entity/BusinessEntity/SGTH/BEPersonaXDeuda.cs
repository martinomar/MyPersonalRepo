﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEPersonaXDeuda
    {
        public int pnPrsId { get; set; }
     
        public String pvEmpresa { get; set; }
        public String pdtFchRegistro { get; set; }
        public String pvMotivoRegistro { get; set; }
        public double pnMontoDeuda { get; set; }

        public int pbDeudaActual { get; set; }

        public String pdtFchLevantamiento { get; set; }
        public string strOpcion { get; set; }
        public string pcEstado { get; set; }
    }
}
