﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEPersonaXCertificacion
    {
        public int nPrsId { get; set; }
        public String cCursoNombr { get; set; }
        public String cCentrEstud { get; set; }

        public int nNivCertifObtenidoID { get; set; }
        public String cNivCertifObtenido { get; set; }

        public String cDuracion { get; set; }
        public int nAnioCertif { get; set; }
        public string cDocAdjunto { get; set; }

        public string strOpcion { get; set; }
        public string pcEstado { get; set; }
    }
}
