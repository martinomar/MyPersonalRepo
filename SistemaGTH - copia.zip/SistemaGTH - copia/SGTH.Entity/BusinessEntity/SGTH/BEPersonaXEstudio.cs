﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEPersonaXEstudio
    {
        public BEPersonaXEstudio()
        {
            pnPrsId = 0;
            pnFicId = 0;
            pnEstSupId = 0;
            pnTipoId = 0;
            pvTipo = "";
            pnEstId = 0;
            pvEstudio = "";
            pnCtrEstId = 0;
            pvCentroEstudio = "";
            pvPrdInicio = "";
            pcPrdInicioDesc = "";
            pvPrdFin = "";
            pcPrdFinDesc = "";
            pnTpoGradoId = 0;
            pvTpoGrado = "";
            pcEstado = "";
            PageNumber = 1;
            PageSize = 1;
            pcDocAdjunto = "";
        }

        //JBT

        public Int32 pnRowId { get; set; }


        public String pnAuxId { get; set; }


        public Int32 pnCorId { get; set; }
        //JBT


        public Int32 pnPrsId { get; set; }


        public Int32 pnFicId { get; set; }


        public Int32 pnEstSupId { get; set; }

        //(PreGrado, PostGrado, Técnico....) cod 25/10

        public Int32 pnTipoId { get; set; }


        public string pvTipo { get; set; }

        //Estudios/Carreras

        public Int32 pnEstId { get; set; }


        public string pvEstudio { get; set; }

        //(Instituto, Universidad....) cod 25/11

        public Int32 pnTpoCtrEstId { get; set; }


        public string pvTpoCtrEst { get; set; }

        //Centro de Estudios

        public Int32 pnCtrEstId { get; set; }


        public string pvCentroEstudio { get; set; }

        //Periodo

        public string pvPrdInicio { get; set; }


        public string pcPrdInicioDesc { get; set; }


        public string pvPrdFin2 { get; set; }


        public string pvPrdFin { get; set; }


        public string pcPrdFinDesc { get; set; }
        //Grado/Condición (Egresado, Bachiller, Titulado..) cod 25/13

        public Int32 pnTpoGradoId { get; set; }


        public string pvTpoGrado { get; set; }


        public string pcDocAdjunto { get; set; }
        //0 inactivo, 1 activo

        public string pcEstado { get; set; }
        public Int32 PageNumber { get; set; }
        public Int32 PageSize { get; set; }
        public Int32 TotalPages { get; set; }
        public string strOpcion { get; set; }
        public int pvMvmId { get; set; }

    }
}
