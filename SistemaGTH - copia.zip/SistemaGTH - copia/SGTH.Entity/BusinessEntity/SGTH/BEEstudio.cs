﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEEstudio
    {

        public Int32 pnEstId { get; set; }


        public String pvEstudio { get; set; }


        public Int32 pnTipo { get; set; }


        public String pcEstado { get; set; }


        public String pvTipo { get; set; }

        public String pcOpcion { get; set; }


        public Int32 pnTotalRows { get; set; }

        public Int32 pnSisId { get; set; }

        //Paginacion
        public Int32 PageNumber { get; set; }
        public Int32 TotalPages { get; set; }
        public Int32 PageSize { get; set; }
    }
}
