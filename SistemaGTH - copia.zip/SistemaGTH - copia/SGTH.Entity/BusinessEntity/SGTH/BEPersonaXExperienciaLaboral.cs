﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEPersonaXExperienciaLaboral
    {
        public BEPersonaXExperienciaLaboral()
        {
            pnPrsId = 0;
            pnFicId = 0;
            pnExpLbrId = 0;
            pvEmpresa = "";
            pvPuesto = "";
            pcFchInicio = "";

            pcFchFin = "";
            pcFchInicioDesc = "";
            pcFchFinDesc = "";
            pnSueldo = 0;
            pcEnPlanilla = "";
            pvMtvCese = "";
            pcEstado = "";
            PageNumber = 1;
            PageSize = 1;
        }

        //JBT

        public Int32 pnRowId { get; set; }


        public String pnAuxId { get; set; }
        //JBT


        public Int32 pnPrsId { get; set; }


        public Int32 pnFicId { get; set; }


        public Int32 pnExpLbrId { get; set; }


        public string pvEmpresa { get; set; }


        public string pvPuesto { get; set; }


        public String pcFchInicio { get; set; }


        public String pcFchFin { get; set; }


        public Decimal pnSueldo { get; set; }


        public string pcEnPlanilla { get; set; }


        public string pvEnPlanilla { get; set; }


        public string pvMtvCese { get; set; }

        //0 inactivo, 1 activo

        public string pcEstado { get; set; }

        public string pcFchInicioDesc { get; set; }
        public string pcFchFinDesc { get; set; }

        public Int32 PageNumber { get; set; }
        public Int32 PageSize { get; set; }
        public Int32 TotalPages { get; set; }
        public string strOpcion { get; set; }

        public string pcHerramientaUsada { get; set; }
        public int pnTipoContratoID { get; set; }
        public string pcTipoContrato { get; set; }

        public string pnRfrNumero { get; set; }
        public string pvRfrNombre { get; set; }
        public string pvMvmId { get; set; }

        public string pdtFchInicio { get; set; }
        public string pdtFchFin { get; set; }

        public string pcFchInicio_parsed { get; set; }
        public string pcFchFin_parsed { get; set; }

    }
}
