﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEConsolidadoAsistenciaPlanilla
    {
        public int nConsAsistPlaId { get; set; }
        public int nPeriodo { get; set; }
        public int nAreaId { get; set; }
        public string cAreaNombre { get; set; }
        public int vCodPrs { get; set; }
        public string cNombres { get; set; }
        public int nTpoColab { get; set; }
        public int nTpoModalidad { get; set; }
        public string cTpoColab { get; set; }
        public DateTime dtFechaInicio { get; set; }
        public DateTime dtFechaFin { get; set; }
        public int nDias { get; set; }
        public string cHorasTarde { get; set; }
        public string cHorasPorRecuperar { get; set; }
        public int nTipoAus { get; set; }
        public string cTipoAus { get; set; }
        public int nAplica { get; set; }
        public string cHorasAplica { get; set; }
        public int nUsuReg { get; set; }
        public DateTime dtFechaReg { get; set; }
        public int nUsuMod { get; set; }
        public DateTime dtFechaMod { get; set; }
        public int nEstadoReg { get; set; }
        public string cEstadoReg { get; set; }
        public string cObservacion { get; set; }
        public string cComentario { get; set; }
        public int nEliminado { get; set; }
        public List<BEConsolidadoAsistenciaPlanillaObservacion> LisObs { get; set;}
    }
    public class BEConsolidadoAsistenciaPlanillaObservacion {
        public int nId { get; set; }
        public string cObservacion { get; set; }
        public string cAbreUsuario { get; set; }
        public int nUsuReg { get; set; }
        public DateTime dtFechaReg { get; set; }
        public int nConsAsistPlaId { get; set; }
        public int nEstadoReg { get; set; }
        public string cNombreUsuario { get; set; }
    }
    public class BEConsolidadoAsistenciaPlanillaRequest {
        public int nPeriodo { get; set; }
        public int nGerencia { get; set; }
        public int nEstado { get; set; }
        public string cNombre { get; set; }
        public int nOpcion { get; set; }
        public int nPersonaId { get; set; }
        public int nId { get; set; }
        public int nUsuId { get; set; }
        public string texto { get; set; }
    }
}
