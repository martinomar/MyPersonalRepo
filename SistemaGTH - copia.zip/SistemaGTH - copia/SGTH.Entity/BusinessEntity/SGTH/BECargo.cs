﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BECargo
    {

        public Int64 pnNro { get; set; }


        public Int32 pnCargoId { get; set; }


        public String pvNombre { get; set; }


        public String pvDescripcion { get; set; }


        public String pcEstado { get; set; }


        public String pvEstado { get; set; }


        public Int32 pnTotalRows { get; set; }

        //INI DDD 24-02-2017 SESNEW
        public Int32 pnAreaId { get; set; }
        //FIN DDD 24-02-2017 SESNEW


        public String pcOpcion { get; set; }
        public Int32 PageNumber { get; set; }
        public Int32 TotalPages { get; set; }
        public Int32 PageSize { get; set; }
    }
}
