﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BECanal : Attribute
    {

        public Int32 pnCanalId { get; set; }


        public String pvCanalReclutamiento { get; set; }


        public Int64 pnNro { get; set; }


        public String pcEstado { get; set; }


        public String pvEstado { get; set; }


        public Int32 pnTotalRows { get; set; }
        public String pcOpcion { get; set; }
        public Int32 PageNumber { get; set; }
        public Int32 TotalPages { get; set; }
        public Int32 PageSize { get; set; }

    }
}
