﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEServicio
    {

        public Int32 pnCodProyecto { get; set; }

        public String pcAliasProyecto { get; set; }

        public String pcNombreProyecto { get; set; }

        public Int32 pnLiderProyecto { get; set; }

        public DateTime pdtFechaInicioPro { get; set; }

        public DateTime pdtFechaFinPro { get; set; }

        public Int32 pnCodResponsable { get; set; }

        public Int32 pnCodServicio { get; set; }

        public Int32 pnCodCliente { get; set; }

        public Int32 pnEliminado { get; set; }

        public Int32 pnCodUsuarioMod { get; set; }
    }
}
