﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGTH.Entity.BusinessEntity.SGTH
{
    public class BEColaborador
    {

        public Int32 pPersonaId { get; set; }


        public Int32 pvCodPrs { get; set; }


        public Int32 pnFicId { get; set; }


        public Int32 pnIdRda { get; set; }


        public Int32 pnIdBioIdentidad { get; set; }


        public Int32 pnIdSeguridad { get; set; }


        public Int32 pnUsuId { get; set; }


        public string pvUsuLogin { get; set; }


        public string pvCorColaborador { get; set; }


        public Int32 pnAnexo { get; set; }


        public int pnPntClnId { get; set; }


        public string pdtFchIngreso { get; set; }

        //INI JBT 20160907 - SESNEW

        public string pdtFchNacimiento { get; set; }


        public string pvDocNro { get; set; }


        public string pvCorreo { get; set; }
        //FIN JBT 20160907 - SESNEW


        public string pvPtoMarcacion { get; set; }


        public string pvCalendario { get; set; }


        public Int32 pnFrmMarcacion { get; set; }


        public Int32 pnModalidad { get; set; }


        public String pPersona { get; set; }


        public String pdtFchInicio { get; set; }


        public String pdtFchFin { get; set; }


        public String pCliente { get; set; }


        public String pdtFchCese { get; set; }


        public Int32 pnMtvCese { get; set; }


        public String pvMtvCese { get; set; }


        public Int32 pnMotCese { get; set; }


        public String pvObsCese { get; set; }


        public String pvEstacion { get; set; }


        public Int32 pnEstacion { get; set; }


        public Int32 pnCliId { get; set; }


        public Int32 pnGrpId { get; set; }


        public String pVigente { get; set; }


        public Int32 pnArea { get; set; }


        public String pcMinTra { get; set; }


        public Int32 pPerfil { get; set; }


        public Int32 pCargoSES { get; set; }


        public String pvCargoSES { get; set; }


        public int pnContratoId { get; set; }


        public Int32 pnEmpId { get; set; }

        //MAT INI

        public Int32 pnTipoContratoId { get; set; }


        public String pvDescripcionContrato { get; set; }
        //MAT FIN


        public String pEstado { get; set; }


        public String pchkVigente { get; set; }


        public String pRenovable { get; set; }


        public String pvNombres { get; set; }


        public string pnSedeId { get; set; }


        //Estado del Colaborador :

        public String pcEstado { get; set; }


        public Int32 pnPrsId { get; set; }


        public DateTime pdtInicioContrato { get; set; }


        public DateTime pdtFinContrato { get; set; }

        //Foto Colaborador

        public string pvImgPrs { get; set; }

        //Datos Cuenta

        public Int32 pnBancoId { get; set; }


        public String pcNroCuenta { get; set; }


        public String pcNroCtaInter { get; set; }

        public Int32 PageNumber { get; set; }
        public Int32 TotalPages { get; set; }
        public Int32 PageSize { get; set; }

        public Int32 pnRolId { get; set; }
        public Int32 pnSisId { get; set; }
        public DateTime pdtFecha { get; set; }


        public Int32 pnTotalRows { get; set; }

        public string strOpcion { get; set; }

        // Servicios
        //INI DDD 14-02-2017 SESMOD

        public Int32 pnLineaServicioCodigo { get; set; }

        public Int32 pnSubLineaServicioCodigo { get; set; }

        public Int32 pnServicioCodigo { get; set; }
        //INI FIN 14-02-2017 SESMOD

        public String pcNombreLineaServicio { get; set; }


        public String pcNombreSubLineaServicio { get; set; }


        public String pcNombreServicio { get; set; }

        //


        public Int32 pnGrpCodigo { get; set; }
        //


        public Int32 pnTipoAreaId { get; set; }


        public String pvAreaSES { get; set; }

        //INI DDD 14-02-2017 SESNEW

        public Int32 pnTpoColab { get; set; }


        public Int32 pnTiemPrac { get; set; }


        public Int32 pnModForm { get; set; }


        public String pvTipo { get; set; }
        //FIN DDD 14-02-2017 SESNEW

        //INI DDD 09-03-2017 SESNEW 
        public Int32 pnOpcion { get; set; }
        //FIN DDD 09-03-2017 SESNEW
    }
}
