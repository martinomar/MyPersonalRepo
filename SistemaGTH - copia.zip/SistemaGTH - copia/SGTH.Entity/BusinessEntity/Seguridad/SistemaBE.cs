﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.BusinessEntity;

namespace Seguridad.Entity.BusinessEntity.Seguridad
{
    public class SistemaBE
    {


        public Int32 pnUsuId { get; set; }


        public Int32 pnSisId { get; set; }


        public String pcSisNombre { get; set; }


        public string pcSisDescripcion { get; set; }


        public string pcEliminado { get; set; }


        public bool pbTipoEjecucion { get; set; }


        public String SisUrl { get; set; }

        public string strOpcion { get; set; }


        public string pcValidacion { get; set; }

        public Int32 PageNumber { get; set; }

        public Int32 PageSize { get; set; }

        public Int32 TotalPages { get; set; }


        public Int32 pnTotalRows { get; set; }


        public Boolean sel { get; set; }
    }
}
