﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.BusinessEntity;
namespace Seguridad.Entity.BusinessEntity.Seguridad
{
    public class MenuBE
    {
        private Int32 nMenuId;
        private Int32 nSisId;
        private String cMenuNom;
        private String cMenuArch;
        private bool bMenuCab;
        private Int32 nMenuGrupo;
        private Int32 nMenuOrden;
        private String cMnuEliminado;
        private String cSisEliminado;
        private String cMenuGrupoNom;
        private Int32 nMenuNivel;
        private Int32 nMenuHijos;



        /*BEGIN -new attribute - martin.delgado 21.05.2018*/
        private bool bMenuXPerfilSelected;
        /*END -new attribute - martin.delgado 21.05.2018*/

        public Int32 pnMenuId
        {
            get { return nMenuId; }
            set { nMenuId = value; }
        }

        public Int32 pnSisId
        {
            get { return nSisId; }
            set { nSisId = value; }
        }

        public String pcMenuNom
        {
            get { return cMenuNom; }
            set { cMenuNom = value; }
        }

        public String pcMenuArch
        {
            get { return cMenuArch; }
            set { cMenuArch = value; }
        }

        public bool pbMenuCab
        {
            get { return bMenuCab; }
            set { bMenuCab = value; }
        }

        public Int32 pnMenuGrupo
        {
            get { return nMenuGrupo; }
            set { nMenuGrupo = value; }
        }

        public Int32 pnMenuOrden
        {
            get { return nMenuOrden; }
            set { nMenuOrden = value; }
        }

        public String pcMnuEliminado
        {
            get { return cMnuEliminado; }
            set { cMnuEliminado = value; }
        }

        public String pcSisEliminado
        {
            get { return cSisEliminado; }
            set { cSisEliminado = value; }
        }

        public String pcMenuGrupoNom
        {
            get { return cMenuGrupoNom; }
            set { cMenuGrupoNom = value; }
        }

        public Int32 pnMenuNivel
        {
            get { return nMenuNivel; }
            set { nMenuNivel = value; }
        }

        public Int32 pnMenuHijos
        {
            get { return nMenuHijos; }
            set { nMenuHijos = value; }
        }
        public Int64 pnRowNumber { get; set; }


        public Int32 pnPerId { get; set; }
        public string pcMenusxPerfil { get; set; }



        public bool pbMenuXPerfilSelected { get; set; }

        public Int32 vant { get; set; }

        public String cSisUrl { get; set; }
    }
    public class MenuEstructura
    {
        public int nMenuId { get; set; }
        public string cMenuNom { get; set; }
        public int nMenuGrupo { get; set; }
        public string cMenuArch { get; set; }
        public int nMenuNivel { get; set; }
        public int nMenuOrden { get; set; }
        public int nSisId { get; set; }
        public string cSisUrl { get; set; }
        public int vant { get; set; }
    }
    public class MenuGeneral
    {
        public int codigo { get; set; }
        public string nombre { get; set; }
        public string url { get; set; }
        public Boolean click { get; set; }
        public int vant { get; set; }
        public List<MenuGeneral> hijo { get; set; }
    }

}
