﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.BusinessEntity;

namespace Seguridad.Entity.BusinessEntity.Seguridad
{
    public class SegMaestroBE
    {

        public Int32 nSisId { get; set; }


        public Int32 nMaeId { get; set; }


        public Int32 nMaeItem { get; set; }


        public String cMaeDenom { get; set; }


        public String cMaeDesc { get; set; }


        public String cMaeValor { get; set; }


        public String cMaeActivo { get; set; }


        public String cSegMaeEliminado { get; set; }


        public String cSisEliminado { get; set; }

        //Enpaginado
        public Int32 PageNumber { get; set; }

        public Int32 PageSize { get; set; }

        public Int32 TotalPages { get; set; }


        public Int32 nTotalRows { get; set; }

        // Fechas

        public DateTime dFechaIni { get; set; }

        public DateTime dFechaFin { get; set; }


        public Int32 nCodTipo { get; set; }

        public Int32 nCodPeriodo { get; set; }

        public bool bseleccionado { get; set; }

        public string cMaeId { get; set; }
    }
}