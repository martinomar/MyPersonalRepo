﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SGTH.Entity.BusinessEntity;
namespace Seguridad.Entity.BusinessEntity.Seguridad
{
    public class PerfilBE
    {
        private Int32 nSisId;
        private Int32 nPerId;
        private String cPerNom;
        private String cPerNem;
        private String cPerDesc;
        private String cPerEliminado;
        private String cSisEliminado;
        private bool cAsignado;


        /*BEGIN.Cambio martin.delgado - 18.05.2018 - tanto el tipo como el nombre del atributo no coincide con la columna 
         * 'cEstado bit' de la tabla Perfil*/
        /*anter:*/
        //private Boolean nEstado;
        //private String cEstado;

        private Boolean cEstado;
        /*END.Cambio martin.delgado*/


        //PerfilXUsuario
        private Int32 nUsuId;
        /*********************************/

        public string strOpcion { get; set; }

        public Int32 PageNumber { get; set; }

        public Int32 PageSize { get; set; }

        public Int32 TotalPages { get; set; }

        //porsiacaso
        public string pcSisNombre { get; set; }

        public string pcValidacion { get; set; }

        public Int32 pnTotalRows { get; set; }
        public Int32 pnUsuId
        {
            get { return nUsuId; }
            set { nUsuId = value; }
        }

        public Int32 pnSisId
        {
            get { return nSisId; }
            set { nSisId = value; }
        }

        public Int32 pnPerId
        {
            get { return nPerId; }
            set { nPerId = value; }
        }

        public String pcPerNom
        {
            get { return cPerNom; }
            set { cPerNom = value; }
        }

        public String pcPerNem
        {
            get { return cPerNem; }
            set { cPerNem = value.Trim(); }
        }

        public String pcPerDesc
        {
            get { return cPerDesc; }
            set { cPerDesc = value; }
        }

        public String pcPerEliminado
        {
            get { return cPerEliminado; }
            set { cPerEliminado = value; }
        }

        public String pcSisEliminado
        {
            get { return cSisEliminado; }
            set { cSisEliminado = value; }
        }

        public bool pcAsignado
        {
            get { return cAsignado; }
            set { cAsignado = value; }
        }
        /*BEGIN.Cambio martin.delgado - 18.05.2018 - tanto el tipo como el nombre del atributo no coincide 
         * con la columna 'cEstado bit' de la tabla Perfil*/

        //public string pcEstado
        //{
        //    get { return cEstado; }
        //    set { cEstado = value; }
        //}

        //public Boolean pnEstado
        //{
        //    get { return nEstado; }
        //    set { nEstado = value; }
        //}

        public Boolean pcEstado
        {
            get { return cEstado; }
            set { cEstado = value; }
        }
        /*END.Cambio martin.delgado - 18.05.2018*/
        private Boolean cEliminado;

        public Boolean pcEliminado
        {
            get { return cEliminado; }
            set { cEliminado = value; }
        }
        public string cfEliminado { get; set; }
    }
}
