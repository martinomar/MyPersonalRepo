﻿using SGTH.Entity.BusinessEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seguridad.Entity.BusinessEntity.Seguridad
{
    public class RolBE
    {

        public Int32 nRolId { get; set; }


        public Int32 nUsuId { get; set; }


        public String cRolNom { get; set; }


        public String cRolEliminado { get; set; }


        public Int32 nSisId { get; set; }


        public String cRolDesc { get; set; }


        public String cRolNem { get; set; }


        public string cSisNombre { get; set; }


        public string cActivo { get; set; }


        public bool cAsignado { get; set; }


        public bool bRolFav
        { get; set; }

        public Int32 PageNumber { get; set; }

        public Int32 PageSize { get; set; }

        public Int32 TotalPages { get; set; }

        public string strOpcion { get; set; }


        public string cValidacion { get; set; }


        public Int32 nTotalRows { get; set; }


        public String cUsuNombres { get; set; }



        //configuracionXAA

        public Int32 pnDAcCodigo { get; set; }


        public Int32 posXAA { get; set; }

        private Boolean cEliminado;


        public Boolean pcEliminado
        {
            get { return cEliminado; }
            set { cEliminado = value; }
        }
    }
}
