﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.BusinessEntity;

namespace Seguridad.Entity.BusinessEntity.Seguridad
{
    public class UsuarioBE
    {
        private String cUsuCorreoCorto;


        public Int32 nUsuId { get; set; }


        public Int32 nRolId { get; set; }


        public Int32 nGruId { get; set; }


        public String cUsuLogin { get; set; }


        public String cUsuNombres { get; set; }


        public String cUsuApePat { get; set; }


        public String cUsuApeMat { get; set; }


        public String cUsuCorreo { get; set; }


        public String cGruNomSisNom { get; set; }

        //Solo una porción del correo a mostrar

        public String pcUsuCorreoCorto
        {
            get { return cUsuCorreoCorto; }
            set
            {
                if (value != null)
                {
                    if (value.Trim().Length > 20)
                    {
                        cUsuCorreoCorto = value.Trim().Substring(0, 20) + "..";
                    }
                    else
                    {
                        cUsuCorreoCorto = value;
                    }
                }
            }
        }


        public String cUsuPrgSecreta { get; set; }


        public String cUsuRptSecreta { get; set; }


        public String cUsuNombreCompleto { get; set; }


        public String cEliminado { get; set; }


        public Int32 nSisId { get; set; }


        public String cSisEliminado { get; set; }


        public String cUsuSisEliminado { get; set; }


        public String cNombreCompleto { get; set; }


        public String cPassword { get; set; }


        public Int32 Item { get; set; }

        //Enpaginado

        public String pcOpcion { get; set; }

        public Int32 PageNumber { get; set; }

        public Int32 PageSize { get; set; }

        public Int32 TotalPages { get; set; }


        public Int32 nTotalRows { get; set; }

        // EG

        public int nProId { get; set; }


        public Int32 nCodPrs { get; set; }

        //KEY
        public string key { set; get; }


        public string cImgUsuario { get; set; }

        public string pcUsuCorreo { get; set; }
    }
}