﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.DataAccess.Seguridad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.GeneralLayer;
namespace Seguridad.Entity.BusinessLogic.Seguridad
{
    public class RolBL
    {
        RolDA objRolDa = new RolDA();

        public GenericEntityDAResponse fListaRolesAsigandosXUsuarioSessionBL(RolBE objRol)
        {
            return objRolDa.fListaRolesAsigandosXUsuarioSessionDL(objRol);
        }
        public String fMantenimientoRolXUsuarioBL(RolBE objRol)
        {
            return objRolDa.fMantenimientoRolXUsuarioDL(objRol);
        }

        public GenericEntityDAResponse fListaRolesAsigandosXUsuarioBL(RolBE objRol)
        {
            return objRolDa.fListaRolesAsigandosXUsuarioDL(objRol);
        }

        public GenericEntityDAResponse fListaRolesBL(RolBE objRol)
        {
            return objRolDa.fListaRolesDL(objRol);
        }

        public String fMantenimientoRolBL(RolBE objELRol)
        {
            return objRolDa.fMantenimientoRolDL(objELRol);
        }

        public GenericEntityDAResponse fListaValidarRolBL(RolBE objRol)
        {
            return objRolDa.fListaValidarRolDL(objRol);
        }
    }
}
