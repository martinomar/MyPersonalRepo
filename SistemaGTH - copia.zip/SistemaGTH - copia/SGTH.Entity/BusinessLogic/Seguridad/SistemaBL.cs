﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.DataAccess.Seguridad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.GeneralLayer;
namespace Seguridad.Entity.BusinessLogic.Seguridad
{
    public class SistemaBL
    {
        SistemaDA objSistemaDA = new SistemaDA();

        public GenericEntityDAResponse fListaSistemaBL(SistemaBE objELSistema)
        {
            return objSistemaDA.fListaSistemaDL(objELSistema);
        }
        public GenericEntityDAResponse fILCargaComboSistemaBL(SistemaBE objSistemaBE)
        {
            return objSistemaDA.fILCargaComboSistemaDL(objSistemaBE);
        }

        public GenericEntityDAResponse fObtenerSistemaxUrlBL(SistemaBE objSistemaBE)
        {
            return objSistemaDA.fObtenerSistemaxUrlDL(objSistemaBE);
        }
        public GenericEntityDAResponse fListaSistemaPaginacionBL()
        {
            /*SistemaBE objPaginacion = new SistemaBE();
            List<SistemaBE> objLista = new List<SistemaBE>();
            objLista = objSistemaDA.fListaSistemaPaginacionDL();
            return objLista;*/
            return new SistemaDA().fListaSistemaPaginacionDL();
        }


        public String fMantenimientoSistemaBL(SistemaBE objSistemaBE)
        {
            return objSistemaDA.fMantenimientoSistemaDL(objSistemaBE);
        }

        public GenericEntityDAResponse fListaVerificarSistemaBL(SistemaBE objSistemaBE)
        {
            return objSistemaDA.fListaVerificarSistemaDL(objSistemaBE);
        }

        public GenericEntityDAResponse fListaValidarSistemaBL(SistemaBE objSistemaBE)
        {
            return objSistemaDA.fListaValidarSistemaDL(objSistemaBE);
        }

        public GenericEntityDAResponse fListaSistemasxRolesAsignandosXUsuarioSessionBL(UsuarioBE objUsuario)
        {
            return objSistemaDA.fListaSistemasxRolesAsignandosXUsuarioSessionDL(objUsuario);
        }

        public GenericEntityDAResponse fListaSistemasAsignadoXUsuarioBL(UsuarioBE objUsuario)
        {
            return objSistemaDA.fListaSistemasAsignadoXUsuarioDL(objUsuario);
        }
    }
}