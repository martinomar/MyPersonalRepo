﻿/*--------------------------------------------------------------------------
SISTEMA : Seguridad
SUBSISTEMA : Seguridad
NOMBRE : PerfilBL.js
DESCRIPCIÓN : 
AUTOR : Marin Delgado - SES Practicante
FECHA CREACIÓN : 17-05-2018
-----------------------------------------------------------------------------------------------------------
FECHA                EMPLEADO             MODIFICACIÓN  
------------------   -----------------    --------------------------------------------------------------------------------------
Juevez 17/05/2018/   martin.delgado       creacion y definicion de metodos(la clase estaba vacia, es decir sin metodos)
---------------------------------------------------------------------------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.DataAccess.Seguridad;
using SGTH.Entity.GeneralLayer;


namespace Seguridad.Entity.BusinessLogic.Seguridad
{
    public class PerfilBL
    {


        #region(cambios Martin.delgado 17/05/2018 ##############################################)

        PerfilDA dlPerfil = new PerfilDA();


        public GenericEntityDAResponse fListaPerfilesAsigandosXUsuarioBL(PerfilBE objPerfil)
        {
            return dlPerfil.fListaPerfilesAsignadosXUsuarioDL(objPerfil);
        }



        public String fMantenimientoPerfilXUsuarioBL(PerfilBE objPerfil, String strOpcion)
        {
            return dlPerfil.fMantenimientoPerfilXUsuarioDL(objPerfil, strOpcion);
        }

        public GenericEntityDAResponse fListaPerfilBL(PerfilBE objPerfilBE)
        {
            return dlPerfil.fListaPerfilDL(objPerfilBE);
        }


        public GenericEntityDAResponse fListaPerfilesBL(PerfilBE objPerfilBE)
        {
            //List<PerfilBE> objListaPerfiles = new List<PerfilBE>();
            //objListaPerfiles = dlPerfil.fListaPerfilesDL(objPerfilBE);

            //return objListaPerfiles;

            return new PerfilDA().fListaPerfilesDL(objPerfilBE);
        }

        public String fMantenimientoPerfilBL(PerfilBE objPerfilBE)
        {
            return dlPerfil.fMantenimientoPerfilDL(objPerfilBE);
        }

        public GenericEntityDAResponse fListaValidarPerfilBL(PerfilBE objPerfil)
        {
            return dlPerfil.fListaValidarPerfilDL(objPerfil);
        }

        public GenericEntityDAResponse fListaVerificarPerfilBL(PerfilBE objPerfil)
        {
            return dlPerfil.fListaVerificarPerfilDL(objPerfil);
        }


        #endregion ##############################################)

    }
}
