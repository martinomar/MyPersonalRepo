﻿//------------------------------------------------------------------------
//SISTEMA : Seguridad
//SUBSISTEMA : Seguridad
//NOMBRE : SegMaestroBL.cs
//DESCRIPCIÓN : Negocio SegMaestro
//AUTOR : Cristhofer Castillo Salvatierra - SES
//FECHA CREACIÓN : 24-05-2018
//------------------------------------------------------------------------
//FECHA MODIFICACIÓN  EMPLEADO
//------------------------------------------------------------------------

using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.DataAccess.Seguridad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.GeneralLayer;
namespace Seguridad.Entity.BusinessLogic.Seguridad
{
    public class SegMaestroBL
    {
        SegMaestroDA objMaestroDA = new SegMaestroDA();

        public GenericEntityDAResponse fListaSegMaestrosBL(SegMaestroBE objSegMaestro)
        {
            return objMaestroDA.fListaSegMaestrosDA(objSegMaestro);
        }

        public GenericEntityDAResponse fListaTablasMaestroBL(SegMaestroBE objSegMaestro)
        {
            return objMaestroDA.fListaTablasMaestroDL(objSegMaestro);
        }

        public String fMantenimientoSegMaestroBL(SegMaestroBE objSegMaestro, String strOpcion)
        {
            return objMaestroDA.fMantenimientoSegMaestroDL(objSegMaestro, strOpcion);
        }
    }
}