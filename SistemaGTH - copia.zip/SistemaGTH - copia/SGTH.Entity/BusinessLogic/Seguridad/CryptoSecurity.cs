﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Seguridad.Entity.GeneralLayer;

namespace Seguridad.Entity.BusinessLogic.Seguridad
{
    public class CryptoSecurity
    {
        public string BLDEcryptURLparam(string _input)
        {
            return new CriptografiaGL().DecryptURLparam(_input);
        }
    }
}
