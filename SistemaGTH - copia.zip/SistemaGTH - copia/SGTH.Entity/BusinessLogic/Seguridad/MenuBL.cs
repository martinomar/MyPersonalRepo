﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.DataAccess.Seguridad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.GeneralLayer;

namespace Seguridad.Entity.BusinessLogic.Seguridad
{
    public class MenuBL
    {
        MenuDA objMenuDA = new MenuDA();

        public GenericEntityDAResponse fListaMenusSitemapBL(RolBE objUsuario)
        {
            return objMenuDA.fListaMenusSitemapDL(objUsuario);
        }
        public GenericEntityDAResponse fListaMenusXPerfilBL(MenuBE objMenu)
        {
            return objMenuDA.fListaMenusXPerfilDL(objMenu);
        }
        public GenericEntityDAResponse fListaMenusBL(MenuBE objMenu)
        {
            return objMenuDA.fListaMenusDL(objMenu);
        }
        public GenericEntityDAResponse fListarMenuXPerfil_selectedBL(MenuBE obj)
        {
            return objMenuDA.fListarMenuXPerfilSelectedDL(obj);
        }
        public String fMantenimientoMenuXPerfilBL(MenuBE objMenu)
        {
            return objMenuDA.fMantenimientoMenuXPerfilDL(objMenu);
        }
        public GenericEntityDAResponse fListaGruposBL(MenuBE objMenu)
        {
            return objMenuDA.fListaGruposDL(objMenu);
        }

        public String fMantenimientoMenuBL(MenuBE objMenu, String strOpcion)
        {
            return objMenuDA.fMantenimientoMenuDL(objMenu, strOpcion);
        }

        public MenuBE fContarHijosPorCodigoBL(MenuBE objMenu)
        {
            return objMenuDA.fContarHijosPorCodigoDL(objMenu);
        }
        public GenericEntityDAResponse fListaMenusSitemapGeneralBL(RolBE objUsuario)
        {
            return objMenuDA.fListaMenusSistemasGeneralDL(objUsuario); ;
        }
    }
}
