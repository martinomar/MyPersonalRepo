﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.DataAccess.Seguridad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.GeneralLayer;
namespace Seguridad.Entity.BusinessLogic.Seguridad
{
    public class UsuarioBL
    {
        UsuarioDL dlUsuario = new UsuarioDL();

        public GenericEntityDAResponse fListaUsuarioIntranetBL(UsuarioBE objElUsuario)
        {
            return dlUsuario.fListaUsuarioIntranetDL(objElUsuario);
        }

        public String fMantenimientoPerfilXUsuarioBL(PerfilBE objPerfil)
        {
            return dlUsuario.fMantenimientoPerfilXUsuarioDL(objPerfil);
        }

        public int fLoginUsuarioBL(string usuario, string password, string eliminado)
        {
            return dlUsuario.fLoginUsuarioDL(usuario, password, eliminado);
        }

        public UsuarioBE fObtenerUsuarioPorCodigoBL(int nUsuId)
        {
            return dlUsuario.fObtenerUsuarioPorCodigoDL(nUsuId);
        }

        public List<UsuarioBE> fListaUsuariosBL(UsuarioBE objUsuario)
        {
            return dlUsuario.fListaUsuariosDL(objUsuario);
        }

        public String fMantenimientoUsuarios(UsuarioBE objUsuario)
        {
            return dlUsuario.fMantenimientoUsuario(objUsuario);
        }

        public GenericEntityDAResponse fValidaUsuarioxGrupoBL(UsuarioBE objUsuario)
        {
            return dlUsuario.fValidaUsuarioxGrupoDL(objUsuario);
        }
        
        public GenericEntityDAResponse fBuscarUsuarioRDA(UsuarioBE objUsuario)
        {
            //List<UsuarioBE> objListaUsuario = dlUsuario.fBuscarUsuarioRDADL(objUsuario);
            return  dlUsuario.fBuscarUsuarioRDADL(objUsuario);
            /*
            foreach (UsuarioBE item in objListaUsuario)
            {
                String[] nombres = item.cUsuNombres.Split(' ');
                String nombreCompleto = "";
                for (int i = 0; i < nombres.Length; i++)
                {
                    int total = nombres[i].Length;
                    String nomIniMayus = nombres[i].Substring(0, 1).ToUpper() + nombres[i].Substring(1, total - 1);
                    nombreCompleto = nombreCompleto + nomIniMayus + " ";
                }
                item.cUsuNombres = nombreCompleto.Trim();

                String[] apePaterno = item.cUsuApePat.Split(' ');
                String apePatCompleto = "";
                for (int i = 0; i < apePaterno.Length; i++)
                {
                    int total = apePaterno[i].Length;
                    String apePatIniMayus = apePaterno[i].Substring(0, 1).ToUpper() + apePaterno[i].Substring(1, total - 1);
                    apePatCompleto = apePatCompleto + apePatIniMayus + " ";
                }
                item.cUsuApePat = apePatCompleto.Trim();

                String[] apeMaterno = item.cUsuApeMat.Split(' ');
                String apeMatCompleto = "";
                for (int i = 0; i < apeMaterno.Length; i++)
                {
                    int total = apeMaterno[i].Length;
                    String apeMatIniMayus = apeMaterno[i].Substring(0, 1).ToUpper() + apeMaterno[i].Substring(1, total - 1);
                    apeMatCompleto = apeMatCompleto + apeMatIniMayus + " ";
                }
                item.cUsuApeMat = apeMatCompleto;
            }

            return objListaUsuario;*/

            
        }
        
        public UsuarioBE fLoginAutenticacionBL(string usuario, string password)
        {
            return dlUsuario.fLoginAutenticacionDL(usuario, password);
        }
        public string fMantDatosUsuarioBL(int nUsuId, string crutaimg, string cOpcion)
        {
            return dlUsuario.fMantDatosUsuarioDL(nUsuId, crutaimg, cOpcion);
        }
    }
}