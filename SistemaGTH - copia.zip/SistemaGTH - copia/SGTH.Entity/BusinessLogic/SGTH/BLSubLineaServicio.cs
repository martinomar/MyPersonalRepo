﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.BusinessEntity.SGTH;
using SGTH.Entity.DataAccess.SGTH;
using SGTH.Entity.GeneralLayer;
namespace SGTH.Entity.BusinessLogic.SGTH
{
    public class BLSubLineaServicio
    {
        DASubLineaServicio objDLSubLineaServicio = new DASubLineaServicio();

        public GenericEntityDAResponse fListarSubLineaServicioBL(BESubLineaServicio objELSubLineaServicio)
        {
            return objDLSubLineaServicio.fListarSubLineaServicioDL(objELSubLineaServicio);
        }
    }
}
