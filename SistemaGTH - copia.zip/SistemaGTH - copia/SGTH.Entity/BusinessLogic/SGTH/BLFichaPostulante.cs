﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.BusinessEntity.SGTH;
using SGTH.Entity.DataAccess.SGTH;
using SGTH.Entity.GeneralLayer;

namespace SGTH.Entity.BusinessLogic.SGTH
{
    public class BLFichaPostulante
    {
        DAFichaPostulante dFP = new DAFichaPostulante();
        DAPostulante dPs = new DAPostulante();


        public GenericEntityDAResponse fnBLConsultarPreRegistroPostulanteXDNI(string cdni)
        {
            return dFP.DL_fnConsultaDNI(cdni);
        }

        public GenericEntityDAResponse fnBLListCargoPresentarse(BECargoPresentarse obj)
        {
            return dPs.fnDAListaCargoPresentarse(obj);
        }

        public GenericEntityDAResponse fnBLListCanal(BECanal obj)
        {
            return dPs.fnDAListaCanal(obj);
        }

        public GenericEntityDAResponse fnBLListDepartamento(BEDepartamento obj)
        {
            return dPs.fnDAListaDepartamento(obj);
        }

        public GenericEntityDAResponse fnBLListProvincia(BEProvincia obj)
        {
            return dPs.fnDAListaProvincia(obj);
        }

        public GenericEntityDAResponse fnBLListDistrito(BEDistrito obj)
        {
            return dPs.fnDAListaDistrito(obj);
        }


        public GenericEntityDAResponse fnBLListCentroDeEstudio(BECentroEstudio obj)
        {
            return dPs.fnDAListaCentroEstudio(obj);
        }

        public GenericEntityDAResponse fnBLListTecnologia(BETecnologia obj)
        {
            return dPs.FnDAListaTecnologia(obj);
        }

        public GenericEntityDAResponse fILCargarEstudios(BEEstudio obj)
        {
            return dPs.fILEstudios_carreras(obj);
        }

        public GenericEntityDAResponse FILCentroEstudios(BECentroEstudio obj)
        {
            return dPs.fnDAListaCentroEstudio(obj);
        }

    }
}
