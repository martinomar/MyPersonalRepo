﻿using SGTH.Entity.DataAccess.SGTH;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.GeneralLayer;
using SGTH.Entity.BusinessEntity.SGTH;

namespace SGTH.Entity.BusinessLogic.SGTH
{
    public class BLConsolidadoAsistenciaPlanilla
    {
        DAConsolidadoAsistenciaPlanilla da = new DAConsolidadoAsistenciaPlanilla();

        public GenericEntityDAResponse fnBLList(BEConsolidadoAsistenciaPlanillaRequest objRequest)
        {
            return da.fnDAListAsistenciaPlanilla(objRequest);
        }
        public GenericEntityDAResponse fnBLListFiltro(BEConsolidadoAsistenciaPlanillaRequest objRequest)
        {
            return da.fnDAFiltroAsistenciaPlanilla(objRequest);
        }
        public GenericEntityDAResponse fnBLGenerar(BEConsolidadoAsistenciaPlanillaRequest objRequest)
        {
            return da.fnDAGenerarAsistenciaPlanilla(objRequest);
        }
        public string fnBLMntObservacion(BEConsolidadoAsistenciaPlanillaRequest objRequest)
        {
            return da.fnMntObservacionDL(objRequest);
        }
    }
}
