﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SGTH.Entity.BusinessEntity.SGTH;
using SGTH.Entity.DataAccess.SGTH;
using SGTH.Entity.GeneralLayer;
namespace SGTH.Entity.BusinessLogic.SGTH
{
    public class BLArea
    {
        DAArea objDLArea = new DAArea();

        public GenericEntityDAResponse fListarAreaBL(BEArea objELArea)
        {
            return objDLArea.fListarAreaDL(objELArea);
        }

        public GenericEntityDAResponse fListarAreaxUsuarioBL(Int32 nUsuId)
        {
            return objDLArea.fListarAreaxUsuarioDL(nUsuId);
        }

        public GenericEntityDAResponse fListarAreaxOrganigramaBL(string cOpcion, int nAreaId)
        {
            return objDLArea.fListarAreaxOrganigramaDL(cOpcion, nAreaId);
        }
    }
}
