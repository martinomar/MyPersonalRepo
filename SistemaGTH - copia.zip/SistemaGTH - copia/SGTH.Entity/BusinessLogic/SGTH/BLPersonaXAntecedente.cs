﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.BusinessEntity.SGTH;
using SGTH.Entity.DataAccess.SGTH;
using Seguridad.Entity.BusinessEntity.Seguridad;
using SGTH.Entity.GeneralLayer;
namespace SGTH.Entity.BusinessLogic.SGTH
{
    public class BLPersonaXAntecedente
    {
        DAPersonaXAntecedente da = new DAPersonaXAntecedente();

        public GenericEntityDAResponse fnBLRegistro(BEPersonaXAntecedente obj)
        {
            return da.fnDARegistro(obj);
        }
    }
}
