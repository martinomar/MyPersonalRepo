﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SGTH.Entity.BusinessEntity.SGTH;
using SGTH.Entity.DataAccess.SGTH;
using SGTH.Entity.GeneralLayer;

namespace SGTH.Entity.BusinessLogic.SGTH
{
    public class BLProyecto
    {
        DAProyecto objDLProyecto = new DAProyecto();

        //public List<ELProyecto> fListaProyectoBL()
        //{
        //    return objDLProyecto.fListaProyectoDL();
        //}

        public GenericEntityDAResponse fRegistraDatosProyectoBL(BEProyecto objELProyecto)
        {
            return objDLProyecto.fRegistraDatosProyectoDL(objELProyecto);
        }
    }
}
