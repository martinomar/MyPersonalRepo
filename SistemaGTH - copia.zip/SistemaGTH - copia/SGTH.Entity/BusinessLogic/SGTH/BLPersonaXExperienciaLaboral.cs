﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.BusinessEntity.SGTH;
using SGTH.Entity.DataAccess.SGTH;
using Seguridad.Entity.BusinessEntity.Seguridad;
using SGTH.Entity.GeneralLayer;

namespace SGTH.Entity.BusinessLogic.SGTH
{
    public class BLPersonaXExperienciaLaboral
    {
        DAPersonaXExperienciaLaboral da = new DAPersonaXExperienciaLaboral();

        public GenericEntityDAResponse fnBLRegistro(BEPersonaXExperienciaLaboral obj)
        {
            return da.fnDARegistro(obj);
        }
    }
}
