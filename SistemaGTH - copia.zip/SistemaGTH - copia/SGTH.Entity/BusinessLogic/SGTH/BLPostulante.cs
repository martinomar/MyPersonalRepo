﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.BusinessEntity.SGTH;
using SGTH.Entity.DataAccess.SGTH;
using SGTH.Entity.GeneralLayer;

namespace SGTH.Entity.BusinessLogic.SGTH
{
    public class BLPostulante
    {
        DAPostulante daPST = new DAPostulante();

        public GenericEntityDAResponse fnBLRegistrarPostulante(BEPostulante obj)
        {
            return daPST.fnDARegistroVirtualPostulante(obj);
        }
        public GenericEntityDAResponse fnBLListarPostulante(BEPostulante obj)
        {
            return daPST.fnBLListarPostulante(obj);
        }
        public GenericEntityDAResponse fnBLListPostulantes_todos()
        {
            return daPST.fnListPostulantes_todos();
        }
        public GenericEntityDAResponse fnListaPostulantes(BEPostulante obj)
        {
            return daPST.fListaPostulantesDL(obj);
        }

        public GenericEntityDAResponse fnRegistraMotivo(BETipoAceptacionXMotivo objMotivo)
        {
            return daPST.fRegistraMotivoDL(objMotivo);
        }

        //Pase Colaborador 
        public GenericEntityDAResponse fPaseColaboradorBL(BEPostulante obj)
        {
            return daPST.fPaseColaborador(obj);
        }
        public GenericEntityDAResponse fObtienePostulanteBL(BEPostulante oEntidad)
        {
            return daPST.fObtienePostulanteDL(oEntidad);
        }
    }
}
