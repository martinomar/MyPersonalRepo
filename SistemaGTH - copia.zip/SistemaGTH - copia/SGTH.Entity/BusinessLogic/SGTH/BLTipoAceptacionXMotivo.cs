﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.BusinessEntity.SGTH;
using SGTH.Entity.DataAccess.SGTH;
using SGTH.Entity.GeneralLayer;
namespace SGTH.Entity.BusinessLogic.SGTH
{
    public class BLTipoAceptacionXMotivo
    {
        DAPostulante dlPostulante = new DAPostulante();
        public GenericEntityDAResponse FListaMotivoBL(BETipoAceptacionXMotivo objMotivo)
        {
            return dlPostulante.FListaMotivoDL(objMotivo);
        }
    }
}
