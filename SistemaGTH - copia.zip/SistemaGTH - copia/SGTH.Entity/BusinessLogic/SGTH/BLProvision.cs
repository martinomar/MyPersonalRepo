﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.BusinessEntity.SGTH;
using SGTH.Entity.DataAccess.SGTH;
using SGTH.Entity.GeneralLayer;
namespace SGTH.Entity.BusinessLogic.SGTH
{
    public class BLProvision
    {
        DAProvision dlProvision = new DAProvision();

        //INI JGA 02/03/2017 SESNEW
        public GenericEntityDAResponse fValidarProvision(BEProvision oELProvision)
        {
            return dlProvision.fValidarProvision(oELProvision);
        }
        public GenericEntityDAResponse fInsProvVacPaseCol(BEProvision oELProvision)
        {
            return dlProvision.fInsProvVacPaseCol(oELProvision);
        }
    }
}
