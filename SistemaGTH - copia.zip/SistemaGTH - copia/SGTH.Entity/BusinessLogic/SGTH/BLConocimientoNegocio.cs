﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.BusinessEntity.SGTH;
using SGTH.Entity.DataAccess.SGTH;
using Seguridad.Entity.BusinessEntity.Seguridad;
using SGTH.Entity.GeneralLayer;

namespace SGTH.Entity.BusinessLogic.SGTH
{
    class BLConocimientoNegocio
    {
        DAConocimientoNegocio DAConNegocio = new DAConocimientoNegocio();

        public GenericEntityDAResponse fnBLListaConocimientoNegocio(BEConocimientoNegocio obj)
        {
            return DAConNegocio.fnDAListaConocimientoNegocio(obj);
        }
        //public List<BEConocimientoNegocio> fListaConocimientoNegocioBL(BEConocimientoNegocio oELConNegocio)
        //{
        //    BEConocimientoNegocio objPaginador = new BEConocimientoNegocio();
        //    List<BEConocimientoNegocio> objLista = new List<BEConocimientoNegocio>();
        //    objLista = dlConNegocio.fListaConocimientoNegocioDL(oELConNegocio);
        //    if (objLista.Count > 0)
        //    {
        //        int TotalRows = objLista.First().pnTotalRows;
        //        objPaginador.pnTotalRows = TotalRows;
        //        int Paginas = 0;
        //        if (oELConNegocio.PageSize == 0)
        //        { Paginas = 1; }
        //        else
        //        { Paginas = ((int)(TotalRows / oELConNegocio.PageSize)); }
        //        if (oELConNegocio.PageSize * Paginas != TotalRows) Paginas += 1;
        //        objPaginador.TotalPages = Paginas;
        //    }
        //    else
        //    {
        //        objPaginador.pnTotalRows = 0;
        //        objPaginador.TotalPages = 0;
        //    }

        //    foreach (BEConocimientoNegocio item in objLista)
        //    {
        //        item.TotalPages = objPaginador.TotalPages;
        //        item.pnTotalRows = objPaginador.pnTotalRows;
        //    }

        //    return objLista;
        //}

        //public List<BLConocimientoNegocio> fListaConocimientoNegocioBL(BEConocimientoNegocio oELConNegocio)
        //{
        //BEConocimientoNegocio objPaginador = new BEConocimientoNegocio();
        //List<BEConocimientoNegocio> objLista = new List<BEConocimientoNegocio>();
        //objLista = dlConNegocio.fListaConocimientoNegocioDL(oELConNegocio);
        //if (objLista.Count > 0)
        //{
        //    int TotalRows = objLista.First().pnTotalRows;
        //    objPaginador.pnTotalRows = TotalRows;
        //    int Paginas = 0;
        //    if (oELConNegocio.PageSize == 0)
        //    { Paginas = 1; }
        //    else
        //    { Paginas = ((int)(TotalRows / oELConNegocio.PageSize)); }
        //    if (oELConNegocio.PageSize * Paginas != TotalRows) Paginas += 1;
        //    objPaginador.TotalPages = Paginas;
        //}
        //else
        //{
        //    objPaginador.pnTotalRows = 0;
        //    objPaginador.TotalPages = 0;
        //}

        //foreach (BEConocimientoNegocio item in objLista)
        //{
        //    item.TotalPages = objPaginador.TotalPages;
        //    item.pnTotalRows = objPaginador.pnTotalRows;
        //}

        //return objLista;
        //}
    }


}
