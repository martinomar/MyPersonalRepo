﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGTH.Entity.BusinessEntity.SGTH;
using SGTH.Entity.DataAccess.SGTH;
using SGTH.Entity.GeneralLayer;
namespace SGTH.Entity.BusinessLogic.SGTH
{
    public class BLContrato
    {
        DAContrato objDLContrato = new DAContrato();
        public GenericEntityDAResponse fILCargoContratoBL(Int32 nAreaId)
        {
            return objDLContrato.fListaCargoContrato(nAreaId);
        }

        public GenericEntityDAResponse fObtenerCorreoBL(BEContrato objContrato)
        {
            return objDLContrato.fObtenerCorreoDL(objContrato);
        }

        public GenericEntityDAResponse fListaCorreoPracticasBL(int empId)
        {
            return objDLContrato.fListaCorreoPracticas(empId); 
        }

        public GenericEntityDAResponse fRegistraContratoBL(BEContrato objContrato)
        {
            return objDLContrato.fRegistraContratoDL(objContrato);
        }

    }
}
