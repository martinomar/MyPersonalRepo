﻿using Newtonsoft.Json;
using SGTH.Entity.BusinessEntity.SGTH;
using SGTH.Entity.BusinessLogic.SGTH;
using SGTH.Entity.GeneralLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SGTH.WebAPI.Controllers.SGTH
{
    public class AsistenciaPlanillaController : ApiController
    {
        BLConsolidadoAsistenciaPlanilla oBLConsolidado = new BLConsolidadoAsistenciaPlanilla();

        [HttpPost]
        public GenericApiResponse aList(BEConsolidadoAsistenciaPlanillaRequest objRequest)
        {
            GenericApiResponse GAR = new GenericApiResponse();
            GenericEntityDAResponse GenDaLR = new GenericEntityDAResponse();
            try
            {
                GenericEntityDAResponse objGeneric = oBLConsolidado.fnBLList(objRequest);

                GAR.IECollection = objGeneric.gList1;
                GAR.nMsj2 = objGeneric.nAttr1;
                GAR.nMsjCode = (GenDaLR.cError == "" || GenDaLR.cError == null ? 200 : 500);
                GAR.cMsj = GenDaLR.cError;
            }
            catch (Exception ex)
            {
                GAR.nMsjCode = 500;
                GAR.cMsj = ex.ToString();
            }
            return GAR;
        }

        [HttpPost]
        public GenericApiResponse aListFiltro(BEConsolidadoAsistenciaPlanillaRequest objRequest)
        {
            GenericApiResponse GAR = new GenericApiResponse();
            GenericEntityDAResponse GenDaLR = new GenericEntityDAResponse();
            try
            {
                GenericEntityDAResponse objGeneric = oBLConsolidado.fnBLListFiltro(objRequest);

                GAR.DtCollection = objGeneric.dTable1;
                GAR.nMsjCode = (GenDaLR.cError == "" || GenDaLR.cError == null ? 200 : 500);
                GAR.cMsj = GenDaLR.cError;
            }
            catch (Exception ex)
            {
                GAR.nMsjCode = 500;
                GAR.cMsj = ex.ToString();
            }
            return GAR;
        }

        [HttpPost]
        public GenericApiResponse aGenerar(BEConsolidadoAsistenciaPlanillaRequest objRequest)
        {
            GenericApiResponse GAR = new GenericApiResponse();
            GenericEntityDAResponse GenDaLR = new GenericEntityDAResponse();
            try
            {
                GenericEntityDAResponse objGeneric = oBLConsolidado.fnBLGenerar(objRequest);

                GAR.nMsj2 = objGeneric.nAttr1;
                GAR.nMsjCode = (GenDaLR.cError == "" || GenDaLR.cError == null ? 200 : 500);
                GAR.cMsj = GenDaLR.cError;
            }
            catch (Exception ex)
            {
                GAR.nMsjCode = 500;
                GAR.cMsj = ex.ToString();
            }
            return GAR;
        }
        [HttpPost]
        public GenericApiResponse aMntObservacion(BEConsolidadoAsistenciaPlanillaRequest objRequest)
        {

            GenericApiResponse oGAR = new GenericApiResponse();

            string prmOk = "";
            try
            {
                List<BEConsolidadoAsistenciaPlanillaRequest> oBERequest = JsonConvert.DeserializeObject<List<BEConsolidadoAsistenciaPlanillaRequest>>(objRequest.texto);

                foreach (var item in oBERequest)
                {
                    oGAR.cMsj = oBLConsolidado.fnBLMntObservacion(item);
                }

                prmOk = oGAR.cMsj.Substring(0, 1);
                oGAR.nMsjCode = prmOk == "1" ? 200 : 500;
            }
            catch (Exception ex)
            {
                oGAR.nMsjCode = 500;
                oGAR.cMsj = ex.ToString();
            }
            return oGAR;
        }
    }
}
