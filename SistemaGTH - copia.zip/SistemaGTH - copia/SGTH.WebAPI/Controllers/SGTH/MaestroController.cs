﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using SGTH.Entity.GeneralLayer;
using SGTH.Entity.BusinessEntity.SGTH;
using SGTH.Entity.BusinessLogic.SGTH;

using Seguridad.Entity.BusinessLogic.Seguridad;
using Seguridad.Entity.BusinessEntity.Seguridad;

namespace SGTH.WebAPI.Controllers
{
    public class MaestroController : ApiController
    {
        
        SegMaestroBL oBL = new SegMaestroBL();
        

        [HttpPost]
        public GenericApiResponse aList(SegMaestroBE oBE)
        {
            GenericApiResponse APIresponse = new GenericApiResponse();
            GenericEntityDAResponse DAresponse = new GenericEntityDAResponse();
            try
            {
                int RDAAA = int.Parse(System.Configuration.ConfigurationManager.AppSettings["RDAAA"].ToString());

                oBE.nSisId = RDAAA;
                ////oBE.nMaeId = nMaeId;
                //oBE.nMaeItem = -1;
                //oBE.cSegMaeEliminado = "0";
                //oBE.cSisEliminado = "0";
                //oBE.cMaeActivo = "SI";

                //GAR.IECollection = oBL.fListaSegMaestrosBL(oBE);
                DAresponse = new BLMaestro().fnBLMaestro(oBE);
                if (DAresponse.cError==null || DAresponse.cError =="")
                {
                    APIresponse.cMsj = null;
                    APIresponse.cMsjDetaill = null;
                    APIresponse.DtCollection = DAresponse.dTable1;
                    APIresponse.nMsjCode = 200;
                }
                else
                {
                    APIresponse.cMsj = "DA error...";
                    //APIresponse.cMsjDetaill = DAresponse.cError;
                    APIresponse.cMsjDetaill = DAresponse.cError.Substring(0,DAresponse.cError.IndexOf(". "));
                    APIresponse.nMsjCode = 500;
                }
                
            }
            catch (Exception ex)
            {
                APIresponse.nMsjCode = 500;
                APIresponse.cMsj = ex.ToString();
            }
            return APIresponse;
        }

        [HttpPost]
        public GenericApiResponse FILTecnologiaBL(BETecnologia obj)
        {
            GenericApiResponse _out = new GenericApiResponse();
            GenericEntityDAResponse gda = new GenericEntityDAResponse();
            try
            {
                gda = new BLFichaPostulante().fnBLListTecnologia(obj);
                _out.DtCollection = gda.dTable1;
                _out.nMsjCode = (gda.cError == "" || gda.cError == null ? 200 : 500);
                _out.cMsj = gda.cError;
            }
            catch (Exception ex)
            {
                _out.nMsjCode = 500;
                _out.cMsj = ex.ToString();
            }
            return _out;

        }

        [HttpPost]
        public GenericApiResponse fIListEstudios(BEEstudio obj)
        {
            GenericApiResponse _out = new GenericApiResponse();
            GenericEntityDAResponse gda = new GenericEntityDAResponse();
            try
            {
                gda = new BLFichaPostulante().fILCargarEstudios(obj);
                _out.DtCollection = gda.dTable1;
                _out.nMsjCode = (gda.cError == "" || gda.cError == null ? 200 : 500);
                _out.cMsj = gda.cError;
            }
            catch (Exception ex)
            {
                _out.nMsjCode = 500;
                _out.cMsj = ex.ToString();
            }
            return _out;

        }

        [HttpPost]
        public GenericApiResponse FILCentroEstudio(BECentroEstudio obj)
        {
            GenericApiResponse _out = new GenericApiResponse();
            GenericEntityDAResponse gda = new GenericEntityDAResponse();
            try
            {
                gda = new BLFichaPostulante().FILCentroEstudios(obj);
                _out.DtCollection = gda.dTable1;
                _out.nMsjCode = (gda.cError == "" || gda.cError == null ? 200 : 500);
                _out.cMsj = gda.cError;
            }
            catch (Exception ex)
            {
                _out.nMsjCode = 500;
                _out.cMsj = ex.ToString();
            }
            return _out;

        }

        [HttpPost]
        public GenericApiResponse fILCargarDepartamento(BEDepartamento obj)
        {
            GenericApiResponse _out = new GenericApiResponse();
            GenericEntityDAResponse gda = new GenericEntityDAResponse();
            try
            {
                gda = new BLFichaPostulante().fnBLListDepartamento(obj);
                _out.DtCollection = gda.dTable1;
                _out.nMsjCode = (gda.cError == "" || gda.cError == null ? 200 : 500);
                _out.cMsj = gda.cError;
            }
            catch (Exception ex)
            {
                _out.nMsjCode = 500;
                _out.cMsj = ex.ToString();
            }
            return _out;

        }



        [HttpPost]
        public GenericApiResponse fILCargarProvincia(BEProvincia obj)
        {
            GenericApiResponse _out = new GenericApiResponse();
            GenericEntityDAResponse gda = new GenericEntityDAResponse();
            try
            {
                gda = new BLFichaPostulante().fnBLListProvincia(obj);
                _out.DtCollection = gda.dTable1;
                _out.nMsjCode = (gda.cError == "" || gda.cError == null ? 200 : 500);
                _out.cMsj = gda.cError;
            }
            catch (Exception ex)
            {
                _out.nMsjCode = 500;
                _out.cMsj = ex.ToString();
            }
            return _out;

        }


        [HttpPost]
        public GenericApiResponse fILCargarDistrito(BEDistrito obj)
        {
            GenericApiResponse _out = new GenericApiResponse();
            GenericEntityDAResponse gda = new GenericEntityDAResponse();
            try
            {
                gda = new BLFichaPostulante().fnBLListDistrito(obj);
                _out.DtCollection = gda.dTable1;
                _out.nMsjCode = (gda.cError == "" || gda.cError == null ? 200 : 500);
                _out.cMsj = gda.cError;
            }
            catch (Exception ex)
            {
                _out.nMsjCode = 500;
                _out.cMsj = ex.ToString();
            }
            return _out;

        }
    }

}
