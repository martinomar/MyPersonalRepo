﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.BusinessLogic.Seguridad;
using Seguridad.Entity.GeneralLayer;
using SGTH.Entity.BusinessLogic.SGTH;
using SGTH.Entity.BusinessEntity.SGTH;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Web;
using System.Net.Http;
using System.Net.Mail;
using System.Web.Http;
using System.Web.Mail;
using System.Web.Security;
using System.Globalization;
using Newtonsoft.Json;
using SGTH.Entity.GeneralLayer;
using System.IO;

namespace SGTH.WebAPI.Controllers.SGTH
{
    public class PostulanteController : ApiController
    {

        [HttpPost]
        public GenericApiResponse fListaMotivoBL(BETipoAceptacionXMotivo obj)
        {

            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {
                daResult = new BLTipoAceptacionXMotivo().FListaMotivoBL(obj);

                if (daResult.cError == null || daResult.cError == "")
                {
                    apiRpta.nMsjCode = 200;
                    apiRpta.DtCollection = daResult.dTable1;
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }


        [HttpPost]
        public GenericApiResponse fRegistraMotivo(BETipoAceptacionXMotivo obj)
        {
            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {
                daResult = new BLPostulante().fnRegistraMotivo(obj);

                if (daResult.cError == null || daResult.cError == "")
                {
                    if (daResult.cAttr1 == "OK")
                    {
                        apiRpta.cMsj = "DA OK..";
                        apiRpta.nMsjCode = 200;
                    }
                    else
                    {
                        apiRpta.cMsj = "DA fail..";
                        apiRpta.nMsjCode = 500;
                    }
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }

        [HttpPost]
        public GenericApiResponse aListPtoMarc(BEPuntoMarcacion obj)
        {
            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {
                daResult = new BLPuntoMarcacion().FListaPuntosMarcaciones(obj);

                if (daResult.cError == null || daResult.cError == "")
                {
                    if (daResult.cAttr1 == "OK")
                    {
                        apiRpta.DtCollection = daResult.dTable1;
                        apiRpta.cMsj = "DA OK..";
                        apiRpta.nMsjCode = 200;
                    }
                    else
                    {
                        apiRpta.cMsj = "DA fail..";
                        apiRpta.nMsjCode = 500;
                    }
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }
        [HttpPost]
        public GenericApiResponse aListCalendario(BECalendarioXPuntoRDA obj)
        {
            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {
                daResult = new BLCalendario().FILListaClnPntMrcBL(obj);
                if (daResult.cError == null || daResult.cError == "")
                {
                    if (daResult.cAttr1 == "OK")
                    {
                        apiRpta.DtCollection = daResult.dTable1;
                        apiRpta.cMsj = "DA OK..";
                        apiRpta.nMsjCode = 200;
                    }
                    else
                    {
                        apiRpta.cMsj = "DA fail..";
                        apiRpta.nMsjCode = 500;
                    }
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }



        [HttpPost]
        public GenericApiResponse aListEmpresa(BEEmpresa obj)
        {
            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {
                daResult = new BLEmpresa().fListaEmpresaBL(obj);
                if (daResult.cError == null || daResult.cError == "")
                {
                    if (daResult.cAttr1 == "OK")
                    {
                        apiRpta.DtCollection = daResult.dTable1;
                        apiRpta.cMsj = "DA OK..";
                        apiRpta.nMsjCode = 200;
                    }
                    else
                    {
                        apiRpta.cMsj = "DA fail..";
                        apiRpta.nMsjCode = 500;
                    }
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }


        [HttpPost]
        public GenericApiResponse aListGrupo(BEGrupo obj)
        {
            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {
                daResult = new BLGrupo().fListaGrupoBL(obj);
                if (daResult.cError == null || daResult.cError == "")
                {
                    if (daResult.cAttr1 == "OK")
                    {
                        apiRpta.DtCollection = daResult.dTable1;
                        apiRpta.cMsj = "DA OK..";
                        apiRpta.nMsjCode = 200;
                    }
                    else
                    {
                        apiRpta.cMsj = "DA fail..";
                        apiRpta.nMsjCode = 500;
                    }
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }

        [HttpPost]
        public GenericApiResponse aListLineaServic(BELineaServicio obj)
        {
            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {
                daResult = new BLLineaServicio().fListarLineaServicioBL(obj);
                if (daResult.cError == null || daResult.cError == "")
                {
                    if (daResult.cAttr1 == "OK")
                    {
                        apiRpta.DtCollection = daResult.dTable1;
                        apiRpta.cMsj = "DA OK..";
                        apiRpta.nMsjCode = 200;
                    }
                    else
                    {
                        apiRpta.cMsj = "DA fail..";
                        apiRpta.nMsjCode = 500;
                    }
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }



        [HttpPost]
        public GenericApiResponse aListSubLinServ(BESubLineaServicio obj)
        {
            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {
                daResult = new BLSubLineaServicio().fListarSubLineaServicioBL(obj);
                if (daResult.cError == null || daResult.cError == "")
                {
                    if (daResult.cAttr1 == "OK")
                    {
                        apiRpta.DtCollection = daResult.dTable1;
                        apiRpta.cMsj = "DA OK..";
                        apiRpta.nMsjCode = 200;
                    }
                    else
                    {
                        apiRpta.cMsj = "DA fail..";
                        apiRpta.nMsjCode = 500;
                    }
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }


        [HttpPost]
        public GenericApiResponse aListServ(BEServicio obj)
        {
            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {
                daResult = new BLServicio().fListarServicioBL(obj);
                if (daResult.cError == null || daResult.cError == "")
                {
                    if (daResult.cAttr1 == "OK")
                    {
                        apiRpta.DtCollection = daResult.dTable1;
                        apiRpta.cMsj = "DA OK..";
                        apiRpta.nMsjCode = 200;
                    }
                    else
                    {
                        apiRpta.cMsj = "DA fail..";
                        apiRpta.nMsjCode = 500;
                    }
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }
        public GenericApiResponse fnRegistroVirtual_Post(BEPostulante obj)
        {
            GenericApiResponse _out = new GenericApiResponse();
            GenericEntityDAResponse _outDA = new GenericEntityDAResponse();
            try
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(obj);
                //return _out;
                if (json == "test")
                {
                    return _out;
                }

                obj.strOpcion = "1";//update postulante
                _outDA = new BLPostulante().fnBLRegistrarPostulante(obj);
                int _nPrsId = -1;
                _out.cMsj = _outDA.cAttr2;//error detalle
                _nPrsId = _outDA.nAttr1;//get nPrsId;
                _out.nMsj2 = _outDA.nAttr1;//get nPrsId;
                if (_nPrsId != -1)
                {
                    if (obj.pLisEstSupe != null)
                    {
                        for (int i = 0; i < obj.pLisEstSupe.Count; i++)
                        {
                            obj.pLisEstSupe[i].strOpcion = "02";
                            obj.pLisEstSupe[i].pnPrsId = _nPrsId;
                            _outDA = new BLPersonaXEstudio().fnBLRegistro(obj.pLisEstSupe[i]);
                        }
                    }
                    if (obj.pListCertif != null)
                    {
                        for (int i = 0; i < obj.pListCertif.Count; i++)
                        {

                            obj.pListCertif[i].strOpcion = "02";
                            obj.pListCertif[i].nPrsId = _nPrsId;
                            obj.pListCertif[i].pcEstado = "1";
                            _outDA = new BLPersonaXCertificacion().fnBLRegistro(obj.pListCertif[i]);
                        }
                    }

                    if (obj.pListConcTe != null)
                    {

                        for (int i = 0; i < obj.pListConcTe.Count; i++)
                        {
                            obj.pListConcTe[i].strOpcion = "1"; /*<<< */
                            obj.pListConcTe[i].pnPrsId = _nPrsId;
                            _outDA = new BLPersonaXConocimientoTecnico().fnBLRegistro(obj.pListConcTe[i]);
                        }
                    }
                    if (obj.pListIdioma != null)
                    {
                        for (int i = 0; i < obj.pListIdioma.Count; i++)
                        {
                            obj.pListIdioma[i].strOpcion = "02";
                            obj.pListIdioma[i].pnPrsId = _nPrsId;
                            obj.pListIdioma[i].pcEstado = "1";
                            _outDA = new BLPersonaXIdioma().fnBLRegistro(obj.pListIdioma[i]);
                        }
                    }


                    if (obj.pListExpLbs != null)
                    {
                        for (int i = 0; i < obj.pListExpLbs.Count; i++)
                        {
                            obj.pListExpLbs[i].strOpcion = "02";
                            obj.pListExpLbs[i].pnPrsId = _nPrsId;
                            _outDA = new BLPersonaXExperienciaLaboral().fnBLRegistro(obj.pListExpLbs[i]);
                        }
                    }

                    //-referencias:
                    if (obj.pListRefLab != null)
                    {
                        for (int i = 0; i < obj.pListRefLab.Count; i++)
                        {
                            obj.pListRefLab[i].strOpcion = "02";
                            obj.pListRefLab[i].pnPrsId = _nPrsId;
                            obj.pListRefLab[i].pcEstado = "1";
                            _outDA = new BLPersonaXReferencia().fnBLRegistro(obj.pListRefLab[i]);
                        }
                    }
                    if (obj.pListRefFam != null)
                    {
                        for (int i = 0; i < obj.pListRefFam.Count; i++)
                        {
                            obj.pListRefFam[i].strOpcion = "02";
                            obj.pListRefFam[i].pnPrsId = _nPrsId;
                            obj.pListRefFam[i].pcEstado = "1";
                            _outDA = new BLPersonaXReferencia().fnBLRegistro(obj.pListRefFam[i]);
                        }
                    }


                    //-antecedentes:
                    if (obj.pListDeudas != null)
                    {
                        for (int i = 0; i < obj.pListDeudas.Count; i++)
                        {
                            obj.pListDeudas[i].strOpcion = "02";
                            obj.pListDeudas[i].pnPrsId = _nPrsId;
                            obj.pListDeudas[i].pcEstado = "1";
                            _outDA = new BLPersonaXDeuda().fnBLRegistro(obj.pListDeudas[i]);
                        }
                    }


                    if (obj.pListAntPen != null)
                    {
                        for (int i = 0; i < obj.pListAntPen.Count; i++)
                        {
                            obj.pListAntPen[i].strOpcion = "02";
                            obj.pListAntPen[i].pnPrsId = _nPrsId;
                            obj.pListAntPen[i].pcEstado = "1";
                            _outDA = new BLPersonaXAntecedente().fnBLRegistro(obj.pListAntPen[i]);
                        }
                    }

                    if (obj.pListAntPol != null)
                    {
                        for (int i = 0; i < obj.pListAntPol.Count; i++)
                        {
                            obj.pListAntPol[i].strOpcion = "02";
                            obj.pListAntPol[i].pnPrsId = _nPrsId;
                            obj.pListAntPol[i].pcEstado = "1";
                            _outDA = new BLPersonaXAntecedente().fnBLRegistro(obj.pListAntPol[i]);
                        }
                    }


                    //-enfermedades:
                    if (obj.pListEnferm != null)
                    {
                        for (int i = 0; i < obj.pListEnferm.Count; i++)
                        {
                            obj.pListEnferm[i].strOpcion = "02";
                            obj.pListEnferm[i].pnPrsId = _nPrsId;
                            obj.pListEnferm[i].pcEstado = "1";
                            _outDA = new BLPersonaXTratamientoEnfermedad().fnBLRegistro(obj.pListEnferm[i]);
                        }
                    }
                    //-carga familiar:
                    if (obj.pListCrgFam != null)
                    {
                        for (int i = 0; i < obj.pListCrgFam.Count; i++)
                        {
                            obj.pListCrgFam[i].pcOpcion = "02";
                            obj.pListCrgFam[i].pnPrsId = _nPrsId;
                            obj.pListCrgFam[i].pnAuxId = DateTime.Now.ToString("ddMMyyyyhhmmss"); /*¿para que?..*/
                            //obj.pListCrgFam[i].pcEstado = "1";
                            _outDA = new BLPersonaXFamilia().fnBLRegistro(obj.pListCrgFam[i]);
                        }
                    }
                    if (obj.pListHobbie != null)
                    {
                        for (int i = 0; i < obj.pListHobbie.Count; i++)
                        {
                            obj.pListHobbie[i].strOpcion = "02";
                            obj.pListHobbie[i].pnPrsId = _nPrsId;
                            obj.pListHobbie[i].pcEstado = "1";
                            _outDA = new BLPersonaXHobbie().fnBLRegistro(obj.pListHobbie[i]);
                        }
                    }


                }


                _out.nMsjCode = 200;
            }
            catch (Exception ex)
            {
                _out.cMsj = ex.ToString();
                _out.nMsjCode = 500;
            }
            return _out;
        }



        //Editar datos por parte de el encargado de gth
        public GenericApiResponse fnListarRegistroVirtual_Post(BEPostulante obj)
        {
            GenericApiResponse _out = new GenericApiResponse();
            GenericEntityDAResponse _outDA = new GenericEntityDAResponse();
            try
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(obj);
                //return _out;
                if (json == "test")
                {
                    return _out;
                }

                obj.strOpcion = "2";//listar postulante
                _outDA = new BLPostulante().fnBLListarPostulante(obj);
                int _nPrsId = -1;
                _out.cMsj = _outDA.cAttr2;//error detalle
                _out.nMsj2 = _outDA.nAttr1;//get nPrsId;
                _nPrsId = _outDA.nAttr1;
                if (_nPrsId > 0)
                {
                    if (obj.pLisEstSupe != null)
                    {
                        for (int i = 0; i < obj.pLisEstSupe.Count; i++)
                        {
                            obj.pLisEstSupe[i].strOpcion = "01";
                            obj.pLisEstSupe[i].pnPrsId = _nPrsId;
                            _outDA = new BLPersonaXEstudio().fnBLRegistro(obj.pLisEstSupe[i]);
                        }
                    }
                    if (obj.pListCertif != null)
                    {
                        for (int i = 0; i < obj.pListCertif.Count; i++)
                        {

                            obj.pListCertif[i].strOpcion = "01";
                            obj.pListCertif[i].nPrsId = _nPrsId;
                            obj.pListCertif[i].pcEstado = "1";
                            _outDA = new BLPersonaXCertificacion().fnBLRegistro(obj.pListCertif[i]);
                        }
                    }

                    if (obj.pListConcTe != null)
                    {

                        for (int i = 0; i < obj.pListConcTe.Count; i++)
                        {
                            obj.pListConcTe[i].strOpcion = "2"; /*<<< */
                            obj.pListConcTe[i].pnPrsId = _nPrsId;
                            _outDA = new BLPersonaXConocimientoTecnico().fnBLRegistro(obj.pListConcTe[i]);
                        }
                    }
                    if (obj.pListIdioma != null)
                    {
                        for (int i = 0; i < obj.pListIdioma.Count; i++)
                        {
                            obj.pListIdioma[i].strOpcion = "01";
                            obj.pListIdioma[i].pnPrsId = _nPrsId;
                            obj.pListIdioma[i].pcEstado = "1";
                            _outDA = new BLPersonaXIdioma().fnBLRegistro(obj.pListIdioma[i]);
                        }
                    }


                    if (obj.pListExpLbs != null)
                    {
                        for (int i = 0; i < obj.pListExpLbs.Count; i++)
                        {
                            obj.pListExpLbs[i].strOpcion = "01";
                            obj.pListExpLbs[i].pnPrsId = _nPrsId;
                            _outDA = new BLPersonaXExperienciaLaboral().fnBLRegistro(obj.pListExpLbs[i]);
                        }
                    }

                    //-referencias:
                    if (obj.pListRefLab != null)
                    {
                        for (int i = 0; i < obj.pListRefLab.Count; i++)
                        {
                            obj.pListRefLab[i].strOpcion = "01";
                            obj.pListRefLab[i].pnPrsId = _nPrsId;
                            obj.pListRefLab[i].pcEstado = "1";
                            _outDA = new BLPersonaXReferencia().fnBLRegistro(obj.pListRefLab[i]);
                        }
                    }
                    if (obj.pListRefFam != null)
                    {
                        for (int i = 0; i < obj.pListRefFam.Count; i++)
                        {
                            obj.pListRefFam[i].strOpcion = "01";
                            obj.pListRefFam[i].pnPrsId = _nPrsId;
                            obj.pListRefFam[i].pcEstado = "1";
                            _outDA = new BLPersonaXReferencia().fnBLRegistro(obj.pListRefFam[i]);
                        }
                    }


                    //-antecedentes:
                    if (obj.pListDeudas != null)
                    {
                        for (int i = 0; i < obj.pListDeudas.Count; i++)
                        {
                            obj.pListDeudas[i].strOpcion = "01";
                            obj.pListDeudas[i].pnPrsId = _nPrsId;
                            obj.pListDeudas[i].pcEstado = "1";
                            _outDA = new BLPersonaXDeuda().fnBLRegistro(obj.pListDeudas[i]);
                        }
                    }


                    if (obj.pListAntPen != null)
                    {
                        for (int i = 0; i < obj.pListAntPen.Count; i++)
                        {
                            obj.pListAntPen[i].strOpcion = "01";
                            obj.pListAntPen[i].pnPrsId = _nPrsId;
                            obj.pListAntPen[i].pcEstado = "1";
                            _outDA = new BLPersonaXAntecedente().fnBLRegistro(obj.pListAntPen[i]);
                        }
                    }

                    if (obj.pListAntPol != null)
                    {
                        for (int i = 0; i < obj.pListAntPol.Count; i++)
                        {
                            obj.pListAntPol[i].strOpcion = "01";
                            obj.pListAntPol[i].pnPrsId = _nPrsId;
                            obj.pListAntPol[i].pcEstado = "1";
                            _outDA = new BLPersonaXAntecedente().fnBLRegistro(obj.pListAntPol[i]);
                        }
                    }


                    //-enfermedades:
                    if (obj.pListEnferm != null)
                    {
                        for (int i = 0; i < obj.pListEnferm.Count; i++)
                        {
                            obj.pListEnferm[i].strOpcion = "01";
                            obj.pListEnferm[i].pnPrsId = _nPrsId;
                            obj.pListEnferm[i].pcEstado = "1";
                            _outDA = new BLPersonaXTratamientoEnfermedad().fnBLRegistro(obj.pListEnferm[i]);
                        }
                    }
                    //-carga familiar:
                    if (obj.pListCrgFam != null)
                    {
                        for (int i = 0; i < obj.pListCrgFam.Count; i++)
                        {
                            obj.pListCrgFam[i].pcOpcion = "05";
                            obj.pListCrgFam[i].pnPrsId = _nPrsId;
                            obj.pListCrgFam[i].pnAuxId = DateTime.Now.ToString("ddMMyyyyhhmmss"); /*¿para que?..*/
                            //obj.pListCrgFam[i].pcEstado = "1";
                            _outDA = new BLPersonaXFamilia().fnBLRegistro(obj.pListCrgFam[i]);
                        }
                    }
                    if (obj.pListHobbie != null)
                    {
                        for (int i = 0; i < obj.pListHobbie.Count; i++)
                        {
                            obj.pListHobbie[i].strOpcion = "01";
                            obj.pListHobbie[i].pnPrsId = _nPrsId;
                            obj.pListHobbie[i].pcEstado = "1";
                            _outDA = new BLPersonaXHobbie().fnBLRegistro(obj.pListHobbie[i]);
                        }
                    }


                }


                _out.nMsjCode = 200;
            }
            catch (Exception ex)
            {
                _out.cMsj = ex.ToString();
                _out.nMsjCode = 500;
            }
            return _out;
        }


        [HttpPost]
        public GenericApiResponse aListArea(BEArea obj)
        {
            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {
                daResult = new BLArea().fListarAreaBL(obj);
                if (daResult.cError == null || daResult.cError == "")
                {
                    if (daResult.cAttr1 == "OK")
                    {
                        apiRpta.DtCollection = daResult.dTable1;
                        apiRpta.cMsj = "DA OK..";
                        apiRpta.nMsjCode = 200;
                    }
                    else
                    {
                        apiRpta.cMsj = "DA fail..";
                        apiRpta.nMsjCode = 500;
                    }
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }

        [HttpPost]
        public GenericApiResponse aListCargoContrat(BEArea obj)
        {
            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {
                daResult = new BLContrato().fILCargoContratoBL(obj.pnAreaId);
                if (daResult.cError == null || daResult.cError == "")
                {
                    if (daResult.cAttr1 == "OK")
                    {
                        apiRpta.DtCollection = daResult.dTable1;
                        apiRpta.cMsj = "DA OK..";
                        apiRpta.nMsjCode = 200;
                    }
                    else
                    {
                        apiRpta.cMsj = "DA fail..";
                        apiRpta.nMsjCode = 500;
                    }
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }


        public GenericApiResponse fObtenerCorreoBL(BEContrato obj)
        {
            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {
                daResult = new BLContrato().fObtenerCorreoBL(obj);
                if (daResult.cError == null || daResult.cError == "")
                {
                    apiRpta.cMsj = daResult.cAttr1;
                    apiRpta.nMsjCode = 200;
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }

        public GenericApiResponse fListaCorreoPracticasBL(GenericAPIRequest obj)
        {
            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {
                daResult = new BLContrato().fListaCorreoPracticasBL(obj.nPrm_1);
                if (daResult.cError == null || daResult.cError == "")
                {
                    apiRpta.DtCollection = daResult.dTable1;
                    apiRpta.nMsjCode = 200;
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }


        [HttpPost]
        public GenericApiResponse fPaseColaborador(BEPaseColaborador obj)
        {
            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {

                BEPostulante objPostulante = new BEPostulante();

                #region(Proc. 1/6 - se obtiene los datos del postulante)
                /*  >>  al consultar el registro, se valida el estado de "activo" (cEstado = 1)
                  Nota: al consultar se deberia validar que el nTpoPersona = 1, es decir postulante
                        ya que podria darse el caso de que se involuntariamente se registre un pase por 2da vez...
                */

                objPostulante.strOpcion = "3";
                objPostulante.pnPersonaId = obj.objPostulante.pnPersonaId;
                objPostulante.pnFicId = obj.objPostulante.pnFicId;
                GenericEntityDAResponse _Gda_postulnte = new GenericEntityDAResponse();
                _Gda_postulnte = new BLPostulante().fObtienePostulanteBL(objPostulante);

                if (_Gda_postulnte.dTable1 == null || _Gda_postulnte.dTable1.Rows.Count == 0)
                {
                    apiRpta.cMsj = "Proc. 1/6 - se obtiene los datos del postulante";
                    apiRpta.cMsjDetaill = "fObtienePostulanteBL() No se logro obtener los datos del postulante...";
                    apiRpta.nMsjCode = 500;
                    return apiRpta;
                }
                #endregion




                #region(Proc. 2/6 - registro del postulante)
                /*en este paso se hace la actualizacion de datos, de Persona, tambien se insertan datos en PuntoMarcacionXPersona y CalendarioXPersona
                 */

                objPostulante.strOpcion = "5";
                objPostulante.pnAnexo = obj.objPostulante.pnAnexo;
                objPostulante.pnPntClnId = obj.objPostulante.pnPntClnId;
                objPostulante.pdtFchIngreso = obj.objPostulante.pdtFchIngreso;
                objPostulante.pnUsuarioRegistraId = obj.objPostulante.pnUsuarioRegistraId;

                objPostulante.pnTpoColab = obj.objPostulante.pnTpoColab;
                objPostulante.pnModForm = obj.objPostulante.pnModForm;

                GenericEntityDAResponse _Gda_paseColab = new BLPostulante().fPaseColaboradorBL(objPostulante);
                if (_Gda_paseColab.cAttr1.Trim() != "OK")
                {
                    apiRpta.cMsj = "Proc. 2/6 - registro del postulante";
                    apiRpta.cMsjDetaill = "fPaseColaboradorBL() Ocurrio un error al registrar el pase a colaborador..." + _Gda_paseColab.cError.Trim();
                    apiRpta.nMsjCode = 500;
                    return apiRpta;
                }

                #endregion





                #region(Proc. 3/6 - registro del contrato)

                //FIN AAB 27/10/2016 - SES
                BEContrato objContrato = new BEContrato();
                objContrato.strOpcion = "1";
                objContrato.pnPersonaId = obj.objContrato.pnPersonaId;
                objContrato.pdtFchInicio = obj.objContrato.pdtFchFin;
                // INI - 30/09/2016 - MAT
                //objContrato.pdtFchFin = txtFchFin.Text;
                // FIN - 30/09/2016 - MAT

                //objContrato.pdtFchFin = ddlTipoCont.SelectedValue != "2" ? txtFchFin.Text : "31/12/9999"; //MAT
                objContrato.pdtFchFin = obj.objContrato.pnTipoContratoId != 2 ? obj.objContrato.pdtFchFin : "31/12/9999"; //MAT
                objContrato.pnEmpId = obj.objContrato.pnEmpId;
                objContrato.pnTipoContratoId = obj.objContrato.pnTipoContratoId;
                objContrato.pnPerfilId = obj.objContrato.pnPerfilId;
                objContrato.pnCargoId = obj.objContrato.pnCargoId;
                objContrato.pnModalidadId = obj.objContrato.pnModalidadId;
                objContrato.pnAreaId = obj.objContrato.pnAreaId;
                objContrato.pvCorreo = obj.objContrato.pvCorreo;
                objContrato.pcMinTra = obj.objContrato.pcMinTra; /*06.11.2018 martin.delgado*/
                objContrato.pcRenovable = obj.objContrato.pcRenovable;
                objContrato.pnUsuID = obj.objContrato.pnUsuID;/*06.11.2018 martin.delgado*/

                GenericEntityDAResponse _Gda_contrat = new BLContrato().fRegistraContratoBL(objContrato);

                if (_Gda_contrat.cAttr1 != "OK")
                {
                    apiRpta.cMsj = "Proc. 3/6 - registro del contrato";
                    apiRpta.cMsjDetaill = "fRegistraContratoBL() Ocurrio un error al registrar el contrato...." + _Gda_contrat.cError.Trim();
                    apiRpta.nMsjCode = 500;
                    return apiRpta;
                }

                #endregion





                #region(Proc. 4/6 - validar Provision de vacaciones)

                //INI JGA 03-03-2017 - SESNEW
                BEProvision objELProvision = new BEProvision();
                objELProvision.pnPrsId = obj.objProvision.pnPrsId;

                GenericEntityDAResponse _Gda_provisn = new BLProvision().fValidarProvision(objELProvision);

                if (_Gda_provisn.cAttr1 != "0")
                {
                    apiRpta.cMsj = "Proc. 4/6 - validar Provision de vacaciones";
                    apiRpta.cMsjDetaill = "fValidarProvision() ha retornado un valor diferente al esperado a cero(0)... el parámetro @pnPrsId=" + objELProvision.pnPrsId + " ha retornado cAttr1=" + _Gda_provisn.cAttr1;
                    apiRpta.nMsjCode = 500;
                    return apiRpta;
                }

                #endregion





                #region(Proc. 5/6 - registro de Provision de vacaciones)

                objELProvision.pdtFchIni = obj.objProvision.pdtFchIni;
                DateTime dtFechaInicio = objELProvision.pdtFchIni;
                DateTime dtFechaFin = dtFechaInicio.AddDays(-1).AddYears(1);
                objELProvision.pdtFechaFin = dtFechaFin;

                GenericEntityDAResponse _Gda_provisionVacac = new BLProvision().fInsProvVacPaseCol(objELProvision);
                if (_Gda_provisionVacac.cAttr1.Trim() != "OK")
                {
                    apiRpta.cMsj = "Proc. 5/6 - registro de Provision de vacaciones";
                    apiRpta.cMsjDetaill = "4121 no se logro registrar la provision de vacaciones... fInsProvVacPaseCol()...";
                    apiRpta.nMsjCode = 500;
                    return apiRpta;
                }

                #endregion





                #region(Proc. 6/6 - registro de Provision de vacaciones)

                BEProyecto objProyecto = new BEProyecto();
                objProyecto.pnPrsId = obj.objProyecto.pnPrsId;
                objProyecto.pnProyectoId = obj.objProyecto.pnProyectoId;
                objProyecto.pdtFchInicio = obj.objProyecto.pdtFchInicio;
                // INI - 30/09/2016 - MAT
                //objProyecto.pdtFchFin = DateTime.Parse(txtFchFin.Text.ToString());
                // FIN - 30/09/2016 - MAT

                //objProyecto.pdtFchFin = ddlTipoCont.SelectedValue != "2" ? DateTime.Parse(txtFchFin.Text.ToString()) : DateTime.Parse("31/12/9999"); //MAT
                objProyecto.pdtFchFin = obj.objContrato.pnTipoContratoId != 2 ? obj.objProyecto.pdtFchFin : DateTime.Parse("31/12/9999"); //MAT


                objProyecto.pnGrpId = obj.objProyecto.pnGrpId;
                //INI AAB 27/10/2016 - SES
                GenericEntityDAResponse _Gda_proyectoPerson = new BLProyecto().fRegistraDatosProyectoBL(objProyecto);

                if (_Gda_proyectoPerson.cAttr1.Trim() == "OK")
                {
                    apiRpta.nMsjCode = 200;
                    apiRpta.cMsj = "Proc. 6/6 - registro de Provision de vacaciones";
                    apiRpta.cMsjDetaill = "se completo el registro del Pase a Colaborador...";
                    return apiRpta;
                }
                else
                {
                    apiRpta.cMsj = "Proc. 6/6 - registro de Provision de vacaciones";
                    apiRpta.cMsjDetaill = "412301 El registro de provision ha retornado un valor desconocido...";
                    apiRpta.nMsjCode = 500;
                    return apiRpta;
                }

                #endregion



            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }

    }
}