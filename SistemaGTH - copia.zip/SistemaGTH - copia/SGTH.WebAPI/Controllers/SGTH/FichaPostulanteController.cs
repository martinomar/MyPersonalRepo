﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.BusinessLogic.Seguridad;
using Seguridad.Entity.GeneralLayer;
using SGTH.Entity.BusinessLogic.SGTH;
using SGTH.Entity.BusinessEntity.SGTH;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Web;
using System.Net.Http;
using System.Net.Mail;
using System.Web.Http;
using System.Web.Mail;
using System.Web.Security;
using System.Globalization;
using Newtonsoft.Json;
using SGTH.Entity.GeneralLayer;
using System.IO;

namespace SGTH.WebAPI.Controllers
{
    public class FichaPostulanteController : ApiController
    {
        public class paramss
        {
            public string dni { get; set; }
            public string cryp { get; set; }
            public string fechaCaduca { get; set; }
        }

        public class UploadFile
        {

            public System.Web.HttpPostedFileBase aFile { get; set; }
            public int codigo { get; set; }
            public string cadena { get; set; }
        }

        private paramss dcrParam(string _param)
        {
            /*decriptParam*/
            paramss oparamss = new paramss();
            try
            {
                /*when we put symbol sum (+) the url convert this value to %2, then, when we recover, this is parse to empty (" ")*/
                _param = _param.Replace(" ", "+");
                var _decrypted = new CryptoSecurity().BLDEcryptURLparam(_param);
                /* <if its necesary to valid the output of decrypt method, put your code here..>*/
                _decrypted = "{" + _decrypted + "}";
                dynamic data = System.Web.Helpers.Json.Decode(_decrypted);
                oparamss.dni = data.dni;
                oparamss.fechaCaduca = data.fechaCaduca;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return oparamss;
        }

        [HttpPost]
        public object fValidarEnlace(paramss _prms)
        {
            string _prm = _prms.cryp;
            object _out;
            GenericEntityDAResponse DAResp = new GenericEntityDAResponse();
            try
            {
                //string _prm = "";
                paramss _parameters = dcrParam(_prm);

                System.Globalization.CultureInfo cultureinfo = new System.Globalization.CultureInfo("es-PE");
                DateTime _fechaCaduca = DateTime.Parse(_parameters.fechaCaduca, cultureinfo);
                /*#01 - validar caduciadad*/
                if (_fechaCaduca < DateTime.Now)
                {
                    DAResp.cMsg3 = "API:Enlace Caducado.    att.SES";
                }
                else
                {
                    DAResp = new BLFichaPostulante().fnBLConsultarPreRegistroPostulanteXDNI(_parameters.dni);
                    if (DAResp.nAttr1 > 0)
                    {
                        if (DAResp.cMsg1 == "OK")
                        {
                            DAResp.cMsg3 = "API:El postulante puede ingresar a la interfaz de registro de ficha de postulante";
                        }
                        else
                        {
                            DAResp.cMsg3 = "API:El postulante no se encuentra validado...";
                        }
                    }
                    else
                    {
                        DAResp.cMsg3 = "API:ha ocurrido un error inesperado, no se logro consultar el pre-registro del postulante...";
                    }
                }

            }
            catch (Exception ex)
            {
                //_out = ex.ToString();
                DAResp.cMsg3 = "API:Parámetro No valido...";
                DAResp.cMsg4 = ex.ToString();
            }
            _out = DAResp;
            _out = clearObjectAPIResponse(_out);
            return _out;
        }


        private object clearObjectAPIResponse(object obj)
        {
            object _out1;
            var obj_jsonSerialized = JsonConvert.SerializeObject(obj,
                             Newtonsoft.Json.Formatting.None,
                             new JsonSerializerSettings
                             {
                                 NullValueHandling = NullValueHandling.Ignore
                                 ,
                                 StringEscapeHandling = StringEscapeHandling.EscapeNonAscii
                             });
            _out1 = JsonConvert.DeserializeObject<object>(obj_jsonSerialized);
            //fuente: https://stackoverflow.com/questions/6507889/how-to-ignore-a-property-in-class-if-null-using-json-net

            return _out1;
        }


        public GenericApiResponse fnRegistroVirtual_FichPost(BEPostulante obj)
        {
            GenericApiResponse _out = new GenericApiResponse();
            GenericEntityDAResponse _outDA = new GenericEntityDAResponse();
            try
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(obj);
                //return _out;
                if (json == "test")
                {
                    return _out;
                }

                obj.strOpcion = "7";//update postulante
                _outDA = new BLPostulante().fnBLRegistrarPostulante(obj);
                int _nPrsId = -1;
                _out.cMsj = _outDA.cAttr2;//error detalle
                _nPrsId = _outDA.nAttr1;//get nPrsId;
                _out.nMsj2 = _outDA.nAttr1;//get nPrsId;
                if (_nPrsId != -1)
                {
                    if (obj.pLisEstSupe != null)
                    {
                        for (int i = 0; i < obj.pLisEstSupe.Count; i++)
                        {
                            obj.pLisEstSupe[i].strOpcion = "02";
                            obj.pLisEstSupe[i].pnPrsId = _nPrsId;
                            _outDA = new BLPersonaXEstudio().fnBLRegistro(obj.pLisEstSupe[i]);
                        }
                    }
                    if (obj.pListCertif != null)
                    {
                        for (int i = 0; i < obj.pListCertif.Count; i++)
                        {

                            obj.pListCertif[i].strOpcion = "02";
                            obj.pListCertif[i].nPrsId = _nPrsId;
                            obj.pListCertif[i].pcEstado = "1";
                            _outDA = new BLPersonaXCertificacion().fnBLRegistro(obj.pListCertif[i]);
                        }
                    }

                    if (obj.pListConcTe != null)
                    {

                        for (int i = 0; i < obj.pListConcTe.Count; i++)
                        {
                            obj.pListConcTe[i].strOpcion = "1"; /*<<< */
                            obj.pListConcTe[i].pnPrsId = _nPrsId;
                            _outDA = new BLPersonaXConocimientoTecnico().fnBLRegistro(obj.pListConcTe[i]);
                        }
                    }
                    if (obj.pListIdioma != null)
                    {
                        for (int i = 0; i < obj.pListIdioma.Count; i++)
                        {
                            obj.pListIdioma[i].strOpcion = "02";
                            obj.pListIdioma[i].pnPrsId = _nPrsId;
                            obj.pListIdioma[i].pcEstado = "1";
                            _outDA = new BLPersonaXIdioma().fnBLRegistro(obj.pListIdioma[i]);
                        }
                    }


                    if (obj.pListExpLbs != null)
                    {
                        for (int i = 0; i < obj.pListExpLbs.Count; i++)
                        {
                            obj.pListExpLbs[i].strOpcion = "02";
                            obj.pListExpLbs[i].pnPrsId = _nPrsId;
                            _outDA = new BLPersonaXExperienciaLaboral().fnBLRegistro(obj.pListExpLbs[i]);
                        }
                    }

                    //-referencias:
                    if (obj.pListRefLab != null)
                    {
                        for (int i = 0; i < obj.pListRefLab.Count; i++)
                        {
                            obj.pListRefLab[i].strOpcion = "02";
                            obj.pListRefLab[i].pnPrsId = _nPrsId;
                            obj.pListRefLab[i].pcEstado = "1";
                            _outDA = new BLPersonaXReferencia().fnBLRegistro(obj.pListRefLab[i]);
                        }
                    }
                    if (obj.pListRefFam != null)
                    {
                        for (int i = 0; i < obj.pListRefFam.Count; i++)
                        {
                            obj.pListRefFam[i].strOpcion = "02";
                            obj.pListRefFam[i].pnPrsId = _nPrsId;
                            obj.pListRefFam[i].pcEstado = "1";
                            _outDA = new BLPersonaXReferencia().fnBLRegistro(obj.pListRefFam[i]);
                        }
                    }


                    //-antecedentes:
                    if (obj.pListDeudas != null)
                    {
                        for (int i = 0; i < obj.pListDeudas.Count; i++)
                        {
                            obj.pListDeudas[i].strOpcion = "02";
                            obj.pListDeudas[i].pnPrsId = _nPrsId;
                            obj.pListDeudas[i].pcEstado = "1";
                            _outDA = new BLPersonaXDeuda().fnBLRegistro(obj.pListDeudas[i]);
                        }
                    }


                    if (obj.pListAntPen != null)
                    {
                        for (int i = 0; i < obj.pListAntPen.Count; i++)
                        {
                            obj.pListAntPen[i].strOpcion = "02";
                            obj.pListAntPen[i].pnPrsId = _nPrsId;
                            obj.pListAntPen[i].pcEstado = "1";
                            _outDA = new BLPersonaXAntecedente().fnBLRegistro(obj.pListAntPen[i]);
                        }
                    }

                    if (obj.pListAntPol != null)
                    {
                        for (int i = 0; i < obj.pListAntPol.Count; i++)
                        {
                            obj.pListAntPol[i].strOpcion = "02";
                            obj.pListAntPol[i].pnPrsId = _nPrsId;
                            obj.pListAntPol[i].pcEstado = "1";
                            _outDA = new BLPersonaXAntecedente().fnBLRegistro(obj.pListAntPol[i]);
                        }
                    }


                    //-enfermedades:
                    if (obj.pListEnferm != null)
                    {
                        for (int i = 0; i < obj.pListEnferm.Count; i++)
                        {
                            obj.pListEnferm[i].strOpcion = "02";
                            obj.pListEnferm[i].pnPrsId = _nPrsId;
                            obj.pListEnferm[i].pcEstado = "1";
                            _outDA = new BLPersonaXTratamientoEnfermedad().fnBLRegistro(obj.pListEnferm[i]);
                        }
                    }
                    //-carga familiar:
                    if (obj.pListCrgFam != null)
                    {
                        for (int i = 0; i < obj.pListCrgFam.Count; i++)
                        {
                            obj.pListCrgFam[i].pcOpcion = "02";
                            obj.pListCrgFam[i].pnPrsId = _nPrsId;
                            obj.pListCrgFam[i].pnAuxId = DateTime.Now.ToString("ddMMyyyyhhmmss"); /*¿para que?..*/
                            //obj.pListCrgFam[i].pcEstado = "1";
                            _outDA = new BLPersonaXFamilia().fnBLRegistro(obj.pListCrgFam[i]);
                        }
                    }
                    if (obj.pListHobbie != null)
                    {
                        for (int i = 0; i < obj.pListHobbie.Count; i++)
                        {
                            obj.pListHobbie[i].strOpcion = "02";
                            obj.pListHobbie[i].pnPrsId = _nPrsId;
                            obj.pListHobbie[i].pcEstado = "1";
                            _outDA = new BLPersonaXHobbie().fnBLRegistro(obj.pListHobbie[i]);
                        }
                    }


                }


                _out.nMsjCode = 200;
            }
            catch (Exception ex)
            {
                _out.cMsj = ex.ToString();
                _out.nMsjCode = 500;
            }
            return _out;
        }


        [HttpPost]
        public GenericApiResponse aListCrgCntrto(BECargoPresentarse obj)
        {
            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {

                daResult = new BLCargoPresentarse().fnGetList();

                if (daResult.cError == null || daResult.cError == "")
                {
                    apiRpta.nMsjCode = 200;
                    apiRpta.DtCollection = daResult.dTable1;
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }

        private string convertToJson(string str1, string str2)
        {
            var _out = "'dni':'" + str1 + "','fechaCaduca':'" + str2 + "'";
            //var _out = "{\"dni\":\"" + str1 + "\",\"fechaCaduca\":\"" + str2 + "\"}";
            //var _out = "{ \"dni\":\"" + str1 + "\",\"fc\":\"" + str2 + "\"}";
            //var _out = str1 + "|" + str2 + "";
            return _out;
        }
        private string Encrypt_X(string stringToEncrypt, string _KEY)
        {
            byte[] inputByteArray = System.Text.Encoding.UTF8.GetBytes(stringToEncrypt);
            byte[] rgbIV = { 0x21, 0x43, 0x56, 0x87, 0x10, 0xfd, 0xea, 0x1c };
            byte[] key = { };
            try
            {
                //key = System.Text.Encoding.UTF8.GetBytes("A0D1nX0Q");
                key = System.Text.Encoding.UTF8.GetBytes(_KEY);
                System.Security.Cryptography.DESCryptoServiceProvider des = new System.Security.Cryptography.DESCryptoServiceProvider();
                MemoryStream ms = new MemoryStream();
                System.Security.Cryptography.CryptoStream cs = new System.Security.Cryptography.CryptoStream(ms, des.CreateEncryptor(key, rgbIV), System.Security.Cryptography.CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                return Convert.ToBase64String(ms.ToArray());
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        [HttpPost]
        public GenericApiResponse aRegPostulante_modManual(BEPostulante obj)
        {
            GenericApiResponse _out = new GenericApiResponse();
            GenericEntityDAResponse _outDA = new GenericEntityDAResponse();
            try
            {
                _outDA = new BLPostulante().fnBLRegistrarPostulante(obj);
                int _nPrsId = -1;

                _nPrsId = _outDA.nAttr1;//get nPrsId;

                if (_nPrsId > 0)
                {
                    if (obj.pLisEstSupe != null)
                    {
                        for (int i = 0; i < obj.pLisEstSupe.Count; i++)
                        {
                            obj.pLisEstSupe[i].strOpcion = "02";
                            obj.pLisEstSupe[i].pnPrsId = _nPrsId;
                            _outDA = new BLPersonaXEstudio().fnBLRegistro(obj.pLisEstSupe[i]);
                        }
                    }
                    if (obj.pListCertif != null)
                    {
                        for (int i = 0; i < obj.pListCertif.Count; i++)
                        {

                            obj.pListCertif[i].strOpcion = "02";
                            obj.pListCertif[i].nPrsId = _nPrsId;
                            obj.pListCertif[i].pcEstado = "1";
                            _outDA = new BLPersonaXCertificacion().fnBLRegistro(obj.pListCertif[i]);
                        }
                    }

                    if (obj.pListConcTe != null)
                    {

                        for (int i = 0; i < obj.pListConcTe.Count; i++)
                        {
                            obj.pListConcTe[i].strOpcion = "1"; /*<<< */
                            obj.pListConcTe[i].pnPrsId = _nPrsId;
                            _outDA = new BLPersonaXConocimientoTecnico().fnBLRegistro(obj.pListConcTe[i]);
                        }
                    }
                    if (obj.pListIdioma != null)
                    {
                        for (int i = 0; i < obj.pListIdioma.Count; i++)
                        {
                            obj.pListIdioma[i].strOpcion = "02";
                            obj.pListIdioma[i].pnPrsId = _nPrsId;
                            obj.pListIdioma[i].pcEstado = "1";
                            _outDA = new BLPersonaXIdioma().fnBLRegistro(obj.pListIdioma[i]);
                        }
                    }


                    if (obj.pListExpLbs != null)
                    {
                        for (int i = 0; i < obj.pListExpLbs.Count; i++)
                        {
                            obj.pListExpLbs[i].strOpcion = "02";
                            obj.pListExpLbs[i].pnPrsId = _nPrsId;
                            _outDA = new BLPersonaXExperienciaLaboral().fnBLRegistro(obj.pListExpLbs[i]);
                        }
                    }

                    //-referencias:
                    if (obj.pListRefLab != null)
                    {
                        for (int i = 0; i < obj.pListRefLab.Count; i++)
                        {
                            obj.pListRefLab[i].strOpcion = "02";
                            obj.pListRefLab[i].pnPrsId = _nPrsId;
                            obj.pListRefLab[i].pcEstado = "1";
                            _outDA = new BLPersonaXReferencia().fnBLRegistro(obj.pListRefLab[i]);
                        }
                    }
                    if (obj.pListRefFam != null)
                    {
                        for (int i = 0; i < obj.pListRefFam.Count; i++)
                        {
                            obj.pListRefFam[i].strOpcion = "02";
                            obj.pListRefFam[i].pnPrsId = _nPrsId;
                            obj.pListRefFam[i].pcEstado = "1";
                            _outDA = new BLPersonaXReferencia().fnBLRegistro(obj.pListRefFam[i]);
                        }
                    }


                    //-antecedentes:
                    if (obj.pListDeudas != null)
                    {
                        for (int i = 0; i < obj.pListDeudas.Count; i++)
                        {
                            obj.pListDeudas[i].strOpcion = "02";
                            obj.pListDeudas[i].pnPrsId = _nPrsId;
                            obj.pListDeudas[i].pcEstado = "1";
                            _outDA = new BLPersonaXDeuda().fnBLRegistro(obj.pListDeudas[i]);
                        }
                    }


                    if (obj.pListAntPen != null)
                    {
                        for (int i = 0; i < obj.pListAntPen.Count; i++)
                        {
                            obj.pListAntPen[i].strOpcion = "02";
                            obj.pListAntPen[i].pnPrsId = _nPrsId;
                            obj.pListAntPen[i].pcEstado = "1";
                            _outDA = new BLPersonaXAntecedente().fnBLRegistro(obj.pListAntPen[i]);
                        }
                    }

                    if (obj.pListAntPol != null)
                    {
                        for (int i = 0; i < obj.pListAntPol.Count; i++)
                        {
                            obj.pListAntPol[i].strOpcion = "02";
                            obj.pListAntPol[i].pnPrsId = _nPrsId;
                            obj.pListAntPol[i].pcEstado = "1";
                            _outDA = new BLPersonaXAntecedente().fnBLRegistro(obj.pListAntPol[i]);
                        }
                    }


                    //-enfermedades:
                    if (obj.pListEnferm != null)
                    {
                        for (int i = 0; i < obj.pListEnferm.Count; i++)
                        {
                            obj.pListEnferm[i].strOpcion = "02";
                            obj.pListEnferm[i].pnPrsId = _nPrsId;
                            obj.pListEnferm[i].pcEstado = "1";
                            _outDA = new BLPersonaXTratamientoEnfermedad().fnBLRegistro(obj.pListEnferm[i]);
                        }
                    }
                    //-carga familiar:
                    if (obj.pListCrgFam != null)
                    {
                        for (int i = 0; i < obj.pListCrgFam.Count; i++)
                        {
                            obj.pListCrgFam[i].pcOpcion = "02";
                            obj.pListCrgFam[i].pnPrsId = _nPrsId;
                            obj.pListCrgFam[i].pnAuxId = DateTime.Now.ToString("ddMMyyyyhhmmss"); /*¿para que?..*/
                            //obj.pListCrgFam[i].pcEstado = "1";
                            _outDA = new BLPersonaXFamilia().fnBLRegistro(obj.pListCrgFam[i]);
                        }
                    }
                    if (obj.pListHobbie != null)
                    {
                        for (int i = 0; i < obj.pListHobbie.Count; i++)
                        {
                            obj.pListHobbie[i].strOpcion = "02";
                            obj.pListHobbie[i].pnPrsId = _nPrsId;
                            obj.pListHobbie[i].pcEstado = "1";
                            _outDA = new BLPersonaXHobbie().fnBLRegistro(obj.pListHobbie[i]);
                        }
                    }


                }


                _out.nMsjCode = 200;

            }
            catch (Exception ex)
            {
                _out.cMsjDetaill = ex.ToString();
                throw;
            }
            return _out;
        }


        [HttpPost]
        public GenericApiResponse aRegEnvrCrrPost(BEPostulante obj)
        {
            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();

            string _rptEnvioEmail = "";
            string _logHelp = "";

            int _diasURL_Activo = 2;
            DateTime _fechaCaduca;
            string _fCaduca;
            try
            {
                _diasURL_Activo = int.Parse(ConfigurationManager.AppSettings["fichPost_RegVirtual_URL_NumeroDiasHabil"].ToString());
                #region (#01 URL - fecha de caducidad)

                System.Globalization.CultureInfo cultureinfo = new System.Globalization.CultureInfo("es-PE");
                _fechaCaduca = DateTime.Parse(DateTime.Now.AddDays(_diasURL_Activo).ToShortDateString(), cultureinfo);
                _fCaduca = _fechaCaduca.ToShortDateString();

                obj.strOpcion = "1";

                {  /*  se setea valores para pasar el registro ya que 
                    *  en la tabla, estos campos son foreing key (property NOT NULL), 
                    *  estos valores serán editados una vez que el usuario 
                    *  registre o complete sus datos a través del enlace..
                    */
                    obj.pnDstDmcId = 1;
                    obj.pnDstNacId = 1;
                }

                #endregion

                #region (#02 validacíón de parámetros para el envio de correo:)
                /*se valida parámetros de configuración para el envio de correo, 
                  se realiza antes de proceder el registro ya que si primero 
                  se registran los datos por algun error con la solicitud al servidor..
                  el usuario no recibirá en el enlace para completar sus registros...*/
                string _urlDomain = "";
                _urlDomain = ConfigurationManager.AppSettings["fichPost_RegVirtual_URLDomain"].ToString();
                if (_urlDomain == "" || _urlDomain == null)
                {
                    apiRpta.cMsj = "No se encontro el parámetro de configuración 'fichPost_RegVirtual_URLDomain'";
                    return apiRpta;
                }

                string _keyEncryp = "";
                _keyEncryp = ConfigurationManager.AppSettings["fichPost_RegVirtual_URLKeyEncrypParam"].ToString();
                if (_keyEncryp == "" || _keyEncryp == null)
                {
                    apiRpta.cMsj = "No se encontro el parámetro de configuración 'fichPost_RegVirtual_URLKeyEncrypParam'";
                    return apiRpta;
                }

                string _correoRemitente = "";
                _correoRemitente = ConfigurationManager.AppSettings["fichPost_RegVirtual_CorreoRemitente"].ToString();
                if (_correoRemitente == "" || _correoRemitente == null)
                {
                    apiRpta.cMsj = "No se encontro el parámetro de configuración 'fichPost_RegVirtual_CorreoRemitente'";
                    return apiRpta;
                }
                string _asunto = "";
                _asunto = ConfigurationManager.AppSettings["fichPost_RegVirtual_CorreoAsunto"].ToString();
                if (_asunto == "" || _asunto == null)
                {
                    apiRpta.cMsj = "No se encontro el parámetro de configuración 'fichPost_RegVirtual_CorreoAsunto'";
                    return apiRpta;
                }

                #endregion

                //2.- encriptar URL
                string urlEncoded = "";



                #region (#03 encriptación de URL)


                string inptEncod = convertToJson(obj.pvDocNro, _fCaduca);
                urlEncoded = Encrypt_X(inptEncod, _keyEncryp);
                urlEncoded = Uri.EscapeDataString(urlEncoded);

                if (urlEncoded.Contains(" ") || urlEncoded == "La clave especificada no tiene el tamaño válido para este algoritmo.")//
                {
                    apiRpta.cMsj = "error al intentar generar la URL encriptada...";
                    return apiRpta;
                }

                #endregion

                daResult = new BLPostulante().fnBLRegistrarPostulante(obj);
                if (daResult.nAttr1 == 0)
                {
                    apiRpta.cMsj = "El DNI ya fue registrado anteriormente";
                    apiRpta.cMsjDetaill = daResult.cError;
                    apiRpta.nMsjCode = 501;
                    return apiRpta ;
                }
                if (daResult.cError == null || daResult.cError == "")
                {
                    //3.- enviar el correo
                    //_rptEnvioEmail = new  GLCorreo().enviarSolicitud_RegistroFichaPostulante(elpost, asunto, (_urlDomain + "" + urlEncoded), puesto, _correoRemitente);
                    _rptEnvioEmail = new Correo.Correo().enviarSolicitud_RegistroFichaPostulante(obj, _asunto, (_urlDomain + "" + urlEncoded), _correoRemitente);

                    if (_rptEnvioEmail.Trim() == "OK")
                    {
                        apiRpta.nMsjCode = 200;
                        apiRpta.DtCollection = daResult.dTable1;
                    }
                    else
                    {
                        apiRpta.cMsj = "error al intentar enviar el correo del postulante";
                        apiRpta.cMsjDetaill = daResult.cError;
                        apiRpta.nMsjCode = 500;
                    }
                }
                else
                {
                    apiRpta.cMsj = "error al intentar enviar el correo del postulante";
                    apiRpta.cMsjDetaill = daResult.cError;
                    apiRpta.nMsjCode = 500;
                }



            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;

        }

        /*[HttpPost]
        //public GenericApiResponse upload(System.Web.HttpPostedFileBase aFile, int codigo, string cadena)
        public GenericApiResponse upload(UploadFile oUploadFile)
        {
            GenericApiResponse _out = new GenericApiResponse();
            try
            {
                System.Web.HttpPostedFileBase aFile = oUploadFile.aFile;
                int codigo = oUploadFile.codigo;
                string cadena = oUploadFile.cadena;

                String strRuta = System.Web.Hosting.HostingEnvironment.MapPath(System.Configuration.ConfigurationManager.AppSettings.Get("rutaArchivos"));
                if (!Directory.Exists(strRuta))
                    Directory.CreateDirectory(strRuta);

                //aFile.SaveAs(strRuta + codigo + "-" + actividad + "-" + aFile.FileName);
                if (codigo != 0) aFile.SaveAs(strRuta + codigo + "-" + aFile.FileName);
                //ANTES
                if (cadena != string.Empty) aFile.SaveAs(strRuta + cadena);
                _out.cMsj = "OK";
            }
            catch (Exception ex)
            {
                _out.cMsj = ex.ToString();
            }
            return _out;
        }*/


        #region .:: Carga de Archivos ::.
        [HttpPost]
        public List<String> UploadAdjuntos()
        {
            List<String> result = new List<String>();
            result.Add("0");
            string vruta = "";
            string extension = "";
            string fileName = "file";
            int _nPrsID_ = -1;
            string _idTipoDoc_ = "00";
            int _correlativo_ = 0;
            string _pathDirectory = "";

            try
            {
                if (HttpContext.Current.Request.Files.AllKeys.Any())
                {
                    var httpPostedFile = HttpContext.Current.Request.Files["_file_"];
                    //fileName = httpPostedFile.FileName;

                    //fileName = Path.GetFileName(httpPostedFile.FileName);
                    fileName = Path.GetFileNameWithoutExtension(httpPostedFile.FileName);

                    extension = Path.GetExtension(httpPostedFile.FileName);
                    _nPrsID_ = Convert.ToInt32(HttpContext.Current.Request["_nPrsID_"]);
                    _idTipoDoc_ = HttpContext.Current.Request["_idTipoDoc_"];
                    if (httpPostedFile != null)
                    {
                        _correlativo_ = 1;

                        _pathDirectory = ConfigurationManager.AppSettings["GCH_PathDirectory_PostulantesDocs"].ToString();
                        if (_pathDirectory == "")
                        {
                            _pathDirectory = "/GCH_DefaultDirectory/";
                        }
                        //string pathName = "GCH_PostulantesDocs/" + Convert.ToString(_nPrsID_);
                        _pathDirectory = _pathDirectory + Convert.ToString(_nPrsID_);

                        var fileSavePath = Path.Combine(HttpContext.Current.Server.MapPath(_pathDirectory));
                        if (!Directory.Exists(fileSavePath))
                        {
                            Directory.CreateDirectory(fileSavePath);
                        }

                        fileName = Convert.ToString(_nPrsID_) + "-" + _idTipoDoc_ + "-" + _correlativo_.ToString("00") + " " + fileName + extension;
                        /*string[] fileArray = Directory.GetFiles(fileSavePath);
                        if (fileArray.Length > 0)
                        {
                            for (int i = 0; i < fileArray.Length; i++)
                            {
                                string ifile = Path.GetFileName(fileArray[i]);
                                if (ifile.Equals(fileName))
                                {
                                    _correlativo_++;
                                    fileName = Convert.ToString(_nPrsID_) + "-" + _idTipoDoc_ + "-" + _correlativo_.ToString("00") + extension;
                                    i = 0;
                                }
                            }
                        }

                        fileName = Convert.ToString(_nPrsID_) + "-" + _idTipoDoc_ + "-" + _correlativo_.ToString("00") + extension;
                        */
                        fileSavePath = Path.Combine(HttpContext.Current.Server.MapPath(_pathDirectory), fileName);

                        httpPostedFile.SaveAs(fileSavePath);
                        vruta = fileSavePath;
                        result[0] = "1";
                    }
                    else
                    {
                        result[0] = "0";
                    }
                }
                else
                {
                    result[0] = "0";
                }
            }
            catch (Exception exp)
            {
                Console.Write(exp.Message);
                result[0] = "0";
            }

            return result;
        }
        #endregion


        [HttpPost]
        public GenericApiResponse fListaPostulante(BEPostulante obj)
        {

            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {

                daResult = new BLPostulante().fnListaPostulantes(obj);

                if (daResult.cError == null || daResult.cError == "")
                {
                    apiRpta.nMsjCode = 200;
                    apiRpta.DtCollection = daResult.dTable1;
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }


    }
}