﻿using Newtonsoft.Json;
using SGTH.Entity.BusinessEntity.SGTH;
using SGTH.Entity.BusinessLogic.SGTH;
using SGTH.Entity.GeneralLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace SGTH.WebAPI.Controllers.SGTH
{
    public class ColaboradorController : ApiController
    {
        [HttpPost]
        public GenericApiResponse fListaColaborador(BEColaborador obj)
        {

            GenericApiResponse apiRpta = new GenericApiResponse();
            GenericEntityDAResponse daResult = new GenericEntityDAResponse();
            try
            {

                daResult = new BLColaborador().fListaColaboradorBL(obj);

                if (daResult.cError == null || daResult.cError == "")
                {
                    apiRpta.nMsjCode = 200;
                    apiRpta.DtCollection = daResult.dTable1;
                }
                else
                {
                    apiRpta.cMsj = "DA error..";
                    apiRpta.nMsjCode = 500;
                    apiRpta.cMsjDetaill = daResult.cError;
                }
            }
            catch (Exception ex)
            {
                apiRpta.cMsj = ex.ToString();
                apiRpta.nMsjCode = 500;
            }
            return apiRpta;
        }
    }
}