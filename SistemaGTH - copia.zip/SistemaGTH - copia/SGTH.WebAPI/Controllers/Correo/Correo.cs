﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Configuration;
using System.Net.Mail;
using System.Net;
using System.Data;
using System.IO;

using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.BusinessLogic.Seguridad;
using Seguridad.Entity.GeneralLayer;
using SGTH.Entity.BusinessLogic.SGTH;
using SGTH.Entity.BusinessEntity.SGTH;

namespace SGTH.WebAPI.Controllers.Correo
{
    public class Correo
    {
        string IP_HOST_MAIL = ConfigurationManager.AppSettings["IP_HOST_MAIL"];
        string HOST_PORT = ConfigurationManager.AppSettings["HOST_PORT"];
        string USER_MAIL = ConfigurationManager.AppSettings["USER_MAIL"];
        string PASS_MAIL = ConfigurationManager.AppSettings["PASS_MAIL"];
        Int32 RDAAA = Convert.ToInt32(ConfigurationManager.AppSettings["RDAAA"]);

        /*Begin  2018.09.28 Martin.Delgado*/

        public string enviarSolicitud_RegistroFichaPostulante(BEPostulante destinatario, string cAsunto, string urlEncoded, string _correoRemitente)
        {
            string _outMsg = "";

            String cCuerpo = "";
            cCuerpo = @"<html>
                        <head>
	                        <title></title>
                        </head>
                        <body>
                        <div style='font-family:Geneva,Arial,Helvetica,sans-serif; font-size:10pt;'>
                        <p>Hola <strong style='font-size:10pt;'>@__DESTINATARIO_NOMBRE__</strong>, te saluda SES.</p>
                        Te escribimos para informarte que has sido seleccionado para pasar a la segunda etapa de la convocatoria para el puesto de:
                        <strong tyle = 'font-size:10pt;' > @__PUESTO__</strong>
                        <p> necesitamos que nos brindes tus datos, usa el siguiente enlace temporal para acceder a la interfaz de registro.<br/>
    
                        <a style = 'margin-left:40px;color:rgb(0, 89, 153); font-family:Geneva,Arial,Helvetica,sans-serif;' href = '@__URL_ENCODED__'>@__URL_ENCODED__</a></p>
                        <p> algunas consideraciones:<br/>
                        1.- el enlace es temporal, por ello procure realizar su registro en la brevedad posible. <br/>
                        2.- este enlace es de un solo uso, verifique todos sus datos antes de finalizar su registro.<br/>
                        3.- no reenvie el enlace a otros contactos, el sistema validará sus datos y ultimo punto de acceso.de omitirse pasará a ser descalificado de la convocatoria.
                        </p>
                        <p> si ya registro sus datos en la Ficha de Postulante ignore este mensaje.</p>
                        <br/>
                        <table>
                            <tr>
                                <td>
                                    <img width = '150' height = '63' src = '@__IMG_01_URL_SRC__' alt = '' >
                                </td>
                                <td style = 'font-family:Geneva,Arial,Helvetica,sans-serif; font-size:9pt;' >
                                    <strong style = 'font-family:Geneva,Arial,Helvetica,sans-serif; color:rgb(0, 89, 153);' > SES </strong><br/>
                                    Gestión de Capital Humano <br/>
                                    Software Enterprise Services <br/>
                                    Central: (511) 428 - 5959 <br/>
                                    <a style = 'margin-left:40px;color:rgb(0, 89, 153); font-family:Geneva,Arial,Helvetica,sans-serif; font-size:9pt;' href = 'http://www.sesperu.com' > www.sesperu.com </a><br/>
                                </td>
                            </tr>

                        </table>
                        <table>
                            <tr>
                                <td>
                                    <img width = '' height = '' src = '@__IMG_02_URL_SRC__' alt = '' >
                                </td>
                                <td style = 'font-family:Geneva,Arial,Helvetica,sans-serif; font-size:9pt;'>
                                    <p style = 'color: rgb(0, 153, 20);' > No me imprimas si no es necesario. El Medio Ambiente es responsabilidad de todos.</p>
                                </td>
                            </tr>
                        </table
                         
                        </div>";



            String img1 = AppDomain.CurrentDomain.BaseDirectory;
            String img2 = AppDomain.CurrentDomain.BaseDirectory;
            //img1 += "/SIS_GCH/Reporte/logo2.jpg";
            img1 += "/Images/logo2.jpg";
            img2 += "/Images/imgEco01.gif";

            Attachment attFile1 = new Attachment(img1);
            attFile1.ContentId = "image001.jpg";
            attFile1.Name = "image001.jpg";

            Attachment attFile2 = new Attachment(img2);
            attFile2.ContentId = "mgEco01.gif";
            attFile2.Name = "mgEco01.gif";

            destinatario.pvNombres = System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(destinatario.pvNombres.Trim().ToLower());
            destinatario.pvCarreraProf = System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(destinatario.pvCarreraProf.Trim().ToLower());
            
            cAsunto = cAsunto.Replace("@__DESTINATARIO_NOMBRE__", destinatario.pvNombres);

            cCuerpo = cCuerpo.Replace("@__DESTINATARIO_NOMBRE__", destinatario.pvNombres);
            cCuerpo = cCuerpo.Replace("@__URL_ENCODED__", urlEncoded);
            cCuerpo = cCuerpo.Replace("@__PUESTO__", destinatario.pvCarreraProf);
            cCuerpo = cCuerpo.Replace("@__IMG_01_URL_SRC__", attFile1.Name);
            cCuerpo = cCuerpo.Replace("@__IMG_02_URL_SRC__", attFile2.Name);




            MailMessage mMailMessage = new MailMessage();
            mMailMessage.To.Add(new MailAddress(destinatario.pvCorreo));

            mMailMessage.IsBodyHtml = true;
            mMailMessage.From = new MailAddress(_correoRemitente);

            mMailMessage.Subject = cAsunto;
            mMailMessage.Body = cCuerpo;
            mMailMessage.Attachments.Add(attFile1);
            mMailMessage.Attachments.Add(attFile2);

            try
            {
                SmtpClient smtp = new System.Net.Mail.SmtpClient();
                {
                    smtp.Host = IP_HOST_MAIL;
                    smtp.Port = int.Parse(HOST_PORT);
                    smtp.EnableSsl = false;
                    smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
                    smtp.Credentials = new NetworkCredential(USER_MAIL, PASS_MAIL);
                    smtp.Timeout = 360000000;
                }
                smtp.Send(mMailMessage);
                _outMsg = "OK";
            }
            catch (SmtpFailedRecipientException ex)
            {
                _outMsg = "SmtpFailedRecipientException " + ex.ToString();
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message, ex);
                _outMsg = "Exception " + ex.ToString();
            }
            return _outMsg;
        }
        /*END  2018.09.28 Martin.Delgado*/

    }
}