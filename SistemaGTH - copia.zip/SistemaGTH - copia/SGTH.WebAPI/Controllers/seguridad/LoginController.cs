﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.BusinessLogic.Seguridad;
using Seguridad.Entity.GeneralLayer;
using System.Configuration;

namespace Seguridad.WebAPI.Controllers
{
    public class LoginController : ApiController
    {
        
        String nIdSis = ConfigurationManager.AppSettings["IdSis"].ToString();

        [ActionName("getValidarLogin")]
        [HttpGet]
        public List<String> getValidarLogin(string valor1, string valor2)
        {
            List<String> lista = new List<String>();
            lista.Add("0");
            lista.Add("");

            UsuarioBE model = new UsuarioBE();
            UsuarioBL objUsuarioBL = new UsuarioBL();
            CriptografiaGL crypt = new CriptografiaGL();
            valor2 = crypt.GetMD5Hash(valor2);

            try
            {
                model = objUsuarioBL.fLoginAutenticacionBL(valor1, valor2);
                model.nSisId = Convert.ToInt32(nIdSis);
                lista[0] = Convert.ToString(model.nProId);

                if (model.nProId > 0)
                {
                    string key = model.cUsuLogin + "|"+ nIdSis + "|543210";
                    lista[1] = EncodeTo64(key);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return lista;
        }

        static public string EncodeTo64(string toEncode)
        {
            byte[] toEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(toEncode);
            string returnValue = System.Convert.ToBase64String(toEncodeAsBytes);
            return returnValue;
        }
    }
}
