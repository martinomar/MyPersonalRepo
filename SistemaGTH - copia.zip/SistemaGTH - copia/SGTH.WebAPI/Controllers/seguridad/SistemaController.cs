﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.BusinessLogic.Seguridad;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SGTH.Entity.GeneralLayer;
using System.Data;

namespace Seguridad.WebAPI.Controllers
{
    public class SistemaController : ApiController
    {


        //public IEnumerable<SistemaBE> PiePagina()
        public GenericApiResponse PiePagina()
        {
            List<SistemaBE> LstSistema = new List<SistemaBE>();
            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();
            try
            {
                
                SistemaBE model = new SistemaBE();
                model.pnSisId = Convert.ToInt32(ConfigurationManager.AppSettings["SGCH"]);
               /* LstSistema = new SistemaBL().fListaSistemaBL(model);*/

               
                _da_response = new SistemaBL().fListaSistemaBL(model);
                _api_response.DtCollection = _da_response.dTable1;
                /*
                IEnumerable<DataRow> sequence = _da_response.dTable1.AsEnumerable();
                //LstSistema = _da_response.dTable1.AsEnumerable<> .ToList<SistemaBE>();
                LstSistema = sequence.ToList<SistemaBE>();*/
            }
            catch (Exception e)
            {
                _api_response.cMsjDetaill = e.ToString();
                throw (e);
            }
            return _api_response;
        }

        [HttpGet]
        //public IEnumerable<SistemaBE> fILListaSistemas(string cOpcion)
        public GenericApiResponse fILListaSistemas(string cOpcion)
        {
            SistemaBE objSistema = new SistemaBE();
            objSistema.strOpcion = cOpcion;
            /*List<SistemaBE> lstSistemas = new List<SistemaBE>();
            lstSistemas = new SistemaBL().fListaSistemaBL(objSistema);
            return lstSistemas;*/


            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();
            _da_response = new SistemaBL().fListaSistemaBL(objSistema);
            return _api_response;

        }
        //[HttpGet]
        //public IEnumerable<SistemaBE> fnListaSistema()
        //{
        //    SistemaBE oELSistema = new SistemaBE();
        //    List<SistemaBE> olistSistema = new List<SistemaBE>();
        //    try
        //    {
        //        olistSistema = new SistemaBL().fListaSistemaBL(oELSistema);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw (ex);
        //    }
        //    return olistSistema;
        //}

        [HttpGet]
        public GenericApiResponse fListaSistemaPaginacion()
        {
            //return new SistemaBL().fListaSistemaPaginacionBL();

            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();
            _da_response =  new SistemaBL().fListaSistemaPaginacionBL();
            _api_response.DtCollection = _da_response.dTable1;

            return _api_response;
        }

        [HttpGet]
        public String fMantenimientoSistema(int pnSisId, string pcSisNombre, string pcSisDescripcion, bool pbTipoEjecucion, string strOpcion, string SisUrl)
        {
            SistemaBE objSistemaBE = new SistemaBE();
            objSistemaBE.pnSisId = pnSisId;
            objSistemaBE.pcSisNombre = pcSisNombre;
            objSistemaBE.pcSisDescripcion = pcSisDescripcion;
            objSistemaBE.pbTipoEjecucion = pbTipoEjecucion;
            objSistemaBE.strOpcion = strOpcion;
            objSistemaBE.SisUrl = SisUrl;
            return new SistemaBL().fMantenimientoSistemaBL(objSistemaBE);
        }

        [HttpGet]
        //public List<SistemaBE> fListaValidarSistema(int pnSisId)
        public GenericApiResponse fListaValidarSistema(int pnSisId)
        {
            SistemaBE objSistemaBE = new SistemaBE();
            objSistemaBE.pnSisId = pnSisId;
            //return new SistemaBL().fListaValidarSistemaBL(objSistemaBE);


            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();
            _da_response  = new SistemaBL().fListaValidarSistemaBL(objSistemaBE);
            _api_response.DtCollection = _da_response.dTable1;
            return _api_response;

        }

        [HttpGet]
        //public List<SistemaBE> fListaSistema(int pnSisId, string op)
        public GenericApiResponse fListaSistema(int pnSisId, string op)
        {

            SistemaBE objSistemaBE = new SistemaBE();
            objSistemaBE.pnSisId = pnSisId;
            //return new SistemaBL().fListaSistemaBL(objSistemaBE);

            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();
            _da_response =  new SistemaBL().fListaSistemaBL(objSistemaBE);
            _api_response.DtCollection = _da_response.dTable1;
            return _api_response;


        }
    }
}