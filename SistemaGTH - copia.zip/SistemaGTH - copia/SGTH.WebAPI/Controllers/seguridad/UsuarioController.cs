﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.BusinessLogic.Seguridad;
using Seguridad.Entity.GeneralLayer;
using SGTH.Entity.GeneralLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web;
using System.IO;

namespace Seguridad.WebAPI.Controllers
{
    public class UsuarioController : ApiController
    {
        [HttpPost]
        public UsuarioBE LIST_USUARIO(UsuarioBE obj)
        {
            List<UsuarioBE> lstUsuario = new List<UsuarioBE>();
            UsuarioBE model = new UsuarioBE();
            UsuarioBL objUsuarioBL = new UsuarioBL();

            String key;
            CriptografiaGL crypt = new CriptografiaGL();
            key = crypt.DecodeFrom64(obj.key);

            string[] sTit = key.Split('|');
            model.Item = int.Parse(sTit[2]);
            model.cUsuNombres = sTit[0];

            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();

            try
            {
                //lstUsuario = objUsuarioBL.fListaUsuarioIntranetBL(model);
                _da_response = objUsuarioBL.fListaUsuarioIntranetBL(model);
                //if (lstUsuario.Count > 0)
                if (_da_response.dTable1.Rows.Count > 0)
                    {
                    //string usuario = lstUsuario[0].cUsuLogin;
                    //string password = lstUsuario[0].cPassword;
                    string usuario = _da_response.dTable1.Rows[0]["cUsuLogin"].ToString();
                    string password = _da_response.dTable1.Rows[0]["cPassword"].ToString();
                    int rpta = Funcion(usuario, password);

                    if (rpta > 0)
                    {
                        model = new UsuarioBE();
                        model = new UsuarioBL().fObtenerUsuarioPorCodigoBL(rpta);
                        model.nSisId = int.Parse(sTit[1]);
                    }

                }
            }
            catch (Exception)
            {
                throw;
            }
            return model;
        }

        private Int32 Funcion(string usu, string pass)
        {
            string respuesta = "";
            string elim = "0";
            int r = new UsuarioBL().fLoginUsuarioBL(usu, pass, elim);
            switch (r)
            {
                case -3:
                    respuesta = "Hubo un error interno en el sistema";
                    break;
                case -2:
                    respuesta = "El usuario ingresado no existe";
                    break;
                case -1:
                    respuesta = "El usuario está bloqueado";
                    break;
                case 0:
                    respuesta = "Contraseña incorrecta";
                    break;
                default:
                    respuesta = "Accediendo";

                    break;
            }

            return r;
        }


        [HttpGet]
        public List<UsuarioBE> fValidarUsuarioLogin(string cUsuLogin)
        {

            List<UsuarioBE> lstUsuarios = new List<UsuarioBE>();
            UsuarioBE objUsuario = new UsuarioBE();

            try
            {
                objUsuario.cUsuLogin = cUsuLogin;
                objUsuario.pcOpcion = "01";
                lstUsuarios = new UsuarioBL().fListaUsuariosBL(objUsuario);

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return lstUsuarios;
        }

    }
}