﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.BusinessLogic.Seguridad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SGTH.Entity.GeneralLayer;

namespace Seguridad.WebAPI.Controllers
{
    public class MenuController : ApiController
    {
        //
        // GET: /Menu/
        [HttpPost]
        //public IEnumerable<MenuBE> LIST_MENU(RolBE model)
        public GenericApiResponse LIST_MENU(RolBE model)
        {
            List<MenuBE> lstMenu = new List<MenuBE>();
            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();

            try
            {
                //lstMenu = new MenuBL().fListaMenusSitemapBL(model);
                _da_response = new MenuBL().fListaMenusSitemapBL(model);
                _api_response.DtCollection = _da_response.dTable1;

            }
            catch (Exception e)
            {
                _api_response.cMsjDetaill = e.ToString();
                throw (e);
            }
            return _api_response;

        }
        [HttpGet]
        //public List<MenuBE> fListaMenus(int pnSisId, string pcMnuEliminado, string pcSisEliminado)
        public GenericApiResponse fListaMenus(int pnSisId, string pcMnuEliminado, string pcSisEliminado)
        {
            MenuBE objMenu = new MenuBE();
            objMenu.pnSisId = pnSisId;
            objMenu.pcMnuEliminado = pcMnuEliminado;
            objMenu.pcSisEliminado = pcSisEliminado;
            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();

            //return new MenuBL().fListaMenusBL(objMenu);
            _da_response =  new MenuBL().fListaMenusBL(objMenu);
            _api_response.DtCollection = _da_response.dTable1;
            return _api_response;

        }

        [HttpGet]
        //public List<MenuBE> fnCargaMenuXPerfilSelected(int pnSisId, int pnPerId)
        public GenericApiResponse fnCargaMenuXPerfilSelected(int pnSisId, int pnPerId)
        {
            List<MenuBE> oliMenuBE = new List<MenuBE>();
            MenuBE oMenuBE = new MenuBE();
            oMenuBE.pnSisId = pnSisId;
            oMenuBE.pnPerId = pnPerId;
            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();

            try
            {
                //oliMenuBE = new MenuBL().fListarMenuXPerfil_selectedBL(oMenuBE);
                _da_response = new MenuBL().fListarMenuXPerfil_selectedBL(oMenuBE);
                _api_response.DtCollection = _da_response.dTable1;
            }
            catch (Exception ex)
            {
                _api_response.cMsjDetaill = ex.ToString();
                throw (ex);
            }
            return _api_response;
        }
        [HttpGet]
        //public List<MenuBE> fListaMenusCombo(int Sis, int Menu, string MnuEliminado, string SisEliminado)
        public GenericApiResponse fListaMenusCombo(int Sis, int Menu, string MnuEliminado, string SisEliminado)
        {
            MenuBE objMenu = new MenuBE();
            objMenu.pnSisId = Sis;
            objMenu.pnMenuId = Menu;
            objMenu.pcMnuEliminado = MnuEliminado;
            objMenu.pcSisEliminado = SisEliminado;

            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();


            //return new MenuBL().fListaMenusBL(objMenu);
            _da_response  = new MenuBL().fListaMenusBL(objMenu);
            _api_response.DtCollection = _da_response.dTable1;
            return _api_response;
        }


        [HttpGet]
        //public List<MenuBE> fListaGrupos(int pnSisId, int pnMenuId, string pcMnuEliminado, string pcSisEliminado)
        public GenericApiResponse fListaGrupos(int pnSisId, int pnMenuId, string pcMnuEliminado, string pcSisEliminado)
        {
            MenuBE objMenu = new MenuBE();
            objMenu.pnSisId = pnSisId;
            objMenu.pnMenuId = pnMenuId;
            objMenu.pcMnuEliminado = pcMnuEliminado;
            objMenu.pcSisEliminado = pcSisEliminado;
            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();

            //return new MenuBL().fListaGruposBL(objMenu);
            _da_response =  new MenuBL().fListaGruposBL(objMenu);
            _api_response.DtCollection = _da_response.dTable1;
            return _api_response;
        }

        [HttpGet]
        public String fMantenimientoMenu(int pnMenuId, int pnSisId, string pcMenuNom, string pcMenuArch, bool pbMenuCab, int pnMenuGrupo,
            int pnMenuOrden, string pcMnuEliminado, int pnMenuNivel, string strOpcion)
        {
            MenuBE objMenu = new MenuBE();
            objMenu.pnMenuId = pnMenuId;
            objMenu.pnSisId = pnSisId;
            objMenu.pcMenuNom = pcMenuNom;
            objMenu.pcMenuArch = pcMenuArch;
            objMenu.pbMenuCab = pbMenuCab;
            objMenu.pnMenuGrupo = pnMenuGrupo;
            objMenu.pnMenuOrden = pnMenuOrden;
            objMenu.pcMnuEliminado = pcMnuEliminado;
            objMenu.pnMenuNivel = pnMenuNivel;

            return new MenuBL().fMantenimientoMenuBL(objMenu, strOpcion);
        }

        [HttpGet]
        public MenuBE fContarHijosPorCodigo(int pnMenuId, string pcMnuEliminado)
        {
            MenuBE objMenu = new MenuBE();
            objMenu.pnMenuId = pnMenuId;
            objMenu.pcMnuEliminado = pcMnuEliminado;
            return new MenuBL().fContarHijosPorCodigoBL(objMenu);
        }
        //[HttpPost]
        //public List<MenuBE> List_MenuGeneral(RolBE model)
        //{

        //    List<MenuBE> lstMenu = new List<MenuBE>();
        //    try
        //    {
        //        lstMenu = new MenuBL().fListaMenusSitemapGeneralBL(model);
        //    }
        //    catch (Exception e)
        //    {
        //        throw (e);
        //    }
        //    return lstMenu;
        //}

    }
}
