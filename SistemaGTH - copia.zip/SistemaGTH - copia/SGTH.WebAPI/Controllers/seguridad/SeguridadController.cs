﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.BusinessLogic.Seguridad;
using Seguridad.Entity.GeneralLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Web.Http;
using SIS_SES_Libraries.Workflow;
using System.Web.Mail;
using SGTH.Entity.GeneralLayer;

namespace Seguridad.WebAPI.Controllers
{
    public class SeguridadController : ApiController
    {

        [HttpGet]
        public IEnumerable<UsuarioBE> fILListaUsuarios(int nPageSize, int nPageNumber, string cUsuLogin, string cUsuNombres, string cUsuApePat, string cUsuApeMat, string cUsuCorreo, string cEliminado, string cOpcion)
        {
            List<UsuarioBE> lstUsuarios = new List<UsuarioBE>();
            UsuarioBE objUsuario = new UsuarioBE();

            try
            {
                objUsuario.PageSize = nPageSize;
                objUsuario.PageNumber = nPageNumber;
                objUsuario.cUsuLogin = cUsuLogin;
                objUsuario.cUsuNombres = cUsuNombres;
                objUsuario.cUsuApePat = cUsuApePat;
                objUsuario.cUsuApeMat = cUsuApeMat;
                objUsuario.cUsuCorreo = cUsuCorreo;
                objUsuario.cEliminado = cEliminado;
                objUsuario.pcOpcion = cOpcion;


                lstUsuarios = new UsuarioBL().fListaUsuariosBL(objUsuario);

                foreach (var item in lstUsuarios)
                {
                    if (item.cEliminado == "0")
                    {
                        item.cEliminado = "SI";
                    }
                    else
                    {
                        item.cEliminado = "NO";
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return lstUsuarios;

        }


        [HttpGet]
        public IEnumerable<UsuarioBE> fValidarUsuarioLogin(string cUsuLogin)
        {

            Int32 intExiste = 0;
            List<UsuarioBE> lstUsuarios = new List<UsuarioBE>();
            UsuarioBE objUsuario = new UsuarioBE();

            try
            {
                objUsuario.cUsuLogin = cUsuLogin;
                objUsuario.pcOpcion = "01";
                lstUsuarios = new UsuarioBL().fListaUsuariosBL(objUsuario);

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return lstUsuarios;

        }

        [HttpGet]
        public String fMantenimientoRol(int nRolId, int nSisId, string cRolNom, string cRolNem, string cRolDesc, string cOpcion, string cRolEliminado)
        {
            RolBE objRol = new RolBE();

            objRol.nRolId = nRolId;
            objRol.nSisId = nSisId;
            objRol.cRolNom = cRolNom;
            objRol.cRolNem = cRolNem;
            objRol.cRolDesc = cRolDesc;
            objRol.strOpcion = cOpcion;
            objRol.cRolEliminado = cRolEliminado;

            return new RolBL().fMantenimientoRolBL(objRol);

        }

        [HttpGet]
        public String fMantenimientoRoles(int nRolId, int nSisId, string cOpcion)
        {
            RolBE objRol = new RolBE();

            objRol.nRolId = nRolId;
            objRol.nSisId = nSisId;
            objRol.strOpcion = cOpcion;

            return new RolBL().fMantenimientoRolBL(objRol);

        }


        [HttpGet]
        public void fEnviarCorreo(string cUsuCorreo, string cUsuNombres, string cUsuApePat, string cUsuApeMat, string cUsuLogin)
        {
            String cuerpo = "Estimado(a) " + cUsuNombres + " " + cUsuApePat + " " + cUsuApeMat + "<br><br>";
            cuerpo += "Se le ha asociado a la cuenta " + cUsuLogin + " con este nuevo correo.<br><br>";

            UsuarioBE objUsuario = new UsuarioBE();
            List<UsuarioBE> lstUsuarios = new List<UsuarioBE>();
            objUsuario.cUsuCorreo = cUsuCorreo;
            lstUsuarios.Add(objUsuario);

            CorreoGL objCorreo = new CorreoGL();

            try
            {
                objCorreo.enviar(lstUsuarios, "Su cuenta fue actualizada", cuerpo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        //public IEnumerable<UsuarioBE> fValidarUsuarioGrupo(int nUsuId)
        public GenericApiResponse fValidarUsuarioGrupo(int nUsuId)
        {
            List<UsuarioBE> lstUsuarios = new List<UsuarioBE>();
            UsuarioBE objUsuario = new UsuarioBE();
            GenericApiResponse _api_response = new GenericApiResponse();
            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            try
            {
                objUsuario.nUsuId = nUsuId;
                //lstUsuarios = new UsuarioBL().fValidaUsuarioxGrupoBL(objUsuario);
                _da_response = new UsuarioBL().fValidaUsuarioxGrupoBL(objUsuario);
                _api_response.DtCollection = _da_response.dTable1;

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return _api_response;
        }

        [HttpGet]
        public String fEliminaRolXUsuario(int pnSisId, int pnUsuId, string strOpcion)
        {
            string resultado;
            RolBE objRol = new RolBE();

            objRol.nSisId = pnSisId;
            objRol.nUsuId = pnUsuId;
            objRol.strOpcion = strOpcion;

            resultado = new RolBL().fMantenimientoRolXUsuarioBL(objRol);

            return resultado;

        }

    }
}