﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.BusinessLogic.Seguridad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SGTH.Entity.GeneralLayer;
namespace Seguridad.WebAPI.Controllers
{
    public class RolController : ApiController
    {

        //public IEnumerable<RolBE> LIST_ROLXUSUARIO(RolBE model)
        [HttpGet]
        //public IEnumerable<RolBE> LIST_ROLXUSUARIO(string cRolEliminado, string strOpcion, int nSisId, int nUsuId)
        public GenericApiResponse LIST_ROLXUSUARIO(string cRolEliminado, string strOpcion, int nSisId, int nUsuId)
        {
            List<RolBE> LstRol = new List<RolBE>();
            RolBE model = new RolBE();
            model.cRolEliminado = cRolEliminado;
            model.strOpcion = strOpcion;
            model.nSisId = nSisId;
            model.nUsuId = nUsuId;

            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();

            try
            {
                //LstRol = new RolBL().fListaRolesAsigandosXUsuarioSessionBL(model);
                _da_response = new RolBL().fListaRolesAsigandosXUsuarioSessionBL(model);
                _api_response.DtCollection = _da_response.dTable1;
                

            }
            catch (Exception e)
            {
                _api_response.cMsjDetaill = e.ToString();
                throw (e);
            }
            return _api_response;
        }

        public string MantenimientoRol(RolBE model)
        {
            string resultado = string.Empty;
            try
            {
                resultado = new RolBL().fMantenimientoRolXUsuarioBL(model);
            }
            catch (Exception e)
            {
                throw e;
            }
            return resultado;
        }

        [HttpGet]
        //public IEnumerable<RolBE> fILListaRoles(int nSisId, string cEliminado)
        public GenericApiResponse fILListaRoles(int nSisId, string cEliminado)
        {
            List<RolBE> lstRoles = new List<RolBE>();
            RolBE objRol = new RolBE();
            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();

            try
            {
                objRol.nSisId = nSisId;
                objRol.cRolEliminado = cEliminado;
                //lstRoles = new RolBL().fListaRolesBL(objRol);
                _da_response = new RolBL().fListaRolesBL(objRol);
                _api_response.DtCollection = _da_response.dTable1;

            }
            catch (Exception ex)
            {
                _api_response.cMsjDetaill = ex.ToString();
                throw ex;
            }

            return _api_response;
        }

        [HttpGet]
        //public List<RolBE> fListaValidarRol(int nRolId)
        public GenericApiResponse fListaValidarRol(int nRolId)
        {
            RolBE objRol = new RolBE();
            objRol.nRolId = nRolId;
            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();

            try
            {
                //return new RolBL().fListaValidarRolBL(objRol);
                _da_response = new RolBL().fListaValidarRolBL(objRol);
                _api_response.DtCollection = _da_response.dTable1;

            }
            catch (Exception ex)
            {
                _api_response.cMsjDetaill = ex.ToString();
                throw;
            }
            return _api_response;

        }


    }
}