﻿using Seguridad.Entity.BusinessEntity.Seguridad;
using Seguridad.Entity.BusinessLogic.Seguridad;
using Seguridad.Entity.GeneralLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SGTH.Entity.GeneralLayer;

namespace Seguridad.WebAPI.Controllers
{
    public class GestionUsuarioController : ApiController
    {
        [HttpGet]
        public String fMantenimientoUsuario(int nUsuId, int nCodPrs, string cUsuLogin, string cUsuNombres, string cUsuApePat, string cUsuApeMat, string cUsuCorreo, string cEliminado, string cOpcion)
        {
            string resultado = "";
            try
            {
                UsuarioBE objUsuario = new UsuarioBE();
                CorreoGL objCorreo = new CorreoGL();
                List<UsuarioBE> objListaUsuarios = new List<UsuarioBE>();
                string nuevapass = new SeguridadGL().generarPassword(8);

                objUsuario.nUsuId = nUsuId;
                objUsuario.nCodPrs = nCodPrs;
                objUsuario.cUsuLogin = cUsuLogin;
                objUsuario.cUsuNombres = cUsuNombres;
                objUsuario.cUsuApePat = cUsuApePat;
                objUsuario.cUsuApeMat = cUsuApeMat;
                objUsuario.cUsuCorreo = cUsuCorreo;
                objUsuario.cEliminado = cEliminado == "true" ? "0" : "1";
                objUsuario.pcOpcion = cOpcion;

                objListaUsuarios.Add(objUsuario);

                if (objUsuario.pcOpcion == "01")
                {

                    CriptografiaGL crypt = new CriptografiaGL();
                    objUsuario.cPassword = crypt.GetMD5Hash(nuevapass);

                    resultado = new UsuarioBL().fMantenimientoUsuarios(objUsuario);

                    if (resultado == "OK")
                    {
                        String cuerpo = "Estimado(a) " + objUsuario.cUsuNombres + " " + objUsuario.cUsuApePat + " " + objUsuario.cUsuApeMat + "<br><br>";
                        cuerpo += "Se le ha registrado una cuenta en el SAR.<br><br>";
                        cuerpo += "Usuario: " + objUsuario.cUsuLogin + "<br>";
                        cuerpo += "Contraseña: " + nuevapass + "<br><br><br>";
                        cuerpo += "Por favor apúntela en un lugar seguro, se recomienda cambiarla al entrar por primera vez.<br><br><br>";



                        try
                        {
                            objCorreo.enviar(objListaUsuarios, "Tu nueva cuenta", cuerpo);
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                }
                else
                {
                    resultado = new UsuarioBL().fMantenimientoUsuarios(objUsuario);

                    if (resultado == "OK")
                    {
                        String cuerpo = "Estimado(a) " + cUsuNombres + " " + cUsuApePat + " " + cUsuApeMat + "<br><br>";
                        cuerpo += "Se le ha asociado a la cuenta " + cUsuLogin + " con este nuevo correo.<br><br>";

                        try
                        {
                            objCorreo.enviar(objListaUsuarios, "Su cuenta fue actualizada", cuerpo);
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return resultado;
        }

        [HttpGet]
        //public List<UsuarioBE> fBuscarUsuarioRDA(int nCodPrs)
        public GenericApiResponse fBuscarUsuarioRDA(int nCodPrs)
        {
            List<UsuarioBE> lstUsuarios = new List<UsuarioBE>();
            UsuarioBE objUsuario = new UsuarioBE();

            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();

            try
            {
                objUsuario.nCodPrs = nCodPrs;
                //lstUsuarios = new UsuarioBL().fBuscarUsuarioRDA(objUsuario);
                _da_response = new UsuarioBL().fBuscarUsuarioRDA(objUsuario);
                _api_response.DtCollection = _da_response.dTable1;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _api_response;
        }

        [HttpGet]
        //public IEnumerable<PerfilBE> fnGetListaPerfiles(int pnSisId, int pnUsuId, string pcPerEliminado)
        public GenericApiResponse fnGetListaPerfiles(int pnSisId, int pnUsuId, string pcPerEliminado)
        {

            List<PerfilBE> olistPerfilBE = new List<PerfilBE>();
            PerfilBL dlPerfilBL = new PerfilBL();

            PerfilBE oPerfilBE = new PerfilBE();
            oPerfilBE.pnSisId = pnSisId;
            oPerfilBE.pnUsuId = pnUsuId;
            oPerfilBE.pcPerEliminado = pcPerEliminado;


            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();

            try
            {
                //olistPerfilBE = dlPerfilBL.fListaPerfilesAsigandosXUsuarioBL(oPerfilBE);
                _da_response = dlPerfilBL.fListaPerfilesAsigandosXUsuarioBL(oPerfilBE);
                _api_response.DtCollection = _da_response.dTable1;

            }
            catch (Exception ex)
            {
                throw (ex);
            }
            return _api_response;
        }

        [HttpGet]
        //public IEnumerable<RolBE> fListaRolesxUsuario(int pnSisId, int pnUsuId, string pcRolEliminado)
        public GenericApiResponse fListaRolesxUsuario(int pnSisId, int pnUsuId, string pcRolEliminado)
        {

            List<RolBE> lstRolesxUsuario = new List<RolBE>();
            RolBE objRol = new RolBE();

            objRol.nSisId = pnSisId;
            objRol.nUsuId = pnUsuId;
            objRol.cRolEliminado = pcRolEliminado;

            GenericEntityDAResponse _da_response = new GenericEntityDAResponse();
            GenericApiResponse _api_response = new GenericApiResponse();


            //lstRolesxUsuario = new RolBL().fListaRolesAsigandosXUsuarioBL(objRol);
            _da_response = new RolBL().fListaRolesAsigandosXUsuarioBL(objRol);
            _api_response.DtCollection = _da_response.dTable1;

            return _api_response;
        }


        [HttpGet]
        public String fRegistraRolXUsuario(int pnSisId, int pnUsuId, int pnRolId, string pbRolFav, string strOpcion)
        {
            string resultado;
            RolBE objRol = new RolBE();

            objRol.nSisId = pnSisId;
            objRol.nUsuId = pnUsuId;
            objRol.nRolId = pnRolId;
            objRol.bRolFav = Convert.ToBoolean(pbRolFav);
            objRol.strOpcion = strOpcion;

            resultado = new RolBL().fMantenimientoRolXUsuarioBL(objRol);

            return resultado;

        }




        [HttpGet]
        public String fMantenimientoPerfilxUsuario(int pnSisId, int pnUsuId, string strOpcion)
        {

            string resultado;

            PerfilBE objPerfil = new PerfilBE();
            objPerfil.pnSisId = pnSisId;
            objPerfil.pnUsuId = pnUsuId;
            objPerfil.strOpcion = strOpcion;

            UsuarioBL dlUsuarioBL = new UsuarioBL();

            resultado = dlUsuarioBL.fMantenimientoPerfilXUsuarioBL(objPerfil);

            return resultado;
        }

        [HttpGet]
        public String fRegistraPerfilxUsuario(int pnSisId, int pnUsuId, int nPerId, string strOpcion)
        {
            string resultado;


            PerfilBE objPerfil = new PerfilBE();
            objPerfil.pnSisId = pnSisId;
            objPerfil.pnUsuId = pnUsuId;
            objPerfil.pnPerId = nPerId;
            objPerfil.strOpcion = strOpcion;

            UsuarioBL dlUsuarioBL = new UsuarioBL();

            resultado = dlUsuarioBL.fMantenimientoPerfilXUsuarioBL(objPerfil);

            return resultado;

        }

    }
}