﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Seguridad.Entity.BusinessLogic.Seguridad;

namespace Seguridad.WebAPI.Controllers
{
    public class AvatarController : ApiController
    {
        #region .:: Carga de avatar ::.
        [HttpPost]
        public List<String> UploadAvatar()
        {
            List<String> result = new List<String>();
            result.Add("0");
            string vruta = "";
            int vidusu = 0;
            try
            {
                if (HttpContext.Current.Request.Files.AllKeys.Any())
                {
                    var httpPostedFile = HttpContext.Current.Request.Files["UploadedImage"];
                    vidusu = Convert.ToInt32(HttpContext.Current.Request["vidusuario"]);
                    if (httpPostedFile != null)
                    {
                        // Validate the uploaded image(optional)
                        // Get the complete file path
                        //var fileSavePath = Path.Combine(HttpContext.Current.Server.MapPath("/Files/Img/Avatar"), httpPostedFile.FileName);
                        var fileSavePath = Path.Combine(HttpContext.Current.Server.MapPath("/Files/Img/Avatar"), "Img_usu_" + Convert.ToString(vidusu) + ".png");
                        // Save the uploaded file to "UploadedFiles" folder
                        httpPostedFile.SaveAs(fileSavePath);
                        vruta = "/Files/Img/Avatar/" + httpPostedFile.FileName;
                        vruta = "/Files/Img/Avatar/" + "Img_usu_" + Convert.ToString(vidusu) + ".png";
                        result.Add(vruta);
                        String vresul = new UsuarioBL().fMantDatosUsuarioBL(vidusu, vruta, "01");
                        result[0] = "1";
                    }
                    else
                    {
                        result[0] = "0";
                    }
                }
                else
                {
                    result[0] = "0";
                }
            }
            catch (Exception exp)
            {
                Console.Write(exp.Message);
                result[0] = "0";
            }

            return result;
        }
        #endregion
    }
}
