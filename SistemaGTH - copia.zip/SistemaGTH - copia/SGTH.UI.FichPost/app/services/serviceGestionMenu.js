﻿(function () {

    var consultaCRUDMenu = function ($http, $q) {
        var baseUrl = _URLApiBase;

        var ListarSistemas = function (_param) {
            var url = baseUrl + "Sistema/fListaSistema";
            return $http.get(url, { params: _param });

            //return $http({
            //    method: 'GET',
            //    contentType: 'application/json; charset=utf-8',
            //    url: baseUrl + "Sistema/fListaSistema?pnSisId=" + _param.pnSisId,
            //   headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            //}).success(function (response) {
            //    return response;
            //});
        }

        var ListaMenus = function (_param) {
            var url = baseUrl + "Menu/fListaMenus";
            return $http.get(url, { params: _param });
        }

        var ListaMenusCombo = function (_param) {
            var url = baseUrl + "Menu/fListaMenusCombo";
            return $http.get(url, { params: _param });
        }


        //var ListaGrupos = function (_param) {
        //    var url = baseUrl + "Menu/fListaGrupos";
        //    return $http.get(url, { params: _param });
        //}


        function ListaGrupos(_param) {
            var defered = $q.defer();
            var promise = defered.promise;
            var url = baseUrl + "Menu/fListaGrupos";

            $http.get(url, { params: _param })
                .success(function (data) {
                    defered.resolve(data);
                })
                .error(function (err) {
                    defered.reject(err)
                });

            return promise;
        }



        var MantenimientoMenu = function (_param) {
            var url = baseUrl + "Menu/fMantenimientoMenu";
            return $http.get(url, { params: _param });
        }

        var ContarHijosPorCodigo = function (_param) {
            var url = baseUrl + "Menu/fContarHijosPorCodigo";
            return $http.get(url, { params: _param });
        }


        return {
            ListarSistemas: ListarSistemas,
            ListaMenus: ListaMenus,
            ListaGrupos: ListaGrupos,
            MantenimientoMenu: MantenimientoMenu,
            ContarHijosPorCodigo: ContarHijosPorCodigo,
            ListaMenusCombo: ListaMenusCombo
        };
    };

    angular.module('commonServiceMenu', []).factory("consultaCRUDMenu", consultaCRUDMenu);

})();