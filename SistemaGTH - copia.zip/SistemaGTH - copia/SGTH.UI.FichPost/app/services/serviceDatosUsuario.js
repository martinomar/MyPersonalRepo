﻿(function () {

    var GestDatosUsuario = function ($http, $q) {
        var baseUrl = _URLApiBase;

        var fnValidacionUsuario = function (valores) {

            var url = baseUrl + "Login/getValidarLogi";
            return $http.get(url, { params: valores });
        }

        var RegistraRolesxUsuario = function (_param) {

            var url = baseUrl + "GestionUsuario/fRegistraRolXUsuario";
            return $http.get(url, { params: _param });

        }

        return {

            fnValidacionUsuario: fnValidacionUsuario,
            RegistraRolesxUsuario: RegistraRolesxUsuario
        };
    };

    angular.module('commonServiceDatosUsuario', []).factory("GestDatosUsuario", GestDatosUsuario);

})();