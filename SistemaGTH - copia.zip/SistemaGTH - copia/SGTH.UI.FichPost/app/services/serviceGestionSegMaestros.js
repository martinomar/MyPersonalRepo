﻿(function () {

    var consultaCRUDSegMaestro = function ($http, $q) {
        var baseUrl = _URLApiBase;

        var ListarSistemas = function (_param) {
            var url = baseUrl + "Sistema/fListaSistema";
            return $http.get(url, { params: _param });
        }

        var ListaTablasMaestro = function (_param) {
            var url = baseUrl + "SegMaestro/fListaTablasMaestro";
            return $http.get(url, { params: _param });
        }

        var ListaSegMaestros = function (_param) {
            var url = baseUrl + "SegMaestro/fListaSegMaestros";
            return $http.get(url, { params: _param });
        }

        var ListaSegMaestrosUPD = function (_param) {
            var url = baseUrl + "SegMaestro/fListaSegMaestrosUPD";
            return $http.get(url, { params: _param });
        }

        var MantenimientoSegMaestro = function (_param) {
            var url = baseUrl + "SegMaestro/fMantenimientoSegMaestro";
            return $http.get(url, { params: _param });
        }

        return {
            ListarSistemas: ListarSistemas,
            ListaTablasMaestro: ListaTablasMaestro,
            ListaSegMaestros: ListaSegMaestros,
            MantenimientoSegMaestro: MantenimientoSegMaestro,
            ListaSegMaestrosUPD: ListaSegMaestrosUPD
        };
    };

    angular.module('commonServiceSegMaestro', []).factory("consultaCRUDSegMaestro", consultaCRUDSegMaestro);

})();