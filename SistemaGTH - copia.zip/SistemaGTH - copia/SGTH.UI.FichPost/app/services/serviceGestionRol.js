﻿
(function () {

    var consultaCRUDRol = function ($http, $q) {
        var baseUrl = _URLApiBase;

        var ListaSistemas = function (_param) {
            var url = baseUrl + "Sistema/fILListaSistemas";
            return $http.get(url, { params: _param });
        }

        var ListaRol = function (_param) {

            var url = baseUrl + "Rol/fILListaRoles";
            return $http.get(url, { params: _param }); 
        }

        var MantenimientoRol = function (_param) {

            var url = baseUrl + "Seguridad/fMantenimientoRol";
            return $http.get(url, { params: _param });  
        }

        var ListaValidarRol = function (_param) {

            var url = baseUrl + "Rol/fListaValidarRol";
            return $http.get(url, { params: _param });
        }

        var MantenimientoRoles = function (_param) {

            var url = baseUrl + "Seguridad/fMantenimientoRoles";
            return $http.get(url, { params: _param });
        }

        return {

            ListaSistemas: ListaSistemas,
            ListaRol: ListaRol,
            MantenimientoRol: MantenimientoRol,
            ListaValidarRol: ListaValidarRol,
            MantenimientoRoles: MantenimientoRoles
        };
    };

    angular.module('commonService', []).factory("consultaCRUDRol", consultaCRUDRol);

})();