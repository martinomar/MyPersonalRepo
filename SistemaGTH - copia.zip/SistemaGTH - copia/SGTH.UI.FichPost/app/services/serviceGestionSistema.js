﻿
(function () {

    var consultaCRUDSistema = function ($http, $q) {
        var baseUrl = _URLApiBase;

        var obtenerSistema = function (_param) {
            var url = baseUrl + "Sistema/fListaSistemaPaginacion";
            return $http.get(url, { params: _param });
        }


        var MantenimientoSistema = function (_param) {
            var url = baseUrl + "Sistema/fMantenimientoSistema";
            return $http.get(url, { params: _param });
        }

        var ListaValidarSistema = function (_param) {
            var burl = 'Sistema/fListaValidarSistema?pnSisIdVal=' + _param.pnSisIdVal;
            var url = baseUrl + "Sistema/fListaValidarSistema";
            return $http.get(url, { params: _param });

        }

        return {
            obtenerSistema: obtenerSistema,
            MantenimientoSistema: MantenimientoSistema,
            ListaValidarSistema: ListaValidarSistema
        };

    };

    angular.module('commonServiceSistema', []).factory("consultaCRUDSistema", consultaCRUDSistema);

})();