﻿
(function () {

    var consultaCRUDUsuario = function ($http, $q) {
        var baseUrl = _URLApiBase;

        var obtenerUsuario = function (_param) {
            var url = baseUrl + "Seguridad/fILListaUsuarios";
            return $http.get(url, { params: _param });
        }

        var mantenimientoUsuario = function (_param) {

            var url = baseUrl + "GestionUsuario/fMantenimientoUsuario";
            return $http.get(url, { params: _param });
        }

        var listarPerfiles = function (_param) {

            var url = baseUrl + "GestionUsuario/fnGetListaPerfiles";
            return $http.get(url, { params: _param });
        }

        var buscarUsuarioRDA = function (_param) {

            var url = baseUrl + "GestionUsuario/fBuscarUsuarioRDA";
            return $http.get(url, { params: _param });
        }

        var validarLoginUsuario = function (_param) {
            debugger
            var url = baseUrl + "Usuario/fValidarUsuarioLogin";
            return $http.get(url, { params: _param });
        }

        var validarUsuarioGrupo = function (_param) {

            var url = baseUrl + "Seguridad/fValidarUsuarioGrupo";
            return $http.get(url, { params: _param });
        }

        var enviarCorreo = function (_param) {

            var url = baseUrl + "Seguridad/fEnviarCorreo";
            return $http.get(url, { params: _param });
        }

        var registrarUsuario = function (_params) {

            return $http({
                method: 'POST',
                contentType: 'application/json; charset=utf-8',
                url: baseUrl + "Seguridad/fRegistrarUsuarios",
                data: $.param(_params),
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            }).success(function (response) {
                return response;
            });
        }

        var RegistraPerfilxUsuario = function (_param) {

            var url = baseUrl + "GestionUsuario/fRegistraPerfilxUsuario";
            return $http.get(url, { params: _param });
        }

        var MantenimientoPerfilxUsuario = function (_param) {

            var url = baseUrl + "GestionUsuario/fMantenimientoPerfilxUsuario";
            return $http.get(url, { params: _param });
        }

        var listarRoles = function (_param) {

            var url = baseUrl + "GestionUsuario/fListaRolesxUsuario";
            return $http.get(url, { params: _param });
        }

        var EliminarRolxUsuario = function (_param) {

            var url = baseUrl + "Seguridad/fEliminaRolXUsuario";
            return $http.get(url, { params: _param });
        }

        var RegistraRolesxUsuario = function (_param) {

            var url = baseUrl + "GestionUsuario/fRegistraRolXUsuario";
            return $http.get(url, { params: _param });

        }

        return {
            listarPerfiles: listarPerfiles,
            obtenerUsuario: obtenerUsuario,
            mantenimientoUsuario: mantenimientoUsuario,
            buscarUsuarioRDA: buscarUsuarioRDA,
            validarLoginUsuario: validarLoginUsuario,
            validarUsuarioGrupo: validarUsuarioGrupo,
            enviarCorreo: enviarCorreo,
            registrarUsuario: registrarUsuario,
            MantenimientoPerfilxUsuario: MantenimientoPerfilxUsuario,
            RegistraPerfilxUsuario: RegistraPerfilxUsuario,
            listarRoles: listarRoles,
            EliminarRolxUsuario: EliminarRolxUsuario,
            RegistraRolesxUsuario: RegistraRolesxUsuario
        };
    };

    angular.module('commonServiceUser', []).factory("consultaCRUDUsuario", consultaCRUDUsuario);

})();