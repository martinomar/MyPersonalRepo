﻿/*--------------------------------------------------------------------------
SISTEMA : Seguridad
SUBSISTEMA : Seguridad
NOMBRE : serviceMntPerfil.js
DESCRIPCIÓN : Mantenimiento de perfiles del sistema
AUTOR : Marin Delgado - SES Practicante APS
FECHA CREACIÓN : 17-05-2018
-----------------------------------------------------------------------------------------------------------
FECHA                EMPLEADO             MODIFICACIÓN  
------------------   -----------------    --------------------------------------------------------------------------------------
Juevez 17/05/2018/   martin.delgado       creacion y definicion de metodos
Lun    21/05/2018/   martin.delgado       creacion de metodo AsociarMenuXPerfil y CargaMenuXPerfilSelected


---------------------------------------------------------------------------------------------------------------------------------*/

(function () {

    var MntPerfilService = function ($http, $q) {
        var baseUrl = _URLApiBase;
        var _HTTP_POST_contentType = 'application/json; charset=utf-8';
        var _HTTP_POST_header = { 'Content-Type': 'application/x-www-form-urlencoded' };

        var listarSistema = function (_param) {
            var url = baseUrl + "Sistema/fnListaSistema";
            return $http.get(url, { params: _param });
        }
        var listarPerfiles = function (_param) {
            var url = baseUrl + "Perfil/fnGetListaPerfiles?nPagina=" + _param.nPagina + "&pnSisId=" + _param.pnSisId + "&pcEliminado=" + _param.cfEliminado;
            return $http.get(url);
        }

        var mantenimientoPerfil = function (_paramx) {

            var url = baseUrl + "Perfil/fnMantenimientoPerfil";

            return $http({
                method: 'POST',
                contenttype: 'application/json; charset=utf-8',
                url: url,
                data: $.param(_paramx),
                headers: { 'content-type': 'application/x-www-form-urlencoded' },
            })

        }

        /*BEGIN - 21.05.2018,martin.delgado-edicion, creacion de metodos de consulta y mantenimiento - MenuXPerfil*/
        var CargaMenuXPerfilSelected = function (_param) {
            var url = baseUrl + "Menu/fnCargaMenuXPerfilSelected?pnSisId=" + _param.pnSisId + "&pnPerId=" + _param.pnPerId;
            return $http.get(url);
        }

        var AsociarMenuXPerfil = function (_param) {
            var url = baseUrl + "Perfil/fnAsociarMenuXPerfil?pnSisId=" + _param.pnSisId + "&pnPerId=" + _param.pnPerId + "&pcMenusxPerfil=" + _param.pcMenusxPerfil;
            return $http.get(url);

        }
        /*END - 21.05.2018,martin.delgado-edicion, creacion de metodos de consulta y mantenimiento - MenuXPerfil*/
        return {
            listarSistema: listarSistema
            , listarPerfiles: listarPerfiles

            , mantenimientoPerfil: mantenimientoPerfil
            , CargaMenuXPerfilSelected: CargaMenuXPerfilSelected
            , AsociarMenuXPerfil: AsociarMenuXPerfil
        }

    }
    angular.module('servicioMntPerfil', []).factory("MntPerfilService", MntPerfilService);
})();