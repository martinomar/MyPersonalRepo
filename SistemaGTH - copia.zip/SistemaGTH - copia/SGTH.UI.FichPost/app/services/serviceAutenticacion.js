﻿(function () {

    var AutenticacionUsuario = function ($http, $q) {
        var baseUrl = _URLApiBase;

        var fnValidacionUsuario = function (valores) {

            var url = baseUrl + "Login/getValidarLogin";
            return $http.get(url, { params: valores });

            //return $http({
            //    method: 'POST',
            //    contentType: 'application/json; charset=utf-8',
            //    url: baseUrl + "Login/getValidarLogin",
            //    data: $.param(valores),
            //   headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            //}).success(function (response) {
            //    return response;
            //});
        }

       
        return {

            fnValidacionUsuario: fnValidacionUsuario,
        };
    };

    angular.module('commonServiceLogin', []).factory("AutUsuario", AutenticacionUsuario);

})();



