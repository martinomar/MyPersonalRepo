﻿/* ------------------------------------------------------------------------*/
/* SISTEMA        : Ficha Postulante
/* SUBSISTEMA     : Ficha Postulante
/* NOMBRE         : app.js
/* DESCRIPCIÓN    : Controllador de la página principal
/* AUTOR          : Martin Delgado (trainee APS)
/* FECHA CREACIÓN : 14/09/2018
/* ------------------------------------------------------------------------*/
/* FECHA MODIFICACIÓN  EMPLEADO    
/* ------------------------------------------------------------------------*/


var app = angular.module('appSES', ['ngRoute', 'ngCookies'

                                    , 'lr.upload'

                                    , 'ui.bootstrap'
                                    , 'loadingMsgDirective'

                                    , 'validadorNumerico'
                                    //, 'utils.autofocus'

                                    , 'datatables'
                                    , 'datatables.options'
                                    , 'commonServiceLogin'
                                    , 'commonServiceDatosUsuario'
                                    , 'manageApiRequests'
                                    //, 'thatisuday.dropzone'
                                ]);




app.config(function ($routeProvider, $httpProvider) {

    $httpProvider.defaults.headers["post"] = {
        'Content-Type': 'application/json;charset=utf-8'
    };

    var _seg = "app/modules/Seguridad/";
    var _fp = "./app/modules/SGTH/";

    $routeProvider
        .when('/', {
            templateUrl: 'app/modules/main/main.html',
            controller: 'mainController'
        })
        .when('/home', {
            templateUrl: 'app/modules/main.html',
            controller: 'mainController'
        })
        .when('/login', {
            templateUrl: _seg+'Login/login.html',
            controller: 'LoginController'
        })
         .when('/usuario', {
             templateUrl: _seg+'/Usuario/Usuario.html',
             controller: 'MntUsuarioController'
         })
       .when('/rol', {
           templateUrl: 'app/modules/Seguridad/MntRol.html',
           controller: 'MntRolController'
       })
        .when('/perfil', {
            templateUrl: _seg+'MntPerfil.html',
            controller: 'MntPerfilController'
        })

        .when('/sistema', {
            templateUrl: _seg+'MntSistema.html',
            controller: 'MntSistemaController'
        })
        .when('/menu', {
            templateUrl: _seg+'MntMenu.html',
            controller: 'MntMenuController'
        })
        .when('/datos', {
            templateUrl: _seg+'/Usuario/usuario.html',
            controller: 'MntDatosUsuarioController'
        })
        .when('/principal', {
            templateUrl: 'app/modules/Principal/principal.html'//,
            //controller: 'MntDatosUsuarioController'
        })
        .when('/maestro', {
            templateUrl: _seg+'MntSegMaestro.html',
            controller: 'MntSegMaestroController'
        })
        .when('/Accesos', {
            templateUrl: _seg+'AccesoSistemas.html',
            controller: 'AccesoSistemasController'
        })
        .when('/ficha', {
            templateUrl: _fp + 'fichaPostulante/ficha.html'
            , controller: "fichaController"
        })
        .when('/msj', {
            templateUrl: _fp + 'viewMessage/Msj.html'
            , controller: "MsjController"
        })



        .when('/GestPostulante', {
            templateUrl: _fp + 'MntPostulante/MntPostulante.html'
            , controller: "MntPostulanteController"
        })
        .when('/GestRegistro', {
            templateUrl: _fp + 'MntPostulante/MntRegistro.html'
            , controller: "MntRegistroController"
        })
        .when('/GestRegistroVirtual', {
            templateUrl: _fp + 'MntPostulante/MntRegistroVirtual.html'
            , controller: "MntRegistroVirtualController"
        })
        .when('/GesAsistenciaPlanilla', {
            templateUrl: _fp + 'GesAsistenciaPlanilla/gesAsistenciaPlanilla.html'
            , controller: "GesAsistenciaPlanillaController"
        })

        .when('/RepCuantosSomos', {
            templateUrl: _fp + 'RepEstadistico/RepCuantosSomos.html'
            , controller: "RepCuantosSomosController"
        })
    .otherwise({
        redirectTo: '/'
    });
});


//.run(['$rootScope', '$location', '$cookieStore', '$http',
//    function ($rootScope, $location, $cookieStore, $http) {
//        // keep user logged in after page refresh
//        var mvcUrl = _URLMvc;
//        $rootScope.globals = $cookieStore.get('usuario') || {};

//        //if ($rootScope.globals) {
//        //    //$http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
//        //    alert('si');
//        //}
//        $rootScope.$on('$locationChangeStart', function (event, next, current) {
//            // redirect to login page if not logged in
//            console.log($rootScope.globals);
//            if ($rootScope.globals.length > 0) {
//            //    alert('logueado');
//            } else {
//              //  alert('no logueado');
//                window.location.href = mvcUrl + "index.html#/login";
//            }
//        });
//    }]);



