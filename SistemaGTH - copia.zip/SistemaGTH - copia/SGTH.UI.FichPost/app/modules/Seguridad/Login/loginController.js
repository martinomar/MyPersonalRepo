﻿/* ------------------------------------------------------------------------*/
/* SISTEMA : Seguridad
/* SUBSISTEMA : Login
/* NOMBRE : LoginController.js
/* DESCRIPCIÓN : Controllador JS validacion de login
/* AUTOR : Jesus Sulla
/* FECHA CREACIÓN : 15-05-2018
/* ------------------------------------------------------------------------*/
/* FECHA MODIFICACIÓN  EMPLEADO    
/* ------------------------------------------------------------------------*/

app.controller('LoginController', function ($scope, $http, $window, $cookieStore, $location, AutUsuario) {
    var mvcUrl = _URLMvc;
    $scope.$parent.sw_layout = false;
    // reset login status
    //AuthenticationService.ClearCredentials();

    $scope.login = function () {
        $scope.dataLoading = true;
        var valores = { valor1: $scope.login.username, valor2: $scope.login.password };

        $cookieStore.remove('usuario');



        AutUsuario.fnValidacionUsuario(valores)
        .success(function (res) {
            if (res[0] == 1) {
                $cookieStore.put('usuario', res);
                //window.location.replace("/index.html#/home?key="+res[1]);
                window.location.href = mvcUrl + "#/home?key=" + res[1];
            } else {
                if (res[1] == "Usuario no cuenta con permisos")
                    $scope.error = 'Usuario no cuenta con permisos';
                else
                    $scope.error = 'Usuario o contraseña incorrectas...';
                $scope.dataLoading = false;
            }
        })
        .error(function (error) {
            console.error(error);
        });
    };
});