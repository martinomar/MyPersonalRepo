﻿app.controller('MntDatosUsuarioController', function ($scope, $http, $cookieStore, $location, $filter, GestDatosUsuario) {
    $scope.vmvcUrl = _URLMvc;
    $scope.vbaseUrl = _URLApiBase;
    $scope.urlImg = _URLApiBaseimg;
    //console.log(JSON.parse(sessionStorage.getItem("datosusuario")));
    $scope.vdatosusuario = JSON.parse(sessionStorage.getItem("datosusuario"));
    $scope.vdatosroles = JSON.parse(sessionStorage.getItem("listarol"));
    $scope.$parent.Usuar = $scope.vdatosusuario;
    $scope.urlImg = _URLApiBaseimg;

    $scope.fnActualizardatos = function () {
        var data = new FormData();
        var __vidusuario = $scope.vdatosusuario.nUsuId;
        var files = $("#fileimg").get(0).files;

        if (files.length > 0) {
            data.append("UploadedImage", files[0]);
        }
        data.append("vidusuario", __vidusuario);
        var vurl = $scope.vbaseUrl + "Avatar/UploadAvatar";
        $.ajax({
            type: "POST",
            url: vurl,
            contentType: false,
            processData: false,
            data: data,
            success: function (res) {
                if (res[0] == "1") {
                    fnalert('success', '¡Aviso!', 'Avatar cargado con exito.');
                    var __data = JSON.parse(sessionStorage.getItem("datosusuario"));
                    __data.cImgUsuario = res[1];
                    sessionStorage.setItem("datosusuario", JSON.stringify(__data));
                    $('.cls-avatar').attr('src', $scope.urlImg + res[1]);
                    //alert($scope.$parent.url_avatar);
                } else if (res[0] == "0") {
                    fnalert('info', '¡Aviso!', 'Disculpe, existió un problema al cargar el Avatar.');
                }
            },
            error: function (xhr, status) {
                fnalert('info', '¡Aviso!', 'Disculpe, existió un problema al cargar el Avatar.');
            },
            complete: function (xhr, status) {
                //alert('Petición realizada');
            }
        });

        //$.ajax({
        //    url: 'post.php',
        //    data: { id: 123 },
        //    type: 'GET',
        //    dataType: 'json',
        //    success: function (json) {
        //        $('<h1/>').text(json.title).appendTo('body');
        //        $('<div class="content"/>')
        //            .html(json.html).appendTo('body');
        //    },
        //    error: function (xhr, status) {
        //        alert('Disculpe, existió un problema');
        //    },
        //    complete: function (xhr, status) {
        //        alert('Petición realizada');
        //    }
        //});

    }


    $scope.fnAactualizarRolActivo = function (obj, vindex) {
        var registraRoles = {
            pnSisId: obj.pnSisId,
            pnUsuId: $scope.vdatosusuario.pnUsuId,
            pnRolId: obj.pnRolId,
            pbRolFav: true,
            strOpcion: '03'
        }

        $scope.vdatosroles = JSON.parse(sessionStorage.getItem("listarol"));
        GestDatosUsuario.RegistraRolesxUsuario(registraRoles)
            .success(function (res) {
                if (res == "OK") {
                    fnalert('success', '¡Aviso!', 'Asociación satisfactoria');
                    $scope.$parent.rol();

                    $.each($scope.vdatosroles, function (index, value) {
                        $scope.vdatosroles[index].pbRolFav = false;
                        if (index == vindex) {
                            $scope.vdatosroles[index].pbRolFav = true;
                        }
                    });

                } else {
                    fnalert('info', '¡Aviso!', 'Error al asociar');
                }

            }).error(function (error) {
                console.log(error)
            }).finally(function () {

            });
    }


});