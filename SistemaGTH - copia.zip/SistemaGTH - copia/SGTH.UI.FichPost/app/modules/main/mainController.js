﻿

/* ------------------------------------------------------------------------*/
/* SISTEMA     : Ficha Postulante
/* SUBSISTEMA  : Ficha Postulante
/* NOMBRE      : mainController.js
/* DESCRIPCIÓN : Controllador de eventos iniciales
/* AUTOR       : Martin Delgado (trainee APS)
/* FECHA CREACIÓN : 14/09/2018
/* ------------------------------------------------------------------------*/
/* FECHA MODIFICACIÓN  EMPLEADO    
/* ------------------------------------------------------------------------*/


app.controller('mainController', function ($scope
, $parse
, $http
, $window
, $cookieStore
, $location
, ftyApiRequest
) {

    if (!$location.search().k) {
        $window.location.href = "https://www.sesperu.com/";
    }


    //debugger;
    var mvcUrl = _URLMvc;
    var baseUrl = _URLApiBase;
    $scope.urlImg = _URLApiBaseimg;
    $scope.sw_layout = true;
    $scope.nombre = "";
    $scope.target = "";
    $scope.rolactual = "";
    $scope.mostrar = true;
    $scope.mensaje = "";
    $scope.ver = false;

    $scope.listRol = JSON.parse(sessionStorage.getItem("listarol"));
    var _vxdata = JSON.parse(sessionStorage.getItem("datosusuario"));
    if (_vxdata != null) {
        $scope.url_avatar = $scope.urlImg + _vxdata.cImgUsuario;
    }


    $scope.logout = function () {
        $cookieStore.remove('usuario');
        window.location.href = mvcUrl + "#/login";
    }
    $scope.spp_title = "";
    $scope.CargaInicial = function () {
        //$scope.Login(); /* ficha postulante.....  */
        if ($location.search().k) {
            LoginFP($location.search().k);
           
        }
        else {
            //alert('acceso no permitido, ingrese su autentificacion... Atte. SES');
            //$scope.redirect();
        }
    }



    //$scope.redirect = function (_k) {
    //    _k = "" + _k;
    //    window.location.href = mvcUrl + "#/ficha?k=" + _k;
    //}
    $scope.redirect = function () {
        $window.location.href = "https://www.sesperu.com/"
        /*$scope.ver = true;
        //$window.location.href = "/index.html#/login";
        window.location.href = mvcUrl + "index.html#/login";*/
    }

    function changeTitle(title) { document.title = title; }
    $scope.ver = false;
    function LoginFP(_k) {

        if (_k) {
            //var _postlllnte = { "gList1": [], "gList2": [], "gList3": [], "gList4": [], "dTable1": [], "dTable2": [{ "vCorreo": "asdfasd" }, { "vCorreo": "marcos.melendez@sesnetperu.com" }], "dTable3": [], "dTable4": [], "cMsg1": "OK", "cMsg2": "El postulante esta Activo", "cMsg3": "API:El postulante puede ingresar a la interfaz de registro de ficha de postulante", "cMsg4": "", "cError": "", "nAttr1": 1, "nAttr2": 0, "nAttr3": 0, "nAttr4": 0, "cAttr1": "71563605", "cAttr2": "MELENDEZ", "cAttr3": "MATOS", "cAttr4": "MARCOS" };
            //$window.sessionStorage.setItem('Postulante', JSON.stringify(_postlllnte));
            //window.location.href = mvcUrl + "#/ficha?k=" + _k;
            //return;

            var _param = {
                cryp: _k
            }
            debugger;
            ftyApiRequest._API_POST_REQUEST('FichaPostulante', 'fValidarEnlace', _param) //doesnt works
              .success(function (response) {
                  //window.prompt('FichaPostulante.response:', JSON.stringify(response));
                  //alert(JSON.stringify(response));
                  var _msg = response.cMsg3.replace('API:', '');

                  if (response.nAttr1 == 1 && response.cMsg1 == "OK") {
                      var _postulante = {
                          pvDocNro: response.cAttr1,
                          pvApePaterno: response.cAttr2,
                          pvApeMaterno: response.cAttr3,
                          pvNombres: response.cAttr4,
                          pcModalidaRegistro: response.cAttr5,
                          //pvCorreo: [],_correos: response.dTable2
                      };
                      //sessionStorage.setItem('MsjFchP', angular.toJson(_postulante));
                      //sessionStorage.setItem('Postulante', angular.toJson(_postulante));
                      //sessionStorage.MsjFchP =  angular.toJson(_postulante);
                      //sessionStorage.Postulante = angular.toJson(_postulante);

                      if (_postulante.pcModalidaRegistro.trim() == "2.2") {
                          $scope.ver = false;
                          $scope.redirect();

                          //$scope.ver = true;

                      }
                      if (_postulante.pcModalidaRegistro.trim() == "2.1") {
                          $scope.ver = true;
                          changeTitle("Sistema GTH");
                      }

                      $window.sessionStorage.setItem('MsjFchP', JSON.stringify(_postulante));
                      $window.sessionStorage.setItem('Postulante', JSON.stringify(_postulante));


                      var _vxdat2a = JSON.parse(sessionStorage.getItem("Postulante"));
                    
                      //window.prompt('FichaPostulante.response3:', JSON.stringify(_vxdat2a));
                      //$scope.redirect($location.search().k);
                      window.location.href = mvcUrl + "#/ficha?k=" + _k;
                  }
                  else {
                      //console.error(response);
                      alert(_msg);
                  }
              })
            .error(function (msj) {
                console.log('verificar el archivo "../srs/js/general.js"');
                console.error(msj);
                fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
            })
        }
        else {
            //sessionStorage.setItem('MsjFchP', angular.toJson('El acceso a la ficha de postulante requiere una clave de acceso...'));
            $window.sessionStorage.setItem('MsjFchP', JSON.stringify("error..."));
            //$window.sessionStorage.setItem('MsjFchP') = JSON.stringify(_postulante); //error...
            window.location.href = mvcUrl + "#/msj";
        }
    }

    $scope.Login = function () {

        alert('login...');
        $scope.Usuario = { key: $scope.target }
        $http({
            method: 'POST',
            contentType: 'application/json; charset=utf-8',
            url: _URLApiBase + 'Usuario/LIST_USUARIO',
            data: $.param($scope.Usuario),
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        }).success(function (response) {
            //console.log(response);
            //window.prompt("response", JSON.stringify(response));

            sessionStorage.setItem("datosusuario", JSON.stringify(response));

            $scope.url_avatar = $scope.urlImg + response.cImgUsuario;

            $cookieStore.put('usuario', response);

            if (response.pcUsuNombres == null) {
                alert('$scope.Usuar.pcUsuNombres == null');
                $scope.redirect();
            }

            $scope.Usuario = $cookieStore.get('usuario');
            $scope.nombre = $scope.Usuario.pcUsuNombres + " " + $scope.Usuario.pcUsuApePat;

            $scope.rol();
            $scope.menu();

        }).error(function (error) {
            $scope.message = 'No se pudo Crear el registro: ' + error.message;
        });
    }



    $scope.rol = function () {
        //alert("$scope.rol...");
        $scope.Usuario = $cookieStore.get('usuario');

        if ($scope.Usuario) {

            if (!$scope.Usuario.pnSisId) {

                alert('$scope.rol()...$scope.Usuario.pnSisId Not defined...');
                return;
            }
            if (!$scope.Usuario.pnUsuId) {

                alert('$scope.rol()...$scope.Usuario.pnSisId Not defined...');
                return;
            }


            //$scope.rol1 = {
            //    pnSisId: $scope.Usuario.pnSisId,
            //    pnUsuId: $scope.Usuario.pnUsuId,
            //    strOpcion: '01',
            //    pcRolEliminado: '0'
            //}
           var _rol1 = {
                pnSisId: $scope.Usuario.pnSisId,
                pnUsuId: $scope.Usuario.pnUsuId,
                strOpcion: '01',
                pcRolEliminado: '0'
           }

            var fnListarRolesxUsuario = function (_param) {
                //var url = baseUrl + "Rol/LIST_ROLXUSUARIO";
                var url = baseUrl + "Rol/LIST_ROLXUSUARIO?pnSisId=" + _param.pnSisId + "&pnUsuId=" + _param.pnUsuId + "&strOpcion=" + _param.strOpcion + "&pcRolEliminado=" + _param.pcRolEliminado;

                //return $http.get(url, { params: _param });
                return $http.get(url);
            }

            fnListarRolesxUsuario(_rol1)
                 .success(function (response) {
                     alert(JSON.stringify(response));
                     $cookieStore.remove('Roles');
                     $scope.lista = [];
                     $scope.listRol = response;
                     sessionStorage.setItem("listarol", JSON.stringify(response));
                     var length = $scope.listRol.length;

                     if (length != 0) {
                         for (i = 0; i < length; i++) {
                             if ($scope.listRol[i].bRolFav == true) {
                                 $scope.rolactual = $scope.listRol[i].pcRolNom;
                             }

                             $scope.lista.push({
                                 actual: $scope.listRol[i].pbRolFav,
                                 id_sistema_rol: $scope.listRol[i].pnSisId,
                                 id_rol: $scope.listRol[i].pnRolId,
                                 nom_rol: $scope.listRol[i].pcRolNom,
                                 nem_rol: $scope.listRol[i].pcRolNem,
                                 desc_rol: $scope.listRol[i].pcRolDesc,
                                 fav_rol: $scope.listRol[i].pbRolFav
                             })
                         }
                         $cookieStore.put('Roles', $scope.lista);

                     } else {
                         $scope.mensaje = 'No se encontraron registros'
                         $cookieStore.put('Roles', $scope.lista);
                     }
                     window.prompt("Roles...$scope.lista:", JSON.stringify($scope.lista));
                 })
                 .error(function (error) {
                     alert("fnListarRolesxUsuario-->error");
                     console.error("fnListarRolesxUsuario-->error",error);
                     $scope.message = 'No se pudo Crear el registro: '
                 });
        }
        else {
            alert('$scope.rol()... $scope.Usuario is undefined...');
        }

    }

    $scope.ir = function () {

        window.location.href = "#/Home";
        $scope.lista = [];
        $scope.lista = $cookieStore.get('Roles');

        $scope.mostrar = false;
    };

    $scope.regresar = function () {
        $scope.mensaje = "";
        $scope.mostrar = true;
    };


    $scope.default = function (val) {
        $scope.rolNameArray = [];
        var length = $scope.lista.length;

        if ($scope.lista[val].fav_rol != false) {
            for (i = 0; i < length; i++) {
                $scope.lista[i].fav_rol = false
            }
            $scope.lista[val].fav_rol = true
        }
        $scope.ActualizarRol(val);
    }

    $scope.actual = function (val) {
        $scope.rolNameArray = [];
        var length = $scope.lista.length;

        if ($scope.lista[val].actual != false) {
            for (i = 0; i < length; i++) {
                $scope.lista[i].actual = false
            }
            $scope.lista[val].actual = true
        }
        angular.forEach($scope.lista, function (item) {
            if (item.actual) {
                $scope.rolactual = item.nom_rol;
            }
        });
        $scope.ActualizarRol(val);
        $cookieStore.remove('Roles');
        $cookieStore.put('Roles', $scope.lista);
    };



    $scope.ActualizarRol = function (val) {
        $scope.favcnt = 0;
        $scope.sescnt = 0;
        $scope.resultado = "";
        var length = $scope.lista.length;
        for (i = 0; i < length; i++) {
            if ($scope.lista[i].fav_rol == true) {
                $scope.favcnt = $scope.favcnt + 1;
            }
            if ($scope.lista[i].actual == true) {
                $scope.sescnt = $scope.sescnt + 1;
            }
        }

        if ($scope.sescnt == 0) {
            $scope.mensaje = "Seleccione un rol para su uso";
        }
        else if ($scope.sescnt > 1) {
            $scope.mensaje = "Seleccione solo un rol para su uso";
        }
        else if ($scope.favcnt == 0) {
            $scope.mensaje = "Seleccione un rol por defecto (default)";
        }
        else if ($scope.favcnt > 1) {
            $scope.mensaje = "Seleccione solo un rol por defecto (default)";
        }
        else {

            $scope.id_rol = 0;
            angular.forEach($scope.lista, function (item) {
                if (item.fav_rol) {
                    $scope.id_rol = item.id_rol;
                }
            });

            $scope.rol2 = {
                pnSisId: $scope.lista[val].id_sistema_rol,
                pnRolId: $scope.id_rol,
                pnUsuId: $scope.Usuario.pnUsuId,
                strOpcion: "03"
            }

            $http({
                method: 'POST',
                contentType: 'application/json; charset=utf-8',
                url: _URLApiBase + 'Rol/MantenimientoRol',
                data: $.param($scope.rol2),
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            }).success(function (response) {
                $scope.resultado = response;
                if ($scope.resultado != "OK") {
                    $scope.mensaje = "Error al asociar";
                }
                else {
                    $scope.mensaje = "Actualización satisfactoria";
                }
            }).error(function (error) {

                $scope.message = 'No se pudo Crear el registro: '
            });
        };
    };



    $scope.Cerrar = function () {
        $cookieStore.remove('Roles');
        $cookieStore.remove('usuario');
        alert("$scope.Cerrar()");
        $scope.redirect();
    };

    $scope.menu = function () {

        if ($scope.Usuario) {
            if (!$scope.Usuario.pnSisId) {
                alert('$scope.menu()...$scope.Usuario.pnSisId Not defined...');
                return;
            }
            if (!$scope.Usuario.pnUsuId) {

                alert('$scope.menu()...$scope.Usuario.pnUsuId Not defined...');
                return;
            }

            $scope.rol3 = {
                pnSisId: $scope.Usuario.pnSisId,
                pnUsuId: $scope.Usuario.pnUsuId,
                pnRolId: 0
            }

            $http({
                method: 'POST',
                //method: 'GET',
                contentType: 'application/json; charset=utf-8',
                url: _URLApiBase + 'Menu/LIST_MENU',// List_MenuGeneral,
                //url: _URLApiBase + 'Menu/List_MenuGeneral',
                data: $.param($scope.rol3),
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            }).success(function (response) {
                $scope.lstMenu = response;
                if (response == null || response.length == 0) {
                    alert('$scope.menu()..  response == null || response.length == 0');
                    $scope.redirect();
                }

            }).error(function (error) {
                $scope.message = 'No se pudo Crear el registro: '
            });
        }
        else {
            alert('$scope.menu()... $scope.Usuario Not defined...');
        }
    }

    $scope.Sistema = function () {
        var fecha = new Date();
        var anno = fecha.getFullYear();
        $scope.annio = anno;
        $http({
            method: 'POST',
            contentType: 'application/json; charset=utf-8',
            url: _URLApiBase + 'Sistema/PiePagina',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        }).success(function (response) {
            $scope.System = response[0].pcSisNombre;
        }).error(function (error) {
            $scope.message = 'No se pudo Crear el registro: ' + error.message;
        });
    }

    $scope.fnEditarDatosUsuario = function () {
        var vkey = sessionStorage.getItem("key");
        //window.location.href = mvcUrl + "index.html#/datos?key="+vkey;
        window.location.href = mvcUrl + "index.html#/datos";
    }

    $scope.fnClickMenu = function (url, vnom, nsisid) {
        var _vxdata = JSON.parse(sessionStorage.getItem("datosusuario"));

        // $cookieStore.put('usuario', _vxdata.pnUsuId);
        //$cookieStore.put('sistema', nsisid);
        sessionStorage.setItem("vtituloview", vnom);
        $cookieStore.put('variables', vnom);
        // var vkey = sessionStorage.getItem("key");

        // window.location.href = url + "?key=" + vkey;

    }



});