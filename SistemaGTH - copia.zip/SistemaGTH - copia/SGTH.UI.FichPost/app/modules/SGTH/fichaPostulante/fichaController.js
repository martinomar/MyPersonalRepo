﻿app.directive("selectNgFiles", function () {
    return {
        require: "ngModel",
        link: function postLink(scope, elem, attrs, ngModel) {
            elem.on("change", function (e) {
                var files = elem[0].files;
                ngModel.$setViewValue(files);
            })
        }
    }
});

app.controller("fichaController", function ($scope, $http, $window, $cookieStore, $location, $compile, DTOptionsBuilder, DTColumnDefBuilder, DTDefaultOptions, $filter,
    ftyApiRequest, upload) {
    //Dropzone.autoDiscover = false;
    //fnSetActiveFieldSet(0, 1); //para iniciar desde el 2 field  
    //fnSetActiveFieldSet(0, 2); //para iniciar desde el 3 field
    //fnSetActiveFieldSet(0, 3); //para iniciar desde el 4 field
    //fnSetActiveFieldSet(0, 4); //para iniciar desde el 5 field
    //fnSetActiveFieldSet(0, 5); //para iniciar desde el field final
    //para un inicio NORMAL no ejecutar fnSetActiveFieldSet()


    if (!sessionStorage.getItem("Postulante")) {
        alert('no existe registro del postulante...');
        //redirect..
    }
    

    $scope.Postulante = JSON.parse(sessionStorage.getItem("Postulante"));
    console.log($scope.Postulante);
    //alert(JSON.stringify($scope.Postulante));
    $scope.DocumentosAdjuntos = [];
    $scope.file = []


    var _tipoAdjunto = [
        { id: '01', descripcion: 'doc de estudio' },
        { id: '02', descripcion: 'doc de Certificaciones' },
        { id: '03', descripcion: 'doc de Conocimientos tecnicos' },
        { id: '04', descripcion: 'doc de Idiomas' },

        { id: '05', descripcion: 'doc de Experiencia Laboral' },
        { id: '06', descripcion: 'doc de Ref. Laboral, PersonaXReferencia.nTipoRef = 1' },
        { id: '07', descripcion: 'doc de Ref. Familiar, PersonaXReferencia.nTipoRef = 2' },

        { id: '08', descripcion: 'doc de Registro de Deudas' },
        { id: '09', descripcion: 'doc de Registros Policiales' },

        { id: '10', descripcion: 'doc de Enfermedades' },
    ]


    $scope.mstr_certobtenida = [
      { id: "4", nombre: "Senior" },
      { id: "3", nombre: "Semi Senior" },
      { id: "2", nombre: "Junior" },
      { id: "1", nombre: "top" }
    ];



    $scope._listMeses =
    [{ val: 1, mes: "Enero" }
    , { val: 2, mes: "Febrero" }
    , { val: 3, mes: "Marzo" }
    , { val: 4, mes: "Abril" }
    , { val: 5, mes: "Mayo" }
    , { val: 6, mes: "Junio" }
    , { val: 7, mes: "Julio" }
    , { val: 8, mes: "Agosto" }
    , { val: 9, mes: "Septiembre" }
    , { val: 10, mes: "Octubre" }
    , { val: 11, mes: "Noviembre" }
    , { val: 12, mes: "Diciembre" }
    ];

    $scope._anios = [];
    getArrAnios();
    function getArrAnios() {
        var dateNow = new Date();
        var _yearNow = dateNow.getFullYear();
        var _rangoAnio = 10;
        var _yearLimitDown = _yearNow - _rangoAnio;

        for (var i = _yearNow; i >= _yearLimitDown; i--) {
            var _anio = { val: i, anio: i };
            $scope._anios.push(_anio);
        }
        //console.log($scope._anios);
    }

    
    $scope.Postulante.Collections = [];
    $scope.Postulante.Collections.EstudiosSuperiores = [];
    $scope.Postulante.Collections.ConocTecnicos = [];
    $scope.Postulante.Collections.Certificaciones = [];
    $scope.Postulante.Collections.Idiomas = [];

    $scope.Postulante.PrimerTrabj = undefined;
    $scope.Postulante.Collections.ExpLaborales = [];

    $scope.Postulante.Collections.RefLaborales = [];
    $scope.Postulante.Collections.RefFamiliar = [];

    $scope.Postulante.Collections.Deudas = [];
    $scope.Postulante.Collections.AntPenales = [];
    $scope.Postulante.Collections.AntPoliciales = [];
    $scope.Postulante.Collections.Enfermedades = [];

    $scope.Postulante.Collections.CargaFamiliar = {
        Padres: []
                                                   , DerechoHabientes: []
    };
    $scope.Postulante.Collections.Hobbies = [];

    $scope.shwFootBtns = true;
    $scope.show_inpt_fechLevant = false;
    $scope.shw_expLab_ref_b = true;


    {//arreglos-maestro
        $scope._maestro = [];
        /*Datos Personales*/
        $scope.maestr_canalReclut = []
        $scope.maestr_perfilCliente = []
        $scope.maestr_genero = []

        $scope.maestr_nacionalidad = []
        $scope.maestr_departamento = []
        $scope.maestr_provincia = []
        $scope.maestr_distrito = []

        $scope.maestr_estadoCivil = []
        $scope.maestr_religion = []

        /*Dom Particular*/

        /*Estudios Superiores*/
        $scope.maestr_tipoEstudio = []
        $scope.maestr_carrera = []
        $scope.maestr_tipoCentro = []
        $scope.maestr_centroEstudio = []
        $scope.maestr_tipoGrado_condicion = []

        /*carga certificaciones*/
        $scope.maestr_certificacion = []

        /*Conocimientos Tecnicos*/
        $scope.maestr_grpoConocTec = []
        $scope.maestr_conocTec = []
        $scope.maestr_conocNegoc = []
        $scope.maestr_conoc_nivel = []

        /*Carga Familiar*/
        $scope.maestr_parentesco = []
        $scope.maestr_ocupacion = []
        $scope.maestr_grdoInstruccion = []

        /*Carga Idioma*/
        $scope.maestr_idioma = []

        /*Experiencia laboral*/
        $scope.maestr_tpo_contrato = []

        /*Referencia laboral*/
        $scope.maestr_tpo_referencia = []

        /*frecuencia (hobbies)*/
        $scope.maestr_hobbies = []
        $scope.maestr_frecuencia = []

        $scope.maestr_tipoRegistro_postulante = []

        //SON LA OPCIONES QUE MUESTRA CADA SELECT, RESPECTIVAMENTE
        $scope.maestr_ids = [
            { MaeId: 28, Descripcion: 'Nacionalidad' },
            { MaeId: 29, Descripcion: 'Estado Civil' },
            { MaeId: 39, Descripcion: 'Religion' },
            { MaeId: 15, Descripcion: 'Grupo COnoc Tecnic' },
            { MaeId: 41, Descripcion: 'Grupo COnoc Negocio' },
            { MaeId: 5, Descripcion: 'Nivel Conocimiento' },
            { MaeId: 10, Descripcion: 'Tipo de estudio' },
            { MaeId: 13, Descripcion: 'Tipo de grado' },
            { MaeId: 11, Descripcion: 'Tipo centro de estudio' },
            { MaeId: 71, Descripcion: 'Parentesco' },
            { MaeId: 72, Descripcion: 'Ocupacion' },
            { MaeId: 66, Descripcion: 'Tipo de contrato' },
            { MaeId: 88, Descripcion: 'Idioma' },
            { MaeId: 89, Descripcion: 'Grado de instruccion' },
            { MaeId: 91, Descripcion: 'Tipo de referencia' },
            { MaeId: 73, Descripcion: 'Genero' },
            { MaeId: 14, Descripcion: 'Listado de Hobbies... ' },
            { MaeId: 30, Descripcion: 'frecuencia' },
            { MaeId: 93, Descripcion: 'Tipo de registro Postulante (manual o virtual)' },
        ];

    }


    $scope.iniciar = function () {


        //concatenando los id's de los maestros a consutlar...
        var _MaestIds = '';
        $.each($scope.maestr_ids, function (key, val) {
            _MaestIds += val.MaeId + ',';
        });
        _MaestIds = _MaestIds.substr(0, _MaestIds.length - 1);


        var _param = {
            cMaeId: _MaestIds,
        }
        $scope._maestro = [];

        ftyApiRequest._API_POST_REQUEST('Maestro', 'aList', _param)
                .success(function (response) {

                    //console.log('response',response);
                    if (response.nMsjCode == 200) {
                        $scope._maestro = response.DtCollection;

                        LoadMaestroOptiones(28, $scope.maestr_nacionalidad);
                        LoadMaestroOptiones(29, $scope.maestr_estadoCivil);
                        LoadMaestroOptiones(39, $scope.maestr_religion);
                        LoadMaestroOptiones(15, $scope.maestr_grpoConocTec);
                        LoadMaestroOptiones(41, $scope.maestr_conocNegoc);
                        LoadMaestroOptiones(5, $scope.maestr_conoc_nivel);
                        LoadMaestroOptiones(10, $scope.maestr_tipoEstudio)

                        LoadMaestroOptiones(13, $scope.maestr_tipoGrado_condicion);
                        LoadMaestroOptiones(11, $scope.maestr_tipoCentro);
                        LoadMaestroOptiones(71, $scope.maestr_parentesco);
                        LoadMaestroOptiones(72, $scope.maestr_ocupacion);
                        LoadMaestroOptiones(66, $scope.maestr_tpo_contrato);
                        LoadMaestroOptiones(88, $scope.maestr_idioma);
                        LoadMaestroOptiones(89, $scope.maestr_grdoInstruccion);
                        LoadMaestroOptiones(91, $scope.maestr_tpo_referencia);
                        LoadMaestroOptiones(73, $scope.maestr_genero);

                        LoadMaestroOptiones(14, $scope.maestr_hobbies);
                        LoadMaestroOptiones(30, $scope.maestr_frecuencia);

                        LoadMaestroOptiones(93, $scope.maestr_tipoRegistro_postulante);


                        //console.log($scope.maestr_nacionalidad);
                        //console.log($scope.maestr_estadoCivil);
                        //console.log($scope.maestr_religion);
                        //console.log($scope.maestr_genero);
                        //console.log($scope.maestr_grpoConocTec);
                        //console.log($scope.maestr_conocNegoc);
                        //console.log($scope.maestr_conoc_nivel);
                        //console.log($scope.maestr_parentesco);


                    }
                    else {
                        //console.error(response.cMsj);
                        fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                    }
                })
                .error(function (msj) {
                    //console.error(msj);
                    fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                })

    }




    function preAPR_fnGetList(controller, method, _param, _outList, _outObject) {
        ftyApiRequest._API_POST_REQUEST(controller, method, _param)
        .success(function (response) {
            //console.log(response);
            if (response.nMsjCode == 200) {
                if (_outList) {
                    $.each(response.DtCollection, function (key, val) {
                        _outList.push(val);
                    });
                }
                else if (_outObject) {
                    _outObject = response;
                }
            }
            else {
                console.error(msj);
                fnalert('warning', 'Aviso', 'Algo no salio bien.. Controller:' + controller + ', method:' + method, 4000);
            }
        })
        .error(function (msj) {
            console.error(msj);
            fnalert('warning', 'Aviso', 'Algo no salio bien.. Controller:' + controller + ', method:' + method, 4000);
        });
    }

    function LoadMaestroOptiones(MaeId, Array) {
        for (var i = 0; i < $scope._maestro.length; i++) {
            if ($scope._maestro[i].nMaeId == MaeId) {
                Array.push($scope._maestro[i]);
            }
        }
    }




    $scope.shw_expLab_ref = function () {

        //$scope.shw_expLab_ref_b != $scope.shw_expLab_ref_b;
        if ($scope.shw_expLab_ref_b) {
            $scope.shw_expLab_ref_b = false;
        }
        else {
            $scope.shw_expLab_ref_b = true;
        }
        console.log($scope.shw_expLab_ref_b);
    }

    function fnShowModal(_modalId) {
        $('#' + _modalId).modal({
            backdrop: 'static', keyboard: false
        });
        //console.log("============================================");
        //console.log($scope.Postulante);
        //console.log("============================================");
    }


    function fnUploadFiles_fichaPostulante_Docs(_inFile, _nPrsId, _idTipoDoc) {

        var _url = _URLApiBase + _CONTEXT_ + '/UploadAvatar';
        //console.log(_url);
        var data = new FormData();

        //data.append("UploadedImage", obj.adjunto[0]);
        data.append("_file_", _inFile);
        data.append("_nPrsID_", _nPrsId);
        data.append("_idTipoDoc_", _idTipoDoc);


        $.ajax({
            type: "POST",
            url: _url,
            contentType: false,
            processData: false,
            data: data,
            success: function (res) {
                //console.log(res);
                console.log("archivo Subido:", JSON.stringify(_inFile));
            },
            error: function (xhr, status) {
                console.error("No se logro subir el archivo:", JSON.stringify(_inFile));
                console.error(xhr);
                console.error(status);
                fnalert('info', '¡Aviso!', 'lo sentimos.. ocurrió un problema al cargar el archivo..');
            },
            complete: function (xhr, status) {
                //alert('Petición realizada');
            }
        });
    }

    function agregarListadoDeArchivos(_adjunto, cIdTipoDoc) {
        //pendiente implementar validacion (verificar que el archivo no exista..)
        var _dscrptn = "";
        for (var i = 0; i < _tipoAdjunto.length; i++) {
            if (_tipoAdjunto[i].id == cIdTipoDoc) {
                _dscrptn = _tipoAdjunto[i].descripcion;
                break;
            }
        }
        if (_adjunto) {
            var _objFile = {
                _file_: _adjunto[0]
                , _idTipoDoc_: cIdTipoDoc
                , _fileName: _adjunto[0].name
                , _TipoDoc: _dscrptn
            }
            $scope.DocumentosAdjuntos.push(_objFile);
            console.log($scope.DocumentosAdjuntos);
        }
    }


    function guardarArchivo(file) {
        upload({
            url: +_CONTEXT_ + '/upload',
            method: 'POST',
            data: {
                aFile: file,
                //aFile: lista,
                codigo: 0,
                cadena: ""
                //actividad: $scope.SolProceso1.nActId
            }

        }).then(function () {
            console.log('Grabo archivos');
        }, function (error) {
            console.log(error);
        });
    }


    function filterArrayObjectByObjectValues(_arr, _obj) {

        var _indexOf = -1;
        if (_arr) {
            var jsn_arr = "";
            var jsn_obj = "";
            for (var i = 0; i < _arr.length; i++) {
                jsn_arr = angular.toJson(_arr[i]);
                jsn_obj = angular.toJson(_obj);
                if (jsn_arr == jsn_obj) {
                    _indexOf = i;
                    return _indexOf;
                }
            }
        }


        return _indexOf;
    }
    $scope.fnPostulanteCollections_estSup = function (obj, _nOption) {

        //console.log(obj);
        if (_nOption) {
            if (_nOption == 1)//show modal
            {
                $scope.estudio = null; //clear ng-model
                fnShowModal('modalNewOrUpdate_carg_EstSup');
                obj = null;
            }
            else if (_nOption == 2)//New
            {
                //VALIDAR INPUTS()...
                //console.log(obj);
                if (obj) {
                    //console.log(obj);
                    //console.log(obj.adjunto);

                    var _newObj = {
                        
                          pnTipoId :obj.gradoEstudio.nMaeItem
                        , pvTipo : obj.gradoEstudio.cMaeDesc

                        , pnCtrEstId: obj.centroEstudio.nCtrEstId
                        , pvCentroEstudio: obj.centroEstudio.vNombre

                        , pnTpoCtrEstId: obj.tipoCentroEstud.nMaeItem
                        , pvTpoCtrEst: obj.tipoCentroEstud.cMaeDenom

                        , pnEstId: obj.carrera.nEstId
                        , pvEstudio: obj.carrera.vDescripcion

                        , pvPrdInicio: obj.periodoInicio_anio.val + ' ' + obj.periodoInicio_mes.val
                        , pcPrdInicioDesc: obj.periodoInicio_anio.val + ' ' + obj.periodoInicio_mes.mes

                        , pvPrdFin: obj.periodoFin_anio.val + ' ' + obj.periodoFin_mes.val
                        , pcPrdFinDesc: obj.periodoFin_anio.val + ' ' + obj.periodoFin_mes.mes

                        , pnTpoGradoId: obj.condicion.nMaeItem
                        , pvTpoGrado: obj.condicion.cMaeDesc

                        , pcDocAdjunto: (obj.adjunto ? obj.adjunto[0].name : "")
                    }


                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.EstudiosSuperiores, _newObj);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'Ya existe un registro igual, verifique sus datos.', 4000);
                        return;
                    }


                    //console.log(_newObj);
                    $scope.Postulante.Collections.EstudiosSuperiores.push(_newObj)


                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "01");
                    }


                    $scope.estudio = null; //clear ng-model
                    $scope.fnPostulanteCollections_estSup(undefined, 99);//clear Inputs
                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.EstudiosSuperiores.indexOf(obj);
                $scope.Postulante.Collections.EstudiosSuperiores.splice(index, 1);
            }
            else {
                $("#inpt_slc_cargEstSup_gradoEstudio").val('');
                $("#inpt_slc_cargEstSup_centroEstudio").val('');
                $("#inpt_slc_cargEstSup_carrera").val('');
                $("#dt_cargEstSup_finicial").val('');
                $("#dt_cargEstSup_ffinal").val('');
            }
        }
    }
   
    $scope.fnPostulanteCollections_CertifObt = function (obj, _nOption) {
        if (_nOption) {
           
            if (_nOption == 1)//shw modal
            {
                $scope.certificacion = null;
                fnShowModal('modalNewOrUpdate_carg_certificacion');
                obj = null;

            }
            else if (_nOption == 2)//New
            {
                //VALIDAR INPUTS()...
                if (obj) {
                    
                    var _newObj = {
                        cCursoNombr: obj.curso
                        , cCentrEstud: obj.centestudio

                        , nNivCertifObtenidoID: obj.certobtenida.id
                        , cNivCertifObtenido: obj.certobtenida.nombre

                        , cDocAdjunto: (obj.adjunto? obj.adjunto[0].name: "") 

                        , cDuracion: obj.duracion
                        , nAnioCertif: obj.year
                    }
                    //console.log(_newObj);

                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.Certificaciones, _newObj);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'Ya existe un registro igual, verifique sus datos.', 4000);
                        return;
                    }



                    //console.log(_certificacion);
                    $scope.Postulante.Collections.Certificaciones.push(_newObj)
                    //CLEAR INPUTS FORM...

                    debugger;
                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "02");
                    }

                    $scope.certificacion = null;
                    $scope.fnPostulanteCollections_CertifObt(undefined, 99);
                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.Certificaciones.indexOf(obj);
                $scope.Postulante.Collections.Certificaciones.splice(index, 1);
            }
            else {
                $("#txt_cargcert_curso").val('');
                $("#txt_cargcert_centestudio").val('');
                $("#inpt_slc_cargcert_obtenida").val('');
                $("#txt_cargcert_duracion").val('');
                $("#txt_cargcert_year").val('');
            }
        }
    }

    $scope.fnPostulanteCollections_conocTecnic = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1)//show modal
            {
                $scope.conocimiento = null; //CLEAR ng-model
                fnShowModal('modalNewOrUpdate_carg_ConTecnicos');
                obj = null;

            }
            else if (_nOption == 2)//New
            {
                //VALIDAR INPUTS...
                if (obj) {
                    //console.log(obj);
                    var _newObj = {
                        pnTpoTecnologiaId: obj.grupo.nMaeItem
                        , pvTpoTecnologia: obj.grupo.cMaeDenom

                        , pnTcnId: obj.conocimiento.nTcnId
                        , pvTecnologia: obj.conocimiento.vDescripcion

                        , pnNivelId: obj.nivel.nMaeItem
                        , pvNivel: obj.nivel.cMaeDenom
                    }


                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.ConocTecnicos, _newObj);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'Ya existe un registro igual, verifique sus datos.', 4000);
                        return;
                    }


                    //console.log(_conocimiento);
                    $scope.Postulante.Collections.ConocTecnicos.push(_newObj)


                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "03");
                    }

                    $scope.conocimiento = null; //CLEAR ng-model
                    $scope.fnPostulanteCollections_conocTecnic(undefined, 99);//CLEAR Inputs
                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.ConocTecnicos.indexOf(obj);
                $scope.Postulante.Collections.ConocTecnicos.splice(index, 1);
            }
            else {
                $("#inpt_slc_cargcon_grupo").val('');
                $("#txt_cargcon_conocimiento").val('');
                $("#inpt_slc_cargcon_nivel").val('');
            }
        }
    }

    $scope.fnPostulanteCollections_idioma = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1) {
                $scope.idioma = null;
                fnShowModal('modalNewOrUpdate_carg_idioma');
                obj = null;

            }
            else if (_nOption == 2)//New
            {
                //VALIDAR INPUTS...
                if (obj) {
                    //console.log(obj);
                    var _newObj = {
                        pnIdiomaId: obj.lengua.nMaeItem
                            , pcIdioma: obj.lengua.cMaeDenom

                            , pnNivelEscritoId: obj.escrito.nMaeItem
                            , pcNivelEscrito: obj.escrito.cMaeDenom

                            , pnNivelOralId: obj.hablado.nMaeItem
                            , pcNivelOral: obj.hablado.cMaeDenom
                    }



                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.Idiomas, _newObj);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'Ya existe un registro igual, verifique sus datos.', 4000);
                        return;
                    }

                    //console.log(_newObj);
                    $scope.Postulante.Collections.Idiomas.push(_newObj)
                    //CLEAR INPUTS FORM...
                    $scope.idioma = null;
                    $scope.fnPostulanteCollections_conocTecnic(undefined, 99);

                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.Idiomas.indexOf(obj);
                $scope.Postulante.Collections.Idiomas.splice(index, 1);
            }
            else {
                $("#inpt_slc_cargidiom_lenguaje").val('');
                $("#inpt_slc_cargidiom_escrito").val('');
                $("#inpt_slc_cargcert_obtenida").val('');
                $("#txt_cargcert_duracion").val('');
                $("#txt_cargcert_year").val('');
            }
        }
    }

    // EXPERIENCIA LABORAL
    $scope.fnPostulanteCollections_expLaboral = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1)//show modal
            {
                $scope.explaboral = null; //clear ng-model
                fnShowModal('modalNewOrUpdate_carg_explaboral');
                obj = null;

            }
            else if (_nOption == 2)//New
            {
                //VALIDAR INPUTS...
                if (obj) {
                    //console.log(obj)
                    var _newObj = {
                        pvEmpresa: obj.empresa
                        , pvPuesto: obj.puesto
                        , pcHerramientaUsada: obj.herramienta /**/
                        , pnSueldo: obj.sueldo

                        , pnTipoContratoID: obj.contrato.nMaeItem
                        , pcTipoContrato: obj.contrato.cMaeDenom

                        , pvMtvCese: obj.retiro
                        , pcFchInicio: obj.periodoInicio_anio.anio + '-' + obj.periodoInicio_mes.val
                        , pcFchInicioDesc: obj.periodoInicio_anio.anio + '-' + obj.periodoInicio_mes.mes
                        //, pcFchInicio_parsed: new Date(obj.periodoInicio_anio.anio, obj.periodoInicio_mes.val, 1) /* <<<< ==========*/
                        , pcFchInicio_parsed: new Date(obj.periodoInicio_anio.anio, obj.periodoInicio_mes.val, 1) /* <<<< ==========*/

                        , pcFchFin: obj.periodoFin_anio.anio + '-' + obj.periodoFin_mes.val
                        , pcFchFinDesc: obj.periodoFin_anio.anio + '-' + obj.periodoFin_mes.mes
                        //, pcFchFin_parsed: new Date(obj.periodoFin_anio.anio, obj.periodoFin_mes.val, 1) /* <<<< ==========*/
                        , pcFchFin_parsed: new Date(obj.periodoFin_anio.anio, obj.periodoFin_mes.val, 1) /* <<<< ==========*/

                    }


                    _newObj.pcFchInicio_parsed = $filter('date')(_newObj.pcFchInicio_parsed, "dd-MM-yyyy") /*!important */
                    _newObj.pcFchFin_parsed = $filter('date')(_newObj.pcFchFin_parsed, "dd-MM-yyyy") /*!important */


                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.ExpLaborales, _newObj);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'Ya existe un registro igual, verifique sus datos.', 4000);
                        return;
                    }


                    //console.log(_newObj);
                    $scope.Postulante.Collections.ExpLaborales.push(_newObj)


                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "05");
                    }
                    $scope.explaboral = null; //clear ng-model
                    $scope.fnPostulanteCollections_expLaboral(undefined, 99);//clear inputs form
                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.ExpLaborales.indexOf(obj);
                $scope.Postulante.Collections.ExpLaborales.splice(index, 1);
            }
            else {
                $("#txt_cargexplab_empresa").val('');
                $("#txt_cargexplab_puesto").val('');
                $("#txt_cargexplab_herramienta").val('');
                $("#txt_cargexplab_sueldo").val('');
                $("#inpt_slc_cargexplab_contrato").val('');
                $("#txt_cargexplab_retiro").val('');
                $("#dt_cargexplab_finicial").val('');
                $("#dt_cargexplab_ffinal").val('');
            }
        }
    }

    $scope.fnPostulanteCollections_refLaboral = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1) {
                $scope.referenciaLab = null; //clear ng-model
                fnShowModal('modalNewOrUpdate_carg_referenciaLab');
                obj = null;

            }
            if (_nOption == 2)//New
            {
                //VALIDAR INPUTS...
                if (obj) {
                    var _newObj = {
                        //pnTipoRef: obj.tipo.nMaeItem
                        pnTipoRef: 1  /*<<<<<<<<===============*/
                        , pvTipoRef: 'LABORAL', /*<<<<<<<<===============*/
                        pvEmpresa: obj.empresa
                        , pcNombrRepresentante: obj.representante
                        , pcCargoRepresentante: obj.cargo
                        , pcTelefRepresentante: obj.telefono
                    }

                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.RefLaborales, _newObj);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'Ya existe un registro igual, verifique sus datos.', 4000);
                        return;
                    }


                    //console.log(_referencia);
                    $scope.Postulante.Collections.RefLaborales.push(_newObj);

                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "06");
                    }
                    $scope.referenciaLab = null; //clear ng-model
                    $scope.fnPostulanteCollections_refLaboral(undefined, 99);//clear inputs
                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.RefLaborales.indexOf(obj);
                $scope.Postulante.Collections.RefLaborales.splice(index, 1);
            }
            else {
                //$("#inpt_slc_cargref_tipo").val('');
                $("#txt_cargrefLab_representante").val('');
                $("#txt_cargrefLab_cargo").val('');
                $("#txt_cargrefLab_empresa").val('');
                $("#txt_cargrefLab_telefono").val('');
            }
        }
    }

    $scope.fnPostulanteCollections_refFamiliar = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1) {
                $scope.referenciaFam = null; //clear ng-model
                fnShowModal('modalNewOrUpdate_carg_referenciaFam');
                obj = null;

            }
            else if (_nOption == 2)//New
            {
                //VALIDAR INPUTS...
                if (obj) {
                    var _newObj = {
                        pnTipoRef: 2  /*<<<<<<<<===============*/
                        , pvTipoRef: 'FAMILIAR', /*<<<<<<<<===============*/
                        pvEmpresa: obj.empresa
                        , pcNombrRepresentante: obj.representante
                        , pcCargoRepresentante: obj.cargo
                        , pcTelefRepresentante: obj.telefono
                    }


                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.RefFamiliar, _newObj);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'Ya existe un registro igual, verifique sus datos.', 4000);
                        return;
                    }

                    //console.log(_referencia);
                    $scope.Postulante.Collections.RefFamiliar.push(_newObj);

                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "07");
                    }
                    $scope.referenciaFam = null; //clear ng-model
                    $scope.fnPostulanteCollections_refFamiliar(undefined, 99);//clear inputs
                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.RefFamiliar.indexOf(obj);
                $scope.Postulante.Collections.RefFamiliar.splice(index, 1);
            }
            else {
                //$("#inpt_slc_cargref_tipo").val('');
                $("#txt_cargrefFam_representante").val('');
                $("#txt_cargrefFam_cargo").val('');
                $("#txt_cargrefFam_empresa").val('');
                $("#txt_cargrefFam_telefono").val('');
            }
        }
    }


    $scope.fnPostulanteCollections_deudas = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1) {
                $scope.deuda = null; //clear ng-model
                fnShowModal('modalNewOrUpdate_carg_deuda');
                obj = null;

            }
            if (_nOption == 2)//New
            {

                if (obj) {
                    //VALIDAR INPUTS...
                    //console.log(obj)
                    if (obj.deudaActual == null) {
                        fnalert('warning', 'Aviso', 'Indique si es una deuda actual o no', 4000);
                        return;
                    }
                    else if (obj.deudaActual == "false" && obj.fechaLevantamnto == null) {

                        fnalert('warning', 'Aviso', 'Especifique la fecha de levantamiento', 4000);
                        return;
                    }
                    var _newObj = {
                        pvEmpresa: obj.empresa
                        , pdtFchRegistro: $filter('date')(obj.fecha, "MM-dd-yyyy") /*!important */
                        , pvMotivoRegistro: obj.motivRegistro
                        , pnMontoDeuda: obj.monto
                        , pbDeudaActual: (obj.deudaActual == "true" ? 1 : 0)
                        , pdtFchLevantamiento: $filter('date')(obj.fechaLevantamnto, "MM-dd-yyyy") /*!important */

                    }

                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.Deudas, _newObj);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'Ya existe un registro igual, verifique sus datos.', 4000);
                        return;
                    }

                    //console.log(_deuda);
                    $scope.Postulante.Collections.Deudas.push(_newObj)

                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "08");
                    }

                    $scope.deuda = null; //clear ng-model
                    $scope.show_inpt_fechLevant = false;
                    $scope.fnPostulanteCollections_deudas(undefined, 99);   //CLEAR INPUTS FORM...
                }
                else {
                    fnalert('warning', 'Aviso', 'Ingrese los datos de la deuda', 4000);
                    return;
                }
            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.Deudas.indexOf(obj);
                $scope.Postulante.Collections.Deudas.splice(index, 1);
            }
            else {
                $("#txt_cargdeu_fregistro").val('');
                $("#txt_cardeu_empresa").val('');
                $("#txt_cardeu_motivo").val('');
                $("#txt_cargdeu_monto").val('');
            }
        }
    }

    // Antecedentes Penales
    $scope.fnPostulanteCollections_antPenales = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1)//New
            {
                $scope.antecedente = null; //clear ng-model
                fnShowModal('modalNewOrUpdate_carg_antecedente');
                obj = null;

            }
            else if (_nOption == 2)//New
            {

                if (!obj.fecha) {
                    fnalert('warning', 'Aviso', 'ingrese la fecha de registro', 4000);
                    return;
                }

                //console.log(obj)
                if (obj) {

                    var _newObj = {
                        pcFchProceso: $filter('date')(obj.fecha, "MM-dd-yyyy")
                        , pnTipoAnt: 1 /*< ======================*/
                        , pcTipoAnt: "PENALES" /*< ======================*/
                        , pvMotivo: obj.motivo
                        , pvResultado: obj.resultado

                    }

                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.AntPenales, _newObj);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'Ya existe un registro igual, verifique sus datos.', 4000);
                        return;
                    }


                    //console.log(_antecedente);
                    $scope.Postulante.Collections.AntPenales.push(_newObj)

                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "09");
                    }

                    $scope.antecedente = null; //clear ng-model
                    $scope.fnPostulanteCollections_antPenales(undefined, 99);  //clear inputs form

                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.AntPenales.indexOf(obj);
                $scope.Postulante.Collections.AntPenales.splice(index, 1);
            }
            else {
                $("#txt_cargant_fecha").val('');
                $("#txt_carant_motivo").val('');
                $("#txt_cargant_resultado").val('');
            }
        }
    }


    // Antecedentes Policiales
    $scope.fnPostulanteCollections_antPoliciales = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1)//New
            {
                $scope.antecedentePoli = null; //clear ng-model
                fnShowModal('modalNewOrUpdate_carg_antecedentePoli');
                $scope.antecedentePoli = null;

            }
            else if (_nOption == 2)//New
            {
                //VALIDAR INPUTS...

                //console.log(obj)
                if (obj) {

                    if (!obj.fecha) {
                        fnalert('warning', 'Aviso', 'ingrese la fecha de registro', 4000);
                        return;
                    }


                    var _newObj = {
                        pcFchProceso: $filter('date')(obj.fecha, "MM-dd-yyyy")
                        , pnTipoAnt: 2 /*< ======================*/
                        , pcTipoAnt: "POLICIAL" /*< ======================*/
                        , pvMotivo: obj.motivo
                        , pvResultado: obj.resultado
                    }

                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.AntPoliciales, _newObj);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'Ya existe un registro igual, verifique sus datos.', 4000);
                        return;
                    }

                    //console.log(_antecedente);
                    $scope.Postulante.Collections.AntPoliciales.push(_newObj)

                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "09");
                    }

                    $scope.antecedentePoli = null; //clear ng-model
                    $scope.fnPostulanteCollections_antPoliciales(undefined, 99);  //clear inputs form

                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.AntPoliciales.indexOf(obj);
                $scope.Postulante.Collections.AntPoliciales.splice(index, 1);
            }
            else {
                $("#txt_cargant_fecha").val('');
                $("#txt_carant_motivo").val('');
                $("#txt_cargant_resultado").val('');
            }
        }
    }

    $scope.fnPostulanteCollections_enfermedds = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1) {
                $scope.enfermedad = null; //clear ng-model
                fnShowModal('modalNewOrUpdate_carg_enfermedad');
                obj = null;

            }
            else if (_nOption == 2)//New
            {
                //VALIDAR INPUTS...

                //console.log(obj)
                if (obj) {
                    var _newObj = {
                        pcTratmnto_enfermd: obj.tratamiento
                    , pcInstituto: obj.instituto
                    , pcTiempoPreexistencia: obj.preexistencia
                    , pnAnioInicio: obj.year

                    }

                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.Enfermedades, _newObj);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'Ya existe un registro igual, verifique sus datos.', 4000);
                        return;
                    }


                    //console.log(_enfermedad);
                    $scope.Postulante.Collections.Enfermedades.push(_newObj)

                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "10");
                    }

                    $scope.enfermedad = null; //clear ng-model
                    $scope.fnPostulanteCollections_enfermedds(undefined, 99); //clear inputs form
                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.Enfermedades.indexOf(obj);
                $scope.Postulante.Collections.Enfermedades.splice(index, 1);
            }
            else {
                $("#txt_cargenf_trat").val('');
                $("#txt_carenf_instituto").val('');
                $("#txt_carenf_preexistencia").val('');
                $("#txt_cargenf_year").val('');
            }
        }
    }

    $scope.fnPostulanteCollections_cargFamiliarPadre = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1)//New
            {
                $scope.Padres = null;
                fnShowModal('modalNewOrUpdate_carg_fam_padres');
                obj = null;
            }
            else if (_nOption == 2)//New
            {
                //VALIDAR INPUTS...
                if (obj) {

                    var _nMaeItem_padre = -1;
                    var _cMaeDenom_padre = "PADRE";
                    //obtener el idMaestro de parentesco = PADRE
                    for (var i = 0; i < $scope.maestr_parentesco.length; i++) {
                        if ($scope.maestr_parentesco[i].cMaeDenom == "PADRE") {
                            _nMaeItem_padre = $scope.maestr_parentesco[i].nMaeItem;
                            break;
                        }
                    }


                    var _newObj = {
                        pvApePaterno: obj.app
                        , pvApeMaterno: obj.apm
                        , pvNombres: obj.nombres
                        , pnEdad: obj.edad
                        , pcVive: (obj.difunto == 'Y' ? '0' : '1')

                        , pnParentesco: _nMaeItem_padre
                        , pvParentesco: _cMaeDenom_padre
                        , pcDerHab: '0'
                        /*, pcGradoInstruccion: obj.instruccion.cMaeDenom
                          , pnGradoInstruccionID: obj.instruccion.nMaeItem*/

                        , pnGenero: obj.pcSexo.nMaeItem
                        , pvGenero: obj.pcSexo.cMaeDenom
                    }


                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.CargaFamiliar.Padres, _newObj);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'Ya existe un registro igual, verifique sus datos.', 4000);
                        return;
                    }

                    //console.log(_newObj);
                    $scope.Postulante.Collections.CargaFamiliar.Padres.push(_newObj)
                    //CLEAR INPUTS FORM...
                    $scope.Padres = null;
                    $scope.fnPostulanteCollections_cargFamiliarPadre(undefined, 99);

                }


            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.CargaFamiliar.Padres.indexOf(obj);
                $scope.Postulante.Collections.CargaFamiliar.Padres.splice(index, 1);
            }
            else {
                $("#txt_cargFam_app").val('');
                $("#txt_cargFam_apm").val('');
                $("#txt_cargFam_nombres").val('');
                $("#inpt_slc_cargFam_parentsco").val('');
                $("#txt_cargFam_edad").val('');
                $("#inpt_slc_cargFam_instruccion").val('');
                $('input[name="rdo_cargFam_difunt"]').removeAttr('checked');
            }
        }
    }


    $scope.fnPostulanteCollections_cargFamiliarDerechHabiente = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1)//New
            {
                $scope.DerechoHabiente = null;
                fnShowModal('modalNewOrUpdate_carg_fam_DerechoHabiente');
                obj = null;
            }
            else if (_nOption == 2)//New
            {
                //VALIDAR INPUTS...
                if (obj) {

                    var _newObj = {
                        pvApePaterno: obj.app
                        , pvApeMaterno: obj.apm
                        , pvNombres: obj.nombres

                        , pnParentesco: obj.parentesco.nMaeItem
                        , pvParentesco: obj.parentesco.cMaeDenom
                        , pcDerHab: '1'

                        , pcGradoInstruccion: obj.instruccion.cMaeDenom
                        , pnGradoInstruccionID: obj.instruccion.nMaeItem

                        , pnOcupacion: obj.ocupacion.nMaeItem
                        , pvOcupacion: obj.ocupacion.cMaeDenom

                        , pnGenero: obj.pcSexo.nMaeItem
                        , pvGenero: obj.pcSexo.cMaeDenom

                        , pvDocNro: obj.nroDoc

                        , pdtFchNac: obj.fechaNac

                        , pcVive: (obj.difunto == 'Y' ? '0' : '1')

                        /*, pnEdad: obj.edad*/


                    }

                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.CargaFamiliar.DerechoHabientes, _newObj);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'Ya existe un registro igual, verifique sus datos.', 4000);
                        return;
                    }

                    console.log(_newObj);
                    $scope.Postulante.Collections.CargaFamiliar.DerechoHabientes.push(_newObj)
                    //CLEAR INPUTS FORM...
                    $scope.DerechoHabiente = null;
                    $scope.fnPostulanteCollections_cargFamiliarDerechHabiente(undefined, 99);

                }


            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.CargaFamiliar.DerechoHabientes.indexOf(obj);
                $scope.Postulante.Collections.CargaFamiliar.DerechoHabientes.splice(index, 1);
            }
            else {
                $("#txt_cargFam_app").val('');
                $("#txt_cargFam_apm").val('');
                $("#txt_cargFam_nombres").val('');
                $("#inpt_slc_cargFam_parentsco").val('');
                $("#txt_cargFam_edad").val('');
                $("#inpt_slc_cargFam_instruccion").val('');
                $('input[name="rdo_cargFam_difunt"]').removeAttr('checked');
            }
        }
    }


    $scope.fnPostulanteCollections_hobbies = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1) {

                $scope.hobbie = null;
                fnShowModal('modalNewOrUpdate_Hobbies');
                obj = null;

            }
            else if (_nOption == 2)//New
            {
                if (obj) {
                    var _obj = {
                        pnHobbieId: obj.hobbie.nMaeItem
                        , pvHobbie: obj.hobbie.cMaeDenom

                         , pnFrecuenciaId: obj.frecuencia.nMaeItem
                         , pvFrecuencia: obj.frecuencia.cMaeDenom

                         , pnNivelId: obj.nivel.nMaeItem
                         , pvNivel: obj.nivel.cMaeDenom
                    };

                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.Hobbies, _obj);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'Ya existe un registro igual, verifique sus datos.', 4000);
                        return;
                    }

                    //console.log(obj);
                    $scope.Postulante.Collections.Hobbies.push(_obj);
                    //console.log($scope.Postulante.Collections.Hobbies);
                    //clean inputs
                    $scope.hobbie = null;

                    $scope.fnPostulanteCollections_hobbies(undefined, 99)
                }

            }
            else if (_nOption == 3)//remove
            {

                var index = $scope.Postulante.Collections.Hobbies.indexOf(obj);
                $scope.Postulante.Collections.Hobbies.splice(index, 1);
            }
            else {
                $scope.hobbie = null;
            }
        }
    }



    var _CONTEXT_ = 'FichaPostulante';
    $scope._ACTION_CRUD_ = null;

    $scope.fnGradoEstudio_SelectedIndexChanged = function (obj) {
        var _param = {
            pnTipo: obj.nMaeItem,
            pcOpcion: '01'
        }
        $scope.maestr_carrera = [];
        ftyApiRequest._API_POST_REQUEST('Maestro', 'fIListEstudios', _param)
                .success(function (response) {
                    if (response.nMsjCode == 200) {
                        $scope.maestr_carrera = response.DtCollection;
                    }
                    else {
                        fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                    }
                })
                .error(function (msj) {
                    //console.error(msj);
                    fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                });
    }

    $scope.fnTipoCentroEstud_SelectedIndexChanged = function (obj) {
        var _param = {
            pnTpoCentro: obj.nMaeItem,
            pcOpcion: '01'
        }
        $scope.maestr_centroEstudio = [];

        ftyApiRequest._API_POST_REQUEST('Maestro', 'FILCentroEstudio', _param)
                .success(function (response) {

                    //console.log(response);
                    if (response.nMsjCode == 200) {
                        $scope.maestr_centroEstudio = response.DtCollection;
                    }
                    else {
                        //console.error(response.cMsj);
                        fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                    }
                })
                .error(function (msj) {
                    //console.error(msj);
                    fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                });
    }



    $scope.fnpostOrigenNacion_SelectedIndexChanged = function (obj) {
        var _param = {
            pnIdNacionalidad: obj.nMaeItem,
            strOpcion: '1'
        }
        $scope.maestr_departamento = [];
        $scope.maestr_provincia = [];
        $scope.maestr_distrito = [];
        preAPR_fnGetList('Maestro', 'fILCargarDepartamento', _param, $scope.maestr_departamento); //works
    }
    $scope.fnpostOrigenDpto_SelectedIndexChanged = function (obj) {
        if (obj) {
            if (obj.nDptId != null || obj.nDptId != undefined) {
                var _param = {
                    pnDptId: obj.nDptId,
                    strOpcion: '2'
                }
                $scope.maestr_provincia = [];
                $scope.maestr_distrito = [];
                preAPR_fnGetList('Maestro', 'fILCargarProvincia', _param, $scope.maestr_provincia); //works
            }
        }

    }
    $scope.fnpostOrigenProvinc_SelectedIndexChanged = function (obj) {
        if (obj) {
            if (obj.nPrvId != null) {
                var _param = {
                    pnPrvId: obj.nPrvId,
                    strOpcion: '3'
                }
                $scope.maestr_distrito = [];
                preAPR_fnGetList('Maestro', 'fILCargarDistrito', _param, $scope.maestr_distrito); //works
            }
        }
    }

    $scope.fnpostDomPartNacion_SelectedIndexChanged = function (obj) {
        var _param = {
            pnIdNacionalidad: obj.nMaeItem,
            strOpcion: '1'
        }
        //LoadMaestroOptionesTESTT(_param, $scope.maestr_departamento);
        $scope.DomicPartic_departamentos = [];
        $scope.DomicPartic_provincias = [];
        $scope.DomicPartic_distrito = [];
        preAPR_fnGetList('Maestro', 'fILCargarDepartamento', _param, $scope.DomicPartic_departamentos); //works
    }

    $scope.fnpostDomPartDpto_SelectedIndexChanged = function (obj) {
        if (obj) {
            if (obj.nDptId != null || obj.nDptId != undefined) {
                var _param = {
                    pnDptId: obj.nDptId,
                    strOpcion: '2'
                }
                $scope.DomicPartic_provincias = [];
                $scope.DomicPartic_distrito = [];
                preAPR_fnGetList('Maestro', 'fILCargarProvincia', _param, $scope.DomicPartic_provincias); //works
            }
        }
    }

    $scope.fnpostDomPartProvinc_SelectedIndexChanged = function (obj) {
        if (obj) {
            if (obj.nPrvId != null || obj.nPrvId != undefined) {
                var _param = {
                    pnPrvId: obj.nPrvId,
                    strOpcion: '3'
                }
                $scope.DomicPartic_distrito = [];
                preAPR_fnGetList('Maestro', 'fILCargarDistrito', _param, $scope.DomicPartic_distrito); //works
            }
        }
    }

    $scope.fnGrpoConocTec_SelectedIndexChanged = function (obj) {
        $scope.maestr_conocTec = [];
        if (obj != null) {
            var _param = {
                pnTpoTecnologia: obj.nMaeItem,
                pcOpcion: '01'
            }
            preAPR_fnGetList('Maestro', 'FILTecnologiaBL', _param, $scope.maestr_conocTec); //works
        }
    }




    $scope.btn_Registrar_Postulante = function () {

        //console.log($scope.chk_politicas);
        if (!$scope.chk_politicas) {
            fnalert('warning', 'Aviso', 'Seleccione la opción Aceptar para continuar con el registro.', 4000);
            return;
        }
        if ($scope.chk_politicas == false) {
            fnalert('warning', 'Aviso', 'Seleccione la opción Aceptar para continuar con el registro.', 4000);
            return;
        }

        var _embarazada = 0;
        var _TiempoEmbarazada = 0;
        if ($scope.Postulante.pcSexo.nMaeItem == 1) {//mujer
             _embarazada =  ($scope.Postulante.tieneEmbarazo == 'Y' ? 1 : 0)
             _TiempoEmbarazada = $scope.Postulante.tiempoEmbarazo;
        }

        /*$("#modalPoliticaDePrivacidad").modal("hide");
        fnSetActiveFieldSet(4, 5);
        console.log($scope.Postulante);
        */
        //return;
        //console.log($scope.Postulante);

        var _param = {
            //inicio campos tabla Persona

            pcModalidaRegistro: "2.2" /*<<=== tipo de registro ======*/
            
            , pvNombres: $scope.Postulante.pvNombres
            , pvApePaterno: $scope.Postulante.pvApePaterno
            , pvApeMaterno: $scope.Postulante.pvApeMaterno
            , pcSexo: $scope.Postulante.pcSexo.nMaeItem
            , pnNacionalidad: $scope.Postulante.pnNacionalidad.nMaeItem
            , pvCorreo: $scope.Postulante.pvCorreo

            , pvTelefono: $scope.Postulante.pvTelefono
            , pvTelefonoCelular: $scope.Postulante.pvTelefonoCelular

            , pvContactFamNombr: $scope.Postulante.pvFamiliar_NombreCompleto
            , pvContactFamTelef: $scope.Postulante.pvFamiliar_telefono

            , pnDstNacId: $scope.Postulante.pnDstNacId.nDstId
            , pvDmcDireccion: $scope.Postulante.pvDmcDireccion
            , pnDstDmcId: $scope.Postulante.pnDstDmcId.nDstId
            , pvDmcReferencia: $scope.Postulante.pvDmcReferencia

            , pdtFchNacimiento: $filter('date')($scope.Postulante.pdtFchNacimiento, "dd-MM-yyyy") /*!important */
            //, pdtFchNacimiento: $filter('date')(_date_fechNacimnto, "dd-MM-yyyy") /*!important */
            , pvDocNro: $scope.Postulante.pvDocNro
            , pdtFchVenDoc: $filter('date')($scope.Postulante.pdtFchVenDoc, "dd-MM-yyyy") /*!important */
            //, pdtFchVenDoc: $filter('date')(_date_fechVencDoc, "dd-MM-yyyy") /*!important */

            , pnEstCivil: $scope.Postulante.pnEstCivil.nMaeItem
            , pnHijos: $scope.Postulante.pnHijos
            , pvReligion: $scope.Postulante.pvReligion.nMaeItem
            , pnCanalId: $scope.Postulante.pnCanalId

            , pcEnfermedad: ($scope.Postulante.tieneEnfermedades == 'Y' ? 1 : 0)
            , pcEmbarazo: _embarazada
            , pnTmpEmbarazo: _TiempoEmbarazada /* int */
            , pcAntPenales: ($scope.Postulante.tieneAntecedente == 'Y' ? 1 : 0)
            , pcAntPoliciales: ($scope.Postulante.tieneAntecedentePoli == 'Y' ? 1 : 0)
            , pcDeudor: ($scope.Postulante.tieneDeuda == 'Y' ? 1 : 0)

            //fin campos tabla Persona

            , pLisEstSupe: $scope.Postulante.Collections.EstudiosSuperiores
            , pListConcTe: $scope.Postulante.Collections.ConocTecnicos
            , pListCertif: $scope.Postulante.Collections.Certificaciones
            , pListIdioma: $scope.Postulante.Collections.Idiomas

            , pcPrimrTrbj: $scope.Postulante.PrimerTrabj /* Solo se usa para la validacion de los campos, no es necesario almacenar este dato? */
            , pListExpLbs: $scope.Postulante.Collections.ExpLaborales
            , pListRefLab: $scope.Postulante.Collections.RefLaborales
            , pListRefFam: $scope.Postulante.Collections.RefFamiliar

            , pListDeudas: $scope.Postulante.Collections.Deudas  /*Tabla: PersonaFinanciero*/
            , pListAntPen: $scope.Postulante.Collections.AntPenales
            , pListAntPol: $scope.Postulante.Collections.AntPoliciales

            , pListEnferm: $scope.Postulante.Collections.Enfermedades  /*Tabla: PersonaXTratmnt_enfermd*/
            , pListCrgFam: $.merge($scope.Postulante.Collections.CargaFamiliar.Padres, $scope.Postulante.Collections.CargaFamiliar.DerechoHabientes)
            , pListHobbie: $scope.Postulante.Collections.Hobbies
        }
        console.log(_param);
        //#01 - se registra/actualiza al postulante
        ftyApiRequest._API_POST_REQUEST('FichaPostulante', 'fnRegistroVirtual_FichPost', _param)
       .success(function (response) {
           //console.log(response);
           if (response.nMsjCode == 200) {
               //#02 - se obtiene el id del postulante para guardar los documentos adjuntos...
               var _nPrsId = -1;
               debugger;
               _nPrsId = response.nMsj2;
               //console.log('_nPrsId', _nPrsId);
               if (_nPrsId != -1) {
                   //#03 - se suben los adjuntos uno a uno...
                   if ($scope.DocumentosAdjuntos) {
                       if ($scope.DocumentosAdjuntos.length > 0) {
                           for (var i = 0; i < $scope.DocumentosAdjuntos.length; i++) {
                               fnUploadFiles_fichaPostulante_Docs($scope.DocumentosAdjuntos[i]._file_
                                                                   , _nPrsId
                                                                   , $scope.DocumentosAdjuntos[i]._idTipoDoc_
                                                                   );
                           }
                       }
                   }

               }

               $("#modalPoliticaDePrivacidad").modal("hide");
              fnSetActiveFieldSet(4, 5);
              $scope.shwFootBtns = false;

           }
           else {
               console.error(msj);
               fnalert('warning', 'Aviso', 'Algo no salio bien.. Controller:' + controller + ', method:' + method, 4000);
           }
       })
       .error(function (msj) {
           console.error(msj);
           fnalert('warning', 'Aviso', 'Algo no salio bien.. Controller:' + controller + ', method:' + method, 4000);
       });





    }



    $scope.btn_valida_formacionCompatencias = function () {
        $scope.clss_formacionCompetencias = "next";
    }


    //LIMPIAR LOS MODALS 
    //limpiar familiar




    $scope.iniciar();

    $scope.fnPostGenero = function (obj) {

        //validación del input: src/js/fichaPostulante.js

        if (obj.cMaeDesc == 'F') {
            $scope.bMostrar_dv_estadoEmbarazo = true;
        }
        else {
            $scope.bMostrar_dv_estadoEmbarazo = false;
        }
    }



    $scope.fn_rdo_deudaActual = function (_val) {
        $scope.show_inpt_fechLevant = !_val;
    }

    $scope.btnsgt = function () {
        $scope.chk_politicas = undefined;
    }

});


