﻿app.controller("MsjController", function ($scope, $http, $window, $cookieStore, $location, $compile, DTOptionsBuilder, DTColumnDefBuilder, DTDefaultOptions, $filter,
    ftyApiRequest) {

    $scope.Msj = JSON.parse(sessionStorage.getItem("MsjFchP"));

});