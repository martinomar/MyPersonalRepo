﻿/*-------------------------------------------------------------------------------------------------*
* SISTEMA		: Ficha Postulante
* SUBSISTEMA	: Ficha Postulante
* NOMBRE		: mainApiRequestFactory.cs
* DESCRIPCIÓN	: define las propiedades para las solicitudes hacia el API
* AUTOR		    : Martin Delgado
* FECHA		    : 2018-08-09 (yyyy-mm-dd)
* 
*====================┬=============================┬========================================================*
* FECHA (yyyy-mm-dd)   EMPLEADO                       MODIFICACIÓN
*====================┼=============================┼========================================================*
* 2018-08-09           Martin.Delgado                   creacion, Definicion de métodos
*--------------------┼-----------------------------┼--------------------------------------------------------*
*
*--------------------┴-----------------------------┴--------------------------------------------------------*/
(function () {

    var ftyApiRequest = function ($http, $q) {

        var baseUrl = _URLApiBase;

        var _API_POST_REQUEST = function (_apiController, _apiAction, _param) {
            var url = baseUrl + _apiController + "/" + _apiAction;
      //      console.log(url);
            return $http({
                method: 'POST',
                contenttype: 'application/json; charset=utf-8',
                url: url,
                data: $.param(_param),
                headers: { 'content-type': 'application/x-www-form-urlencoded' },
            })

        }

        var _api_get_rest = function (url,_param) {
            $http.get(url, { params: _param });
        }
        //var _API_POST_REQUEST_N = function (_apiController, _apiAction) {
        //    var url = baseUrl + _apiController + "/" + _apiAction;
        //    console.log(url);
        //    return $http({
        //        method: 'POST',
        //        contenttype: 'application/json; charset=utf-8',
        //        url: url,
        //        headers: { 'content-type': 'application/x-www-form-urlencoded' },
        //    })

        //}


        //var _API_POST_REQUEST_MstList = function (_nIdItemMaestro) {
        //    var _param = {
        //        nIdItemMaestro: _nIdItemMaestro
        //    }
        //    var url = baseUrl + 'Maestro/aList';
        //    return $http({
        //        method: 'POST',
        //        contenttype: 'application/json; charset=utf-8',
        //        url: url,
        //        data: $.param(_param),
        //        headers: { 'content-type': 'application/x-www-form-urlencoded' },
        //    })
        //}


        return {
            _API_POST_REQUEST: _API_POST_REQUEST,
            _api_get_rest: _api_get_rest
            //_API_POST_REQUEST_MstList: _API_POST_REQUEST_MstList,
        }


    }

    angular.module('manageApiRequests', []).factory("ftyApiRequest", ftyApiRequest);

})();