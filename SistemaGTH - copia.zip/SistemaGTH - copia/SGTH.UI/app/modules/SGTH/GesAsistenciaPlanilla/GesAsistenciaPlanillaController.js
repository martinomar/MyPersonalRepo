﻿/*-- ------------------------------------------------------------------------
SISTEMA : GCH
SUBSISTEMA : GCH
NOMBRE : GesAsistenciaPlanillaController.js
DESCRIPCIÓN : Archivo con funcionalidad para gestionar asistencia por periodo
AUTOR : Jesus Sulla - SES
FECHA CREACIÓN : 23/10/2018
------------------------------------------------------------------------
FECHA MODIFICACIÓN  EMPLEADO
------------------------------------------------------------------------*/

app.controller('GesAsistenciaPlanillaController', function ($scope, $http, $window, $cookieStore, $location, $compile, DTOptionsBuilder, DTColumnDefBuilder, DTDefaultOptions, $filter,
    ftyApiRequest) {

    $scope.Usuario = $cookieStore.get('usuario');//Important for CRUD
    vdatosroles = JSON.parse(sessionStorage.getItem("listarol"));
    if ($scope.Usuario == undefined || $scope.Usuario == null) {
        fnalert('warning', 'Aviso', 'No se logro obtener los datos del usuario, porfavor ingrese nuevamente...', 4000);
        return;
    }

    var _CONTEXT_ = 'AsistenciaPlanilla';
    $scope._ACTION_CRUD_ = null;/*1:Create,2:Update,3:Delete*/
    $scope._ID_ = null;
    $scope.vtituloview = sessionStorage.getItem("vtituloview");

    $scope.dtOptions = DTOptionsBuilder.newOptions()
    .withOption('lengthMenu', [[10, 20, 30], [10, 20, 30]])
    .withDisplayLength(10)
    //.withOption('scrollY', 100);
    //ftyApiRequest.utilitario = { codigo : 2};
    //var vutilitario = ftyApiRequest.utilitario;
    //datatable properties...
    $scope.dtColumnDefs = [
       DTColumnDefBuilder.newColumnDef(11).notSortable(),
       DTColumnDefBuilder.newColumnDef(13).notSortable()
    ];
    $scope.BodyEmailtemplate = '<p>Estimado(a)  <b>[Destinatario]</b> ,</p><p></p><p>Se envía archivo con la información de asistencias de <b>[Fecha Emision]</b> para su validación a la brevedad posible.</p><p>Favor considerar los siguientes puntos:</p><p>1. A partir de la fecha solo se notificara todo aquello que no se tenga como registro en nuestro sistema, tales como inasistencias/ incumplimiento/ tardanzas.</p><p>2. Las inasistencias e incumplimientos de horas/ tardanzas corresponden desde el <b>[Fecha Registro]</b> .</p><p>3. En el campo &#34;<b>Información de Líder</b>&#34;, solicitamos:</p><p>- Para los casos de inasistencias se nos especifique so se procede como DESCUENTO o caso contrario si es que se va realizar alguna excepción (Vacaciones, Compensación autorizada, etc.)</p><p>- <b>Tardanzas</b>: Si aun cuando estas no han generado incumplimiento de horas se podrán descontar aplicando un descuento adicional.</p><p>- <b>Incumplimiento</b>: En principio deberían descontarse en su totalidad, salvo alguna excepción que especifiquen.</p><p>- <b>Incumplimiento y Tardanzas</b>: Reiteramos que las tardanzas que no han generado incumplimiento se informan para que puedan tener información de la reiteración. Si no se ha generado incumplimiento no aparecerá otra fila con dicha información. Asimismo, considerar que el incumplimiento ya contiene tardanza en alguna medida, por lo mismo solo deberíamos aplicar el mayor, salvo que por reiteración apliquemos descuento adicional.</p><p>4. Es importante reiterarles, que para ser consideradas como Vacaciones en la planilla, al cierre del mes, éstas ya deben estar registradas, de lo contrario serán consideradas como FALTAS.</p><p>5. Agradecemos nos apoyen en el tiempo de respuestas, prospectando su validación como fecha máxima hasta las 15:00 horas del día martes.</p>';
    $scope.vGrilla = [];
    $scope.objListAplica = [{ codigo: 1, text: 'SI' }, { codigo: 0, text: 'NO' }];
    $scope.param_filter = { vgerencia: '', vestado: '', vnombre: '' };
    $scope.vCampObs = true;
    $scope.nCerrado = 0;
    var objRoles = {
        AC1: [5],
        AC2: [4],
        AC3: [2],
        AC4: [146]
    };
    $scope.vControles = {
        btnConsultar: true,
        btnCorreo: true,
        btnCorreo_disabled: true,
        btnFeedback: true,
        btnFeedback_disabled: true,
        btnObservacion: true,
        btnObservacion_disabled: true,
        btnSaveObservacion: true,
        btnSaveObservacion_disabled: true,
        btnReProcesar: true,
        btnReProcesar_disabled: true,
        btnCierre: true,
        btnCierre_disabled: true,
        cboGerencia: false, // Disabled
        dvContent: true,
        txtNombre: true // Disabled
    };
    var _objTpRol = '';
    $scope.fninicio = function () {

        $.each(vdatosroles, function (index, value) {
            if (value.bRolFav == true) {
                var _rolSelect = value.nRolId;
                $.each(objRoles, function (xindex, xvalue) {
                    if (xvalue.indexOf(_rolSelect) > -1) {
                        _objTpRol = xindex;
                    }
                });
            }
        });
        //alert(_objTpRol);
        switch (_objTpRol) {
            case 'AC1':
                $scope.vControles.btnFeedback = false;
                fnFiltro(2, '');//Gerencias
                break;
            case 'AC2':
                $scope.vControles.cboGerencia = true;
                $scope.vControles.btnFeedback = false;
                fnFiltro(2, '');//Gerencias
                break;
            case 'AC3':
                $scope.vControles.cboGerencia = true;
                $scope.vControles.btnFeedback = true;
                $scope.vControles.btnReProcesar = false;
                $scope.vControles.btnCierre = false;
                $scope.vControles.btnCorreo = false;
                //fnFiltro(2, $scope.Usuario.nUsuId);//Gerencias
                fnFiltro(2, 122);//Gerencias
                $scope.fnConsDatos();
                break;
            case 'AC4':
                $scope.vControles.cboGerencia = false;
                $scope.vControles.btnFeedback = true;
                $scope.vControles.btnReProcesar = false;
                $scope.vControles.btnCierre = false;
                $scope.vControles.btnCorreo = false;
                //fnFiltro(2, $scope.Usuario.nUsuId);//Gerencias
                fnFiltro(2, 122);//Gerencias
                $scope.fnConsDatos();
                break;
            default:
                $scope.vControles.dvContent = false;
                break;
        }
        fnFiltro(1, '');//Periodos        
        fnFiltro(3, '');//Estados

    }

    $scope.fnConsultar = function () {
        //$scope.vGrilla = undefined;
        if ($scope.param_filter.vperiodo == null || $scope.param_filter.vperiodo == '') {
            fnalert('info', 'Aviso', 'Tiene que seleccionar un periodo para realizar la consulta...', 4000);
            return;
        }
        if ($scope.param_filter.vgerencia == null || $scope.param_filter.vgerencia == '') {
            fnalert('info', 'Aviso', 'Tiene que seleccionar una gerencia para realizar la consulta...', 4000);
            return;
        }

        var _param = {
            nPeriodo: ($scope.param_filter.vperiodo == null || $scope.param_filter.vperiodo == '' ? 0 : $scope.param_filter.vperiodo.cCodigo),
            nGerencia: ($scope.param_filter.vgerencia == null || $scope.param_filter.vgerencia == '' ? 0 : $scope.param_filter.vgerencia.cCodigo),
            nEstado: ($scope.param_filter.vestado == null || $scope.param_filter.vestado == '' ? 0 : $scope.param_filter.vestado.cCodigo),
            cNombre: ($scope.param_filter.vnombre == null || $scope.param_filter.vnombre == '' ? '' : $scope.param_filter.vnombre),
            nOpcion: 1
        }

        ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aList', _param)
        .success(function (response) {
            if (response.nMsj2 === 0) {

                $scope.cMsgProcesoConsulta_Periodo = 'No se encuentran datos para el periodo seleccionado. ¿Desea iniciar el proceso para el periodo ' + $scope.param_filter.vperiodo.cTexto + ' ?';
                $('#md-proceso-x-consulta').modal({ keyboard: false, backdrop: 'static' });
            } else if (response.nMsj2 === -1) {
                fnalert('danger', 'Aviso', 'Ocurrio un problema...', 4000);
            }
            else {
                //$scope.vGrilla = response.IECollection;
            }
            $scope.vGrilla = response.IECollection;
            $scope.nCerrado = response.nMsj3;
            if ($scope.nCerrado == 1) {
                $scope.vControles.btnFeedback_disabled = true;
                $scope.vControles.btnObservacion_disabled = true;
                $scope.vControles.btnReProcesar_disabled = true;
                $scope.vControles.btnCierre_disabled = true;
                $scope.vControles.btnCorreo_disabled = true;
            } else {
                $scope.vControles.btnFeedback_disabled = false;
                $scope.vControles.btnReProcesar_disabled = false;
                $scope.vControles.btnCierre_disabled = false;
                $scope.vControles.btnCorreo_disabled = false;
                $scope.vControles.btnObservacion_disabled = false;
            }
        })
        .error(function (msj) {
            fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
        });
    }
    $scope.fnConsDatos = function () {
        if ($scope.param_filter.vgerencia != '' && $scope.param_filter.vgerencia != null) {
            $scope.param_filter.vnombre = '';
            $scope.vControles.txtNombre = false;
            fnFiltro(5, $scope.param_filter.vgerencia.cCodigo);//Estados
            $scope.fnConsultar();
        } else {
            $scope.vControles.txtNombre = true;
            $scope.param_filter.vnombre = '';
            $scope.vGrilla = [];
        }
    }
    function fnFiltro(vop, vparam) {
        var _param = {
            nOpcion: vop,
            texto: vparam
        };

        ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aListFiltro', _param)
        .success(function (response) {
            if (vop == 1) {
                $scope.vPeriodo = response.IECollection;
            }
            if (vop == 2) {
                $scope.vGerencia = response.IECollection;
                if (vparam != '') {
                    $scope.param_filter.vgerencia = response.IECollection[0];
                    $scope.param_filter.vnombre = '';
                    $scope.vControles.txtNombre = false;
                    fnFiltro(5, $scope.param_filter.vgerencia.cCodigo);//Estados
                }
            }
            if (vop == 3) {
                $scope.vEstado = response.IECollection;
            }
            if (vop == 5) {
                $scope.vColaborador = response.IECollection;
            }
        })
        .error(function (msj) {
            fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
        });
    }
    $scope.fnObservacion = function () {

        if ($scope.vGrilla == null || $scope.vGrilla.lenght <= 0 || $scope.vGrilla == '') {
            fnalert('info', 'Aviso', 'No cuenta con información a la cual observar..', 3000);
            return;
        }
        if ($scope.nCerrado == 1) {
            fnalert('info', 'Aviso', 'El periodo de encuentra cerrado, no se puede realizar la observación', 3000);
            return;
        }
        $scope.vCampObs = false;
        $('#btn-consultar').attr('disabled', 'disabled');
        $('#btn-correo').attr('disabled', 'disabled');
        $('#btn-feedback input').attr('disabled', 'disabled');
        $('#btn-reprocesar').attr('disabled', 'disabled');
        $('#btn-cierre').attr('disabled', 'disabled');
    }
    $scope.fnSaveObservacion = function () {
        $scope.vCampObs = true;
        $('#btn-consultar').removeAttr('disabled');
        $('#btn-correo').removeAttr('disabled');
        $('#btn-feedback input').removeAttr('disabled');
        $('#btn-reprocesar').removeAttr('disabled');
        $('#btn-cierre').removeAttr('disabled');
        var __vdata = [];
        $.each($scope.vGrilla, function (index, value) {
            if ($scope.vGrilla[index].cComentario != null && $scope.vGrilla[index].cComentario != '') {
                __vdata.push({
                    texto: $scope.vGrilla[index].cComentario,
                    nUsuId: $scope.Usuario.nUsuId,
                    nId: $scope.vGrilla[index].nConsAsistPlaId
                });
            }
        });


        if (__vdata.length > 0) {
            $scope.lista = JSON.stringify(__vdata);
            var _param = {
                texto: $scope.lista
            }

            ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aMntObservacion', _param)
            .success(function (response) {
                if (response.nMsjCode == 200) {
                    fnalert('success', 'Aviso', 'La solicitud fue completada con exito', 4000);
                }
                else {
                    fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                }
                $scope.fnConsultar();
            })
            .error(function (Error) {
                fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
            });
        } else {
            fnalert('info', 'Aviso', 'No se ingreso ninguna observación', 4000);
        }

    }
    $scope.fnCancelObservacion = function () {
        $scope.vCampObs = true;
        $('#btn-consultar').removeAttr('disabled');
        $('#btn-correo').removeAttr('disabled');
        $('#btn-feedback input').removeAttr('disabled');
        $('#btn-reprocesar').removeAttr('disabled');
        $('#btn-cierre').removeAttr('disabled');
        var __vdata = [];
        $.each($scope.vGrilla, function (index, value) {
            if ($scope.vGrilla[index].cComentario != null && $scope.vGrilla[index].cComentario != '') {
                $scope.vGrilla[index].cComentario = '';
            }
        });

    }
    $scope.fnComentarios = function (item) {
        $('#md-comentarios').modal({ keyboard: false, backdrop: 'static' });
        $scope.vListaComentarios = item;
    }
    $scope.fnCorreo = function () {
        if ($scope.vGrilla == null || $scope.vGrilla == undefined || $scope.vGrilla.length <= 0) {
            fnalert('info', 'Aviso', 'Debe seleccionar información a enviar a usuario!!!', 4000);
            return;
        }

        var _param = {
            nOpcion: 4,
            texto: $scope.param_filter.vgerencia.cCodigo + ',' + $scope.param_filter.vperiodo.cCodigo
        };

        ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aListDatosCorreo', _param)
        .success(function (response) {
            if (response != null) {
                $scope.vDatosCorreo = response.IEObject;
                $scope.BodyEmail = $scope.BodyEmailtemplate;
                $scope.BodyEmail = $scope.BodyEmail.replace('[Fecha Registro]', $scope.param_filter.vperiodo.cTexto);
                $scope.BodyEmail = $scope.BodyEmail.replace('[Fecha Emision]', $scope.vDatosCorreo.cFechaEmision);
                $scope.BodyEmail = $scope.BodyEmail.replace('[Destinatario]', $scope.vDatosCorreo.cDestinatario);
                $scope.vAsuntoCorreo = 'Reporte de asistencias: ' + $scope.vDatosCorreo.cAbreArea + ' - ' + $scope.vDatosCorreo.cFechaEmision;
                $('#md-correo').modal({ keyboard: false, backdrop: 'static' });

            } else {
                fnalert('info', 'Aviso', 'No se cuenta con datos para iniciar envio de correo..', 4000);
            }
        })
        .error(function (msj) {
            fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
        });

    }

    $scope.fnEnvio = function () {

        if ($scope.BodyEmail == null || $scope.BodyEmail.length == 0) {
            $scope.msg = "Debe ingresar mensaje a enviar";
            $('#dv-msg').modal({ keyboard: false, backdrop: 'static' });
            return;
        }

        var _param = {
            cDestinatario: $scope.vDatosCorreo.cDestinatario,
            cCorreoDestinatario: $scope.vDatosCorreo.cCorreoDestinatario,
            cBuzon: $scope.vDatosCorreo.cCorreoDestinatario,
            cCorreoBuzon: $scope.vDatosCorreo.cCorreoBuzon,
            cAsunto: $scope.vAsuntoCorreo,
            cCuerpo: $scope.BodyEmail,
            nPeriodo: ($scope.param_filter.vperiodo == null || $scope.param_filter.vperiodo == '' ? 0 : $scope.param_filter.vperiodo.cCodigo),
            nGerencia: ($scope.param_filter.vgerencia == null || $scope.param_filter.vgerencia == '' ? 0 : $scope.param_filter.vgerencia.cCodigo),
            nEstado: ($scope.param_filter.vestado == null || $scope.param_filter.vestado == '' ? 0 : $scope.param_filter.vestado.cCodigo),
            cNombre: ($scope.param_filter.vnombre == null || $scope.param_filter.vnombre == '' ? '' : $scope.param_filter.vnombre)
        };

        ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aEnvioCorreo', _param)
        .success(function (response) {
            if (response != null) {
                //alert(response.nMsjCode);
                if (response.nMsjCode == '200') {
                    $scope.msg = "Correo enviado satisfactoriamente";
                    $('#dv-msg').modal({ keyboard: false, backdrop: 'static' });
                    $('#md-correo').modal('hide');
                    $scope.fnConsultar();
                } else {
                    $scope.msg = "Ocurrió un error en el proceso de envío: " + (response.nMsjCode == null ? '' : response.nMsjCode);
                    $('#dv-msg').modal({ keyboard: false, backdrop: 'static' });
                }
            } else {
                //fnalert('info', 'Aviso', 'No se cuenta con datos para iniciar envio de correo..', 4000);
            }
        })
        .error(function (msj) {
            //fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
            $scope.msg = "Ocurrió un error en el proceso de envío: ";
            $('#dv-msg').modal({ keyboard: false, backdrop: 'static' });
        });
    }
    $scope.fnGenerar = function () {
        $scope.vGrilla = [];
        if ($scope.param_filter.vperiodo == null || $scope.param_filter.vperiodo == '') {
            fnalert('info', 'Aviso', 'Tiene que seleccionar un periodo para realizar la generación.', 4000);
            return;
        }

        var _param = {
            nPeriodo: ($scope.param_filter.vperiodo == null || $scope.param_filter.vperiodo == '' ? 0 : $scope.param_filter.vperiodo.cCodigo)
        }

        ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aGenerar', _param)
        .success(function (response) {
            $('#md-proceso-x-consulta').modal('hide');
            if (response.nMsj2 > 0) {
                fnalert('success', 'Aviso', 'Proceso realizado con exito.', 4000);
                $scope.fnConsultar();
            } else if (response.nMsj2 == 0) {
                fnalert('info', 'Aviso', 'El periodo seleccionado no cuenta con registros para la generación.', 4000);
            }
            else {
                fnalert('danger', 'Aviso', 'Ocurrio un problema...', 4000);
            }
        })
        .error(function (msj) {
            fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
        });
    }
    $scope.fnPreReprocesar = function () {
        //$scope.vGrilla = undefined;
        if ($scope.param_filter.vperiodo == null || $scope.param_filter.vperiodo == '') {
            fnalert('info', 'Aviso', 'Tiene que seleccionar un periodo para realizar el reproceso...', 4000);
            return;
        }
        if ($scope.param_filter.vgerencia == null || $scope.param_filter.vgerencia == '') {
            fnalert('info', 'Aviso', 'Tiene que seleccionar una gerencia para realizar el reproceso...', 4000);
            return;
        }

        var _param = {
            nPeriodo: ($scope.param_filter.vperiodo == null || $scope.param_filter.vperiodo == '' ? 0 : $scope.param_filter.vperiodo.cCodigo),
            nGerencia: ($scope.param_filter.vgerencia == null || $scope.param_filter.vgerencia == '' ? 0 : $scope.param_filter.vgerencia.cCodigo),
            cNombre: ($scope.param_filter.vnombre == null || $scope.param_filter.vnombre == '' ? '' : $scope.param_filter.vnombre),
            nOpcion: 3
        }

        ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aList', _param)
        .success(function (response) {
            if (response.nMsj2 > 0) {
                $scope.cMsgProcesoConsulta_Periodo = '¿ Esta seguro de reprocesar la información del periodo ' + $scope.param_filter.vperiodo.cTexto + ' ?';
                $('#md-proceso-x-consulta').modal({ keyboard: false, backdrop: 'static' });
            } else if (response.nMsj2 === -1) {
                fnalert('info', 'Aviso', 'Periodo se encuentra cerrado no es posible reprocesar', 4000);
            } else if (response.nMsj2 === 0) {
                fnalert('info', 'Aviso', 'Todos los registros se encuentran en estado iniciado', 4000);
            }
        })
        .error(function (msj) {
            fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
        });
    }
    /* Inicio: Carga archivo */
    $scope.CargarArchivo = function () {

        var vfile = $("#IdUploadFormato").get(0).files;
        var file = vfile[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function (e) {
                var data = e.target.result;
                var workbook = XLSX.read(data, { type: 'binary' });
                var first_sheet_name1 = workbook.SheetNames[0];

                var dataObjects = XLSX.utils.sheet_to_json(workbook.Sheets[first_sheet_name1]);

                if (dataObjects != null) {
                    $scope.guardarArchivo(dataObjects);
                } else {
                    fnalert('danger', '¡Aviso!', 'Error al subir el archivo', 3000);
                }
            }
            reader.onerror = function (ex) { }
            reader.readAsBinaryString(file);
        }
        $("#IdUploadFormato").val('');
    }
    $scope.guardarArchivo = function (data) {

        var _vcabeceras = ['DNI', 'COLABORADOR', 'MODALIDAD', 'LIDER', 'FECHA INICIO', 'FECHA FIN', 'DIAS INASISTENCIAS', 'TARDANZA', 'INCUMPLIMIENTO', 'TIPO', 'APLICA', 'HRS', 'OBSERVACION', 'ID'];
        var _vcabecerasfile = [];

        if (data.length > 0) {
            $.each(data[0], function (index, value) {
                _vcabecerasfile.push(index);
            });
            var sw = 0;
            $.each(_vcabeceras, function (index, value) {
                if (_vcabecerasfile.indexOf(value) == -1) {
                    sw++;
                }
            });
            if (sw > 0) {
                fnalert('warning', 'Aviso', 'Archivo seleccionado no corresponde a proceso de validación.', 4000);
                return;
            } else {
                fnalert('warning', 'Aviso', 'El archivo cuenta con el formato correcto.', 4000);
            }
        } else {
            fnalert('info', 'Aviso', 'No se cuenta con datos para cargar.', 4000);
            return;
        }
        var __vDataRequest = [];
        $.each(data, function (index, value) {
            __vDataRequest.push({
                nAplica: (value.APLICA == 'SI' ? 1 : 0),
                cHorasAplica: value.HRS,
                cObservacion: value.OBSERVACION,
                nConsAsistPlaId: value.ID,
                nUsuReg: $scope.Usuario.nUsuId
            });
        });

        var _parametro = JSON.stringify(__vDataRequest);
        var _param = {
            texto: _parametro
        }

        ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aUploadFile', _param)
        .success(function (response) {
            if (response.nMsjCode == 200) {
                fnalert('success', 'Aviso', 'La solicitud fue completada con exito', 4000);

            }
            else {
                fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
            }
            $scope.fnConsultar();
        })
        .error(function (Error) {
            fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
        });
        $("#IdUploadFormato").val('');

    }

    $scope.fnCierre = function () {
        if ($scope.param_filter.vperiodo == null || $scope.param_filter.vperiodo == '') {
            fnalert('info', 'Aviso', 'Tiene que seleccionar un periodo para poder inciar con el proceso de cierre...', 4000);
            return;
        }
        var _param = {
            nPeriodo: ($scope.param_filter.vperiodo == null || $scope.param_filter.vperiodo == '' ? 0 : $scope.param_filter.vperiodo.cCodigo),
            nUsuId: $scope.Usuario.nUsuId
        };

        ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aCierre', _param)
        .success(function (response) {
            if (response != null) {
                if (response.nMsjCode == '200') {
                    fnalert('info', 'Aviso', response.cMsj2, 8000);
                    $scope.fnConsultar();
                } else {
                    fnalert('danger', 'Aviso', 'Ocurrió un error, no se pudo realizar el proceso de cierre', 4000);
                }
            } else {
                //fnalert('info', 'Aviso', 'No se cuenta con datos para iniciar envio de correo..', 4000);
            }
        })
        .error(function (msj) {
            fnalert('danger', 'Aviso', 'Ocurrió un error, no se pudo realizar el proceso de cierre', 4000);
        });
    }
    /* Fin: Carga archivo*/

});