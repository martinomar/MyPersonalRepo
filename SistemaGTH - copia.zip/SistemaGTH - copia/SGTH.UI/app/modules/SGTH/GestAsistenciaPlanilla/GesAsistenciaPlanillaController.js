﻿app.controller('GesAsistenciaPlanillaController', function ($scope, $parse, $http, $window, $cookieStore, $location, ftyApiRequest) {

    var _CONTEXT_ = 'AsistenciaPlanilla';


})