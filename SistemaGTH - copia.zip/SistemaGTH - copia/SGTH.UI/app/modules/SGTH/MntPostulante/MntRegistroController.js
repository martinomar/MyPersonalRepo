﻿app.controller('MntRegistroController', function ($scope
, $parse
, $http
, $window
, $cookieStore
, $location
, ftyApiRequest
, $filter
) {

    $scope.vtituloview = sessionStorage.getItem("vtituloview");
    /* $scope.Postulante = JSON.parse(sessionStorage.getItem("Postulante"));
     if (!$scope.Postulante) {
         alert('no existe registro del postulante...');
     }*/

    var _CONTEXT_ = 'FichaPostulante';

    $scope.datosPers = {};
    $scope.datosPers.genero = {};
    $scope.datosPers.Canalrec = {};
    $scope.datosPers.EstCivil = {};
    $scope.datosPers.Perfil_cliente = {};
    $scope.datosPers.Religion = {};


    $scope.Postulante = {
        'something|': 'dfdfdf'
    };

    $scope.Postulante.Collections = [];
    $scope.Postulante.Collections.EstudiosSuperiores = [];
    $scope.Postulante.Collections.ConocTecnicos = [];
    $scope.Postulante.Collections.Certificaciones = [];
    $scope.Postulante.Collections.Idioma = [];

    $scope.Postulante.PrimerTrabj = undefined;
    $scope.Postulante.Collections.ExpLaborales = [];

    $scope.Postulante.Collections.RefLaborales = [];
    $scope.Postulante.Collections.RefFamiliar = [];

    $scope.Postulante.Collections.Deudas = [];
    $scope.Postulante.Collections.AntPenales = [];
    $scope.Postulante.Collections.AntPolicial = [];
    $scope.Postulante.Collections.Enfermedades = [];

    $scope.Postulante.Collections.CargagrupoConocimineto = [];

    $scope.Postulante.Collections.CargaFamiliar = [];
    $scope.Postulante.Collections.Hobbies = [];






    {//arreglos-maestro
        $scope._maestro = [];
        /*Datos Personales*/
        $scope.maestr_canalReclut = []
        $scope.maestr_perfilCliente = []
        $scope.maestr_genero = []

        $scope.maestr_nacionalidad = []
        $scope.maestr_departamento = []
        $scope.maestr_provincia = []
        $scope.maestr_distrito = []

        $scope.maestr_estadoCivil = []
        $scope.maestr_religion = []




        /*Dom Particular*/

        /*Estudios Superiores*/
        $scope.maestr_tipoEstudio = []
        $scope.maestr_carrera = []
        $scope.maestr_tipoCentro = []
        $scope.maestr_centroEstudio = []
        $scope.maestr_tipoGrado_condicion = []

        /*carga certificaciones*/
        $scope.maestr_certificacion = []

        /*Conocimientos Tecnicos*/
        $scope.maestr_grpoConocTec = []
        $scope.maestr_conocTec = []
        $scope.maestr_conocNegoc = []
        $scope.maestr_conoc_nivel = []

        /*Carga Familiar*/
        $scope.maestr_parentesco = []
        $scope.maestr_ocupacion = []
        $scope.maestr_grdoInstruccion = []

        /*Carga Idioma*/
        $scope.maestr_idioma = []

        /*Experiencia laboral*/
        $scope.maestr_tpo_contrato = []

        /*Referencia laboral*/
        $scope.maestr_tpo_referencia = []

        /*Conocimiento del negocio*/
        $scope.maestr_conoc_negocio = []

        /*frecuencia (hobbies)*/
        $scope.maestr_hobbies = []
        $scope.maestr_frecuencia = []

        $scope.mtnLista_postulantes = []



        $scope.maestr_tipoDeAceptacion = []
        //SON LA OPCIONES QUE MUESTRA CADA SELECT, RESPECTIVAMENTE
        $scope.maestr_ids = [
            { MaeId: 28, Descripcion: 'Nacionalidad' },
            { MaeId: 29, Descripcion: 'Estado Civil' },
            { MaeId: 92, Descripcion: 'canal de reclutamiento' },
            { MaeId: 39, Descripcion: 'Religion' },
            { MaeId: 15, Descripcion: 'Grupo COnoc Tecnic' },
            { MaeId: 41, Descripcion: 'Grupo COnoc Negocio' },
            { MaeId: 5, Descripcion: 'Nivel Conocimiento' },
            { MaeId: 10, Descripcion: 'Tipo de estudio' },
            { MaeId: 13, Descripcion: 'Tipo de grado' },
            { MaeId: 11, Descripcion: 'Tipo centro de estudio' },
            { MaeId: 71, Descripcion: 'Parentesco' },
            { MaeId: 72, Descripcion: 'Ocupacion' },
            { MaeId: 66, Descripcion: 'Tipo de contrato' },
            { MaeId: 88, Descripcion: 'Idioma' },
            { MaeId: 89, Descripcion: 'Grado de instruccion' },
            { MaeId: 91, Descripcion: 'Tipo de referencia' },
            { MaeId: 73, Descripcion: 'Genero' },
            { MaeId: 41, Descripcion: 'Conocimineto de negocio' },
            { MaeId: 14, Descripcion: 'Listado de Hobbies... ' },
            { MaeId: 30, Descripcion: 'frecuencia' },
            { MaeId: 9, Descripcion: 'tipo de aceptación, en el RDA figura con el nombre de "FSW"...' },
        ];
    }


    $scope.mstr_certobtenida = [
      { id: "4", nombre: "Senior" },
      { id: "3", nombre: "Semi Senior" },
      { id: "2", nombre: "Junior" },
      { id: "1", nombre: "top" }
    ];



    $scope._listMeses =
    [{ val: 1, mes: "Enero" }
    , { val: 2, mes: "Febrero" }
    , { val: 3, mes: "Marzo" }
    , { val: 4, mes: "Abril" }
    , { val: 5, mes: "Mayo" }
    , { val: 6, mes: "Junio" }
    , { val: 7, mes: "Julio" }
    , { val: 8, mes: "Agosto" }
    , { val: 9, mes: "Septiembre" }
    , { val: 10, mes: "Octubre" }
    , { val: 11, mes: "Noviembre" }
    , { val: 12, mes: "Diciembre" }
    ];

    $scope._anios = [];
    getArrAnios();
    function getArrAnios() {
        var dateNow = new Date();
        var _yearNow = dateNow.getFullYear();
        var _rangoAnio = 10;
        var _yearLimitDown = _yearNow - _rangoAnio;

        for (var i = _yearNow; i >= _yearLimitDown; i--) {
            var _anio = { val: i, anio: i };
            $scope._anios.push(_anio);
        }
        console.log($scope._anios);
    }
    function LoadMaestroOptiones(MaeId, Array) {
        for (var i = 0; i < $scope._maestro.length; i++) {
            if ($scope._maestro[i].nMaeId == MaeId) {
                Array.push($scope._maestro[i]);
            }
        }
    }



    function loadList_perfilCliente() {

        //ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aListCrgCntrto', _param)
        ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aListCrgCntrto', null)
         .success(function (response) {

             console.log(response);
             if (response.nMsjCode == 200) {
                 $scope.listaperfilcliente = response.DtCollection;
             }
             else {
                 fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
             }
         })
        .error(function (msj) {
            //console.error(msj);
            fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
        })
    }

    function loadList_Maestros() {

        //concatenando los id's de los maestros a consultar...
        var _MaestIds = '';
        $.each($scope.maestr_ids, function (key, val) {
            _MaestIds += val.MaeId + ',';
        });
        _MaestIds = _MaestIds.substr(0, _MaestIds.length - 1);

        var _param = {
            cMaeId: _MaestIds,
        }
        $scope._maestro = [];

        ftyApiRequest._API_POST_REQUEST('Maestro', 'aList', _param)
        .success(function (response) {

            console.log('response', response);
            if (response.nMsjCode == 200) {
                $scope._maestro = response.DtCollection;
                LoadMaestroOptiones(28, $scope.maestr_nacionalidad);
                LoadMaestroOptiones(29, $scope.maestr_estadoCivil);
                LoadMaestroOptiones(39, $scope.maestr_religion);
                LoadMaestroOptiones(15, $scope.maestr_grpoConocTec);
                LoadMaestroOptiones(41, $scope.maestr_conocNegoc);
                LoadMaestroOptiones(92, $scope.maestr_canalReclut);
                LoadMaestroOptiones(5, $scope.maestr_conoc_nivel);
                LoadMaestroOptiones(10, $scope.maestr_tipoEstudio);

                LoadMaestroOptiones(13, $scope.maestr_tipoGrado_condicion);
                LoadMaestroOptiones(11, $scope.maestr_tipoCentro);
                LoadMaestroOptiones(71, $scope.maestr_parentesco);
                LoadMaestroOptiones(72, $scope.maestr_ocupacion);
                LoadMaestroOptiones(66, $scope.maestr_tpo_contrato);
                LoadMaestroOptiones(88, $scope.maestr_idioma);
                LoadMaestroOptiones(89, $scope.maestr_grdoInstruccion);
                LoadMaestroOptiones(91, $scope.maestr_tpo_referencia);
                LoadMaestroOptiones(73, $scope.maestr_genero);

                LoadMaestroOptiones(14, $scope.maestr_hobbies);
                LoadMaestroOptiones(30, $scope.maestr_frecuencia);

                LoadMaestroOptiones(41, $scope.maestr_conoc_negocio);

                LoadMaestroOptiones(9, $scope.maestr_tipoDeAceptacion);
                console.log($scope.maestr_tipoEstudio)
            }
            else {
                //console.error(response.cMsj);
                fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
            }
        })
        .error(function (msj) {
            //console.error(msj);
            fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
        });
    }

    function loadList_CentroDeEstudio() {
        var _param = {
            pnTpoCentro: '0',/*<< '0 will bring us every row...*/
            pcOpcion: '01'
        }
        $scope.maestr_centroEstudio = [];

        ftyApiRequest._API_POST_REQUEST('Maestro', 'FILCentroEstudio', _param)
                .success(function (response) {

                    //console.log(response);
                    if (response.nMsjCode == 200) {
                        $scope.maestr_centroEstudio = response.DtCollection;
                    }
                    else {
                        //console.error(response.cMsj);
                        fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                    }
                })
                .error(function (msj) {
                    //console.error(msj);
                    fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                });
    }


    function loadList_Carrera() {
        var _param = {
            pnTipo: '0',
            pcOpcion: '01'
        }
        $scope.maestr_carrera = [];
        ftyApiRequest._API_POST_REQUEST('Maestro', 'fIListEstudios', _param)
                .success(function (response) {
                    if (response.nMsjCode == 200) {
                        $scope.maestr_carrera = response.DtCollection;
                    }
                    else {
                        fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                    }
                })
                .error(function (msj) {
                    //console.error(msj);
                    fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                });
    }



    $scope.fILListaPostulantes = function (_nPrsId, _nFichaId) {


        var _param = {}
        if (_nPrsId) {


            _param = {
                'pnPersonaId': _nPrsId
                , strOpcion: 3
                , pnFicId: _nFichaId
                /*
               , 'PageNumber': 1
               , 'PageSize': 10
               , 'strOpcion': "2"*/
            }

        }
        else {
            _param = {
                'PageNumber': 1
                , 'PageSize': 10
                , 'strOpcion': '2'
            }
        }
        console.log(_param);
        ftyApiRequest._API_POST_REQUEST('FichaPostulante', 'fListaPostulante', _param)
               .success(function (response) {
                   console.log(response);
                   if (response.nMsjCode == 200) {
                       $scope.respuesta = response.DtCollection[0];
                       console.log($scope.respuesta);
                       $scope.datosPers.nombre = $scope.respuesta.vNombres;
                       $scope.datosPers.App = $scope.respuesta.vApePaterno;
                       $scope.datosPers.Apm = $scope.respuesta.vApeMaterno;
                       $scope.datosPers.genero.nMaeItem = $scope.respuesta.cSexo;
                       //$scope.datosPers.nacimiento = $filter('date')($scope.respuesta.dtFchNacimiento, "dd-MM-yyyy"); //añadir fecha de nacimineto

                       //añadir edad
                       $scope.datosPers.EstCivil.nMaeItem = $scope.respuesta.nEstCivil
                       $scope.datosPers.nhijos = $scope.respuesta.nHijos;//añadir numero de hijos
                       $scope.datosPers.documento = $scope.respuesta.vDocNro;
                       $scope.datosPers.Religion.nMaeItem = $scope.respuesta.vReligion;//añadir religion
                       //$scope.datosPers.vencdoc = $filter('date')($scope.respuesta.dtFchVenDoc, "dd-MM-yyyy");//añadir fecha de vencimineto
                       $scope.datosPers.Canalrec.nMaeItem = $scope.respuesta.nCanalId;
                       $scope.datosPers.Perfil_cliente.nCrgPrsId = $scope.respuesta.nCrgPrsId;
                       $scope.datosPers.correo = $scope.respuesta.vCorreo; // anadir correo
                       $scope.datosPers.cell = $scope.respuesta.vTelefonoCelular;// añadir celular
                       // añadir nombre familiar
                       // añadir telefono de familiar
                       // añadir nacionalidadorigen
                       // añadir departamentoorigen
                       // añadir provinciaorigen
                       // añadir distritoorigen
                       $scope.datosPers.direcActual = $scope.respuesta.vDmcDireccion// añadir direccion actual 
                       $scope.datosPers.pntref = $scope.respuesta.vDmcReferencia// añadir punto de referencia
                       // añadir nacionalidadactual
                       // añadir departamentoactual
                       // añadir provinciaactual
                       // añadir distritoactual
                       $scope.datosPers.tlfparticualar = $scope.respuesta.cTelefonos;
                       //$scope.Postulante.Collections.EstudiosSuperiores = 
                   }
                   else {
                       fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                   }
               })
               .error(function (msj) {
                   //console.error(msj);
                   fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
               });

    }

    $scope.fnpostOrigenNacion_SelectedIndexChanged = function (obj) {
        var _param = {
            pnIdNacionalidad: obj.nMaeItem,
            strOpcion: '1'
        }
        $scope.maestr_departamento = [];
        $scope.maestr_provincia = [];
        $scope.maestr_distrito = [];
        preAPR_fnGetList('Maestro', 'fILCargarDepartamento', _param, $scope.maestr_departamento); //works
    }
    $scope.fnpostOrigenDpto_SelectedIndexChanged = function (obj) {
        if (obj) {
            if (obj.nDptId != null || obj.nDptId != undefined) {
                var _param = {
                    pnDptId: obj.nDptId,
                    strOpcion: '2'
                }
                $scope.maestr_provincia = [];
                $scope.maestr_distrito = [];
                preAPR_fnGetList('Maestro', 'fILCargarProvincia', _param, $scope.maestr_provincia); //works
            }
        }

    }
    $scope.fnpostOrigenProvinc_SelectedIndexChanged = function (obj) {
        if (obj) {
            if (obj.nPrvId != null) {
                var _param = {
                    pnPrvId: obj.nPrvId,
                    strOpcion: '3'
                }
                $scope.maestr_distrito = [];
                preAPR_fnGetList('Maestro', 'fILCargarDistrito', _param, $scope.maestr_distrito); //works
            }
        }
    }

    $scope.fnpostDomPartNacion_SelectedIndexChanged = function (obj) {
        var _param = {
            pnIdNacionalidad: obj.nMaeItem,
            strOpcion: '1'
        }
        //LoadMaestroOptionesTESTT(_param, $scope.maestr_departamento);
        $scope.DomicPartic_departamentos = [];
        $scope.DomicPartic_provincias = [];
        $scope.DomicPartic_distrito = [];
        preAPR_fnGetList('Maestro', 'fILCargarDepartamento', _param, $scope.DomicPartic_departamentos); //works
    }

    $scope.fnpostDomPartDpto_SelectedIndexChanged = function (obj) {
        if (obj) {
            if (obj.nDptId != null || obj.nDptId != undefined) {
                var _param = {
                    pnDptId: obj.nDptId,
                    strOpcion: '2'
                }
                $scope.DomicPartic_provincias = [];
                $scope.DomicPartic_distrito = [];
                preAPR_fnGetList('Maestro', 'fILCargarProvincia', _param, $scope.DomicPartic_provincias); //works
            }
        }
    }

    $scope.fnpostDomPartProvinc_SelectedIndexChanged = function (obj) {
        if (obj) {
            if (obj.nPrvId != null || obj.nPrvId != undefined) {
                var _param = {
                    pnPrvId: obj.nPrvId,
                    strOpcion: '3'
                }
                $scope.DomicPartic_distrito = [];
                preAPR_fnGetList('Maestro', 'fILCargarDistrito', _param, $scope.DomicPartic_distrito); //works
            }
        }
    }

    $scope.fnGrpoConocTec_SelectedIndexChanged = function (obj) {
        $scope.maestr_conocTec = [];
        if (obj != null) {
            var _param = {
                pnTpoTecnologia: obj.nMaeItem,
                pcOpcion: '01'
            }
            preAPR_fnGetList('Maestro', 'FILTecnologiaBL', _param, $scope.maestr_conocTec); //works
        }
    }

    function preAPR_fnGetList(controller, method, _param, _outList, _outObject) {
        ftyApiRequest._API_POST_REQUEST(controller, method, _param)
        .success(function (response) {
            //console.log(response);
            if (response.nMsjCode == 200) {
                if (_outList) {
                    $.each(response.DtCollection, function (key, val) {
                        _outList.push(val);
                    });
                }
                else if (_outObject) {
                    _outObject = response;
                }
            }
            else {
                console.error(msj);
                fnalert('warning', 'Aviso', 'Algo no salio bien.. Controller:' + controller + ', method:' + method, 4000);
            }
        })
        .error(function (msj) {
            console.error(msj);
            fnalert('warning', 'Aviso', 'Algo no salio bien.. Controller:' + controller + ', method:' + method, 4000);
        });
    }

    //  INICIA LOS MODALS 
    //INICIA  ESTUDIOS SUPERIORES
    $scope.fnPostulanteCollections_estSup_GTH = function (obj, _nOption) {


        console.log(obj);
        if (_nOption) {
            if (_nOption == 1)//show modal

            {
                // limpia inputs
                $scope.estudio = null; //clear ng-model
                $scope.fnPostulanteCollections_estSup_GTH(undefined, 99);
                fnShowModal('modalNewOrUpdate_carg_EstSup_GTH');

                $scope.mnt_Estsup_Option = 2;
                obj = null;
            }
            else if (_nOption == 2)//New
            {


                //VALIDAR INPUTS en campos obligatorios()...
                if (obj == undefined || obj.gradoEstudio == undefined || obj.centroEstudio == undefined || obj.tipoCentroEstud == undefined ||
                    obj.carrera == undefined || obj.periodoInicio_anio == undefined || obj.periodoInicio_mes == undefined || obj.periodoFin_anio == undefined || obj.periodoFin_mes == undefined || obj.condicion == undefined) {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                } if (obj == null || obj.gradoEstudio == null) {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                //VALIDAR INPUTS()...
                for (var i = 0; i < $scope.Postulante.Collections.EstudiosSuperiores.length; i++) {
                    if (obj.carrera.nEstId == $scope.Postulante.Collections.EstudiosSuperiores[i].pnEstId) {
                        fnalert('warning', 'Aviso', 'No puede haber dos carreras  iguales');
                        return;
                    }
                }

                console.log(obj);
                if (obj) {
                    console.log(obj);
                    console.log(obj.adjunto);
                    var _EstSup = {
                        pnTipoId: obj.gradoEstudio.nMaeItem
                        , pvTipo: obj.gradoEstudio.cMaeDesc

                        , pnCtrEstId: obj.centroEstudio.nCtrEstId
                        , pvCentroEstudio: obj.centroEstudio.vNombre

                        , pnTpoCtrEstId: obj.tipoCentroEstud.nMaeItem
                        , pvTpoCtrEst: obj.tipoCentroEstud.cMaeDenom

                        , pnEstId: obj.carrera.nEstId
                        , pvEstudio: obj.carrera.vDescripcion

                        , pvPrdInicio: obj.periodoInicio_anio.val + ' ' + obj.periodoInicio_mes.val
                        , pcPrdInicioDesc: obj.periodoInicio_anio.val + ' ' + obj.periodoInicio_mes.mes

                        , pvPrdFin: obj.periodoFin_anio.val + ' ' + obj.periodoFin_mes.val
                        , pcPrdFinDesc: obj.periodoFin_anio.val + ' ' + obj.periodoFin_mes.mes

                        , pnTpoGradoId: obj.condicion.nMaeItem
                        , pvTpoGrado: obj.condicion.cMaeDesc
                    }
                    console.log(_EstSup);
                    $scope.Postulante.Collections.EstudiosSuperiores.push(_EstSup)

                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "01");
                    }

                    $scope.estudio = null; //clear ng-model
                    $scope.fnPostulanteCollections_estSup_GTH(undefined, 99);//clear Inputs
                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.EstudiosSuperiores.indexOf(obj);
                $scope.Postulante.Collections.EstudiosSuperiores.splice(index, 1);
            }
            else if (_nOption == 4) {

                $scope.mnt_Estsup_Option = 4;
                fnShowModal('modalNewOrUpdate_carg_EstSup_GTH');

                var _EstSup = {
                    gradoEstudio: null
                    , carrera: null
                    , centroEstudio: null
                    , tipoCentroEstud: null
                    , condicion: null
                }

                for (var i = 0; i < $scope.maestr_carrera.length; i++) {
                    if (obj.pnEstId == $scope.maestr_carrera[i].nEstId) {
                        _EstSup.carrera = $scope.maestr_carrera[i]
                        break;
                    }
                }
                for (var i = 0; i < $scope.maestr_tipoEstudio.length; i++) {
                    if (obj.pnTipoId == $scope.maestr_tipoEstudio[i].nMaeItem) {
                        _EstSup.gradoEstudio = $scope.maestr_tipoEstudio[i]
                        break;
                    }
                }
                for (var i = 0; i < $scope.maestr_centroEstudio.length; i++) {
                    if (obj.pnCtrEstId == $scope.maestr_centroEstudio[i].nCtrEstId) {
                        _EstSup.centroEstudio = $scope.maestr_centroEstudio[i]
                        break;
                    }
                }
                for (var i = 0; i < $scope.maestr_tipoCentro.length; i++) {
                    if (obj.pnTpoCtrEstId == $scope.maestr_tipoCentro[i].nMaeItem) {
                        _EstSup.tipoCentroEstud = $scope.maestr_tipoCentro[i]
                        break;
                    }
                }

                $scope.estudio = _EstSup;

            }
            else if (_nOption == 5) {

                if (obj == undefined || obj.gradoEstudio == undefined || obj.centroEstudio == undefined || obj.tipoCentroEstud == undefined ||
                    obj.carrera == undefined || obj.periodoInicio_anio == undefined || obj.periodoInicio_mes == undefined || obj.periodoFin_anio == undefined || obj.periodoFin_mes == undefined || obj.condicion == undefined) {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                } if (obj == null || obj.gradoEstudio == null) {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                var _EstSup = {
                    pnTipoId: obj.gradoEstudio.nMaeItem
                        , pvTipo: obj.gradoEstudio.cMaeDesc

                        , pnCtrEstId: obj.centroEstudio.nCtrEstId
                        , pvCentroEstudio: obj.centroEstudio.vNombre

                        , pnTpoCtrEstId: obj.tipoCentroEstud.nMaeItem
                        , pvTpoCtrEst: obj.tipoCentroEstud.cMaeDenom

                        , pnEstId: obj.carrera.nEstId
                        , pvEstudio: obj.carrera.vDescripcion

                        , pvPrdInicio: obj.periodoInicio_anio.val + ' ' + obj.periodoInicio_mes.val
                        , pcPrdInicioDesc: obj.periodoInicio_anio.val + ' ' + obj.periodoInicio_mes.mes

                        , pvPrdFin: obj.periodoFin_anio.val + ' ' + obj.periodoFin_mes.val
                        , pcPrdFinDesc: obj.periodoFin_anio.val + ' ' + obj.periodoFin_mes.mes

                        , pnTpoGradoId: obj.condicion.nMaeItem
                        , pvTpoGrado: obj.condicion.cMaeDesc
                }



                for (var i = 0; i < $scope.Postulante.Collections.EstudiosSuperiores.length; i++) {
                    if (obj.carrera.nEstId == $scope.Postulante.Collections.EstudiosSuperiores[i].pnEstId) {
                        $scope.Postulante.Collections.EstudiosSuperiores[i] = _EstSup;

                    }
                }


            }
            else {
                $("#inpt_slc_cargEstSup_gradoEstudio").val('');
                $("#inpt_slc_cargEstSup_carrera").val('');
                $("#inpt_slc_cargEstSup_tipoCentro").val('');
                $("#inpt_slc_cargEstSup_centroEstudio").val('');
                $("#inpt_slc_cargEstSup_inicio").val('');
                $("#inpt_slc_cargEstSup_fin").val('');
            }
        }
    }

    //iNICIA CONOCIMIENTOS TECNICOS
    $scope.fnPostulanteCollections_conocTecnic_GTH = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1)//show modal
            {
                $scope.conocimiento = null; //CLEAR ng-model
                $scope.fnPostulanteCollections_conocTecnic_GTH(undefined, 99);
                fnShowModal('modalNewOrUpdate_carg_ConTecnicos_GTH');

                $scope.mnt_Contec_Option = 2;
                obj = null;

            }
            else if (_nOption == 2)//New
            {
                //valida campos obligatorios
                if (obj == undefined || obj.grupo == undefined || obj.conocimiento == undefined || obj.nivel == undefined) {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                //VALIDAR INPUTS...
                for (var i = 0; i < $scope.Postulante.Collections.ConocTecnicos.length; i++) {
                    if (obj.conocimiento.nTcnId == $scope.Postulante.Collections.ConocTecnicos[i].pnTcnId) {
                        fnalert('warning', 'Aviso', 'No puede haber dos programas  iguales');
                        return;
                    }
                }

                if (obj) {
                    //console.log(obj);
                    var _conocimiento = {
                        pnTpoTecnologiaId: obj.grupo.nMaeItem
                        , pvTpoTecnologia: obj.grupo.cMaeDenom

                        , pnTcnId: obj.conocimiento.nTcnId
                        , pvTecnologia: obj.conocimiento.vDescripcion

                        , pnNivelId: obj.nivel.nMaeItem
                        , pvNivel: obj.nivel.cMaeDenom
                    }

                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.ConocTecnicos, _conocimiento);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'No puede haber dos programas iguales');
                        return;
                    }
                    //console.log(_conocimiento);
                    $scope.Postulante.Collections.ConocTecnicos.push(_conocimiento)

                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "03");
                    }

                    $scope.conocimiento = null; //CLEAR ng-model
                    $scope.fnPostulanteCollections_conocTecnic_GTH(undefined, 99);//CLEAR Inputs
                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.ConocTecnicos.indexOf(obj);
                $scope.Postulante.Collections.ConocTecnicos.splice(index, 1);
            }
            else if (_nOption == 4)//titulos
            {
                $scope.mnt_Contec_Option = 4;
                _conocimiento = {
                    grupo: null
                    , conocimiento: null
                    , nivel: null
                }
                fnShowModal('modalNewOrUpdate_carg_ConTecnicos_GTH');

                for (var i = 0; i < $scope.maestr_grpoConocTec.length; i++) {
                    if (obj.pnTpoTecnologiaId == $scope.maestr_grpoConocTec[i].nMaeItem) {
                        _conocimiento.grupo = $scope.maestr_grpoConocTec[i]
                        break;
                    }
                }
                for (var i = 0; i < $scope.maestr_conocTec.length; i++) {
                    if (obj.pnTcnId == $scope.maestr_conocTec[i].nTcnId) {
                        _conocimiento.conocimiento = $scope.maestr_conocTec[i]
                        break;
                    }
                }
                for (var i = 0; i < $scope.maestr_conoc_nivel.length; i++) {
                    if (obj.pnNivelId == $scope.maestr_conoc_nivel[i].nMaeItem) {
                        _conocimiento.nivel = $scope.maestr_conoc_nivel[i]
                        break;
                    }
                }

                $scope.conocimiento = _conocimiento;
            }
            else if (_nOption == 5)//edita
            {
                //valida campos obligatorios
                if (obj == undefined || obj.grupo == undefined || obj.conocimiento == undefined || obj.nivel == undefined) {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                var _conocimiento = {
                    pnTpoTecnologiaId: obj.grupo.nMaeItem
                        , pvTpoTecnologia: obj.grupo.cMaeDenom

                        , pnTcnId: obj.conocimiento.nTcnId
                        , pvTecnologia: obj.conocimiento.vDescripcion

                        , pnNivelId: obj.nivel.nMaeItem
                        , pvNivel: obj.nivel.cMaeDenom
                }
                for (var i = 0; i < $scope.Postulante.Collections.ConocTecnicos.length; i++) {

                    if (obj.conocimiento.nTcnId == $scope.Postulante.Collections.ConocTecnicos[i].pnTcnId) {
                        $scope.Postulante.Collections.ConocTecnicos[i] = _conocimiento
                    }
                }
            }
            else {
                $("#inpt_slc_cargcon_grupo").val('');
                $("#txt_cargcon_conocimiento").val('');
                $("#inpt_slc_cargcon_nivel").val('');
            }
        }
    }

    //INICIA CERTIFICACION
    $scope.fnPostulanteCollections_CertifObt_GTH = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1)//shw modal
            {
                $scope.certificacion = null;
                $scope.fnPostulanteCollections_CertifObt_GTH(undefined, 99);
                fnShowModal('modalNewOrUpdate_carg_certificacion_GTH');

                $scope.mnt_Cert_Option = 2;
                obj = null;

            }
            else if (_nOption == 2)//New
            {
                //NO SE CUAL CAMPO DEBE SER UNICO
                for (var i = 0; i < $scope.Postulante.Collections.Certificaciones.length; i++) {
                    if (obj.curso == $scope.Postulante.Collections.Certificaciones[i].cCursoNombr) {
                        fnalert('warning', 'Aviso', 'No puede haber dos Cursos iguales');
                        return;
                    }
                }
                //VALIDAR INPUTS()...
                if (obj == undefined || obj.curso == undefined || obj.centestudio == undefined || obj.certobtenida == undefined || obj.duracion == undefined || obj.year == undefined ||
                     obj.curso == '' || obj.centestudio == '' || obj.year == '' || obj.duracion == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }


                if (obj) {
                    var _certificacion = {
                        cCursoNombr: obj.curso
                        , cCentrEstud: obj.centestudio

                        , nNivCertifObtenidoID: obj.certobtenida.id
                        , cNivCertifObtenido: obj.certobtenida.nombre

                        , cDuracion: obj.duracion
                        , nAnioCertif: obj.year


                    }
                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.Certificaciones, _certificacion);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'No puede haber dos Cursos iguales');
                        return;
                    }
                    //console.log(_certificacion);
                    $scope.Postulante.Collections.Certificaciones.push(_certificacion)
                    //CLEAR INPUTS FORM...

                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "02");
                    }

                    $scope.certificacion = null;
                    $scope.fnPostulanteCollections_CertifObt_GTH(undefined, 99);
                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.Certificaciones.indexOf(obj);
                $scope.Postulante.Collections.Certificaciones.splice(index, 1);
            }
            else if (_nOption == 4)//TITULOS
            {
                $scope.mnt_Cert_Option = 4;
                fnShowModal('modalNewOrUpdate_carg_certificacion_GTH');
                var _certificacion = {
                    curso: obj.cCursoNombr
                    , centestudio: obj.cCentrEstud
                    , certobtenida: null
                    , duracion: obj.cDuracion
                    , year: obj.nAnioCertif


                }



                for (var i = 0; i < $scope.mstr_certobtenida.length; i++) {
                    if (obj.nNivCertifObtenidoID == $scope.mstr_certobtenida[i].id) {
                        _certificacion.certobtenida = $scope.mstr_certobtenida[i]
                        break;
                    }
                }

                $scope.certificacion = _certificacion;

            }
            else if (_nOption == 5)//Edita
            {
                //VALIDAR INPUTS()...
                if (obj == undefined || obj.curso == undefined || obj.centestudio == undefined || obj.certobtenida == undefined || obj.duracion == undefined || obj.year == undefined ||
                     obj.curso == '' || obj.centestudio == '' || obj.year == '' || obj.duracion == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                var _certificacion = {
                    cCursoNombr: obj.curso
                        , cCentrEstud: obj.centestudio

                        , nNivCertifObtenidoID: obj.certobtenida.id
                        , cNivCertifObtenido: obj.certobtenida.nombre

                        , cDuracion: obj.duracion
                        , nAnioCertif: obj.year


                }
                for (var i = 0; i < $scope.Postulante.Collections.Certificaciones.length; i++) {
                    if (obj.curso == $scope.Postulante.Collections.Certificaciones[i].cCursoNombr) {
                        $scope.Postulante.Collections.Certificaciones[i] = _certificacion;
                    }
                }
            }
            else {
                $("#txt_cargcert_curso").val('');
                $("#txt_cargcert_centestudio").val('');
                $("#inpt_slc_cargcert_obtenida").val('');
                $("#txt_cargcert_duracion").val('');
                $("#txt_cargcert_year").val('');
                $("#file_crgcert_adjunto").val('');

            }
        }
    }

    // EXPERIENCIA LABORAL
    $scope.fnPostulanteCollections_expLaboral_GTH = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1)//show modal
            {
                $scope.explaboral = null; //clear ng-model
                $scope.fnPostulanteCollections_expLaboral_GTH(undefined, 99);
                fnShowModal('modalNewOrUpdate_carg_explaboral_GTH');

                $scope.mnt_ExpLab_option = 2;
                obj = null;

            }
            else if (_nOption == 2)//New
            {
                //VALIDAR INPUTS obligatorios
                if (obj == undefined || obj.empresa == undefined || obj.puesto == undefined || obj.herramienta == undefined ||
                    obj.sueldo == undefined || obj.contrato == undefined || obj.retiro == undefined || obj.periodoInicio_anio == undefined ||
                    obj.periodoInicio_mes == undefined || obj.periodoFin_anio == undefined || obj.periodoFin_mes == undefined ||
                    obj.empresa == '' || obj.puesto == '' || obj.herramienta == '' || obj.sueldo == '' ||
                    obj.retiro == '' || obj.periodoInicio_anio == '' || obj.periodoFin_anio == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                //VALIDAR INPUTS...
                for (var i = 0; i < $scope.Postulante.Collections.ExpLaborales.length; i++) {
                    if (obj.empresa == $scope.Postulante.Collections.ExpLaborales[i].pvEmpresa) {
                        fnalert('warning', 'Aviso', 'ya existe esta empresa');
                        return;
                    }
                }

                if (obj) {
                    //console.log(obj)
                    var _explaboral = {
                        pvEmpresa: obj.empresa
                        , pvPuesto: obj.puesto
                        , pcHerramientaUsada: obj.herramienta /**/
                        , pnSueldo: obj.sueldo

                        , pnTipoContratoID: obj.contrato.nMaeItem
                        , pcTipoContrato: obj.contrato.cMaeDenom

                        , pvMtvCese: obj.retiro
                        , pcFchInicio: obj.periodoInicio_anio.anio + '-' + obj.periodoInicio_mes.val
                        , pcFchInicioDesc: obj.periodoInicio_anio.anio + '-' + obj.periodoInicio_mes.mes
                        //, pcFchInicio_parsed: new Date(obj.periodoInicio_anio.anio, obj.periodoInicio_mes.val, 1) /* <<<< ==========*/
                        , pcFchInicio_parsed: $filter('date')(new Date(obj.periodoInicio_anio.anio, obj.periodoInicio_mes.val, 1), "dd-MM-yyyy")  /* <<<< ==========*/

                        , pcFchFin: obj.periodoFin_anio.anio + '-' + obj.periodoFin_mes.val
                        , pcFchFinDesc: obj.periodoFin_anio.anio + '-' + obj.periodoFin_mes.mes
                        //, pcFchFin_parsed: new Date(obj.periodoFin_anio.anio, obj.periodoFin_mes.val, 1) /* <<<< ==========*/
                        , pcFchFin_parsed: $filter('date')(new Date(obj.periodoFin_anio.anio, obj.periodoFin_mes.val, 1), "dd-MM-yyyy")  /* <<<< ==========*/

                    }


                    // _explaboral.pcFchInicio_parsed = $filter('date')(_explaboral.pcFchInicio_parsed, "dd-MM-yyyy") /*!important */
                    //_explaboral.pcFchFin_parsed = $filter('date')(_explaboral.pcFchFin_parsed, "dd-MM-yyyy") /*!important */

                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.ExpLaborales, _explaboral);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'No puede haber dos Cursos iguales');
                        return;
                    }

                    console.log(_explaboral);
                    $scope.Postulante.Collections.ExpLaborales.push(_explaboral)


                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "05");
                    }
                    $scope.explaboral = null; //clear ng-model
                    $scope.fnPostulanteCollections_expLaboral_GTH(undefined, 99);//clear inputs form
                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.ExpLaborales.indexOf(obj);
                $scope.Postulante.Collections.ExpLaborales.splice(index, 1);
            }
            else if (_nOption == 4)//Titulos y botones
            {
                $scope.mnt_ExpLab_option = 4;
                fnShowModal('modalNewOrUpdate_carg_explaboral_GTH');

                var _explaboral = {
                    empresa: obj.pvEmpresa
                    , puesto: obj.pvPuesto
                    , herramienta: obj.pcHerramientaUsada
                    , sueldo: obj.pnSueldo
                    , contrato: null
                    , retiro: obj.pvMtvCese
                }

                for (var i = 0; i < $scope.maestr_tpo_contrato.length; i++) {
                    if (obj.pnTipoContratoID == $scope.maestr_tpo_contrato[i].nMaeItem) {
                        _explaboral.contrato = $scope.maestr_tpo_contrato[i]
                    }
                }
                $scope.explaboral = _explaboral;

            }
            else if (_nOption == 5)//Editar
            {
                if (obj == undefined || obj.empresa == undefined || obj.puesto == undefined || obj.herramienta == undefined ||
                   obj.sueldo == undefined || obj.contrato == undefined || obj.retiro == undefined || obj.periodoInicio_anio == undefined ||
                   obj.periodoInicio_mes == undefined || obj.periodoFin_anio == undefined || obj.periodoFin_mes == undefined ||
                   obj.empresa == '' || obj.puesto == '' || obj.herramienta == '' || obj.sueldo == '' ||
                   obj.retiro == '' || obj.periodoInicio_anio == '' || obj.periodoFin_anio == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                var _explaboral = {
                    pvEmpresa: obj.empresa
                        , pvPuesto: obj.puesto
                        , pcHerramientaUsada: obj.herramienta /**/
                        , pnSueldo: obj.sueldo

                        , pnTipoContratoID: obj.contrato.nMaeItem
                        , pcTipoContrato: obj.contrato.cMaeDenom

                        , pvMtvCese: obj.retiro
                        , pcFchInicio: obj.periodoInicio_anio.anio + '-' + obj.periodoInicio_mes.val
                        , pcFchInicioDesc: obj.periodoInicio_anio.anio + '-' + obj.periodoInicio_mes.mes
                    //, pcFchInicio_parsed: new Date(obj.periodoInicio_anio.anio, obj.periodoInicio_mes.val, 1) /* <<<< ==========*/
                        , pcFchInicio_parsed: new Date(obj.periodoInicio_anio.anio, obj.periodoInicio_mes.val, 1) /* <<<< ==========*/

                        , pcFchFin: obj.periodoFin_anio.anio + '-' + obj.periodoFin_mes.val
                        , pcFchFinDesc: obj.periodoFin_anio.anio + '-' + obj.periodoFin_mes.mes
                    //, pcFchFin_parsed: new Date(obj.periodoFin_anio.anio, obj.periodoFin_mes.val, 1) /* <<<< ==========*/
                        , pcFchFin_parsed: new Date(obj.periodoFin_anio.anio, obj.periodoFin_mes.val, 1) /* <<<< ==========*/

                }


                // _explaboral.pcFchInicio_parsed = $filter('date')(_explaboral.pcFchInicio_parsed, "dd-MM-yyyy") /*!important */
                //_explaboral.pcFchFin_parsed = $filter('date')(_explaboral.pcFchFin_parsed, "dd-MM-yyyy") /*!important */

                for (var i = 0; i < $scope.Postulante.Collections.ExpLaborales.length; i++) {
                    if (obj.empresa == $scope.Postulante.Collections.ExpLaborales[i].pvEmpresa) {
                        $scope.Postulante.Collections.ExpLaborales[i] = _explaboral
                    }
                }
            }
            else {
                $("#txt_cargexplab_empresa").val('');
                $("#txt_cargexplab_puesto").val('');
                $("#txt_cargexplab_herramienta").val('');
                $("#txt_cargexplab_sueldo").val('');
                $("#inpt_slc_cargexplab_contrato").val('');
                $("#txt_cargexplab_retiro").val('');
                $("#dt_cargexplab_finicial").val('');
                $("#dt_cargexplab_ffinal").val('');
            }
        }
    }

    // referencia laboral
    $scope.fnPostulanteCollections_refLaboral_GTH = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1) {

                $scope.referenciaLab = null; //clear ng-model
                $scope.fnPostulanteCollections_refLaboral_GTH(undefined, 99);
                fnShowModal('modalNewOrUpdate_carg_referenciaLab_GTH');

                $scope.mnt_RefLab_Option = 2;
                obj = null;

            }
            if (_nOption == 2)//New
            {
                //VALIDAR INPUTS...
                if (obj == undefined || obj.empresa == undefined || obj.representante == undefined || obj.cargo == undefined || obj.telefono == undefined ||
                     obj.empresa == '' || obj.representante == '' || obj.cargo == '' || obj.telefono == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                //VALIDAR INPUTS...
                for (var i = 0; i < $scope.Postulante.Collections.RefLaborales.length; i++) {
                    if (obj.representante == $scope.Postulante.Collections.RefLaborales[i].pcNombrRepresentante
                        || obj.empresa == $scope.Postulante.Collections.RefLaborales[i].pvEmpresa) {
                        fnalert('warning', 'Aviso', 'ya Existe el Representante y/o la empresa');
                        return;
                    }
                }
                if (obj) {
                    var _referencia = {
                        //pnTipoRef: obj.tipo.nMaeItem
                        pnTipoRef: 1  /*<<<<<<<<===============*/
                        , pvTipoRef: 'LABORAL', /*<<<<<<<<===============*/
                        pvEmpresa: obj.empresa
                        , pcNombrRepresentante: obj.representante
                        , pcCargoRepresentante: obj.cargo
                        , pcTelefRepresentante: obj.telefono
                    }
                    //console.log(_referencia);
                    $scope.Postulante.Collections.RefLaborales.push(_referencia);

                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "06");
                    }
                    $scope.referenciaLab = null; //clear ng-model
                    $scope.fnPostulanteCollections_refLaboral_GTH(undefined, 99);//clear inputs
                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.RefLaborales.indexOf(obj);
                $scope.Postulante.Collections.RefLaborales.splice(index, 1);
            }
            else if (_nOption == 4)//remove
            {
                $scope.mnt_RefLab_Option = 4;
                fnShowModal('modalNewOrUpdate_carg_referenciaLab_GTH');

                var _referencia = {
                    empresa: obj.pvEmpresa
                    , representante: obj.pcNombrRepresentante
                    , cargo: obj.pcCargoRepresentante
                    , telefono: obj.pcTelefRepresentante
                }

                $scope.referenciaLab = _referencia;
            }
            else if (_nOption == 5)//remove
            {
                //VALIDAR INPUTS...
                if (obj == undefined || obj.empresa == undefined || obj.representante == undefined || obj.cargo == undefined || obj.telefono == undefined ||
                     obj.empresa == '' || obj.representante == '' || obj.cargo == '' || obj.telefono == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                var _referencia = {
                    //pnTipoRef: obj.tipo.nMaeItem
                    pnTipoRef: 1  /*<<<<<<<<===============*/
                       , pvTipoRef: 'LABORAL', /*<<<<<<<<===============*/
                    pvEmpresa: obj.empresa
                       , pcNombrRepresentante: obj.representante
                       , pcCargoRepresentante: obj.cargo
                       , pcTelefRepresentante: obj.telefono
                }
                for (var i = 0; i < $scope.Postulante.Collections.RefLaborales.length; i++) {
                    if (obj.representante == $scope.Postulante.Collections.RefLaborales[i].pcNombrRepresentante) {
                        $scope.Postulante.Collections.RefLaborales[i] = _referencia
                    }
                }
            }
            else {
                //$("#inpt_slc_cargref_tipo").val('');
                $("#txt_cargrefLab_representante").val('');
                $("#txt_cargrefLab_cargo").val('');
                $("#txt_cargrefLab_empresa").val('');
                $("#txt_cargrefLab_telefono").val('');
            }
        }
    }

    //DEUDAS FINANCIERAS
    $scope.fnPostulanteCollections_deudas_GTH = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1) {
                $scope.deuda = null; //clear ng-model
                $scope.fnPostulanteCollections_deudas_GTH(undefined, 99);   //CLEAR INPUTS FORM...
                fnShowModal('modalNewOrUpdate_carg_deuda_GTH');

                $scope.mnt_deudas_opcion = 2;
                obj = null;

            }
            if (_nOption == 2)//New
            {
                //VALIDAR INPUTS obligatorios
                if (obj == undefined || obj.empresa == undefined || obj.fecha == undefined || obj.motivRegistro == undefined ||
                    obj.monto == undefined || obj.deudaActual == undefined ||
                    obj.empresa == '' || obj.fecha == '' || obj.motivRegistro == '' || obj.monto == '' || obj.deudaActual == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                if ($('input[name="rdo_deuda_actual"]').is(':checked') && obj.deudaActual == 'SI') {

                    if (obj.fechaLevantamnto == undefined || obj.fechaLevantamnto == '') {
                        fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                        return false;
                    }

                }
                if (obj) {
                    //VALIDAR INPUTS...
                    for (var i = 0; i < $scope.Postulante.Collections.Deudas.length; i++) {
                        if (obj.motivRegistro == $scope.Postulante.Collections.Deudas[i].pvMotivoRegistro) {
                            fnalert('warning', 'Aviso', 'El motivo ya exite');
                            return;
                        }
                    }
                    //console.log(obj)
                    var _deuda = {
                        pvEmpresa: obj.empresa
                        , pdtFchRegistro: $filter('date')(obj.fecha, "MM-dd-yyyy") /*!important */
                        , pvMotivoRegistro: obj.motivRegistro
                        , pnMontoDeuda: obj.monto
                        , pcDeudaActual: obj.deudaActual
                        , pdtFchLevantamiento: $filter('date')(obj.fechaLevantamnto, "MM-dd-yyyy") /*!important */

                    }
                    //console.log(_deuda);
                    $scope.Postulante.Collections.Deudas.push(_deuda)

                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "08");
                    }

                    $scope.deuda = null; //clear ng-model
                    $scope.fnPostulanteCollections_deudas_GTH(undefined, 99);   //CLEAR INPUTS FORM...

                }
            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.Deudas.indexOf(obj);
                $scope.Postulante.Collections.Deudas.splice(index, 1);
            }
            else if (_nOption == 4)//Titulos y botones
            {

                var _deuda = {
                    empresa: obj.pvEmpresa
                    , fecha: $filter('date')(obj.fecha, "MM-dd-yyyy")
                    , motivRegistro: obj.pvMotivoRegistro
                    , monto: obj.pnMontoDeuda
                    , deudaActual: obj.pcDeudaActual
                    , fechaLevantamnto: $filter('date')(obj.pdtFchLevantamiento, "MM-dd-yyyy")
                }
                fnShowModal('modalNewOrUpdate_carg_deuda_GTH');

                $scope.mnt_deudas_opcion = 4;
                $scope.deuda = _deuda;
            }
            else if (_nOption == 5)//Editar
            {
                //VALIDAR INPUTS obligatorios
                if (obj == undefined || obj.empresa == undefined || obj.fecha == undefined || obj.motivRegistro == undefined ||
                    obj.monto == undefined || obj.deudaActual == undefined ||
                    obj.empresa == '' || obj.fecha == '' || obj.motivRegistro == '' || obj.monto == '' || obj.deudaActual == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                if ($('input[name="rdo_deuda_actual"]').is(':checked') && obj.deudaActual == 'SI') {

                    if (obj.fechaLevantamnto == undefined || obj.fechaLevantamnto == '') {
                        fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                        return false;
                    }

                }
                var _deuda = {
                    pvEmpresa: obj.empresa
                        , pdtFchRegistro: $filter('date')(obj.fecha, "MM-dd-yyyy") /*!important */
                        , pvMotivoRegistro: obj.motivRegistro
                        , pnMontoDeuda: obj.monto
                        , pcDeudaActual: obj.deudaActual
                        , pdtFchLevantamiento: $filter('date')(obj.fechaLevantamnto, "MM-dd-yyyy") /*!important */

                }
                for (var i = 0; i < $scope.Postulante.Collections.Deudas.length; i++) {
                    if (obj.motivRegistro == $scope.Postulante.Collections.Deudas[i].pvMotivoRegistro) {
                        $scope.Postulante.Collections.Deudas[i] = _deuda
                        return;
                    }
                }
            }
            else {
                $("#txt_cargdeu_fregistro").val('');
                $("#txt_cardeu_empresa").val('');
                $("#txt_cardeu_motivo").val('');
                $("#txt_cargdeu_monto").val('');
            }
        }
    }

    //PENALES
    $scope.fnPostulanteCollections_antPenales_GTH = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1)//New
            {
                $scope.antecedente = null; //clear ng-model
                $scope.fnPostulanteCollections_antPenales_GTH(undefined, 99);  //clear inputs form
                fnShowModal('modalNewOrUpdate_carg_antecedente_GTH');

                $scope.mnt_AntPenales_opcion = 2;
                obj = null;

            }
            else if (_nOption == 2)//New
            {
                //VALIDAR INPUTS CAompos obligatorios
                if (obj == undefined || obj.fecha == undefined || obj.motivo == undefined || obj.resultado == undefined ||
                    obj.motivo == '' || obj.resultado == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                //VALIDAR INPUTS...
                for (var i = 0; i < $scope.Postulante.Collections.AntPenales.length; i++) {
                    if (obj.motivo == $scope.Postulante.Collections.AntPenales[i].pvMotivo) {
                        fnalert('warning', 'Aviso', 'motivo ya existente');
                        return;
                    }
                }
                console.log(obj)
                if (obj) {

                    var _antecedente = {

                        pcFchProceso: $filter('date')(obj.fecha, "MM-dd-yyyy")
                        , pnTipoAnt: 1
                        , pcTipoAnt: "PENALES"
                        , pvMotivo: obj.motivo
                        , pvResultado: obj.resultado

                    }
                    console.log(_antecedente);
                    $scope.Postulante.Collections.AntPenales.push(_antecedente)

                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "09");
                    }

                    $scope.antecedente = null; //clear ng-model
                    $scope.fnPostulanteCollections_antPenales_GTH(undefined, 99);  //clear inputs form

                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.AntPenales.indexOf(obj);
                $scope.Postulante.Collections.AntPenales.splice(index, 1);
            }
            else if (_nOption == 4)//Titulos y botones
            {
                var _newObj = {
                    fecha: $filter('date')(obj.pcFchProceso, "MM-dd-yyyy") // NO MUESTRA SU VALOR AL EDITAR
                    , motivo: obj.pvMotivo
                    , resultado: obj.pvResultado
                }
                fnShowModal('modalNewOrUpdate_carg_antecedente_GTH');

                $scope.mnt_AntPenales_opcion = 4;
                $scope.antecedente = _newObj
            }
            else if (_nOption == 5)//Editar
            {
                //VALIDAR INPUTS CAompos obligatorios
                if (obj == undefined || obj.fecha == undefined || obj.motivo == undefined || obj.resultado == undefined ||
                    obj.motivo == '' || obj.resultado == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                var _newObj = {
                    pcFchProceso: $filter('date')(obj.fecha, "MM-dd-yyyy")
                        , pvMotivo: obj.motivo
                        , pvResultado: obj.resultado

                }
                for (var i = 0; i < $scope.Postulante.Collections.AntPenales.length; i++) {
                    if (obj.motivo == $scope.Postulante.Collections.AntPenales[i].pvMotivo) {
                        $scope.Postulante.Collections.AntPenales[i] = _newObj
                        return;
                    }
                }
            }
            else {
                $("#txt_cargant_fecha").val('');
                $("#txt_carant_motivo").val('');
                $("#txt_cargant_resultado").val('');
            }
        }
    }

    //POLICIAL
    $scope.fnPostulanteCollections_antPoliciales_GTH = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1)//New
            {
                $scope.antecedente = null; //clear ng-model
                $scope.fnPostulanteCollections_antPoliciales_GTH(undefined, 99);  //clear inputs form
                fnShowModal('modalNewOrUpdate_carg_antecedentePolicial_GTH');

                $scope.mnt_AntPolicial_opcion = 2;
                obj = null;

            }
            else if (_nOption == 2)//New
            {
                //VALIDAR INPUTS CAompos obligatorios
                if (obj == undefined || obj.fecha == undefined || obj.motivo == undefined || obj.resultado == undefined ||
                    obj.motivo == '' || obj.resultado == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                //VALIDAR INPUTS...
                for (var i = 0; i < $scope.Postulante.Collections.AntPolicial.length; i++) {
                    if (obj.motivo == $scope.Postulante.Collections.AntPolicial[i].pvMotivo) {
                        fnalert('warning', 'Aviso', 'motivo ya existente');
                        return;
                    }
                }
                console.log(obj)
                if (obj) {
                    console.log(obj);
                    var _antePolicial = {
                        pcFchProceso: $filter('date')(obj.fecha, "MM-dd-yyyy")
                        , pnTipoAnt: 2
                        , pcTipoAnt: "POLICIAL"
                        , pvMotivo: obj.motivo
                        , pvResultado: obj.resultado

                    }
                    console.log(_antePolicial);
                    $scope.Postulante.Collections.AntPolicial.push(_antePolicial)

                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "09");
                    }

                    $scope.antecedente = null; //clear ng-model
                    $scope.fnPostulanteCollections_antPoliciales_GTH(undefined, 99);  //clear inputs form

                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.AntPolicial.indexOf(obj);
                $scope.Postulante.Collections.AntPolicial.splice(index, 1);
            }
            else if (_nOption == 4)//Titulos y botones
            {
                var _antePolicial = {
                    fecha: $filter('date')(obj.pcFchProceso, "MM-dd--yyyy")
                    , motivo: obj.pvMotivo
                    , resultado: obj.pvResultado
                }
                $scope.mnt_AntPolicial_opcion = 4;
                fnShowModal('modalNewOrUpdate_carg_antecedentePolicial_GTH');

                $scope.antepolicial = _antePolicial;
            }
            else if (_nOption == 5)//Editar
            {
                //VALIDAR INPUTS CAompos obligatorios
                if (obj == undefined || obj.fecha == undefined || obj.motivo == undefined || obj.resultado == undefined ||
                    obj.motivo == '' || obj.resultado == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                var _antePolicial = {
                    pcFchProceso: $filter('date')(obj.fecha, "MM-dd-yyyy")
                        , pvMotivo: obj.motivo
                        , pvResultado: obj.resultado

                }
                for (var i = 0; i < $scope.Postulante.Collections.AntPolicial.length; i++) {
                    if (obj.motivo == $scope.Postulante.Collections.AntPolicial[i].pvMotivo) {
                        $scope.Postulante.Collections.AntPolicial[i] = _antePolicial
                        return;
                    }
                }
            }
            else {
                $("#txt_cargant_fecha").val('');
                $("#txt_carant_motivo").val('');
                $("#txt_cargant_resultado").val('');
            }
        }
    }

    //ENFERMEDADES
    $scope.fnPostulanteCollections_enfermedds_GTH = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1) {

                $scope.enfermedad = null; //clear ng-model
                $scope.fnPostulanteCollections_enfermedds_GTH(undefined, 99); //clear inputs form
                fnShowModal('modalNewOrUpdate_carg_enfermedad_GTH');

                $scope.mnt_enfermeda_Option = 2;
                obj = null;

            }
            else if (_nOption == 2)//New
            {
                //VALIDAR INPUTS campos obligatorios
                if (obj == undefined || obj.tratamiento == undefined || obj.instituto == undefined || obj.preexistencia == undefined || obj.year == undefined ||
                    obj.tratamiento == '' || obj.instituto == '' || obj.preexistencia == '' || obj.year == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                //VALIDAR INPUTS...
                for (var i = 0; i < $scope.Postulante.Collections.Enfermedades.length; i++) {
                    if (obj.tratamiento == $scope.Postulante.Collections.Enfermedades[i].pcTratmnto_enfermd) {
                        fnalert('warning', 'Aviso', 'no puede haber enfermedad duplicada');
                        return;
                    }
                }

                //console.log(obj)
                if (obj) {
                    var _enfermedad = {
                        pcTratmnto_enfermd: obj.tratamiento
                    , pcInstituto: obj.instituto
                    , pcTiempoPreexistencia: obj.preexistencia
                    , pnAnioInicio: obj.year

                    }
                    //console.log(_enfermedad);
                    $scope.Postulante.Collections.Enfermedades.push(_enfermedad)

                    if (obj.adjunto) {
                        agregarListadoDeArchivos(obj.adjunto, "10");
                    }

                    $scope.enfermedad = null; //clear ng-model
                    $scope.fnPostulanteCollections_enfermedds_GTH(undefined, 99); //clear inputs form
                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.Enfermedades.indexOf(obj);
                $scope.Postulante.Collections.Enfermedades.splice(index, 1);
            }
            else if (_nOption == 4)//remove
            {
                $scope.mnt_enfermeda_Option = 4;
                fnShowModal('modalNewOrUpdate_carg_enfermedad_GTH');

                var _enfermedad = {
                    tratamiento: obj.pcTratmnto_enfermd
                    , instituto: obj.pcInstituto
                    , preexistencia: obj.pcTiempoPreexistencia
                    , year: obj.pnAnioInicio
                }

                $scope.enfermedad = _enfermedad;
            }
            else if (_nOption == 5)//remove
            {
                //VALIDAR INPUTS campos obligatorios
                if (obj == undefined || obj.tratamiento == undefined || obj.instituto == undefined || obj.preexistencia == undefined || obj.year == undefined ||
                    obj.tratamiento == '' || obj.instituto == '' || obj.preexistencia == '' || obj.year == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                var _enfermedad = {
                    pcTratmnto_enfermd: obj.tratamiento
                      , pcInstituto: obj.instituto
                      , pcTiempoPreexistencia: obj.preexistencia
                      , pnAnioInicio: obj.year

                }

                for (var i = 0; i < $scope.Postulante.Collections.Enfermedades.length; i++) {
                    if (obj.tratamiento == $scope.Postulante.Collections.Enfermedades[i].pcTratmnto_enfermd) {
                        $scope.Postulante.Collections.Enfermedades[i] = _enfermedad
                    }
                }
            }
            else {
                $("#txt_cargenf_trat").val('');
                $("#txt_carenf_instituto").val('');
                $("#txt_carenf_preexistencia").val('');
                $("#txt_cargenf_year").val('');
            }
        }
    }

    // HOBBIES
    $scope.fnPostulanteCollections_hobbies_GTH = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1) {
                $scope.hobbie = null;

                $scope.fnPostulanteCollections_hobbies_GTH(undefined, 99)

                fnShowModal('modalNewOrUpdate_Hobbies_GTH');

                $scope.mnt_hobbie_Option = 2;
                obj = null;

            }
            else if (_nOption == 2)//New
            {
                //validar inputs
                if (obj == undefined || obj.frecuencia == undefined || obj.nivel == undefined || obj.hobbie == undefined) {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }

                //validar que el pasa tiempo no se repita
                for (var i = 0; i < $scope.Postulante.Collections.Hobbies.length; i++) {
                    if (obj.hobbie.nMaeItem == $scope.Postulante.Collections.Hobbies[i].pnHobbieId) {
                        fnalert('warning', 'Aviso', 'no puede haber pasa-tiempos duplicados');
                        return;
                    }
                }
                if (obj) {

                    var _obj = {
                        pnHobbieId: obj.hobbie.nMaeItem
                        , pvHobbie: obj.hobbie.cMaeDenom

                         , pnFrecuenciaId: obj.frecuencia.nMaeItem
                         , pvFrecuencia: obj.frecuencia.cMaeDenom

                         , pnNivelId: obj.nivel.nMaeItem
                         , pvNivel: obj.nivel.cMaeDenom
                    };
                    //console.log(obj);
                    $scope.Postulante.Collections.Hobbies.push(_obj);
                    //console.log($scope.Postulante.Collections.Hobbies);
                    //clean inputs
                    $scope.hobbie = null;

                    $scope.fnPostulanteCollections_hobbies_GTH(undefined, 99)
                }

            }
            else if (_nOption == 3)//remove
            {

                var index = $scope.Postulante.Collections.Hobbies.indexOf(obj);
                $scope.Postulante.Collections.Hobbies.splice(index, 1);
            }
            else if (_nOption == 4)//remove
            {
                $scope.mnt_hobbie_Option = 4;
                fnShowModal('modalNewOrUpdate_Hobbies_GTH');
                var _obj = {
                    hobbie: null
                    , frecuencia: null
                    , nivel: null
                }
                for (var i = 0; i < $scope.maestr_hobbies.length; i++) {
                    if (obj.pnFrecuenciaId == $scope.maestr_hobbies[i].nMaeItem) {
                        _obj.hobbie = $scope.maestr_hobbies[i]
                    }
                }
                for (var i = 0; i < $scope.maestr_frecuencia.length; i++) {
                    if (obj.pnHobbieId == $scope.maestr_frecuencia[i].nMaeItem) {
                        _obj.frecuencia = $scope.maestr_frecuencia[i]
                    }
                }
                for (var i = 0; i < $scope.maestr_conoc_nivel.length; i++) {
                    if (obj.pnNivelId == $scope.maestr_conoc_nivel[i].nMaeItem) {
                        _obj.nivel = $scope.maestr_conoc_nivel[i]
                    }
                }

                $scope.hobbie = _obj;
            }
            else if (_nOption == 5)//remove
            {
                //validar inputs
                if (obj == undefined || obj.frecuencia == undefined || obj.nivel == undefined || obj.hobbie == undefined) {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                var _obj = {
                    pnHobbieId: obj.hobbie.nMaeItem
                        , pvHobbie: obj.hobbie.cMaeDenom

                         , pnFrecuenciaId: obj.frecuencia.nMaeItem
                         , pvFrecuencia: obj.frecuencia.cMaeDenom

                         , pnNivelId: obj.nivel.nMaeItem
                         , pvNivel: obj.nivel.cMaeDenom
                };
                for (var i = 0; i < $scope.Postulante.Collections.Hobbies.length; i++) {
                    if (obj.hobbie.nMaeItem == $scope.Postulante.Collections.Hobbies[i].pnHobbieId) {
                        $scope.Postulante.Collections.Hobbies[i] = _obj
                        return;
                    }
                }

            }

            else {
                $scope.hobbie = null;
            }
        }
    }

    //IDIOMA 
    $scope.fnPostulanteCollections_idioma_GTH = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1) {

                // limpiar inputs
                $scope.idioma = null;
                $scope.fnPostulanteCollections_idioma_GTH(undefined, 99);
                fnShowModal('modalNewOrUpdate_carg_idioma_GTH');

                $scope.mtnIdioma_nOpt = 2;

                obj = null;

            }
            else if (_nOption == 2)//New
            {


                //VALIDAR INPUTS...
                if (obj == undefined || obj.lengua == undefined || obj.escrito == undefined || obj.hablado == undefined) {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                //NO DUPLICADOS
                for (var i = 0; i < $scope.Postulante.Collections.Idioma.length; i++) {
                    if (obj.lengua.nMaeItem == $scope.Postulante.Collections.Idioma[i].pnIdiomaId) {

                        fnalert('warning', 'Aviso', 'No puede haber dos idiomas iguales');
                        return;
                    }
                }
                //

                if (obj) {
                    console.log(obj);
                    var _idioma = {
                        pnIdiomaId: obj.lengua.nMaeItem
                            , pcIdioma: obj.lengua.cMaeDenom

                            , pnNivelEscritoId: obj.escrito.nMaeItem
                            , pcNivelEscrito: obj.escrito.cMaeDenom

                            , pnNivelOralId: obj.hablado.nMaeItem
                            , pcNivelOral: obj.hablado.cMaeDenom
                    }
                    //console.log(_idioma);
                    $scope.Postulante.Collections.Idioma.push(_idioma)

                    //CLEAR INPUTS FORM...
                    $scope.idioma = null;
                    $scope.fnPostulanteCollections_idioma_GTH(undefined, 99);

                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.Idioma.indexOf(obj);
                $scope.Postulante.Collections.Idioma.splice(index, 1);
            } else if (_nOption == 4) {

                $scope.mtnIdioma_nOpt = 4;// titulo y botones
                fnShowModal('modalNewOrUpdate_carg_idioma_GTH');

                var _idioma = {
                    lengua: null
                    , escrito: null
                    , hablado: null
                }


                //$("#inpt_slc_cargidiom_lenguaje").val(obj);
                debugger;
                for (var i = 0; i < $scope.maestr_idioma.length; i++) {
                    if (obj.pnIdiomaId == $scope.maestr_idioma[i].nMaeItem) {
                        _idioma.lengua = $scope.maestr_idioma[i]
                        break;
                    }
                }
                for (var i = 0; i < $scope.maestr_conoc_nivel.length; i++) {
                    if (obj.pnNivelEscritoId == $scope.maestr_conoc_nivel[i].nMaeItem) {
                        _idioma.escrito = $scope.maestr_conoc_nivel[i]


                        break;
                    }
                }
                for (var i = 0; i < $scope.maestr_conoc_nivel.length; i++) {

                    if (obj.pnNivelOralId == $scope.maestr_conoc_nivel[i].nMaeItem) {
                        _idioma.hablado = $scope.maestr_conoc_nivel[i]

                        break;
                    }
                }

                $scope.idioma = _idioma;
                console.log($scope.idioma);


            } else if (_nOption == 5) {

                //VALIDAR INPUTS...
                if (obj == undefined || obj.lengua == undefined || obj.escrito == undefined || obj.hablado == undefined) {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }

                var _idioma = {
                    pnIdiomaId: obj.lengua.nMaeItem
                           , pcIdioma: obj.lengua.cMaeDenom

                           , pnNivelEscritoId: obj.escrito.nMaeItem
                           , pcNivelEscrito: obj.escrito.cMaeDenom

                           , pnNivelOralId: obj.hablado.nMaeItem
                           , pcNivelOral: obj.hablado.cMaeDenom
                }

                for (var i = 0; i < $scope.Postulante.Collections.Idioma.length; i++) {
                    if (obj.lengua.nMaeItem == $scope.Postulante.Collections.Idioma[i].pnIdiomaId) {

                        $scope.Postulante.Collections.Idioma[i] = _idioma;
                    }
                }

            }








            else {
                $("#inpt_slc_cargidiom_lenguaje").val('');
                $("#inpt_slc_cargidiom_escrito").val('');
                $("#inpt_slc_cargidiom_hablado").val('');

            }
        }
    }

    //GRUPO CONOCIMIENTO 
    $scope.fnPostulanteCollections_GpoConocimiento_GTH = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1) {

                // limpiar inputs
                $scope.gpoConocimiento = null;
                $scope.fnPostulanteCollections_GpoConocimiento_GTH(undefined, 99);
                fnShowModal('modalNewOrUpdate_carg_gpoconocimineto_GTH');

                $scope.mtn_gpoConocimiento_nOpt = 2;

                obj = null;

            }
            else if (_nOption == 2)//New
            {


                //VALIDAR INPUTS...
                //if (obj == undefined || obj.lengua == undefined || obj.escrito == undefined || obj.hablado == undefined) {
                //    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                //    return false;
                //}
                //NO DUPLICADOS
                for (var i = 0; i < $scope.Postulante.Collections.CargagrupoConocimineto.length; i++) {
                    if (obj.lengua.nMaeItem == $scope.Postulante.Collections.CargagrupoConocimineto[i].pnIdiomaId) {

                        fnalert('warning', 'Aviso', 'No puede haber dos idiomas iguales');
                        return;
                    }
                }


                if (obj) {
                    console.log(obj);
                    var _grupoConocimiento = {

                        pnConNegocioId: obj.gpocpn.nMaeItem
                        , pvDesConNegocio: obj.gpocpn.cMaeDenom
                        , pnTpoConNegocioId: obj.conocimiento.nMaeItem
                        , pvTpoConNegocio: obj.conocimiento.cMaeDenom
                        , pnNivel: obj.nivel.nMaeItem
                        , pvNivel: obj.nivel.cMaeDenom


                    }
                    console.log(_grupoConocimiento);
                    $scope.Postulante.Collections.CargagrupoConocimineto.push(_grupoConocimiento)

                    //CLEAR INPUTS FORM...
                    $scope.gpoConocimiento = null;
                    $scope.fnPostulanteCollections_GpoConocimiento_GTH(undefined, 99);

                }

            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.CargagrupoConocimineto.indexOf(obj);
                $scope.Postulante.Collections.CargagrupoConocimineto.splice(index, 1);
            } else if (_nOption == 4) {

                $scope.mtn_gpoConocimiento_nOpt = 4;// titulo y botones
                fnShowModal('modalNewOrUpdate_carg_gpoconocimineto_GTH');

                var _grupoConocimiento = {
                    lengua: null
                    , escrito: null
                    , hablado: null
                }


                //$("#inpt_slc_cargidiom_lenguaje").val(obj);

                for (var i = 0; i < $scope.maestr_idioma.length; i++) {
                    if (obj.pnIdiomaId == $scope.maestr_idioma[i].nMaeItem) {
                        _idioma.lengua = $scope.maestr_idioma[i]
                        break;
                    }
                }
                for (var i = 0; i < $scope.maestr_conoc_nivel.length; i++) {
                    if (obj.pnNivelEscritoId == $scope.maestr_conoc_nivel[i].nMaeItem) {
                        _idioma.escrito = $scope.maestr_conoc_nivel[i]


                        break;
                    }
                }
                for (var i = 0; i < $scope.maestr_conoc_nivel.length; i++) {

                    if (obj.pnNivelOralId == $scope.maestr_conoc_nivel[i].nMaeItem) {
                        _idioma.hablado = $scope.maestr_conoc_nivel[i]

                        break;
                    }
                }

                $scope.gpoConocimiento = _grupoConocimiento;
                console.log($scope.gpoConocimiento);

            }
                //deja esta llave} else if (_nOption == 5) {

                //    //VALIDAR INPUTS...
                //    if (obj == undefined || obj.lengua == undefined || obj.escrito == undefined || obj.hablado == undefined) {
                //        fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                //        return false;
                //    }

                //    var _idioma = {
                //        pnIdiomaId: obj.lengua.nMaeItem
                //               , pcIdioma: obj.lengua.cMaeDenom

                //               , pnNivelEscritoId: obj.escrito.nMaeItem
                //               , pcNivelEscrito: obj.escrito.cMaeDenom

                //               , pnNivelOralId: obj.hablado.nMaeItem
                //               , pcNivelOral: obj.hablado.cMaeDenom
                //    }

                //    for (var i = 0; i < $scope.Postulante.Collections.CargagrupoConocimineto.length; i++) {
                //        if (obj.lengua.nMaeItem == $scope.Postulante.Collections.CargagrupoConocimineto[i].pnIdiomaId) {

                //            $scope.Postulante.Collections.CargagrupoConocimineto[i] = _idioma;
                //        }
                //    }

                //}








            else {
                $("#inpt_slc_cargidiom_lenguaje").val('');
                $("#inpt_slc_cargidiom_escrito").val('');
                $("#inpt_slc_cargidiom_hablado").val('');

            }
        }
    }

    //CARGA FAMILIAR
    $scope.fnPostulanteCollections_cargFamiliar_GTH = function (obj, _nOption) {
        if (_nOption) {
            if (_nOption == 1)//New
            {
                $scope.familiar = null;
                $scope.fnPostulanteCollections_cargFamiliar_GTH();
                fnShowModal('modalNewOrUpdate_carg_fam_GTH');

                $scope.mnt_crga_fam_opcion = 2;
                obj = null;
            }
            else if (_nOption == 2)//New
            {
                //VALIDAR INPUTS...
                // EN ESTE FORMULARIO SI SE PUEDEN REPETIR LOS CAMPOS
                for (var i = 0; i < $scope.Postulante.Collections.CargaFamiliar.length; i++) {
                    if (obj.app == $scope.Postulante.Collections.CargaFamiliar[i].pvApePaterno &&
                        obj.apm == $scope.Postulante.Collections.CargaFamiliar[i].pvApeMaterno &&
                        obj.nombres == $scope.Postulante.Collections.CargaFamiliar[i].pvNombres) {
                        fnalert('warning', '¡Aviso!', 'Familiar ya registrado');
                        return false;
                    }
                }

                //VALIDAR INPUTS...
                if (obj == undefined || obj.app == undefined || obj.apm == undefined || obj.nombres == undefined || obj.edad == undefined || obj.parentesco == undefined || obj.instruccion == undefined || obj.ocupacion == undefined ||
                    obj.app == '' || obj.apm == '' || obj.nombres == '' || obj.edad == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                if (!$('input[name="rdo_cargFam_difunt"]:checked').val()) {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }

                console.log(obj);
                if (obj) {

                    var _familiar = {
                        pvApePaterno: obj.app
                        , pvApeMaterno: obj.apm
                        , pvNombres: obj.nombres
                        , pnEdad: obj.edad

                        , pnParentesco: obj.parentesco.nMaeItem
                        , pvParentesco: obj.parentesco.cMaeDenom

                        , pcGradoInstruccion: obj.instruccion.cMaeDenom
                        , pnGradoInstruccionID: obj.instruccion.nMaeItem

                        , pnOcupacion: obj.ocupacion.nMaeItem
                        , vOcupacion: obj.ocupacion.cMaeDenom

                        , cVive: obj.difunto
                    }

                    //validación registros duplicados:
                    var _indx = filterArrayObjectByObjectValues($scope.Postulante.Collections.CargaFamiliar, _familiar);
                    if (_indx != -1) {
                        fnalert('warning', 'Aviso', 'No puede haber dos familiarres con las mismas caracteristicas');
                        return;
                    }

                    console.log(_familiar);
                    $scope.Postulante.Collections.CargaFamiliar.push(_familiar)
                    //CLEAR INPUTS FORM...
                    $scope.familiar = null;
                    $scope.fnPostulanteCollections_cargFamiliar_GTH();

                }


            }
            else if (_nOption == 3)//remove
            {
                var index = $scope.Postulante.Collections.CargaFamiliar.indexOf(obj);
                $scope.Postulante.Collections.CargaFamiliar.splice(index, 1);
            }
            else if (_nOption == 4)//Titulos y botones
            {
                $scope.mnt_crga_fam_opcion = 4;
                fnShowModal('modalNewOrUpdate_carg_fam_GTH');

                var _familiar = {
                    app: obj.pvApePaterno
                        , apm: obj.pvApeMaterno
                        , nombres: obj.pvNombres
                        , edad: obj.pnEdad


                        , parentesco: null

                        , instruccion: null


                        , ocupacion: null

                        , difunto: obj.cVive
                }

                for (var i = 0; i < $scope.maestr_parentesco.length; i++) {
                    if (obj.pnParentesco == $scope.maestr_parentesco[i].nMaeItem) {
                        _familiar.parentesco = $scope.maestr_parentesco[i]
                        break;
                    }
                }
                for (var i = 0; i < $scope.maestr_grdoInstruccion.length; i++) {
                    if (obj.pnGradoInstruccionID == $scope.maestr_grdoInstruccion[i].nMaeItem) {
                        _familiar.instruccion = $scope.maestr_grdoInstruccion[i]
                        break;
                    }
                }
                for (var i = 0; i < $scope.maestr_ocupacion.length; i++) {
                    if (obj.pnOcupacion == $scope.maestr_ocupacion[i].nMaeItem) {
                        _familiar.ocupacion = $scope.maestr_ocupacion[i]
                        break;
                    }
                }


                $scope.familiar = _familiar;
            }

            else if (_nOption == 5)//Editar
            {
                if (obj == undefined || obj.app == undefined || obj.apm == undefined || obj.nombres == undefined || obj.edad == undefined || obj.parentesco == undefined || obj.instruccion == undefined || obj.ocupacion == undefined ||
                   obj.app == '' || obj.apm == '' || obj.nombres == '' || obj.edad == '') {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }
                if (!$('input[name="rdo_cargFam_difunt"]:checked').val()) {
                    fnalert('info', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
                    return false;
                }

                var _familiar = {
                    pvApePaterno: obj.app
                        , pvApeMaterno: obj.apm
                        , pvNombres: obj.nombres
                        , pnEdad: obj.edad

                        , pnParentesco: obj.parentesco.nMaeItem
                        , pvParentesco: obj.parentesco.cMaeDenom

                        , pcGradoInstruccion: obj.instruccion.cMaeDenom
                        , pnGradoInstruccionID: obj.instruccion.nMaeItem

                        , pnOcupacion: obj.ocupacion.nMaeItem
                        , vOcupacion: obj.ocupacion.cMaeDenom

                        , cVive: obj.difunto
                }

                // FALTA SABER COMO SE VA A EDITAR SI LOS CAMPOS NO SON GIJOS

                for (var i = 0; i < $scope.Postulante.Collections.CargaFamiliar.length; i++) {
                    if (obj.app == $scope.Postulante.Collections.CargaFamiliar[i].pvApePaterno &&
                        obj.apm == $scope.Postulante.Collections.CargaFamiliar[i].pvApeMaterno &&
                        obj.nombres == $scope.Postulante.Collections.CargaFamiliar[i].pvNombres) {
                        $scope.Postulante.Collections.CargaFamiliar[i] = _familiar
                        return;
                    }
                }
            }
            else {
                $("#txt_cargFam_app").val('');
                $("#txt_cargFam_apm").val('');
                $("#txt_cargFam_nombres").val('');
                $("#inpt_slc_cargFam_parentsco").val('');
                $("#txt_cargFam_edad").val('');
                $("#inpt_slc_cargFam_instruccion").val('');
                $('input[name="rdo_cargFam_difunt"]').removeAttr('checked');
            }
        }
    }




    //  FINALIZA LOS MODALS 

    function filterArrayObjectByObjectValues(_arr, _obj) {

        var _indexOf = -1;
        if (_arr) {
            var jsn_arr = "";
            var jsn_obj = "";
            for (var i = 0; i < _arr.length; i++) {
                jsn_arr = angular.toJson(_arr[i]);
                jsn_obj = angular.toJson(_obj);
                if (jsn_arr == jsn_obj) {
                    _indexOf = i;
                    return _indexOf;
                }
            }
        }


        return _indexOf;
    }

    //  Muestra los modals
    function fnShowModal(_modalId) {
        $('#' + _modalId).modal({
            backdrop: 'static', keyboard: false
        });
        //console.log("============================================");
        //console.log($scope.Postulante);
        //console.log("============================================");
    }

    function validacion_min() {
        if ($("#txt_cargadato_app_gth").val() == undefined || $("#txt_cargadato_app_gth").val() == '' ||
            $("#txt_cargadato_apm_gth").val() == undefined || $("#txt_cargadato_apm_gth").val() == '' ||
            $("#txt_cargadato_nombre_gth").val() == undefined || $("#txt_cargadato_nombre_gth").val() == '' ||
            $("#dt_cargadato_fechanac_gth").val() == undefined || $("#dt_cargadato_fechanac_gth").val() == '' ||
            $("#txt_cargadato_edad_gth").val() == undefined || $("#txt_cargadato_edad_gth").val() == '' ||
            $("#txt_cargadato_documento_gth").val() == undefined || $("#txt_cargadato_documento_gth").val() == '' ||
            $("#dt_cargadato_vencdoc_gth").val() == undefined || $("#dt_cargadato_vencdoc_gth").val() == '' ||
            $("#txt_cargadato_direcactual_gth").val() == undefined || $("#txt_cargadato_direcactual_gth").val() == '' ||
            //para los select
            $("#inpt_slc_regis_sexo").val() == 0 || $("#inpt_slc_regdtspersEstadoCivil").val() == 0 ||
            $("#inpt_slc_regTpoReclutamiento").val() == 0 || $("#inpt_slc_regdtpersPerfil_Cliente").val() == 0 ||
            $("#inpt_slc_regdtspersNAcionalidad").val() == 0 || $("#inpt_slc_regDepartamento").val() == 0 ||
            $("#inpt_slc_regProvincia").val() == 0 || $("#inpt_slc_regDistrito").val() == 0 ||
            $("#inpt_slc_regdompartNacionalidad").val() == 0 || $("#inpt_slc_regdompartDepartamento").val() == 0 ||
            $("#inpt_slc_regdompartProvincia").val() == 0 || $("#inpt_slc_regdompartDistrito").val() == 0) {
            fnalert('danger', '¡Aviso!', 'Debe ingresar los campos obligatorios (*)');
            return true;

        }
        return false;

    }

    $scope.btn_Registrar_Postulante = function () {
        //VALIDACIONES EN ESPERA
        if (validacion_min()) {
            return false;
        } else {

            alert("1");
            var _Regiparam = {
                //inicio campos tabla Persona

                pcModalidaRegistro: "1" /*<<=== tipo de registro ======*/

              , pvNombres: $scope.datosPers.nombre
              , pvApePaterno: $scope.datosPers.App
              , pvApeMaterno: $scope.datosPers.Apm
              , pcSexo: $scope.datosPers.genero.nMaeItem
              , pnNacionalidad: $scope.datosPers.Nacionalidad.nMaeItem
              , pvCorreo: $scope.datosPers.correo

              , pvTelefono: $scope.datosPers.tlfparticualar
              , pvTelefonoCelular: $scope.datosPers.cell

              , pnDstNacId: $scope.datosPers.nacDistrito.nDstId
              , pvDmcDireccion: $scope.datosPers.direcActual
              , pnDstDmcId: $scope.datosPers.DomPart_pnDstpart.nDstId
              , pvDmcReferencia: $scope.datosPers.pntref
              , pnCrgPresentarseId: $scope.datosPers.Perfil_cliente.nCrgPrsId

              , pdtFchNacimiento: $filter('date')($scope.datosPers.nacimiento, "dd-MM-yyyy") /*!important */
                //, pdtFchNacimiento: $filter('date')(_date_fechNacimnto, "dd-MM-yyyy") /*!important */
              , pvDocNro: $scope.datosPers.documento
              , pdtFchVenDoc: $filter('date')($scope.datosPers.vencdoc, "dd-MM-yyyy") /*!important */
                //, pdtFchVenDoc: $filter('date')(_date_fechVencDoc, "dd-MM-yyyy") /*!important */

              , pnEstCivil: $scope.datosPers.EstCivil.nMaeItem
              , pnHijos: $scope.datosPers.nhijos
              , pvReligion: $scope.datosPers.Religion.nMaeItem
              , pnCanalId: $scope.datosPers.Canalrec.nMaeItem

                //COMENTADOS PARA REALIZAR PRUEBAS
                //, pcEnfermedad: ($scope.Postulante.tieneEnfermedades == 'SI' ? 1 : 0)
                //, pcEmbarazo: _embarazada
                //, pnTmpEmbarazo: _TiempoEmbarazada /* int */
                //, pcAntPenales: ($scope.Postulante.tieneAntecedente == 'SI' ? 1 : 0)
                //, pcAntPoliciales: ($scope.Postulante.tieneAntecedentePoli == 'SI' ? 1 : 0)
                //, pcDeudor: ($scope.deuda.deudaActual == 'SI' ? 1 : 0)

                //fin campos tabla Persona

                // COMENTADOS PARA REALIZAR PRUEBAS
              , pLisEstSupe: $scope.Postulante.Collections.EstudiosSuperiores
              , pListConcTe: $scope.Postulante.Collections.ConocTecnicos
              , pListCertif: $scope.Postulante.Collections.Certificaciones
              , pListIdioma: $scope.Postulante.Collections.Idioma

              , pcPrimrTrbj: $scope.Postulante.PrimerTrabj /* Solo se usa para la validacion de los campos, no es necesario almacenar este dato? */
              , pListExpLbs: $scope.Postulante.Collections.ExpLaborales
              , pListRefLab: $scope.Postulante.Collections.RefLaborales
              , pListRefFam: $scope.Postulante.Collections.RefFamiliar

              , pListDeudas: $scope.Postulante.Collections.Deudas  /*Tabla: PersonaFinanciero*/
              , pListAntPen: $scope.Postulante.Collections.AntPenales
              , pListAntPol: $scope.Postulante.Collections.AntPolicial

              , pListEnferm: $scope.Postulante.Collections.Enfermedades  /*Tabla: PersonaXTratmnt_enfermd*/
              , pListCrgFam: $scope.Postulante.Collections.CargaFamiliar
                //, pListCrgFam: $.merge($scope.Postulante.Collections.CargaFamiliar.Padres, $scope.Postulante.Collections.CargaFamiliar.DerechoHabientes)
              , pListHobbie: $scope.Postulante.Collections.Hobbies

            }

        }
        console.log(_Regiparam);


        //#01 - se registra/actualiza al postulante
        ftyApiRequest._API_POST_REQUEST('Postulante', 'fnRegistroVirtual_Post', _Regiparam)
       .success(function (response) {
           console.log(response);
           if (response.nMsjCode == 200) {
               //#02 - se obtiene el id del postulante para guardar los documentos adjuntos...
               var _nPrsId = -1;

               _nPrsId = response.nMsj2;
               console.log('_nPrsId', _nPrsId);
               if (_nPrsId != -1) {
                   //#03 - se suben los adjuntos uno a uno...
                   if ($scope.DocumentosAdjuntos) {
                       if ($scope.DocumentosAdjuntos.length > 0) {
                           for (var i = 0; i < $scope.DocumentosAdjuntos.length; i++) {
                               fnUploadFiles_fichaPostulante_Docs($scope.DocumentosAdjuntos[i]._file_
                                                                   , _nPrsId
                                                                   , $scope.DocumentosAdjuntos[i]._idTipoDoc_
                                                                   );
                           }
                       }
                   }

               }

           }

       })

        alert("registrado correctamente");
    }







    //$scope.datosPers = {};
    function iniciar() {
        if (ftyApiRequest.utilitario != null) {
            //alert(ftyApiRequest.utilitario.codigo);
            $scope.fILListaPostulantes(ftyApiRequest.utilitario.codigo, ftyApiRequest.utilitario.fichaId);
        }

        loadList_CentroDeEstudio();
        loadList_perfilCliente();
        loadList_Carrera();
        loadList_Maestros();
        console.log($scope.maestr_perfilCliente);

    }



    iniciar();



})