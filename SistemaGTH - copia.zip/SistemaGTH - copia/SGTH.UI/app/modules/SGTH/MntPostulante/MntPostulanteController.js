﻿app.controller('MntPostulanteController', function ($scope
, $parse
, $http
, $window
, $cookieStore
, $location
, ftyApiRequest

, DTOptionsBuilder, DTColumnDefBuilder
,$filter
) {
    $scope.vtituloview = sessionStorage.getItem("vtituloview");


    $scope.Usuario = $cookieStore.get('usuario');//Important for CRUD
    if ($scope.Usuario == undefined || $scope.Usuario == null) {
        fnalert('warning', 'Aviso', 'No se logro obtener los datos del usuario, porfavor ingrese nuevamente...', 4000);
        return;
    }
    console.log($scope.Usuario);




    var mvcUrl = _URLMvc;
    var _CONTEXT_ = 'FichaPostulante';

    $scope.objPostulante_selected = {};
    $scope.objPostulante = {};
    $scope.evaluacion = {};
    //set DataTable order
    $scope.options = DTOptionsBuilder.newOptions().withOption('order', [[0, 'desc']]);


    {//arreglos-maestro
        $scope._maestro = [];
        /*Datos Personales*/
        $scope.maestr_canalReclut = []
        $scope.maestr_perfilCliente = []
        $scope.maestr_genero = []

        $scope.maestr_nacionalidad = []
        $scope.maestr_departamento = []
        $scope.maestr_provincia = []
        $scope.maestr_distrito = []

        $scope.maestr_estadoCivil = []
        $scope.maestr_religion = []

        /*Dom Particular*/

        /*Estudios Superiores*/
        $scope.maestr_tipoEstudio = []
        $scope.maestr_carrera = []
        $scope.maestr_tipoCentro = []
        $scope.maestr_centroEstudio = []
        $scope.maestr_tipoGrado_condicion = []

        /*carga certificaciones*/
        $scope.maestr_certificacion = []

        /*Conocimientos Tecnicos*/
        $scope.maestr_grpoConocTec = []
        $scope.maestr_conocTec = []
        $scope.maestr_conocNegoc = []
        $scope.maestr_conoc_nivel = []

        /*Carga Familiar*/
        $scope.maestr_parentesco = []
        $scope.maestr_ocupacion = []
        $scope.maestr_grdoInstruccion = []

        /*Carga Idioma*/
        $scope.maestr_idioma = []

        /*Experiencia laboral*/

        /*Referencia laboral*/
        $scope.maestr_tpo_referencia = []

        /*frecuencia (hobbies)*/
        $scope.maestr_hobbies = []
        $scope.maestr_frecuencia = []


        $scope.mtnLista_postulantes = []

        $scope.maestr_tipoRegistro = []

        $scope.maestr_tipoDeAceptacion = []

        $scope.maestr_tipoDeColaborador = []

        $scope.maestr_modalidadForm = []
        $scope.maestr_perfilTec = []
        $scope.maestr_TipoDeArea = []
        $scope.maestr_modalidaContrato = []



        //SON LA OPCIONES QUE MUESTRA CADA SELECT, RESPECTIVAMENTE
        $scope.maestr_ids = [
          /*  
            { MaeId: 39, Descripcion: 'Religion' },
            { MaeId: 15, Descripcion: 'Grupo COnoc Tecnic' },
            { MaeId: 41, Descripcion: 'Grupo COnoc Negocio' },
            { MaeId: 5, Descripcion: 'Nivel Conocimiento' },
            { MaeId: 10, Descripcion: 'Tipo de estudio' },
            { MaeId: 13, Descripcion: 'Tipo de grado' },
            { MaeId: 11, Descripcion: 'Tipo centro de estudio' },
            { MaeId: 71, Descripcion: 'Parentesco' },
            { MaeId: 72, Descripcion: 'Ocupacion' },
            { MaeId: 88, Descripcion: 'Idioma' },
            { MaeId: 89, Descripcion: 'Grado de instruccion' },
            { MaeId: 91, Descripcion: 'Tipo de referencia' },
            { MaeId: 14, Descripcion: 'Listado de Hobbies... ' },
            { MaeId: 30, Descripcion: 'frecuencia' },*/
            { MaeId: 73, Descripcion: 'Genero' },
            { MaeId: 28, Descripcion: 'Nacionalidad' },
            { MaeId: 29, Descripcion: 'Estado Civil' },
            { MaeId: 9, Descripcion: 'tipo de aceptación, en el RDA figura con el nombre de "FSW"...' },
            { MaeId: 93, Descripcion: 'tipo de modalidad de registro del postulante' },

            { MaeId: 69, Descripcion: 'Tipo de Colaborador' },
            { MaeId: 88, Descripcion: 'Idioma' },
            { MaeId: 89, Descripcion: 'Grado de instruccion' },
            { MaeId: 70, Descripcion: 'Modalidad de formación, profesional, pre-profesional' },
            { MaeId: 66, Descripcion: 'Tipo de contrato' },
            { MaeId: 35, Descripcion: 'Perfil Tecnico' },
            { MaeId: 25, Descripcion: 'Tipo de Area' },
            { MaeId: 26, Descripcion: 'Modalidad de Contrato' },
        ];
    }

    $scope.ini_listPntoMarc = []
    $scope.list_calendario = []
    $scope.ini_listEmpresa = []
    $scope.maestr_tpo_contrato = []
    $scope.ini_listGrupo = []

    $scope.ini_listLineaServ = []
    $scope.ini_listSubLineaServ = []
    $scope.ini_listServ = []

    $scope.list_Area = []
    $scope.list_CargoContrato = []


    function LoadMaestroOptiones(MaeId, Array) {
        for (var i = 0; i < $scope._maestro.length; i++) {
            //remove item if 'cEliminado' = 1;
            if ($scope._maestro[i].nMaeId == MaeId && $scope._maestro[i].cEliminado == '0') {
                Array.push($scope._maestro[i]);
            }
        }

    }

    function loadList_cargoDeContrato() {

        //ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aListCrgCntrto', _param)
        ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aListCrgCntrto', null)
         .success(function (response) {

             //console.log(response);
             if (response.nMsjCode == 200) {
                 $scope.listCargoContrto = response.DtCollection;
             }
             else {
                 fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
             }
         })
        .error(function (msj) {
            //console.error(msj);
            fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
        })
    }

    function loadList_Maestros() {

        //concatenando los id's de los maestros a consultar...
        var _MaestIds = '';
        $.each($scope.maestr_ids, function (key, val) {
            _MaestIds += val.MaeId + ',';
        });
        _MaestIds = _MaestIds.substr(0, _MaestIds.length - 1);

        var _param = {
            cMaeId: _MaestIds,
        }
        $scope._maestro = [];

        ftyApiRequest._API_POST_REQUEST('Maestro', 'aList', _param)
        .success(function (response) {
            console.log(response);
            if (response.nMsjCode == 200) {
                $scope._maestro = response.DtCollection;
                /* 
                
                 LoadMaestroOptiones(39, $scope.maestr_religion);
                 LoadMaestroOptiones(15, $scope.maestr_grpoConocTec);
                 LoadMaestroOptiones(41, $scope.maestr_conocNegoc);
                 LoadMaestroOptiones(5, $scope.maestr_conoc_nivel);
                 LoadMaestroOptiones(10, $scope.maestr_tipoEstudio)
 
                 LoadMaestroOptiones(13, $scope.maestr_tipoGrado_condicion);
                 LoadMaestroOptiones(11, $scope.maestr_tipoCentro);
                 LoadMaestroOptiones(71, $scope.maestr_parentesco);
                 LoadMaestroOptiones(72, $scope.maestr_ocupacion);
                 LoadMaestroOptiones(88, $scope.maestr_idioma);
                 LoadMaestroOptiones(89, $scope.maestr_grdoInstruccion);
                 LoadMaestroOptiones(91, $scope.maestr_tpo_referencia);
                 
 
                 LoadMaestroOptiones(14, $scope.maestr_hobbies);
                 LoadMaestroOptiones(30, $scope.maestr_frecuencia);*/

                LoadMaestroOptiones(29, $scope.maestr_estadoCivil);
                LoadMaestroOptiones(28, $scope.maestr_nacionalidad);
                LoadMaestroOptiones(73, $scope.maestr_genero);
                LoadMaestroOptiones(9, $scope.maestr_tipoDeAceptacion);
                console.log($scope.maestr_tipoDeAceptacion);
                LoadMaestroOptiones(93, $scope.maestr_tipoRegistro);
                //console.log($scope.maestr_tipoRegistro);
                LoadMaestroOptiones(69, $scope.maestr_tipoDeColaborador);
                LoadMaestroOptiones(70, $scope.maestr_modalidadForm);
                LoadMaestroOptiones(66, $scope.maestr_tpo_contrato);
                LoadMaestroOptiones(35, $scope.maestr_perfilTec);
                LoadMaestroOptiones(25, $scope.maestr_TipoDeArea);



                LoadMaestroOptiones(26, $scope.maestr_modalidaContrato);
                console.log($scope.maestr_modalidaContrato);





            }
            else {
                //console.error(response.cMsj);
                fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
            }
        })
        .error(function (msj) {
            //console.error(msj);
            fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
        });
    }

    function loadList_CentroDeEstudio() {
        var _param = {
            pnTpoCentro: '0',/*<< '0 will bring us every row...*/
            pcOpcion: '01'
        }
        $scope.maestr_centroEstudio = [];

        ftyApiRequest._API_POST_REQUEST('Maestro', 'FILCentroEstudio', _param)
                .success(function (response) {

                    //console.log(response);
                    if (response.nMsjCode == 200) {
                        $scope.maestr_centroEstudio = response.DtCollection;
                    }
                    else {
                        //console.error(response.cMsj);
                        fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                    }
                })
                .error(function (msj) {
                    //console.error(msj);
                    fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                });
    }


    function loadList_Carrera() {
        var _param = {
            pnTipo: '0',
            pcOpcion: '01'
        }
        $scope.maestr_carrera = [];
        ftyApiRequest._API_POST_REQUEST('Maestro', 'fIListEstudios', _param)
                .success(function (response) {
                    if (response.nMsjCode == 200) {
                        $scope.maestr_carrera = response.DtCollection;
                    }
                    else {
                        fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                    }
                })
                .error(function (msj) {
                    //console.error(msj);
                    fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                });
    }


    $scope.fILListaPostulantes = function () {

        var _param = {}
        if ($scope.filterMnt) {

            var _txtPostulante = "";
            var _nCrgPrsId = 0;
            var _cNroDoc = '';
            var _ntipoAceptacion = 0;

            if ($scope.filterMnt.txtPostulante != undefined && $scope.filterMnt.txtPostulante != null && $scope.filterMnt.txtPostulante != "") {
                _txtPostulante = $scope.filterMnt.txtPostulante;
            }
            if ($scope.filterMnt.slcCargo != undefined || $scope.filterMnt.slcCargo != null) {
                _nCrgPrsId = $scope.filterMnt.slcCargo.nCrgPrsId;
            }

            if ($scope.filterMnt.txtNroDoc != undefined || $scope.filterMnt.txtNroDoc != null) {
                _cNroDoc = $scope.filterMnt.txtNroDoc;
            }

            if ($scope.filterMnt.slcTipoAceptacion != undefined || $scope.filterMnt.slcTipoAceptacion != null) {
                _ntipoAceptacion = $scope.filterMnt.slcTipoAceptacion.nMaeItem
            }
            _param = {
                'pvApellidosNombres': _txtPostulante
               , 'pnCrgPresentarseId': _nCrgPrsId
               , 'pvDocNro': _cNroDoc
               , 'pnTpoAceptacion': _ntipoAceptacion

               , 'PageNumber': 1
               , 'PageSize': 10
               , 'strOpcion': "2"
            }
        }
        else {
            _param = {
                'PageNumber': 1
                , 'PageSize': 10
                , 'strOpcion': '2'
            }
        }

        ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'fListaPostulante', _param)
               .success(function (response) {
                   //console.log(response);
                   if (response.nMsjCode == 200) {
                       $scope.mtnLista_postulantes = response.DtCollection;

                       if ($scope.maestr_tipoRegistro) {

                           for (var i = 0; i < $scope.mtnLista_postulantes.length; i++) {



                               if (($scope.mtnLista_postulantes[i].cModalidaRegistro).trim() == "1") {
                                   $scope.mtnLista_postulantes[i].cModalidaRegistro_COLORTEXT = { color: '#0e88b5' };
                               }
                               else if (($scope.mtnLista_postulantes[i].cModalidaRegistro).trim() == "2.1") {
                                   $scope.mtnLista_postulantes[i].cModalidaRegistro_COLORTEXT = { color: '#000' };
                               }
                               else if (($scope.mtnLista_postulantes[i].cModalidaRegistro).trim() == "2.2") {
                                   $scope.mtnLista_postulantes[i].cModalidaRegistro_COLORTEXT = { color: '#0ba026' };
                               }



                               for (var j = 0; j < $scope.maestr_tipoRegistro.length; j++) {

                                   if (($scope.maestr_tipoRegistro[j].cMaeValor).trim() == ($scope.mtnLista_postulantes[i].cModalidaRegistro).trim()) {
                                       $scope.mtnLista_postulantes[i].cModalidaRegistro_cMaeDenom = $scope.maestr_tipoRegistro[j].cMaeDenom;
                                       break;
                                   }
                               }
                           }
                       }


                   }
                   else {
                       fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                   }
               })
               .error(function (msj) {
                   //console.error(msj);
                   fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
               });

    }

    function obtenerPostulante(_nPrsId, _nFicId) {
        if (_nPrsId) {
            var _param = {

                'pnPersonaId': _nPrsId
                , 'pnFicId': _nFicId
                , 'strOpcion': '3'
            }
            ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'fListaPostulante', _param)
                   .success(function (response) {

                       if (response.nMsjCode == 200) {
                           $scope.objPostulante = response.DtCollection[0];
                           $scope.objPostulante.cGenero = '';
                           console.log($scope.objPostulante);

                           if ($scope.objPostulante.cModalidaRegistro.trim() == "2.1") {
                               $scope.objPostulante.cEnfermedad = null;
                               $scope.objPostulante.cEmbarazo = null;
                               $scope.objPostulante.cAntPenales = null;
                               $scope.objPostulante.nHijos = null;
                               $scope.objPostulante.vDmcDireccion = null;
                               $scope.objPostulante.cDeudor = null;
                               //...

                               if ($scope.objPostulante.dtFchVenDoc == '01/01/1900') {
                                   $scope.objPostulante.dtFchVenDoc = ''
                               }
                           }
                           else if ($scope.objPostulante.cModalidaRegistro.trim() == "2.2") {
                               $scope.objPostulante.cEnfermedad = $scope.objPostulante.cEnfermedad == '0' ? 'NO' : 'SI';
                               $scope.objPostulante.cEmbarazo = $scope.objPostulante.cEmbarazo == '0' ? 'NO' : 'SI';
                               $scope.objPostulante.cAntPenales = $scope.objPostulante.cAntPenales == '0' ? 'NO' : 'SI';
                               $scope.objPostulante.cDeudor = $scope.objPostulante.cDeudor == '0' ? 'NO' : 'SI';
                               //...

                           }
                           else if ($scope.objPostulante.cModalidaRegistro.trim() == "1") {


                           }


                           if ($scope.objPostulante.dtFchNacimiento == '01/01/1900') {
                               $scope.objPostulante.dtFchNacimiento = null;
                           }
                           else {
                               var _DateArray = $scope.objPostulante.dtFchNacimiento.split("/")
                               var _Date = new Date(_DateArray[2], _DateArray[1] - 1, _DateArray[0])
                               var _Date_Year = _Date.getFullYear();
                               var _TodayDate_Year = new Date().getFullYear();
                               var _edad = _TodayDate_Year - _Date_Year;
                               $scope.objPostulante._edad = _edad;
                           }
                           if ($scope.objPostulante.dtFchVenDoc == '01/01/1900') {
                               $scope.objPostulante.dtFchVenDoc = null;
                           }


                           $scope.objPostulante.cNacionalidad = null;
                           for (var j = 0; j < $scope.maestr_nacionalidad.length; j++) {

                               if (($scope.maestr_nacionalidad[j].cMaeValor).trim() == $scope.objPostulante.nNacionalidad) {
                                   $scope.objPostulante.cNacionalidad = $scope.maestr_nacionalidad[j].cMaeDenom;
                                   break;
                               }
                           }

                           for (var j = 0; j < $scope.maestr_tipoRegistro.length; j++) {

                               if (($scope.maestr_tipoRegistro[j].cMaeValor).trim() == ($scope.objPostulante.cModalidaRegistro).trim()) {
                                   $scope.objPostulante.cModalidaRegistro_cMaeDenom = $scope.maestr_tipoRegistro[j].cMaeDenom;
                                   break;
                               }
                           }


                           for (var i = 0; i < $scope.maestr_genero.length; i++) {
                               if ($scope.maestr_genero[i].nMaeItem == $scope.objPostulante.cSexo) {
                                   $scope.objPostulante.cGenero = $scope.maestr_genero[i].cMaeDenom;
                               }
                           }


                           $scope.objPostulante.cEstCivil = null;
                           for (var i = 0; i < $scope.maestr_estadoCivil.length; i++) {
                               if ($scope.maestr_estadoCivil[i].nMaeItem == $scope.objPostulante.nEstCivil) {
                                   $scope.objPostulante.cEstCivil = $scope.maestr_estadoCivil[i].cMaeDenom;
                               }
                           }

                           fnShowModal('modalPostulante_detalle');

                       }
                       else {
                           fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                       }
                   })
                   .error(function (msj) {
                       //console.error(msj);
                       fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                   });
        }
    }


    $scope.slc_tipoColaborador = function (_obj) {
        if (_obj) {
            if (_obj.cMaeValor == '1') {

                $scope.paseColab.slcModalidaFormacion = "";
                $scope.slcModalidaFormacion_Enabled = false;
            }
            else if (_obj.cMaeValor == '2') {
                $scope.slcModalidaFormacion_Enabled = true
            }
            else {
                $scope.paseColab.slcModalidaFormacion = "";
            }
        }
        else {
            $scope.paseColab.slcModalidaFormacion = "";

        }
    }

    function iniciar() {

        loadList_CentroDeEstudio();
        loadList_cargoDeContrato();
        loadList_Carrera();
        loadList_Maestros();
        $scope.fILListaPostulantes();

        fnListarPntoMarcacion();
        fnListarEmpresa();
        fnListarGrupo();
        fnListaLineaServicio();


    }
    function fnShowModal(_modalId) {
        $('#' + _modalId).modal({
            backdrop: 'static', keyboard: false
        });
    }

    $scope.fnMntPostulante = function (nOption, obj) {

        console.log(obj);
        $scope.objPostulante_selected = obj;
        if (nOption) {
            if (nOption == 1) {
                obtenerPostulante(obj.nPrsId, obj.nFicId);
            }
            else if (nOption == 2) {
                //fnalert('info', 'Aviso', 'En construcción...', 4000);
                ftyApiRequest.utilitario = {
                    codigo: obj.nPrsId
                    , fichaId: obj.nFicId
                };
                var _nUrl = mvcUrl + "#/GestRegistro";
                window.location.href = _nUrl;
                //return;
            }
            else if (nOption == 3) {
                if ((obj.cModalidaRegistro).trim() == "2.1") {
                    fnalert('info', 'Aviso', 'El postulante No ha completado su registro en la Ficha.', 4000);
                    return;
                }
                else {
                    $scope.evaluacion.calificacion = null;
                    $scope.evaluacion.motivo = null;
                    $scope.listaMotivoAceptacion = null;
                    //se da los valores si ya fue registrado...
                    if (obj.nTpoAceptacion > 0) {
                        for (var i = 0; i < $scope.maestr_tipoDeAceptacion.length; i++) {
                            if ($scope.maestr_tipoDeAceptacion[i].nMaeItem == obj.nTpoAceptacion) {
                                $scope.evaluacion.calificacion = $scope.maestr_tipoDeAceptacion[i];
                                $scope.fnSlc_tipoAceptacion(obj.nMtvId);
                                break;
                            }
                        }
                    }

                    fnShowModal("modalPostulante_evaluacion");
                    $scope.evaluacion.postulante = obj;
                    //console.log($scope.evaluacion);
                }


            }
            else if (nOption == 4) {
                if (obj.nTpoAceptacion == 0) {
                    fnalert('info', 'Aviso', 'El postulante no registra una Evaluación de Aceptación.', 4000);
                    return;
                }
                else {
                    fnShowModal("modalPostulante_paseColaborador");
                    $scope.objPostulante = obj;
                }


            }
        }
        else {
            alert('seleccione al postulante..');
        }


    }

    $scope.fnSlc_tipoAceptacion = function (_nMtvId) {



        if ($scope.evaluacion.calificacion != null) {
            var _param = {
                'pnTpoAceptacion': $scope.evaluacion.calificacion.nMaeItem
               , 'strOpcion': '1'
            }

            ftyApiRequest._API_POST_REQUEST('Postulante', 'fListaMotivoBL', _param)
                   .success(function (response) {
                       //console.log(response);
                       if (response.nMsjCode == 200) {
                           $scope.listaMotivoAceptacion = response.DtCollection;

                           if (_nMtvId) {
                               for (var i = 0; i < $scope.listaMotivoAceptacion.length; i++) {
                                   if ($scope.listaMotivoAceptacion[i].nMtvId = _nMtvId) {
                                       $scope.evaluacion.motivo = $scope.listaMotivoAceptacion[i];
                                       break;
                                   }

                               }
                           }
                       }
                       else {
                           fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                       }
                   })
                   .error(function (msj) {
                       //console.error(msj);
                       fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                   });


        }
    }


    function fnListarPntoMarcacion() {
        var _param = {
            'strOpcion': '6'
        }
        ftyApiRequest._API_POST_REQUEST('Postulante', 'aListPtoMarc', _param)
               .success(function (response) {
                   //console.log(response);
                   if (response.nMsjCode == 200) {
                       $scope.ini_listPntoMarc = response.DtCollection;
                   }
                   else {
                       fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                   }
               })
               .error(function (msj) {
                   //console.error(msj);
                   fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
               });
    }

    function fnListarEmpresa() {

        ftyApiRequest._API_POST_REQUEST('Postulante', 'aListEmpresa', null)
               .success(function (response) {
                   if (response.nMsjCode == 200) {
                       $scope.ini_listEmpresa = response.DtCollection;
                   }
                   else {
                       fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                   }
               })
               .error(function (msj) {
                   //console.error(msj);
                   fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
               });
    }


    $scope.fILCargarCalendario = function (obj) {
        if (obj) {
            var _param = {
                'pnPntMrcId': obj.nPntMrcId
            }
            ftyApiRequest._API_POST_REQUEST('Postulante', 'aListCalendario', _param)
                   .success(function (response) {
                       if (response.nMsjCode == 200) {
                           $scope.list_calendario = response.DtCollection;
                       }
                       else {
                           fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                       }
                   })
                   .error(function (msj) {
                       fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                   });
        }

    }

    function fnListarGrupo() {

        ftyApiRequest._API_POST_REQUEST('Postulante', 'aListGrupo', null)
               .success(function (response) {
                   console.log(response);
                   if (response.nMsjCode == 200) {
                       $scope.ini_listGrupo = response.DtCollection;
                   }
                   else {
                       fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                   }
               })
               .error(function (msj) {
                   //console.error(msj);
                   fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
               });
    }


    function fnListaLineaServicio() {

        var _param = {
            'pnLineaServicioCodigo': 0
        }
        ftyApiRequest._API_POST_REQUEST('Postulante', 'aListLineaServic', _param)
               .success(function (response) {
                   console.log(response);
                   if (response.nMsjCode == 200) {
                       $scope.ini_listLineaServ = response.DtCollection;
                   }
                   else {
                       fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                   }
               })
               .error(function (msj) {
                   //console.error(msj);
                   fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
               });
    }

    $scope.slc_LineaServicio = function (_obj) {
        if (_obj) {
            var _param = {
                'pnLineaServicioCodigo': _obj.CODLINSERV
            }
            ftyApiRequest._API_POST_REQUEST('Postulante', 'aListSubLinServ', _param)
                   .success(function (response) {
                       console.log(response);
                       if (response.nMsjCode == 200) {
                           $scope.ini_listSubLineaServ = response.DtCollection;
                       }
                       else {
                           fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                       }
                   })
                       .error(function (msj) {
                           //console.error(msj);
                           fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                       });
        }

    }
    $scope.slc_subLineaServicio = function (_obj) {
        if (_obj) {
            var _param = {
                'pnCodServicio': _obj.CODSUBLINSERV
            }
            ftyApiRequest._API_POST_REQUEST('Postulante', 'aListServ', _param)
                   .success(function (response) {
                       console.log(response);
                       if (response.nMsjCode == 200) {
                           $scope.ini_listServ = response.DtCollection;
                       }
                       else {
                           fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                       }
                   })
                       .error(function (msj) {
                           //console.error(msj);
                           fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                       });
        }

    }

    $scope.fnSlc_empresa = function (_obj) {
        if (_obj) {
            var _param = {
                'pnEmpresaId': _obj.nEmpId
            }
            ftyApiRequest._API_POST_REQUEST('Postulante', 'aListArea', _param)
                   .success(function (response) {
                       if (response.nMsjCode == 200) {
                           $scope.list_Area = response.DtCollection;
                       }
                       else {
                           fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                       }
                   })
                   .error(function (msj) {
                       //console.error(msj);
                       fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                   });

        }
    }



    $scope.fnSlc_area = function (_obj) {
        if (_obj) {
            var _param = {
                'pnAreaId': _obj.nAreaId
            }
            ftyApiRequest._API_POST_REQUEST('Postulante', 'aListCargoContrat', _param)
                   .success(function (response) {
                       console.log(response);
                       if (response.nMsjCode == 200) {
                           $scope.list_CargoContrato = response.DtCollection;
                       }
                       else {
                           fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                       }
                   })
                   .error(function (msj) {
                       //console.error(msj);
                       fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                   });

        }
    }
    $scope.paseColab = {};
    $scope.paseColab.txtCorreo_disabled = true;

    $scope.fnSlc_modalidad = function () {

        $scope.paseColab.txtCorreo_disabled = true;
        $scope.paseColab.txtCorreo = null;
        $scope.listCorreoContrato = null;

        if ($scope.paseColab.slcEmpresa == undefined) {
            fnalert('warning', 'Aviso', 'Seleccione la Empresa', 4000);
            $scope.paseColab.slcModalidadContrato = null;
            return;
        }


        if ($scope.paseColab.slcEmpresa != undefined) {


            if ($scope.paseColab.slcModalidadContrato.cMaeValor != "2") {

                var _param = {
                    'pnPersonaId': $scope.objPostulante_selected.nPrsId
                    , 'pnEmpId': $scope.paseColab.slcEmpresa.nEmpId == "0" ? 0 : $scope.paseColab.slcEmpresa.nEmpId
                }
                ftyApiRequest._API_POST_REQUEST('Postulante', 'fObtenerCorreoBL', _param)
                .success(function (response) {
                    console.log(response);

                    if (response.nMsjCode == 200) {
                        $scope.paseColab.txtCorreo = response.cMsj;
                    }
                    else {

                        $scope.paseColab.txtCorreo = null;
                        fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                    }
                })
                .error(function (msj) {
                    fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                });
            }
            else {

                var _param = {
                    'nPrm_1': $scope.paseColab.slcEmpresa.nEmpId == "0" ? 0 : $scope.paseColab.slcEmpresa.nEmpId
                }
                ftyApiRequest._API_POST_REQUEST('Postulante', 'fListaCorreoPracticasBL', _param)
                .success(function (response) {
                    console.log(response);
                    if (response.nMsjCode == 200) {
                        $scope.listCorreoContrato = response.DtCollection;
                    }
                    else {
                        fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                    }
                })
                .error(function (msj) {
                    //console.error(msj);
                    fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                });

                //$scope.paseColab.txtCorreo_disabled = false;
            }
        }
        else {
            $scope.paseColab.txtCorreo = null;
        }

    }


    $scope.btnConsultarPostulante = function () {
        $scope.fILListaPostulantes();

    }
    $scope.fnRegistrarMotivo = function (_obj) {
        if (_obj) {
            var _param = {
                'pnPersonaId': _obj.postulante.nPrsId
               , 'pnFicId': _obj.postulante.nFicId
               , 'pnMtvId': _obj.motivo.nMtvId
               , 'strOpcion': "2"
            }

            debugger;
            ftyApiRequest._API_POST_REQUEST('Postulante', 'fRegistraMotivo', _param)
                   .success(function (response) {
                       console.log(response);
                       if (response.nMsjCode == 200) {
                           $scope.fILListaPostulantes();
                           fnalert('success', 'Aviso', 'Se registro la evaluación', 4000);
                           $("#modalPostulante_evaluacion").modal('hide');
                       }
                       else {
                           fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                       }
                   })
                   .error(function (msj) {
                       //console.error(msj);
                       fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
                   });


        }
    }

    function validarDatosPase() {
        /* lblErrorPaseClb.Text = "";
         if (ddlTipoColaborador.SelectedIndex == 0)
         {
             lblErrorPaseClb.Text = "Seleccione Tipo de Colaborador";
             return true;
         }
 
         //INI JPG 18/07/2017 - SESNEW
         if (ddlTipoColaborador.SelectedIndex == 2)
         {
             if (ddlModalidadForm.SelectedIndex == 0)
             {
                 lblErrorPaseClb.Text = "Seleccione Tipo de Formación";
                 return true;
             }
         }
         //if (ddlModalidadForm.SelectedIndex == 0)
         //{
         //    lblErrorPaseClb.Text = "Seleccione Tipo de Formación";
         //    return true;
         //}
 
         //FIN JPG 18/07/2017 - SESNEW
 
         if (ddlPtoMarcacion.SelectedIndex == 0)
         {
             lblErrorPaseClb.Text = "Seleccione Punto de Marcación";
             return true;
         }
         else if (ddlCalendario.SelectedIndex == 0)
         {
             lblErrorPaseClb.Text = "Seleccione Calendario";
             return true;
         }
 
         return false;*/
    }




    //anterior:protected bool validarDatosContrato()
    //nuevo: ..(motivo: el metodo anterior No mostraba el mensaje en la vista,"lblErrorPaseClb.text")
    function validarDatosContrato() {
        /*string InfoOut = "";
        lblErrorPaseClb.Text = "";
        Int32 nRes;
        if (Int32.TryParse(txtAnexo.Text, out nRes) == false && txtAnexo.Text != "")
        {
            //lblErrorPaseClb.Text = "Ingrese un anexo correcto o no ingrese valor.";
            InfoOut = "Ingrese un anexo correcto o no ingrese valor.";
            txtAnexo.Focus();
            return InfoOut;
        }
        if (ddlEmpresa.SelectedIndex == 0)
        {
            //lblErrorPaseClb.Text = "Seleccione una Empresa";
            InfoOut = "Seleccione una Empresa";
            return InfoOut;
        }
        if (ddlTipoCont.SelectedIndex == 0)
        {
            //lblErrorPaseClb.Text = "Seleccione un Tipo de Contrato";
            InfoOut = "Seleccione un Tipo de Contrato";
            return InfoOut;
        }
        if (txtFchInicio.Text.Trim() == "")
        {
            //lblErrorPaseClb.Text = "Ingrese fecha de Inicio";
            InfoOut = "Ingrese fecha de Inicio";
            txtFchInicio.Focus();
            return InfoOut;
        }
        if (ddlTipoCont.SelectedValue == "1")
        {
            if (txtFchFin.Text.Trim() == "")
            {
                //lblErrorPaseClb.Text = "Ingrese fecha Fin";
                InfoOut = "Ingrese fecha Fin";
                txtFchFin.Focus();
                return InfoOut;
            }
        }
        if (IsDate(txtFchInicio.Text.Trim().ToString()) != true)
        {
            //lblErrorPaseClb.Text = "Ingrese fecha de Inicio válida";
            InfoOut = "Ingrese fecha de Inicio válida";
            txtFchInicio.Text = "";
            txtFchInicio.Focus();
            return InfoOut;
        }
        if (ddlTipoCont.SelectedValue == "1")
        {
            if (IsDate(txtFchFin.Text.Trim().ToString()) != true)
            {
                //lblErrorPaseClb.Text = "Ingrese fecha Fin válida";
                InfoOut = "Ingrese fecha Fin válida";
                txtFchFin.Text = "";
                txtFchFin.Focus();
                return InfoOut;
            }

            DateTime fechaIni = DateTime.Parse(txtFchInicio.Text);
            DateTime fechaFin = DateTime.Parse(txtFchFin.Text);

            TimeSpan ts = fechaFin - fechaIni;

            if (fechaIni > fechaFin)
            {
                //lblErrorPaseClb.Text = "La fecha de inicio no puede ser mayor a la fecha de fin";
                InfoOut = "La fecha de inicio no puede ser mayor a la fecha de fin";
                return InfoOut;
            }
            if (ts.Days < 7)
            {
                //lblErrorPaseClb.Text = "El contrato no puede durar menos de una semana";
                InfoOut = "El contrato no puede durar menos de una semana";
                return InfoOut;
            }
        }
        if (ddlGrupo.SelectedIndex == 0)
        {
            //lblErrorPaseClb.Text = "Seleccione un Grupo";
            InfoOut = "Seleccione un Grupo";
            return InfoOut;
        }
        if (ddlPerfil.SelectedIndex == 0)
        {
            //lblErrorPaseClb.Text = "Seleccione un Perfil";
            InfoOut = "Seleccione un Perfil";
            return InfoOut;
        }


        if (ddlLineaServicio.SelectedIndex == 0)
        {
            //lblErrorPaseClb.Text = "Seleccione una Línea de Servicio";
            InfoOut = "Seleccione una Línea de Servicio";
            return InfoOut;
        }
        if (ddlSubLineaServicio.SelectedIndex == 0)
        {
            //lblErrorPaseClb.Text = "Seleccione una Sublínea de Servicio";
            InfoOut = "Seleccione una Sublínea de Servicio";
            return InfoOut;
        }
        if (ddlServicio.SelectedIndex == 0)
        {
            //lblErrorPaseClb.Text = "Seleccione un Servicio";
            InfoOut = "Seleccione un Servicio";
            return InfoOut;
        }

        if (ddlTipoArea.SelectedIndex == 0)
        {
            //lblErrorPaseClb.Text = "Seleccione un Tipo de Área";
            InfoOut = "Seleccione un Tipo de Área";
            return InfoOut;
        }


        if (ddlCargo.SelectedIndex == 0)
        {
            //lblErrorPaseClb.Text = "Seleccione un Puesto";
            InfoOut = "Seleccione un Puesto";
            return InfoOut;
        }




        //2018.07.27 MODQ
        //anterior
        //if (ddlModalidad.SelectedIndex == 0)
        //{
        //    lblErrorPaseClb.Text = "Seleccione una Modalidad";
        //    return InfoOut;
        //}
        //nuevo:...(condicionado por "SelectedValue" en lugar de "SelectedIndex")
        if (int.Parse(ddlTipoColaborador.SelectedValue.ToString()) == 0)
        {
            InfoOut = "Seleccione un Tipo de Colaborado";
            return InfoOut;
        }
        else
        {
            if (int.Parse(ddlModalidad.SelectedValue.ToString()) == 2)
            {
                InfoOut = "Seleccione una Modalidad";
                return InfoOut;
            }
        }
        //2018.07.27 MODQ

        return InfoOut;*/
    }

    $scope.fnPostulanteGrabar = function (_obj) {

        console.log(_obj);

        if (!$scope.objPostulante_selected) {
            alert("postulante no seleccionado");
            return
        }
        if (!$scope.paseColab) {
            alert("no se obtubieron los datos del postulante");
            return
        }

        validarDatosPase();
        validarDatosContrato();


        //valida empresa
        if (!_obj.slcEmpresa) {
            alert("¿Desea continua sin grabar un contrato?");
            return;
        }
        debugger;

        var _pntoMarcacionId = 0;
        var _anexo = 0;

        if (_obj.anexo) {
            _anexo = _obj.anexo;
        }
        console.log(_obj.slc_calendario);
        if (_obj.slc_calendario) {
            if (_obj.slc_calendario.nPntClnId) {
                _pntoMarcacionId = _obj.slc_calendario.nPntClnId
            }
        }


        /* var _objPostulante = {
             pnPersonaId: _obj.nPrsId
            , pnFicId: _obj.nFicId
 
            , pnAnexo: _obj.anexo
            , pnPntClnId: _pntoMarcacionId
            , pdtFchIngreso: _obj.fechaInicio
            , pnUsuarioRegistraId: $scope.Usuario.nUsuId
            , pnTpoColab: _obj.slcTipoAceptacion.nMaeItem
            , pnModForm: _obj.slcModalidaFormacion.nMaeItem
         }
         var _objContrato = {
             pdtFchFin: _obj
             , pnEmpId: _obj
             , pnTipoContratoId: _obj
             , pnPerfilId: _obj
             , pnCargoId: _obj
             , pnModalidadId: _obj
             , pnAreaId: _obj
             , pvCorreo: _obj
             , pcRenovable: _obj
         }*/

        var _param = {
            objPostulante:
                {
                     pnPersonaId: $scope.objPostulante_selected.nPrsId
                   , pnFicId: $scope.objPostulante_selected.nFicId

                   , pnAnexo: _obj.anexo
                   , pnPntClnId: _pntoMarcacionId
                   //, pdtFchIngreso: $filter('date')(_obj.fechaInicio, "MM-dd-yyyy")
                   , pdtFchIngreso: $filter('date')(_obj.fechaInicio, "dd-MM-yyyy") /*pdtFchIngreso type: string<<<<*/
                   , pnUsuarioRegistraId: $scope.Usuario.nUsuId
                   , pnTpoColab: _obj.slcTipoAceptacion.nMaeItem
                   , pnModForm: _obj.slcModalidaFormacion.nMaeItem
                }
            , objContrato:
                {
                      pnPersonaId: $scope.objPostulante_selected.nPrsId
                    //, pdtFchFin: $filter('date')(_obj.fechaFin, "MM-dd-yyyy")
                    , pdtFchFin: $filter('date')(_obj.fechaFin, "dd-MM-yyyy") /*pdtFchIngreso type: string<<<<*/
                    , pnEmpId: _obj.slcEmpresa.nEmpId
                    , pnTipoContratoId: _obj.slcTipoContrato.nMaeItem
                    , pnPerfilId: _obj.slcPerfilTec.nMaeItem
                    , pnCargoId: _obj.slcPuesto.nCargoId
                    , pnModalidadId: _obj.slcModalidadContrato.nMaeItem
                    , pnAreaId: _obj.slcArea.nAreaId
                    , pvCorreo: ($scope.listCorreoContrato == null ? _obj.txtCorreo : _obj.slcCorreo.vCorreo)

                    , pcMinTra: (_obj.renovable ? '1' : '0') /*new */
                    , pcRenovable: (_obj.renovable?'1':'0')
                    , pnUsuID: $scope.Usuario.nUsuId /*new */
                }
            , objProyecto:
                {
                      pnPrsId: $scope.objPostulante_selected.nPrsId
                    , pnProyectoId: _obj.slcServicio.CODPRO
                    //, pdtFchInicio: $filter('date')(_obj.fechaInicio, "dd-MM-yyyy") /*!important */
                    , pdtFchInicio: $filter('date')(_obj.fechaInicio, "MM-dd-yyyy") /*!important, pdtFchInicio type: DateTime<<<<  */
                    //, pdtFchFin: $filter('date')(_obj.fechaFin, "dd-MM-yyyy") /*!important */
                    , pdtFchFin: $filter('date')(_obj.fechaFin, "MM-dd-yyyy") /*!important,pdtFchFin type: DateTime<<  se cambio el formato ya que no ingresa los valores al API */
                    , pnGrpId: _obj.slcGrupo.nGrpId

                }
            , objProvision:
                {
                    pnPrsId: $scope.objPostulante_selected.nPrsId
                  , pdtFchIni: $filter('date')(_obj.fechaInicio, "MM-dd-yyyy") /*!important, pdtFchInicio type: DateTime<<<<  */
                  , pdtFchFin: $filter('date')(_obj.fechaFin, "MM-dd-yyyy") /*!important,pdtFchFin type: DateTime<<  se cambio el formato ya que no ingresa los valores al API */
                }
        }
        console.log(_param);

        ftyApiRequest._API_POST_REQUEST('Postulante', 'fPaseColaborador', _param)
        .success(function (response) {
            console.log(response);
            if (response.nMsjCode == 200) {
                $scope.fILListaPostulantes();
                fnalert('success', 'Aviso', 'Pase a Colaborador Exitoso', 4000);
                $("#modalPostulante_paseColaborador").modal('hide');
                $scope.objPostulante_selected = null;
                $scope.paseColab = null;
                //fILListaPostulantes(1); <<<<<<<<<<<<<<
            }
            else {
                fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
            }

        })
        .error(function (msj) {
            //console.error(msj);
            fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
        });

        /*
        var _param = {
              strOpcion: "5"
            , pnPersonaId : _obj.nPrsId
            , pnFicId: _obj.nFicId 
            , pnAnexo : _obj.anexo
            , pnPntClnId : _pntoMarcacionId
            , pdtFchIngreso: _obj.fechaInicio
            , pnUsuarioRegistraId: $scope.Usuario.nUsuId
            , pnTpoColab: _obj.slcTipoAceptacion.nMaeItem
            , pnModForm: _obj.slcModalidaFormacion.nMaeItem
        }
   
        ftyApiRequest._API_POST_REQUEST('Postulante', 'fPaseColaborador', _param)
        .success(function (response) {
            console.log(response);

            if (response.nMsjCode == 200) {
                //setError("Pase a Colaborador Exitoso");
                $scope.fILListaPostulantes();
                fnalert('success', 'Aviso', 'Se registro la evaluación', 4000);
                //fILListaPostulantes(1); <<<<<<<<<<<<<<
            }
            else {
                fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
            }

        })
        .error(function (msj) {
            //console.error(msj);
            fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
        });

        */




        /* console.log($scope.objPostulante_selected);
         console.log(_obj);
 
         var _pntoMarcacionId = 0;
         var _anexo = 0;
 
         if ( _obj.anexo) {
             _anexo =  _obj.anexo;
         }
 
         if ( _obj.slc_calendario) {
             if ( _obj.slc_calendario.pnPntMrcId) {
                 _pntoMarcacionId =  _obj.slc_calendario.pnPntMrcId
             }
         }
     
         var _param = {
              strOpcion: "5"
             ,pnPersonaId : _obj.nPrsId
             ,pnAnexo : _obj.anexo
             ,pnPntClnId : _pntoMarcacionId
         }
         debugger;
         ftyApiRequest._API_POST_REQUEST('Postulante', 'fPaseColaborador', _param)
         .success(function (response) {
             console.log(response);
 
             if (response.nMsjCode == 200) {
                 //setError("Pase a Colaborador Exitoso");
                 $scope.fILListaPostulantes();
                 fnalert('success', 'Aviso', 'Se registro la evaluación', 4000);
                 //fILListaPostulantes(1); <<<<<<<<<<<<<<
             }
             else {
                 fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
             }
 
         })
         .error(function (msj) {
             //console.error(msj);
             fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
         });
         
         */




    }


    iniciar();


})