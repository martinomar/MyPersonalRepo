﻿app.controller('MntRegistroVirtualController', function ($scope
        , $parse
        , $http
        , $window
        , $cookieStore
        , $location
        , ftyApiRequest
        ) {


    $scope.vtituloview = sessionStorage.getItem("vtituloview");

    var _loadMaestros = false;

    var _CONTEXT_ = 'FichaPostulante';

    $scope.listCargoContrto = [];

    function loadList_cargoDeContrato() {

        //ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aListCrgCntrto', _param)
        ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aListCrgCntrto', null)
         .success(function (response) {

             console.log(response);
             if (response.nMsjCode == 200) {
                 $scope.listCargoContrto = response.DtCollection;
             }
             else {
                 fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
             }
         })
        .error(function (msj) {
            //console.error(msj);
            fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
        })
    }



    function iniciar() {

        loadList_cargoDeContrato();

    }

    $scope.btnRegEnvrCorr = function (obj) {
        $scope.modalRegDialog_opt = null;
        if (obj) {

            if (obj.nroDoc == undefined || obj.nroDoc == null || obj.nroDoc == "") {
                fnalert('warning', 'Aviso', 'por favor ingrese el Número de Documento.', 4000);
                return;
            }
            if (obj.correo == undefined || obj.correo == null || obj.correo == "") {
                fnalert('warning', 'Aviso', 'por favor ingrese correo', 4000);
                return;
            }
            if (obj.nombre == undefined || obj.nombre == null || obj.nombre =="") {
                fnalert('warning', 'Aviso', 'por favor ingrese Nombre del Postulante', 4000);
                return;
            }
            if (obj.apellMat == undefined || obj.apellMat == null || obj.apellMat=="") {
                fnalert('warning', 'Aviso', 'por favor ingrese Apellido Materno', 4000);
                return;
            }
            if (obj.apellPat == undefined || obj.apellPat == null || obj.apellPat == "") {
                fnalert('warning', 'Aviso', 'por favor ingrese Apellido Paterno', 4000);
                return;
            }
            if (obj.cargo == undefined || obj.cargo == null || obj.cargo == "") {
                fnalert('warning', 'Aviso', 'por favor Seleccione el cargo al que postula ', 4000);
                return;
            }

            var _param = {
                'pvDocNro': obj.nroDoc
                ,'pvCorreo' : obj.correo
                ,'pvNombres' : obj.nombre
                ,'pvApeMaterno' : obj.apellMat
                ,'pvApePaterno' : obj.apellPat
                ,'pnCrgPresentarseId' : obj.cargo.nCrgPrsId
                , 'pvCarreraProf': obj.cargo.vDescripcion
                , 'pcModalidaRegistro': "2.1" /*<<< =================================*/
            };

            ftyApiRequest._API_POST_REQUEST(_CONTEXT_, 'aRegEnvrCrrPost', _param)
            .success(function (response) {
                console.log(response);
                debugger;
                if (response.nMsjCode == 200) {
                    $scope.postulante = null;
                    fnalert('success', 'Aviso', 'Se registró al postulante correctamente.', 7000);
                }
                else if (response.nMsjCode == 501) {
                    fnalert('warning', 'Aviso', response.cMsj, 4000);
                    angular.element('#inptDni').focus()
                    //$scope.postulante = null;
                }
                else {
                    $('#modalRegDialog').modal({ backdrop: 'static', keyboard: false });
                    $scope.modalRegDialog_opt = 1;
                    $scope.modal_errorDetails = response.cMsj;
                }
            })
            .error(function (msj) {
                //console.error(msj);
                fnalert('warning', 'Aviso', 'Algo no salio bien..', 4000);
            });
        }
        else {
            fnalert('warning', 'Aviso', 'Por Favor especifique los datos del postulante', 4000);
        }
    }

    iniciar();

});