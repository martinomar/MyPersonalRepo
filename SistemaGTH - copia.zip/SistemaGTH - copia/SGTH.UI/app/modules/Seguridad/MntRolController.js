﻿/* ------------------------------------------------------------------------*/
/* SISTEMA : Seguridad
/* SUBSISTEMA : Seguridad
/* NOMBRE : MntRolController.js
/* DESCRIPCIÓN : Controllador JS mantenimiento de roles
/* AUTOR : David Donayre
/* FECHA CREACIÓN : 16-05-2018
/* ------------------------------------------------------------------------*/
/* FECHA MODIFICACIÓN  EMPLEADO    
/* ------------------------------------------------------------------------*/

app.controller('MntRolController', function ($scope, $http, $cookieStore, $location, $filter, consultaCRUDRol, DTOptionsBuilder, DTColumnDefBuilder) {


});