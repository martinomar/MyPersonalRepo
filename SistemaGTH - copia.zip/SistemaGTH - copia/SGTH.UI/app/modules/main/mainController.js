﻿

/* ------------------------------------------------------------------------*/
/* SISTEMA     : Ficha Postulante
/* SUBSISTEMA  : Ficha Postulante
/* NOMBRE      : mainController.js
/* DESCRIPCIÓN : Controllador de eventos iniciales
/* AUTOR       : Martin Delgado (trainee APS)
/* FECHA CREACIÓN : 14/09/2018
/* ------------------------------------------------------------------------*/
/* FECHA MODIFICACIÓN  EMPLEADO    
/* ------------------------------------------------------------------------*/

app.controller('mainController', function ($scope, $http, $window, $cookieStore, $location) {
    var mvcUrl = _URLMvc;
    var baseUrl = _URLApiBase;
    $scope.urlImg = _URLApiBaseimg;
    $scope.sw_layout = true;
    $scope.nombre = "";
    $scope.target = "";
    $scope.rolactual = "";
    $scope.mostrar = true;
    $scope.mensaje = "";
    $scope.ver = false;
    $scope.listRol = JSON.parse(sessionStorage.getItem("listarol"));
    var _vxdata = JSON.parse(sessionStorage.getItem("datosusuario"));
    if (_vxdata != null) {
        $scope.url_avatar = $scope.urlImg + _vxdata.cImgUsuario;
    }





    $scope.logout = function () {
        $cookieStore.remove('usuario');
        window.location.href = mvcUrl + "index.html#/login";
    }
    $scope.CargaInicial = function () {
        $scope.mensaje = "";
        $scope.location = $location;
        $scope.$watch('location.search()', function () {
      
            // $scope.target = ($location.search()).key;
            var _target = ($location.search()).key;
            //if ($scope.target) {
            if (_target) {
                sessionStorage.setItem("key", _target);
                $location.url($location.path());

            } else if (sessionStorage.getItem("key")) {
                $scope.target = sessionStorage.getItem("key");
                sessionStorage.removeItem("key");
                $scope.ver = true;
                $scope.mensaje = "";
                $scope.mostrar = true;
                $scope.Login();
                $scope.Sistema();
            }
            else {
                if ($cookieStore.get('usuario') && $cookieStore.get('Roles')) {
                    $scope.ver = true;
                    $scope.Usuario = $cookieStore.get('usuario');
                    $scope.nombre = $scope.Usuario.cUsuNombres + " " + $scope.Usuario.cUsuApePat;

                    $scope.listarol = $cookieStore.get('Roles');
                    var length = $scope.listarol.length;

                    for (i = 0; i < length; i++) {
                        if ($scope.listarol[i].actual == true) {
                            $scope.rolactual = $scope.listarol[i].nom_rol;
                        }
                    }
                    $scope.menu();
                    $scope.Sistema();
                } else {
                    $scope.ver = false;
                    $scope.redirect();
                }
            }
        }, true);
    }

    $scope.redirect = function () {
        //$window.location.href = "https://www.sesperu.com/intranet/"
        $scope.ver = true;
        //$window.location.href = "/index.html#/login";
        window.location.href = mvcUrl + "index.html#/login";
    }

    $scope.Login = function () {

        $scope.Usuario = { key: $scope.target }
        $http({
            method: 'POST',
            contentType: 'application/json; charset=utf-8',
            url: _URLApiBase + 'Usuario/LIST_USUARIO',
            data: $.param($scope.Usuario),
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        }).success(function (response) {

            sessionStorage.setItem("datosusuario", JSON.stringify(response));
            $scope.Usuar = response;
            $scope.url_avatar = $scope.urlImg + $scope.Usuar.cImgUsuario;
            $cookieStore.put('usuario', response);

            if ($scope.Usuar.cUsuNombres == null) {
                $scope.redirect();
            }

            $scope.Usuario = $cookieStore.get('usuario');
            $scope.nombre = $scope.Usuario.cUsuNombres + " " + $scope.Usuario.cUsuApePat;
            $scope.rol();
            $scope.menu();

        }).error(function (error) {
            $scope.message = 'No se pudo Crear el registro: ' + error.message;
        });
    }

    $scope.rol = function () {
        $scope.Usuario = $cookieStore.get('usuario');
        $scope.rol1 = {
            nSisId: $scope.Usuario.nSisId,
            nUsuId: $scope.Usuario.nUsuId,
            strOpcion: '01',
            cRolEliminado: '0'
        }

        var fnListarRolesxUsuario = function (_param) {

            //var url = baseUrl + "Rol/LIST_ROLXUSUARIO?cRolEliminado=" + _param.cRolEliminado + "&strOpcion=" + _param.strOpcion + "&nSisId=" + _param.nSisId + "&nUsuId=" + _param.nUsuId;
            var url = baseUrl + "Rol/LIST_ROLXUSUARIO";
            return $http.get(url, { params: _param });
        }

        fnListarRolesxUsuario($scope.rol1)
             .success(function (response) {
                 $cookieStore.remove('Roles');
                 $scope.lista = [];
                 $scope.listRol = response;
                 sessionStorage.setItem("listarol", JSON.stringify(response));
                 var length = $scope.listRol.length;

                 if (length != 0) {
                     for (i = 0; i < length; i++) {
                         if ($scope.listRol[i].bRolFav == true) {
                             $scope.rolactual = $scope.listRol[i].cRolNom;
                         }

                         $scope.lista.push({
                             actual: $scope.listRol[i].bRolFav,
                             id_sistema_rol: $scope.listRol[i].nSisId,
                             id_rol: $scope.listRol[i].nRolId,
                             nom_rol: $scope.listRol[i].cRolNom,
                             nem_rol: $scope.listRol[i].cRolNem,
                             desc_rol: $scope.listRol[i].cRolDesc,
                             fav_rol: $scope.listRol[i].bRolFav
                         })
                     }
                     $cookieStore.put('Roles', $scope.lista);
                 } else {
                     $scope.mensaje = 'No se encontraron registros'
                     $cookieStore.put('Roles', $scope.lista);
                 }
             })
             .error(function (error) {
                 $scope.message = 'No se pudo Crear el registro: '
             });

    }

    $scope.ir = function () {

        window.location.href = "#/Home";
        $scope.lista = [];
        $scope.lista = $cookieStore.get('Roles');
        console.log($scope.lista);
        $scope.mostrar = false;
    };

    $scope.regresar = function () {
        $scope.mensaje = "";
        $scope.mostrar = true;
    };

    $scope.default = function (val) {
        $scope.rolNameArray = [];
        var length = $scope.lista.length;

        if ($scope.lista[val].fav_rol != false) {
            for (i = 0; i < length; i++) {
                $scope.lista[i].fav_rol = false
            }
            $scope.lista[val].fav_rol = true
        }
        $scope.ActualizarRol(val);
    }

    $scope.actual = function (val) {
        $scope.rolNameArray = [];
        var length = $scope.lista.length;

        if ($scope.lista[val].actual != false) {
            for (i = 0; i < length; i++) {
                $scope.lista[i].actual = false
            }
            $scope.lista[val].actual = true
        }
        angular.forEach($scope.lista, function (item) {
            if (item.actual) {
                $scope.rolactual = item.nom_rol;
            }
        });
        $scope.ActualizarRol(val);
        $cookieStore.remove('Roles');
        $cookieStore.put('Roles', $scope.lista);
    };

    $scope.ActualizarRol = function (val) {
        $scope.favcnt = 0;
        $scope.sescnt = 0;
        $scope.resultado = "";
        var length = $scope.lista.length;
        for (i = 0; i < length; i++) {
            if ($scope.lista[i].fav_rol == true) {
                $scope.favcnt = $scope.favcnt + 1;
            }
            if ($scope.lista[i].actual == true) {
                $scope.sescnt = $scope.sescnt + 1;
            }
        }

        if ($scope.sescnt == 0) {
            $scope.mensaje = "Seleccione un rol para su uso";
        }
        else if ($scope.sescnt > 1) {
            $scope.mensaje = "Seleccione solo un rol para su uso";
        }
        else if ($scope.favcnt == 0) {
            $scope.mensaje = "Seleccione un rol por defecto (default)";
        }
        else if ($scope.favcnt > 1) {
            $scope.mensaje = "Seleccione solo un rol por defecto (default)";
        }
        else {

            $scope.id_rol = 0;
            angular.forEach($scope.lista, function (item) {
                if (item.fav_rol) {
                    $scope.id_rol = item.id_rol;
                }
            });

            $scope.rol2 = {
                nSisId: $scope.lista[val].id_sistema_rol,
                nRolId: $scope.id_rol,
                nUsuId: $scope.Usuario.nUsuId,
                strOpcion: "03"
            }

            $http({
                method: 'POST',
                contentType: 'application/json; charset=utf-8',
                url: _URLApiBase + 'Rol/MantenimientoRol',
                data: $.param($scope.rol2),
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            }).success(function (response) {
                $scope.resultado = response;
                if ($scope.resultado != "OK") {
                    $scope.mensaje = "Error al asociar";
                }
                else {
                    $scope.mensaje = "Actualización satisfactoria";
                }
            }).error(function (error) {

                $scope.message = 'No se pudo Crear el registro: '
            });
        };
    };

    $scope.Cerrar = function () {
        $cookieStore.remove('Roles');
        $cookieStore.remove('usuario');
        $scope.redirect();
    };



    var _array_mantenedores_icons = [/*fuente:https://www.w3schools.com/icons/icons_reference.asp */
          { show: true, cssClass: "fa fa-building", pcMenuArch: "GesEmpresa" }
        , { show: true, cssClass: "fa fa-cogs", pcMenuArch: "GesProcesos" }
        , { show: true, cssClass: "fa fa-sitemap", pcMenuArch: "Organigrama" }
        , { show: true, cssClass: "glyphicon glyphicon-font", pcMenuArch: "Area" }
        , { show: true, cssClass: "glyphicon glyphicon-star-empty", pcMenuArch: "GesCompetencia" }
        , { show: true, cssClass: "glyphicon glyphicon-stats", pcMenuArch: "GesEscala" }
        , { show: true, cssClass: "fa fa-wpforms", pcMenuArch: "GesCompetencia" }
        , { show: true, cssClass: "fa fa-street-view", pcMenuArch: "Comportamiento" }
        , { show: true, cssClass: "fa fa-align-left", pcMenuArch: "Nivel" }
        , { show: true, cssClass: "fa fa-vcard-o", pcMenuArch: "Cargo" }
        , { show: true, cssClass: "fa fa-users", pcMenuArch: "Colaborador" }
        , { show: true, cssClass: "fa fa-user-md", pcMenuArch: "GesTipEvaluacion" }
        , { show: true, cssClass: "fa fa-gears", pcMenuArch: "" }
        , { show: true, cssClass: "fa fa-road", pcMenuArch: "Seguimiento" }
    ];

    function fnFilterMenu_getMenuIcons(_listInput, _listOutput, _arrayIcons, _mNivel, _mGrupo) {//
        //$scope.lstMenu_mantenedores = [];
        //$scope._archivos = [];
        $.each(_listInput, function (key, val) {

            //if (val.pnMenuNivel == _mNivel && val.pnMenuGrupo == _mGrupo) {
            if (val.nMenuNivel == _mNivel && val.pnMenuGrupo == _mGrupo) { /*27.10.2018 martin.delgado*/

                //val._MenuArch = val.cMenuArch.substring(1);//remove '#'  
                val._MenuArch = val.pcMenuArch.substring(1);//remove '#'   /*27.10.2018 martin.delgado*/
                //filtrando el icono a mostrar segun el nombre del archivo...
                if (_arrayIcons) {
                    for (var i = 0; i < _arrayIcons.length; i++) {
                        if (_arrayIcons[i].pcMenuArch == val._MenuArch) {
                            val._show = _arrayIcons[i].show;
                            val._cssClass = _arrayIcons[i].cssClass;
                            break;
                        }
                    }
                }
                else {
                    val._show = true;
                }
                if (val._show) {
                    _listOutput.push(val);
                }
            }
        });
        console.log(_listOutput);
    }

    $scope.menu = function () {

        //console.log('usuario', $scope.Usuario);

        $scope.rol3 = {
            nSisId: $scope.Usuario.nSisId,
            nUsuId: $scope.Usuario.nUsuId,
            nRolId: 0
        }

        $http({
            method: 'POST',
            //method: 'GET',
            contentType: 'application/json; charset=utf-8',
            url: _URLApiBase + 'Menu/LIST_MENU',
            data: $.param($scope.rol3),
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        }).success(function (response) {
            //console.log(response);
            //$scope.lstMenu = response;
            $scope.lstMenu = response.DtCollection; /*27.10.2018 martin.delgado*/

            //console.log($scope.lstMenu);



            $.each($scope.lstMenu, function (index, value) {
                //if (value.pnMenuNivel > 1) {
                if (value.nMenuNivel > 1) { /*27.10.2018 martin.delgado*/
                    //var _vmenu = value.pcMenuArch.replace('#', '');
                    var _vmenu = value.cMenuArch.replace('#', '');
                    $scope.lstMenu[index].iconmenu = "";
                    $.each(_array_mantenedores_icons, function (xindex, xvalue) {
                        //if (_vmenu == xvalue.pcMenuArch) {
                        if (_vmenu == xvalue.cMenuArch) {
                            $scope.lstMenu[index].iconmenu = xvalue.cssClass;
                        }
                    });
                }
            });
            //console.log($scope.lstMenu);
            //$scope.lstMenu_mantenedores = [];
            //fnFilterMenu_getMenuIcons($scope.lstMenu, $scope.lstMenu_mantenedores, _array_mantenedores_icons, 3, 4601);

            //$scope.lstMenu_adminAccesos = [];
            //fnFilterMenu_getMenuIcons($scope.lstMenu, $scope.lstMenu_adminAccesos, null, 3, 4669);

            //$scope.lstMenu_adminAcciones= [];
            //fnFilterMenu_getMenuIcons($scope.lstMenu, $scope.lstMenu_adminAcciones, null, 3, 4672);

            //$scope.lstMenu_evaluaciones = [];
            //fnFilterMenu_getMenuIcons($scope.lstMenu, $scope.lstMenu_evaluaciones, null, 3, 4677);


            //fnFilterMenu_getMenuIcons($scope.lstMenu, 3, 4671);

            var __valores = [];
            if (response.DtCollection == null || response.DtCollection.length == 0) {
                $scope.redirect();
            }
            $.each(response.DtCollection, function (index, value) {
                //if (value.pnMenuNivel == 3) {
                if (value.nMenuNivel == 3) { /*27.10.2018 martin.delgado*/
                    //__valores.push(value.pcMenuArch.replace('#', '/'));
                    __valores.push(value.cMenuArch.replace('#', '/'));
                }
            });
            __valores.push('/home');
            __valores.push('/datos');
            __valores.push('/login');
            $window.localStorage.setItem("objmenu", JSON.stringify(__valores));
            //console.log('menu');
        }).error(function (error) {
            $scope.message = 'No se pudo Crear el registro: '
        });
    }

    $scope.Sistema = function () {
        var fecha = new Date();
        var anno = fecha.getFullYear();
        $scope.annio = anno;
        $http({
            method: 'POST',
            contentType: 'application/json; charset=utf-8',
            url: _URLApiBase + 'Sistema/PiePagina',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        }).success(function (response) {
            //$scope.System = response[0].pcSisNombre;
            //console.log(response);
            $scope.System = response.DtCollection[0].cSisNombre; /*27.10.2018 martin.delgado*/
        }).error(function (error) {
            $scope.message = 'No se pudo Crear el registro: ' + error.message;
        });
    }

    $scope.fnEditarDatosUsuario = function () {
        var vkey = sessionStorage.getItem("key");
        //window.location.href = mvcUrl + "index.html#/datos?key="+vkey;
        window.location.href = mvcUrl + "index.html#/datos";
    }

    $scope.fnClickMenu = function (url, vnom, nsisid) {
        if (vnom) {
            var _vxdata = JSON.parse(sessionStorage.getItem("datosusuario"));
            var _menuData = {
                url: url
                , vnom: vnom
            }
            // $cookieStore.put('usuario', _vxdata.nUsuId);
            //$cookieStore.put('sistema', nsisid);

           // $window.sessionStorage.setItem('vtituloview', JSON.stringify(_menuData));
            $window.sessionStorage.setItem('vtituloview', vnom);

            //var vkey = sessionStorage.getItem("key");
            //window.location.href = url + "?key=" + vkey;
        }

    }

});