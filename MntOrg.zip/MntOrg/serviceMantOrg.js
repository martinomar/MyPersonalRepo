﻿/*---------------------------------------------------------------------------------*
* SISTEMA		: Nucleo
* SUBSISTEMA	: ---
* NOMBRE		: serviceMantOrg.js
* DESCRIPCIÓN	: este archivo define las rutas de acceso para las solicitudes a los metodos del API
* AUTOR		    : Martin Delgado
* FECHA		    : 2018-06-04 (yyyy-mm-dd)
*----------------------------------------------------------------------------------*	
* FECHA		    EMPLEADO                           MODIFICACIÓN				                        
*--------------¡----------------------------¡---------------------------------------------*
* 2018-06-04     Martin.Delgado               Creacion y Definicion de metodos

*--------------¡----------------------------¡---------------------------------------------*/


(function () {

    var serviceMantOrg = function ($http, $q) {
        var ApiCntrl_Entd = "MntOrgEntd";
        var ApiCntrl_Crgo = "MntOrgCarg";
        var ApiCntrl_AscP = "MntOrgAscP";

        var baseUrl = _URLApiBase;

        var RegistrarEntidad = function(_param){
            var url = baseUrl + ApiCntrl_Entd + "/fnRegistrarEntidad";
            return $http({
                method: 'POST',
                contenttype: 'application/json; charset=utf-8',
                url: url,
                data: $.param(_param),
                headers: { 'content-type': 'application/x-www-form-urlencoded' },
            })
        }
        var EditarEntidad = function (_param) {

            var url = baseUrl + ApiCntrl_Entd + "/fnEditarEntidad?pnAreaId=" + _param.pnAreaId + "&pcAreaNombre=" + _param.pcAreaNombre + "&pcAreaAbreviatura=" + _param.pcAreaAbreviatura + "&pcAreaApoyo=" + _param.pcAreaApoyo + "&pnAreaSuperiorId=" + _param.pnAreaSuperiorId + "&pnUsuarioModificaId=" + _param.pnUsuarioModificaId;
            return $http.get(url);
        }
        var EliminarEntidad= function (_param) {

            var url = baseUrl + ApiCntrl_Entd + "/fnEliminarEntidad?pnAreaId=" + _param.pnAreaId + "&pdtFechaFin=" + _param.pdtFechaFin + "&pnUsuarioModificaId=" + _param.pnUsuarioModificaId;
            return $http.get(url);
        }




        var RegistrarCargo = function (_param) {
            var url = baseUrl + ApiCntrl_Crgo+"/fnRegistrarCargo";
            return $http({
                method: 'POST',
                contenttype: 'application/json; charset=utf-8',
                url: url,
                data: $.param(_param),
                headers: { 'content-type': 'application/x-www-form-urlencoded' },
            })
        }
        var EditarCargo = function (_param) {
            
            var url = baseUrl + ApiCntrl_Crgo+"/fnEditarCargo?pnCargoId=" + _param.pnCargoId + "&pcCargoNombre=" + _param.pcCargoNombre + "&pcCargoAbreviatura=" + _param.pcCargoAbreviatura + "&pcCargoResponsable=" + _param.pcCargoResponsable + "&pnCargoSuperiorId=" + _param.pnCargoSuperiorId + "&pnUsuarioModificaId=" + _param.pnUsuarioModificaId;
            return $http.get(url);
        }
        var EliminarCargo = function (_param) {

            var url = baseUrl + ApiCntrl_Crgo+"/fnEliminarCargo?pnCargoId=" + _param.pnCargoId + "&pdtFechaFin=" + _param.pdtFechaFin + "&pnUsuarioModificaId=" + _param.pnUsuarioModificaId;
            return $http.get(url);
        }





        var AsociarPersona = function (_param) {
            var url = baseUrl + ApiCntrl_AscP+"/fnAcociarPersona";
            return $http({
                method: 'POST',
                contenttype: 'application/json; charset=utf-8',
                url: url,
                data: $.param(_param),
                headers: { 'content-type': 'application/x-www-form-urlencoded' },
            })
        }

        var EditarAsociarPersona = function (_param) {
            var url = baseUrl + ApiCntrl_AscP+"/fnEditarAsociaPersona?pnCargoPersonaId=" + _param.pnCargoPersonaId + "&pnCargoPersonaSuperiorId=" + _param.pnCargoPersonaSuperiorId + "&pnPersonaSuplenteId=" + _param.pnPersonaSuplenteId + "&pnUsuarioModificaId=" + _param.pnUsuarioModificaId;
            return $http.get(url);
        }

        var EliminarAsociaPersona = function (_param) {
            var url = baseUrl + ApiCntrl_AscP+"/fnEliminarAsociaPersona?pnCargoPersonaId=" + _param.pnCargoPersonaId + "&pdtFechaFin=" + _param.pdtFechaFin + "&pnUsuarioModificaId=" + _param.pnUsuarioModificaId;
            return $http.get(url);
        }

        return {
            RegistrarEntidad: RegistrarEntidad
            , EditarEntidad: EditarEntidad
            , EliminarEntidad: EliminarEntidad


            , RegistrarCargo: RegistrarCargo
            , EditarCargo: EditarCargo
            , EliminarCargo: EliminarCargo


            , AsociarPersona: AsociarPersona
            , EditarAsociarPersona: EditarAsociarPersona
            , EliminarAsociaPersona: EliminarAsociaPersona
        };
    }

    angular.module('servicioMantOrg', [])
    .factory("serviceMantOrg", serviceMantOrg);
})();