﻿/*---------------------------------------------------------------------------------*
* SISTEMA		: NUCLEO
* SUBSISTEMA	: NUCLEO
* NOMBRE		: MntOrgController.js
* DESCRIPCIÓN	: contiene los metodos de interaccion para los eventos de la vista html
* AUTOR		    : Martin Delgado
* FECHA		    : 2018-06-04 (yyyy-mm-dd)
*----------------------------------------------------------------------------------*	
* FECHA		    EMPLEADO                           MODIFICACIÓN				                        
*--------------¡----------------------------¡---------------------------------------------*
* 2018-06-04     Martin.Delgado               creacion, Definicion de eventos y metodos

*--------------¡----------------------------¡---------------------------------------------*/


app.controller('MntOrganigramaController', function ($scope, $http, $q, $cookieStore, $location, $filter, serviceNucleo_General, serviceMantOrg) {
    
    $scope.organigrama = [];
    $scope.Usuario = $cookieStore.get('usuario');
    if ($scope.Usuario!=null) {
        console.log('loged');
    }

    $scope.orgSelectOpts =
        [{ textOpt: 'Ver Detalle', actId: 1 }
        , { textOpt: 'Editar', actId: 2 }
        , { textOpt: 'Nuevo', actId: 3 }
        , { textOpt: 'Eliminar', actId: 4 }
        ]
    $scope.orgSelectOptsCE =
       [{ textOpt: 'Ver Detalle', actId: 1 }
       , { textOpt: 'Nuevo', actId: 3 }
       ];
    $scope.orgSelectOptsAr =
       [{ textOpt: 'Ver Detalle', actId: 1 }
        , { textOpt: 'Editar', actId: 2 }
        , { textOpt: 'Eliminar', actId: 4 }
       ];
    $scope.orgSelectOptsCrg =
       [{ textOpt: 'Ver Detalle', actId: 1 }
        , { textOpt: 'Editar', actId: 2 }
        , { textOpt: 'Eliminar', actId: 4 }
       ];
    $scope.orgSelectOptsClb =
       [{ textOpt: 'Ver Detalle', actId: 1 }
        , { textOpt: 'Editar', actId: 2 }
        , { textOpt: 'Eliminar', actId: 4 }
       ];
 

    function getDetaill_CE(id, ceId) {
        //traer los detalles de Cargo o Entidad
        var output = [];

        return output;
    }
    $scope.testParameter = "222";
    

    var _actId = null;
    var _ce = null;
    var _cOrgIndx = null;
    var _nIndx = null;
    $scope.ramaPadre_Info = null;
    

    function updateOrggg() {
        $scope.ModalOrgTree_data.info.cAreaNombre = $scope.ModalOrgTree_data.info.cAreaNombre + ' EDITED';

    }


    
      $scope.evntSlctAct = function (actId, ce, cOrgIndx, nIndx, ramaPadre_Info) {

        $scope.ramaPadre_Info = null;
        _actId = null;
        _ce = null;
        _cOrgIndx = null;
        _nIndx = null;
       //pasing values of "input parameters" to "controller variables", why? later we will need this values to Update or refresh the treeView for the client...
        _actId = actId;
        _ce = ce;
        _cOrgIndx = cOrgIndx;
        _nIndx = nIndx;
        $scope.ramaPadre_Info = ramaPadre_Info;

        $scope.ModalOrgTree_tittle = "????";
        $scope.ModalOrgTree_actId = actId;
        $scope.ModalOrgTree_modal_lg = 0;
        $scope.ModalOrgTree_cec = ce;
        $scope.ModalOrgTree_data = undefined;

        if (nIndx != undefined && nIndx != null) {
            $scope.ModalOrgTree_data = $scope.$eval(cOrgIndx)[nIndx].info;
        }
        else{
            $scope.ModalOrgTree_data = $scope.$eval(cOrgIndx);
        }

        if (ce.substring(0,5)=='table') {
            $scope.ModalOrgTree_modal_lg = 1;
        }
        console.log("$scope.ModalOrgTree_data",$scope.ModalOrgTree_data);
        if (ce == 'table_A' || ce == 'modal_A') {
                
            if (actId == 1) {

                if (ce == 'table_A') {
                    $scope.ModalOrgTree_tittle = '::Detalle de Areas::';
                 
                }
                else if (ce == 'modal_A') {

                    $scope.ModalOrgTree_tittle = '::Detalle Area::';
      
                }
                else {
                    alert('valor desconocido.');
                    return;
                }
            }
            else if (actId==2) {
                $scope.ModalOrgTree_tittle = '::Editar Area::';
               
                SetValueToInputsForm_Entidad(true);

              
            }
            else if (actId == 3) {
                $scope.lblEmpresa_Selected_RE = $scope.objSlcEmpresa;
                $scope.ModalOrgTree_tittle = '::Nuevo Areas::';
                $scope.ModalOrgTree_cec = 'modal_A';/*en el caso de las entidades-cabezeras, se obtiene 'table'...*/

                SetValueToInputsForm_Entidad();
                 
                $scope.ModalOrgTree_modal_lg = 0;
            }
            else if(actId==4){
                $scope.ModalOrgTree_tittle = '::Eliminar Areas::';
                //_orgData = _data;
            }
            else {
                alert('valor desconocido Areas...');
                return;
            }
            //$scope.ModalOrgTree_data = _orgData;
            $("#ModalOrgTree_entidad").modal("show");

        }
        else if (ce == 'table_C' || ce == 'modal_C') {
            if (actId == 1) {
                if (ce == 'table_C') {
                    $scope.ModalOrgTree_tittle = '::Detalle de Cargos::';
                   
                }
                else if (ce == 'modal_C') {

                    $scope.ModalOrgTree_tittle = '::Detalle Cargo::';
                   
                }
                else {
                    alert('valor desconocido.');
                    return;
                }
            }
            else if (actId == 2) {
                $scope.ModalOrgTree_tittle = '::Editar Cargo::';
                
                SetValueToInputsForm_Cargo(true);
            }
            else if (actId == 3) {
                $scope.ModalOrgTree_tittle = '::Nuevo Cargo::';
                $scope.ModalOrgTree_cec = 'modal_C';/*en el caso de los Cargos-cabezeras, se obtiene 'table'...*/
               
                SetValueToInputsForm_Cargo();
                $scope.ModalOrgTree_modal_lg = 0;
            }
            else if (actId == 4) {
                $scope.ModalOrgTree_tittle = '::Eliminar Cargo::';
         
            }
            else {
                alert('valor desconocido Cargo...');
                return;
            }

            $("#ModalOrgTree_cargo").modal("show");
           
        }
        else if (ce == 'table_Clb' || ce == 'modal_Clb') {
            if (actId == 1) {

                if (ce == 'table_Clb') {
                    $scope.ModalOrgTree_tittle = '::Detalle de Colaboradores::';
                   
                }
                else if (ce == 'modal_Clb') {

                    $scope.ModalOrgTree_tittle = '::Detalle de Colaborador::';
                }
                else {
                    alert('valor desconocido.');
                    return;
                }
            }
            else if (actId == 2) {
                $scope.ModalOrgTree_tittle = '::Editar Colaborador::';
               
                SetValueToInputsForm_Colab(true);
            }
            else if (actId == 3) {
                $scope.ModalOrgTree_tittle = '::Nuevo Colaborador::';
                $scope.ModalOrgTree_cec = 'modal_Clb';/*en el caso de los Colaboradores-cabezeras, se obtiene 'table'...*/
             
                SetValueToInputsForm_Colab();
                $scope.ModalOrgTree_modal_lg = 0;
            }
            else if (actId == 4) {
                $scope.ModalOrgTree_tittle = '::Eliminar Colaborador::';
               
                SetValueToInputsForm_Colab();
            }
            else {
                alert('valor desconocido Colaborador...');
                return;
            }

            
            $("#ModalOrgTree_colab").modal("show");
          
        }

        else {
            alert('valor desconocido zz1');
            return;
               
        }
          
      
    }

    function ActualizarOrganigrama(actId, _data, ce, optionalInfo01_, optionalInfo02_, strINDX) {

        strINDX = strINDX + "";//IndexOf no funciona en Enteros, por ello convertimos a string
        var nmric = $.isNumeric(strINDX);

        var arrIndx = [];
        if (nmric) {
            arrIndx.push(strINDX)
        }
        else {
           
            arrIndx = strINDX.split(",");
        }

        var arrNivel = arrIndx.length;

        if (arrNivel == 1) {

            if (ce == "table_C") {
                //console.log('Cargos*');
                //console.log($scope.organigrama[strINDX].Cargos);
            }
            else if (ce == "modal_A") {
                //console.log('Entidad');
                //console.log($scope.organigrama[strINDX]);
            }
        }

        if (arrNivel == 2) {

            if (ce == 'modal_C') {
                //console.log('Cargo');
                //console.log($scope.organigrama[arrIndx[0]].Cargos[arrIndx[1]]);
            }
            else if (ce == 'table_Clb') {
                //console.log('Colaboradores');
                //console.log($scope.organigrama[arrIndx[0]].Cargos[arrIndx[1]].Colaboradores);
            }

        }
        else if (arrNivel == 3) {
            if (ce == 'modal_Clb') {
                //console.log('Colaborador');
                //console.log($scope.organigrama[arrIndx[0]].Cargos[arrIndx[1]].Colaboradores[arrIndx[2]]);
            }
        }
    }



    $scope.btnModalOrgTree_close = function () {
        $('#ModalOrgTree_cargo').modal('hide');
        $('#ModalOrgTree_colab').modal('hide');
        $('#ModalOrgTree_entidad').modal('hide');
    }

    function filterList(_data,_valFilter) {
        var _finded = false;
        if (_data!=undefined && _data.length>0) {
            $.each(_data, function (key, val) {
                if (val.nAreaId == _valFilter) {
                    _finded = true;
                    return _finded;
                }
            })
        }
        return _finded;
    }
 
    function filterAndPut_OrgJSON_entidad_edit(_newDataInfo,_CRUD) {
        
         var _founded = false;


            $.each($scope.organigrama, function (key, val) {
                if (val != null && val.info.nAreaId == _newDataInfo.nAreaId) {
                    if (_CRUD == 'U') {
                        $scope.organigrama[key].info = _newDataInfo;
                    }
                    else if (_CRUD=='D') {
                        delete $scope.organigrama[key];
                    }
                    _founded = true;
                }
            });//end filter N# 01





            if (_founded) {
                return;
            }

            $.each($scope.organigrama, function (key, val) {
                $.each($scope.organigrama[key].Entidades, function (key2, val2) {
                    if (val2!=null && val2.info.nAreaId == _newDataInfo.nAreaId) {
                        if (_CRUD == 'U') {
                            $scope.organigrama[key].Entidades.info = _newDataInfo;
                        }
                        else if (_CRUD == 'D') {
                            delete $scope.organigrama[key].Entidades;
                        }
                        _founded = true;
                    }
                });//end filter N# 02
            });//end filter N# 01
            



            if (_founded) {
                return;
            }
            $.each($scope.organigrama, function (key, val) {
                $.each($scope.organigrama[key].Entidades, function (key2, val2) {
                    $.each($scope.organigrama[key].Entidades[key2].Entidades, function (key3, val3) {
                        if (val3 != null && val3.info.nAreaId == _newDataInfo.nAreaId) {
                            //console.log('Entidades,_CRUD:' + _CRUD )
                            //console.log("$scope.organigrama["+key+"].Entidades["+key2+"].Entidades["+key3+"]");
                            //console.log($scope.organigrama[key].Entidades[key2].Entidades[key3]);
                            if (_CRUD == 'U') {
                                $scope.organigrama[key].Entidades[key2].Entidades[key3].info = _newDataInfo;
                            }
                            else if (_CRUD == 'D') {
                                delete $scope.organigrama[key].Entidades[key2].Entidades[key3];
                            }
                            _founded = true;
                        }
                    });//end filter N# 03
                });//end filter N# 02
            });//end filter N# 01

            if (_founded) {
                return;
            }



            $.each($scope.organigrama, function (key, val) {
                $.each($scope.organigrama[key].Entidades, function (key2, val2) {
                    $.each($scope.organigrama[key].Entidades[key2].Entidades, function (key3, val3) {
                        $.each($scope.organigrama[key].Entidades[key2].Entidades[key3].Entidades, function (key4, val4) {
                            if (val4 != null && val4.info.nAreaId == _newDataInfo.nAreaId) {

                                if (_CRUD == 'U') {
                                    $scope.organigrama[key].Entidades[key2].Entidades[key3].Entidades[key4].info = _newDataInfo;
                                }
                                else if (_CRUD == 'D') {
                                    delete $scope.organigrama[key].Entidades[key2].Entidades[key3].Entidades[key4]
                                }
                                _founded = true;
                                
                            }

                        });//end filter N# 04
                    });//end filter N# 03
                });//end filter N# 02
            });//end filter N# 01

        
            if (_founded) {
                return;
            }

            $.each($scope.organigrama, function (key, val) {
                $.each($scope.organigrama[key].Entidades, function (key2, val2) {
                    $.each($scope.organigrama[key].Entidades[key2].Entidades, function (key3, val3) {
                        $.each($scope.organigrama[key].Entidades[key2].Entidades[key3].Entidades, function (key4, val4) {
                            $.each($scope.organigrama[key].Entidades[key2].Entidades[key3].Entidades[key4].Entidades, function (key5, val5) {
                                if (val5 != null && val5.info.nAreaId == _newDataInfo.nAreaId) {

                                    if (_CRUD == 'U') {
                                        $scope.organigrama[key].Entidades[key2].Entidades[key3].Entidades[key4].Entidades[key5].info = _newDataInfo;
                                    }
                                    else if (_CRUD == 'D') {
                                        delete $scope.organigrama[key].Entidades[key2].Entidades[key3].Entidades[key4].Entidades[key5];
                                    }
                                    _founded = true;
                                   
                                }
                            });//end filter N# 05

                        });//end filter N# 04
                    });//end filter N# 03
                });//end filter N# 02
            });//end filter N# 01
            

            if (_founded) {
                return;
            }

            
            $.each($scope.organigrama, function (key, val) {
                $.each($scope.organigrama[key].Entidades, function (key2, val2) {
                    $.each($scope.organigrama[key].Entidades[key2].Entidades, function (key3, val3) {
                        $.each($scope.organigrama[key].Entidades[key2].Entidades[key3].Entidades, function (key4, val4) {
                            $.each($scope.organigrama[key].Entidades[key2].Entidades[key3].Entidades[key4].Entidades, function (key5, val5) {
                                $.each($scope.organigrama[key].Entidades[key2].Entidades[key3].Entidades[key4].Entidades[key5].Entidades, function (key6, val6) {
                                    if (val6 != null && val6.info.nAreaId == _newDataInfo.nAreaId) {

                                        if (_CRUD == 'U') {
                                            $scope.organigrama[key].Entidades[key2].Entidades[key3].Entidades[key4].Entidades[key5].Entidades[key6].info = _newDataInfo;
                                        }
                                        else if (_CRUD == 'D') {
                                            delete $scope.organigrama[key].Entidades[key2].Entidades[key3].Entidades[key4].Entidades[key5].Entidades[key6];
                                        }
                                        _founded = true;

                                    }
                                });//end filter N# 06
                            });//end filter N# 05
                        });//end filter N# 04
                    });//end filter N# 03
                });//end filter N# 02
            });//end filter N# 01


    }


 



    $scope.fnku_txtSelecEntidad = function () {
        //$scope.txtSelecEntidad
    }
    $scope.consultar = function () {
        
    }
    
    $scope.salirM1 = function () {
        $('#modalOrg01_').modal('hide');
        $scope.ModalOrgTree_tittle = "::Registrar Entidad::";
        $scope.prRegEnt = false;
        $scope.prRegCarg = false;
        $scope.prAsocPer = false;
    }

   
    function searchTree_Org(element, param) {
        if (element.info.nAreaId == param.pnAreaSuperiorId) {

            var infoOject = {
                      nEmpresaId: param.pnEmpresaId
                    , nNivelId: param.pnNivelId
                    , cAreaNombre: param.pcAreaNombre
                    , cAreaAbreviatura: param.pcAreaAbreviatura
                    , nAreaSuperiorId: param.pnAreaSuperiorId
                    , cAreaApoyo: param.pcAreaApoyo
                    , cFechaInicio: param.pdtFechaInicio

                    , cNivelNombre: param.pcNivelNombre
                    , cAreaSuperiorNombre: param.pcAreaSuperiorNombre
                    , cEmpresaNombre: param.pcEmpresaNombre

                     /*, nAreaId: param.pnAreaId*/
                    , nAreaId: param.nAreaId

                    }

            element.Entidades.push({
                 Cargos: []
                ,Entidades: []
                , info: infoOject
            });
            return element;
        } else if (element.Entidades != null) {
            var i;
            var result = null;
            for (i = 0; result == null && i < element.Entidades.length; i++) {
                result = searchTree_Org(element.Entidades[i], param);
            }
            return result;
        }
        return null;
    }

    function searchTree_Org_Cargo(element, param) {


        if (element.info.nAreaId == param.pnAreaId) {/*<<<< "pnAreaId"!! */

            var infoOject = {
                cAreaAbreviatura: param.pcAreaAbreviatura
                     , cAreaNombre: param.pcAreaNombre
                     , cCargoAbreviatura: param.pcCargoAbreviatura
                     , cCargoNombre: param.pcCargoNombre
                     , cCargoResponsable: param.pcCargoResponsable
                     , cCargoSuperiorNombre: param.pcCargoSuperiorNombre

                     , cFechaInicio: param.pdtFechaInicio

                     , nCargoId: param.nCargoId

                     , nCargoSuperiorId: param.pnCargoSuperiorId
                     , nPersonasDesg: 0 /*useless?, por defecto, al registrar no tiene personas asignadas...*/
                     , nRow: 11111 /* useless? */

                     , nAreaId: param.pnAreaId
            }

            element.Cargos.push({
                info: infoOject
                , Colaboradores: []
            });
            return element;
        }

        else if (element.Entidades != null) {
            var i;
            var result = null;
            for (i = 0; result == null && i < element.Entidades.length; i++) {
                result = searchTree_Org_Cargo(element.Entidades[i], param);
            }
            return result;
        }
        return null;
    }



    function searchTree_Org_Colaborador(element, param) {

        if (element.info.nAreaId == param.pnAreaId) {/*<<<< "pnAreaId"!! */

            for (var i = 0; i < element.Cargos.length; i++) {

                if (element.Cargos[i].info.nCargoId == param.pnCargoId) {/*<<<< "pnCargoId"!! */
                    var infoOject = {
                        cCargoPerSupNom: param.pcCargoPerSupNom
                          , cFechaInicio: param.pdtFechaInicio
                          , cPersonaNom: param.pcPersonaNom
                          , cPersonaSuplNom: param.pcPersonaSuplNom
                          , nAreaId: param.pnAreaId
                          , nCargoId: param.pnCargoId

                          , nCargoPersonaId: param.pnCargoPersonaId
                          , nCargoPersonaSuperiorId: param.pnCargoPersonaSuperiorId

                          , nCrgContrato: param.pnCrgContrato

                          , nIdSeguridad: param.pnIdSeguridad

                          , nPersonaId: param.pnPersonaId
                          , nPersonaSuplenteId: param.pnPersonaSuplenteId
                          , nRow: 11111 /* useless ?  */

                    }

                    element.Cargos[i].Colaboradores.push({
                        info: infoOject
                        , Colaboradores: []
                    });
                    return element;
                }
            }
           
        }

        else if (element.Entidades != null) {
            var i;
            var result = null;
            for (i = 0; result == null && i < element.Entidades.length; i++) {
                result = searchTree_Org_Colaborador(element.Entidades[i], param);
            }
            return result;
        }
        return null;
    }


        /*
            function filterTree( str_ScopeOrg, objSearch) {
        
        
                //execute::
                //var objectFilter = { data: { nAreaId: 1254, cAreaNombre: 'test area'} }
                //debugger;
                //filterTree('organigrama', objectFilter);
                //return;
        
        
        
                //check line 95...
                var findedNode = false;
        
                iteracioness++;
                console.log('iteracioness',iteracioness);
                if (iteracioness > 100) { return; }
        
                var _org = [];
                    _org = $scope.$eval(str_ScopeOrg);
                
                if (_org.length == 0 || _org==undefined) { return findedNode; }
        
                for (i = 0; i < _org.length; i++) {
                    if (_org[i].info.nAreaId == objSearch.data.nAreaId) {
                        console.log($scope._org[i].info);
                        findedNode = true;
                        break;
                    }
                }
                if (findedNode) {
                    console.log('item finded!');
                    return findedNode;
                }
                else {
                    for ( j = 0; j < _org.length; j++) {
                        if (_org[j].hasOwnProperty('Entidades')) {
                            str_ScopeOrg += '['+j+'].Entidades';
                            if (filterTree(str_ScopeOrg, objSearch)) {
                                break;
                            } 
                        }
                    }
                    
                    //if ($scope._org.hasOwnProperty('Entidades')) {
                    //    str_ScopeOrg += '.Entidades';
                    //    filterTree(str_ScopeOrg, objSearch);
                    //}
                    //else {
                    return findedNode;
                    //}
                }
                
            }
        */
        function filtrarOrganigrama_desdePadre(param) {

        var out = null;
        for (var i = 0; out == null && i < $scope.organigrama.length; i++) {
            out = searchTree_Org($scope.organigrama[i], param);
        }
            return;
    }
        function filtrarOrganigrama_desdePadre_cargo(param) {

        var out = null;
        for (var i = 0; out == null && i < $scope.organigrama.length; i++) {
            out = searchTree_Org_Cargo($scope.organigrama[i], param);
        }
            return;
    }

        function filtrarOrganigrama_desdePadre_colaborador(param) {

            var out = null;
            for (var i = 0; out == null && i < $scope.organigrama.length; i++) {
                out = searchTree_Org_Colaborador($scope.organigrama[i], param);
            }
            return;
        }


            function filterListArea_RE(_data, _nEmpresaId, _nAreaId, _nNivelId) {

        var _outPut = [];

        if (_nAreaId != 0) {

            /*...*/
        }
        else {

            $.each(_data, function (i, val) {
                if (_data[i].nEmpresaId == _nEmpresaId) {
                    if (_nNivelId == 0 || _data[i].nNivelId < _nNivelId) {
                        if (_data[i].nAreaId != _nAreaId) {
                            _outPut.push(_data[i]);
                    }
                }
            }
            });
            _nNivelId = (_nNivelId == 1 ? 0 : - 1);


            $.each(_data, function (i, val) {

                if (_data[i].nEmpresaId == _nEmpresaId) {

                    if (_data[i].nAreaId != 0) {

                        if (_data[i].nAreaSuperiorId == _nNivelId) {

                            if (_data[i].nAreaId != _nAreaId) {
                                _outPut.push(_data[i]);
                        }
                    }
                }
            }
            });
            }
        return _outPut;

        }

            function filterListArea_RC(_data, _nEmpresaId, _nNivelId, _nAreaSuperiorId) {

        var _outPut = [];

        $.each(_data, function (i, val) {
            if (_data[i].nEmpresaId == _nEmpresaId) {
                if (_data[i].nNivelId == _nNivelId) {
                    _outPut.push(_data[i]);
            }
        }
        });
        return _outPut;

        }

            function filterListCargo_RC(_data, _nAreaId, _nCargoId) {
        var _outPut = [];

        $.each(_data, function (i, val) {
            if (val.nAreaId == _nAreaId || val.nAreaId == _nCargoId) {
                _outPut.push(val);
        }
        });
        return _outPut;
        }

            function filterListCargo_AP(_data, _nAreaId) {
        var _outPut = [];

        $.each(_data, function (i, val) {
            if (val.nAreaId == _nAreaId) {
                _outPut.push(val);
        }
        });
        return _outPut;
        }

    $scope.chg_objSlcNivel_RE = function (Nivel) {


        $scope.listEntidad_RE_Filtered = [];

        if (Nivel != undefined && Nivel != null) {

            $scope.listEntidad_RE_Filtered = filterListArea_RE($scope.listEntidad, $scope.objSlcEmpresa.pnCodEmp, 0, Nivel.cMaeValor)
    }
        }
    $scope.chng_objSlcNivel_RC = function (Nivel) {
        $scope.listEntidad_RC_Filtered = filterListArea_RC($scope.listEntidad, $scope.objSlcEmpresa.pnCodEmp, Nivel.cMaeValor, -1)
        }

    $scope.chng_objSlcEntidad_RC = function (Entidad) {
        $scope.listCargo_RC_Filtered = [];
        if (Entidad != undefined && Entidad != null) {
            var _nCargoSuperiorId = Entidad.nAreaSuperiorId;
            $scope.listCargo_RC_Filtered = filterListCargo_RC($scope.listCargo, Entidad.nAreaId, _nCargoSuperiorId);
    }
        }

    $scope.chng_objSlcNivel_AP = function (Nivel) {
        $scope.listEntidad_AP_Filtered = filterListArea_RC($scope.listEntidad, $scope.objSlcEmpresa.pnCodEmp, Nivel.cMaeValor, -1)
        }
    $scope.chng_objSlcEntidad_AP = function (Entidad) {
        $scope.listCargo_AP_Filtered = filterListCargo_AP($scope.listCargo, Entidad.nAreaId);
        }

    $scope.chng_objSlcCargo_AP = function (Cargo) {


        $scope.listSuperior_AP_Filtered = [];
        $.each($scope.listCargoPersona, function (i, val) {
            if (val.nCargoId == Cargo.nCargoSuperiorId) {
                $scope.listSuperior_AP_Filtered.push(val);
        }
        })
        }

            function fgenerarOrganigrama(_areas, _cargos) {

        $scope.liArea = [];
        $.each(_areas, function (key, val) {
            if (val.nAreaSuperiorId == 0) {
                $scope.liArea.push({
                        nAreaId: val.nAreaId
                    , cAreaNombre: val.cAreaNombre
                    , nNivelId: val.nNivelId
                    , cNivelNombre: val.cNivelNombre
                    , Cargos: []
                    , Entidades: []
                });

        }
        });
        $.each($scope.liArea, function (key, val) {
            $.each(_areas, function (key2, val2) {
                if (val2.nAreaSuperiorId == val.nAreaId) {
                    $scope.liArea[key].Entidades.push({
                            nAreaId: val2.nAreaId
                                                    , cAreaNombre: val2.cAreaNombre
                                                    , nNivelId: val2.nNivelId
                                                    , cNivelNombre: val2.cNivelNombre
                                                     , Cargos: []
                                                    , Entidades: []
                    });

            }
            });
        });
        $.each($scope.liArea, function (key, val) {
            $.each($scope.liArea[key].Entidades, function (key2, val2) {
                $.each(_areas, function (key3, val3) {
                    if (val3.nAreaSuperiorId == val2.nAreaId) {
                        $scope.liArea[key].Entidades[key2].Entidades.push({
                                nAreaId: val3.nAreaId
                                                            , cAreaNombre: val3.cAreaNombre
                                                            , nNivelId: val3.nNivelId
                                                            , cNivelNombre: val3.cNivelNombre
                                                             , Cargos: []
                                                            , Entidades: []
                        });

                }
                });
            });
        });


        $.each($scope.liArea, function (key, val) {
            $.each($scope.liArea[key].Entidades, function (key2, val2) {
                $.each($scope.liArea[key].Entidades[key2].Entidades, function (key3, val3) {
                    $.each(_areas, function (key4, val4) {
                        if (val4.nAreaSuperiorId == val3.nAreaId) {
                            $scope.liArea[key].Entidades[key2].Entidades[key3].Entidades.push({
                                    nAreaId: val4.nAreaId
                                                                , cAreaNombre: val4.cAreaNombre
                                                                , nNivelId: val4.nNivelId
                                                                , cNivelNombre: val4.cNivelNombre
                                                                 , Cargos: []
                                                                , Entidades: []
                            });

                    }
                    });
                });
            });
        });
        $.each($scope.liArea, function (key, val) {
            $.each($scope.liArea[key].Entidades, function (key2, val2) {
                $.each($scope.liArea[key].Entidades[key2].Entidades, function (key3, val3) {
                    $.each($scope.liArea[key].Entidades[key2].Entidades[key3].Entidades, function (key4, val4) {
                        $.each(_areas, function (key5, val5) {
                            if (val5.nAreaSuperiorId == val4.nAreaId) {
                                $scope.liArea[key].Entidades[key2].Entidades[key3].Entidades[key4].Entidades.push({
                                        nAreaId: val5.nAreaId
                                                                    , cAreaNombre: val5.cAreaNombre
                                                                    , nNivelId: val5.nNivelId
                                                                    , cNivelNombre: val5.cNivelNombre
                                                                    , Cargos: []
                                                                    , Entidades: []
                                });

                        }
                        });
                    });
                });
            });
        });

        }

            function fgenerarOrganigrama_1_3_Area(_areas) {

        var liArea = [];
        $.each(_areas, function (key, val) {
            if (val.nAreaSuperiorId == 0) {
                liArea.push({
                        info: _areas[key]
                    , Cargos: []
                    , Entidades: []
                });

        }
        });
        $.each(liArea, function (key, val) {
            $.each(_areas, function (key2, val2) {
                if (val2.nAreaSuperiorId == val.info.nAreaId) {
                    liArea[key].Entidades.push({
                            info: _areas[key2]
                        , Cargos: []
                        , Entidades: []
                    });
            }
            });

        });

        $.each(liArea, function (key, val) {
            $.each(liArea[key].Entidades, function (key2, val2) {
                $.each(_areas, function (key3, val3) {
                    if (val3.nAreaSuperiorId == val2.info.nAreaId) {
                        liArea[key].Entidades[key2].Entidades.push({
                                info: _areas[key3]
                            , Cargos: []
                            , Entidades: []
                        });

                }
                });
            });
        });


        $.each(liArea, function (key, val) {
            $.each(liArea[key].Entidades, function (key2, val2) {
                $.each(liArea[key].Entidades[key2].Entidades, function (key3, val3) {
                    $.each(_areas, function (key4, val4) {
                        if (val4.nAreaSuperiorId == val3.info.nAreaId) {
                            liArea[key].Entidades[key2].Entidades[key3].Entidades.push({
                                    info: _areas[key4]
                                , Cargos: []
                                , Entidades: []
                            });

                    }
                    });
                });
            });
        });
        $.each(liArea, function (key, val) {
            $.each(liArea[key].Entidades, function (key2, val2) {
                $.each(liArea[key].Entidades[key2].Entidades, function (key3, val3) {
                    $.each(liArea[key].Entidades[key2].Entidades[key3].Entidades, function (key4, val4) {
                        $.each(_areas, function (key5, val5) {
                            if (val5.nAreaSuperiorId == val4.info.nAreaId) {
                                liArea[key].Entidades[key2].Entidades[key3].Entidades[key4].Entidades.push({
                                        info: _areas[key5]
                                        , Cargos: []
                                        , Entidades: []
                                });

                        }
                        });
                    });
                });
            });
        });
        return liArea;

        }

            function fgenerarOrganigrama_2_3_Cargo(_areas, _cargos) {
        var _liResult = _areas;

        $.each(_liResult, function (key, val) {
            $.each(_cargos, function (key2, val2) {
                if (val2.nAreaId == val.info.nAreaId) {
                    _liResult[key].Cargos.push({
                            info: _cargos[key2]
                        , Colaboradores: []
                    });
            }
            });

        });

        $.each(_liResult, function (key, val) {
            $.each(_liResult[key].Entidades, function (key2, val2) {
                $.each(_cargos, function (key3, val3) {
                    if (val3.nAreaId == val2.info.nAreaId) {
                        _liResult[key].Entidades[key2].Cargos.push({
                                info: _cargos[key3]
                          , Colaboradores: []
                        });

                }
                });
            });
        });


        $.each(_liResult, function (key, val) {
            $.each(_liResult[key].Entidades, function (key2, val2) {
                $.each(_liResult[key].Entidades[key2].Entidades, function (key3, val3) {
                    $.each(_cargos, function (key4, val4) {
                        if (val4.nAreaId == val3.info.nAreaId) {
                            _liResult[key].Entidades[key2].Entidades[key3].Cargos.push({
                                    info: _cargos[key4]
                                , Colaboradores: []
                            });

                    }
                    });
                });
            });
        });
        $.each(_liResult, function (key, val) {
            $.each(_liResult[key].Entidades, function (key2, val2) {
                $.each(_liResult[key].Entidades[key2].Entidades, function (key3, val3) {
                    $.each(_liResult[key].Entidades[key2].Entidades[key3].Entidades, function (key4, val4) {
                        $.each(_cargos, function (key5, val5) {
                            if (val5.nAreaId == val4.info.nAreaId) {
                                _liResult[key].Entidades[key2].Entidades[key3].Entidades[key4].Cargos.push({
                                        info: _cargos[key5]
                                     , Colaboradores: []
                                });
                        }
                        });
                    });
                });
            });
        });

        $.each(_liResult, function (key, val) {
            $.each(_liResult[key].Entidades, function (key2, val2) {
                $.each(_liResult[key].Entidades[key2].Entidades, function (key3, val3) {
                    $.each(_liResult[key].Entidades[key2].Entidades[key3].Entidades, function (key4, val4) {
                        $.each(_liResult[key].Entidades[key2].Entidades[key3].Entidades[key4].Entidades, function (key5, val5) {
                            $.each(_cargos, function (key6, val6) {
                                if (val6.nAreaId == val5.info.nAreaId) {
                                    _liResult[key].Entidades[key2].Entidades[key3].Entidades[key4].Entidades[key5].Cargos.push({
                                            info: _cargos[key6]
                                         , Colaboradores: []
                                    });
                            }
                            });
                        });
                    });
                });
            });
        });
        return _liResult;
        }

            function fgenerarOrganigrama_3_3_Colaboradores(_areas_cargos, _CargoPersona) {
        var _liResult = _areas_cargos;

        $.each(_liResult, function (key, val) {
            $.each(_liResult[key].Cargos, function (key2, val2) {
                $.each(_CargoPersona, function (key3, val3) {
                    if (val3.nCargoId == val2.info.nCargoId) {
                        _liResult[key].Cargos[key2].Colaboradores.push({
                                info: _CargoPersona[key3]
                        });

                }
                });
            });
        });


        $.each(_liResult, function (key, val) {
            $.each(_liResult[key].Entidades, function (key2, val2) {
                $.each(_liResult[key].Entidades[key2].Cargos, function (key3, val3) {
                    $.each(_CargoPersona, function (key4, val4) {
                        if (val4.nCargoId == val3.info.nCargoId) {
                            _liResult[key].Entidades[key2].Cargos[key3].Colaboradores.push({
                                    info: _CargoPersona[key4]
                            });

                    }
                    });
                });
            });
        });
                //return _liResult;
        $.each(_liResult, function (key, val) {
            $.each(_liResult[key].Entidades, function (key2, val2) {
                $.each(_liResult[key].Entidades[key2].Entidades, function (key3, val3) {
                    $.each(_liResult[key].Entidades[key2].Entidades[key3].Cargos, function (key4, val4) {
                        $.each(_CargoPersona, function (key5, val5) {
                            if (val5.nCargoId == val4.info.nCargoId) {
                                _liResult[key].Entidades[key2].Entidades[key3].Cargos[key4].Colaboradores.push({
                                        info: _CargoPersona[key5]
                                });
                        }
                        });
                    });
                });
            });
        });

        $.each(_liResult, function (key, val) {
            $.each(_liResult[key].Entidades, function (key2, val2) {
                $.each(_liResult[key].Entidades[key2].Entidades, function (key3, val3) {
                    $.each(_liResult[key].Entidades[key2].Entidades[key3].Entidades, function (key4, val4) {
                        $.each(_liResult[key].Entidades[key2].Entidades[key3].Entidades[key4].Cargos, function (key5, val5) {
                            $.each(_CargoPersona, function (key6, val6) {
                                if (val6.nCargoId == val5.info.nCargoId) {
                                    _liResult[key].Entidades[key2].Entidades[key3].Entidades[key4].Cargos[key5].Colaboradores.push({
                                            info: _CargoPersona[key6]
                                    });
                            }
                            });
                        });
                    });
                });
            });
        });

        $.each(_liResult, function (key, val) {
            $.each(_liResult[key].Entidades, function (key2, val2) {
                $.each(_liResult[key].Entidades[key2].Entidades, function (key3, val3) {
                    $.each(_liResult[key].Entidades[key2].Entidades[key3].Entidades, function (key4, val4) {
                        $.each(_liResult[key].Entidades[key2].Entidades[key3].Entidades[key4].Entidades, function (key5, val5) {
                            $.each(_liResult[key].Entidades[key2].Entidades[key3].Entidades[key4].Entidades[key5].Cargos, function (key6, val6) {
                                $.each(_CargoPersona, function (key7, val7) {
                                    if (val7.nCargoId == val6.info.nCargoId) {
                                        _liResult[key].Entidades[key2].Entidades[key3].Entidades[key4].Entidades[key5].Cargos[key6].Colaboradores.push({
                                                info: _CargoPersona[key7]
                                        });
                                }
                                });
                            });
                        });
                    });
                });
            });
        });
        return _liResult;
        }

            function fListaNucleo() {
        var _param = {
                pnEmpresaId: 0
            };
        serviceNucleo_General.listarNucleo(_param)
       .success(function (data) {
           if (data.message != "") {
               console.error(data.message);
               return;
       }
           //console.log(data);

           $scope.listaEmpresa = data.listEmpresa;
           if (data.listEmpresa.length > 0) {

               $scope.objSlcEmpresa = $scope.listaEmpresa[1];
       }

           $scope.listEntidad = data.listArea;
           $scope.objSlcEntid = $scope.listEntidad[0];
           $scope.listPersona = data.listPersona;
           $scope.listCargoPersona = data.listCargoPersona;/* ! */
           $scope.listaNivel = data.listNivel;
           $scope.listCargo = data.listCargo;


           /*↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ !IMPORTANT*/
           $scope.organigrama = fgenerarOrganigrama_1_3_Area(data.listArea);
           $scope.organigrama = fgenerarOrganigrama_2_3_Cargo($scope.organigrama, data.listCargo);
           $scope.organigrama = fgenerarOrganigrama_3_3_Colaboradores($scope.organigrama, data.listCargoPersona);
           /*↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑*/
           console.log($scope.organigrama);
        }).error(function (error) {
           console.error(error);
        });
        }




            function fValidarUnicoEntSinSuperiorBL(_nAreaId, _nEmpresaId) {
        var _out = 0;

        if ($scope.listEntidad.length > 0) {

            $.each($scope.listEntidad, function (key, val) {

                if ((val.nAreaSuperiorId == null ? 0 : val.nAreaSuperiorId) == 0

                        && val.nEmpresaId == _nEmpresaId
                        && val.nAreaId == _nAreaId) {
                    _out++;
            }
            });
            }
        return _out;

        }

    $scope.evntSlctEmpresa_RE = function (_Empresa) {


        //console.log(_Empresa);
        //console.log($scope.listaNivel[0]);
        return;
        $scope.listaNivel_RE_Filtered = [];
        $.each($scope.listaNivel, function (key, val) {
            if (val.nEmpresaId == _Empresa.pnCodEmp) {
                $scope.listaNivel_RE_Filtered.push(val);
        }
        });

        }


    $scope.btnRegistrarEnt = function () {

        if ($scope.objSlcNivel_RE == undefined || $scope.objSlcNivel_RE == null) {
            alert("Nivel es un campo requerido");
            return;
    }
        if ($scope.txtNombre_RE == "" || $scope.txtNombre_RE == undefined) {
            alert("Nombre es un campo requerido");
            return;
    }
        if ($scope.txtAbrev_RE == "" || $scope.txtAbrev_RE == undefined) {
            alert("Abreviatura es un campo requerido");
            return;
    }


        //objEntidad.pnEmpresaId = Convert.ToInt32(ddlEmpresa.SelectedValue);
        //Int32 nResultado = new BLEntidad().fValidarUnicoEntSinSuperiorBL(objEntidad); 
        //var nResultado = NUC_GEN_ValEntSinSup(param.pnAreaSuperiorId, param.pnEmpresaId);


        if ($scope.objSlcNivelSup_RE == undefined) {
            alert("Superior es un campo requerido .");
            return;
    }

        var nResultado = fValidarUnicoEntSinSuperiorBL($scope.objSlcNivelSup_RE.nAreaId, $scope.lblEmpresa_Selected_RE.pnCodEmp);
        //console.log($scope.objSlcNivelSup_RE);
        //console.log(nResultado);
        if ($scope.objSlcNivelSup_RE == undefined && nResultado > 0) {
            alert("Superior es un campo requerido");
            return;
    }
        if ($scope.txtFechaInicio_RE == undefined || $scope.txtFechaInicio_RE == null) {
            alert("La fecha de inicio es obligatoria");
            return;
    }
        //if (!IsDate(txtFchIniEntReg.Text))
        //{
        //    lblRegEntError.Text = "Ingrese una fecha de Inicio Correcta";
        //    return;
        //}

        var datNow = new Date();

        //if (Convert.ToDateTime(txtFchIniEntReg.Text) > dtFechaActual)
        if ($scope.txtFechaInicio_RE > datNow) {
            alert("La fecha de inicio no puede ser mayor a la fecha actual");
            return;
    }


        var param = {
                pnEmpresaId: $scope.lblEmpresa_Selected_RE.pnCodEmp
            , pcEmpresaNombre: $scope.lblEmpresa_Selected_RE.pcAliasEmp /*for update Organigrama Only*/

            , pnNivelId: parseInt($scope.objSlcNivel_RE.cMaeValor) //important parseInt, because it will cause troubles later..
            , pcNivelNombre: $scope.objSlcNivel_RE.cMaeDenom /*for update Organigrama Only*/

            , pcAreaNombre: $scope.txtNombre_RE
            , pcAreaAbreviatura: $scope.txtAbrev_RE

            , pnAreaSuperiorId: $scope.objSlcNivelSup_RE.nAreaId
            , pcAreaSuperiorNombre: $scope.objSlcNivelSup_RE.cAreaNombre /*for update Organigrama Only*/

            , pcAreaApoyo: ($scope.txtApoyo_RE == true ? '1' : '0')
            /*, pdtFechaInicio: getDateStringFromInputDtVal($scope.txtFechaInicio_RE)*/
            , pdtFechaInicio: $filter('date')($scope.txtFechaInicio_RE, "MM-dd-yyyy")
    }



        serviceMantOrg.RegistrarEntidad(param)
           .success(function (data) {

               alert(data.cMsj);
               //debugger;
               if (data.nMsjCode == 200) {

                   param.nAreaId = data.nMsj;//<<<<<<<<<<<<<<<<<<<

                   if ($scope.ModalOrgTree_data == undefined) {//from the button "register entidad"
                       filtrarOrganigrama_desdePadre(param);
                   }
                   else {
                       if (!actualizarOrganigrama_Entidad(param)) {
                           console.error('error', 'no se logro asignar los valores al conjunto de datos')
                   }
               }
                   SetValueToInputsForm_Entidad(null);

           }
               //$("#ModalOrgTree_entidad").modal("hide");
               //fILLIstarGrillaOrg(); //REFRESH JSON.Organigrama
        }).error(function (error) {
               console.error(error);
        });

        }

    $scope.btnEditarEnt = function () {

        if ($scope.objSlcNivel_RE == undefined || $scope.objSlcNivel_RE == null) {
            alert("Nivel es un campo requerido");
            return;
    }
        if ($scope.txtNombre_RE == "" || $scope.txtNombre_RE == undefined) {
            alert("Nombre es un campo requerido");
            return;
    }
        if ($scope.txtAbrev_RE == "" || $scope.txtAbrev_RE == undefined) {
            alert("Abreviatura es un campo requerido");
            return;
    }
        if ($scope.objSlcNivelSup_RE == undefined) {
            alert("Superior es un campo requerido .");
            return;
    }

        var nResultado = fValidarUnicoEntSinSuperiorBL($scope.objSlcNivelSup_RE.nAreaId, $scope.lblEmpresa_Selected_RE.pnCodEmp);

        //if ($scope.objSlcNivelSup_RE == undefined && nResultado > 0) {
        //    alert("Superior es un campo requerido");
        //    return;
        //}
        //if ($scope.txtFechaInicio_RE == undefined || $scope.txtFechaInicio_RE == null) {
        //    alert("La fecha de inicio es obligatoria");
        //    return;
        //}

        //if (!IsDate(txtFchIniEntReg.Text))
        //{
        //    lblRegEntError.Text = "Ingrese una fecha de Inicio Correcta";
        //    return;
        //}

        var datNow = new Date();

        //if (Convert.ToDateTime(txtFchIniEntReg.Text) > dtFechaActual)
        if ($scope.txtFechaInicio_RE > datNow) {
            alert("La fecha de inicio no puede ser mayor a la fecha actual");
            return;
    }

        var param = {
                pnAreaId: $scope.ModalOrgTree_data.nAreaId
            , pcAreaNombre: $scope.txtNombre_RE
            , pcAreaAbreviatura: $scope.txtAbrev_RE
            , pnAreaSuperiorId: $scope.objSlcNivelSup_RE.nAreaId
            , pcAreaApoyo: ($scope.txtApoyo_RE == true ? '1' : '0')
            , pnUsuarioModificaId: $scope.Usuario.nUsuId
    }
        if ($scope.Usuario == null || $scope.Usuario ==undefined) {
            alert('Los se obtuvo los datos del usuario, consulte al administrador de sistemas...');
    }

        serviceMantOrg.EditarEntidad(param)
           .success(function (data) {
               //console.log(data);
               alert(data.cMsj);
               if (data.nMsjCode == 200) {

                   if (actualizarOrganigrama_Entidad(param)) {
                       $scope.ModalOrgTree_data = undefined;// 'cause -> SetValueToInputsForm_Entidad - condition if ...
                       SetValueToInputsForm_Entidad();
                       $("#ModalOrgTree_entidad").modal("hide");
               }

               }
               else {
                   console.error(data.cMsj);
           }
               //fILLIstarGrillaOrg(); //REFRESH JSON.Organigrama
        }).error(function (error) {
               console.error(error);
        });



        }

            function actualizarOrganigrama_Entidad(param) {
        var done = false;
        if (_actId ==2) {
            $scope.ModalOrgTree_data.cAreaNombre = param.pcAreaNombre
            //pnAreaId: $scope.ModalOrgTree_data.nAreaId
            $scope.ModalOrgTree_data.cAreaAbreviatura = param.pcAreaAbreviatura
            $scope.ModalOrgTree_data.nAreaSuperiorId = param.pnAreaSuperiorId
            $scope.ModalOrgTree_data.cAreaApoyo = param.pcAreaApoyo

        }
        else if (_actId == 3) {

            //seting to object..
            var infoOject = {
                    nEmpresaId: param.pnEmpresaId
                    , nNivelId: param.pnNivelId
                    , cAreaNombre: param.pcAreaNombre
                    , cAreaAbreviatura: param.pcAreaAbreviatura
                    , nAreaSuperiorId: param.pnAreaSuperiorId
                    , cAreaApoyo: param.pcAreaApoyo
                    , cFechaInicio: param.pdtFechaInicio

                    , cNivelNombre: param.pcNivelNombre
                    , cAreaSuperiorNombre: param.pcAreaSuperiorNombre
                    , cEmpresaNombre: param.pcEmpresaNombre

                /*, nAreaId: param.pnAreaId*/
                    , nAreaId: param.nAreaId

        }
            //actualizar organigrama...
            $scope.ModalOrgTree_data.push({
                    info: infoOject,
                    Cargos: [],
                    Entidades: [],

            });


            $scope.listEntidad.push(infoOject);

        }
        else if (_actId ==4) {
            //$scope.ModalOrgTree_data.splice(_nIndx, 1);
            $scope.$eval(_cOrgIndx).splice(_nIndx, 1);

            console.log('$scope.listEntidad', $scope.listEntidad);
            //removing "Area" from "scope.List..."
            if ($scope.listEntidad.length > 0) {
                var _length = $scope.listEntidad.length;
                for (var i = 0; i < _length; i++) {
                    if ($scope.listEntidad[i].nAreaId == param.pnAreaId) {/*<<<<<<<< !Important "pnAreaId", not "nAreaId" */
                        console.log('($scope.listEntidad[' + i +'].nAreaId', $scope.listEntidad[i].nAreaId);
                        $scope.listEntidad.splice(i, 1);
                        i = _length;
                }
            }
        }

            }

        done = true;
        return done;
        }

            function actualizarOrganigrama_Cargo(param) {
        var done = false;
        if (_actId == 2) {

            $scope.ModalOrgTree_data.cCargoNombre = param.pcCargoNombre;
            $scope.ModalOrgTree_data.cCargoAbreviatura = param.pcCargoAbreviatura;
            $scope.ModalOrgTree_data.nCargoSuperiorId = param.pnCargoSuperiorId;
            $scope.ModalOrgTree_data.cCargoSuperiorNombre = param.pcCargoSuperiorNombre;
            $scope.ModalOrgTree_data.cCargoResponsable = param.pcCargoResponsable;

        }
        else if (_actId ==3) {
            //seting to object..
            var infoOject = {
                    cAreaAbreviatura: param.pcAreaAbreviatura
                    , cAreaNombre: param.pcAreaNombre
                    , cCargoAbreviatura: param.pcCargoAbreviatura
                    , cCargoNombre: param.pcCargoNombre
                    , cCargoResponsable: param.pcCargoResponsable
                    , cCargoSuperiorNombre: param.pcCargoSuperiorNombre

                    , cFechaInicio: param.pdtFechaInicio
                    , nAreaId: param.pnAreaId

                    , nCargoId: param.nCargoId

                    , nCargoSuperiorId: param.pnCargoSuperiorId
                    , nPersonasDesg: 0 /*useless?, por defecto, al registrar no tiene personas asignadas...*/
                    , nRow: 11111 /* useless? */

                    , nAreaId: param.pnAreaId

        }
            //actualizar organigrama...
            $scope.ModalOrgTree_data.push({
                    info: infoOject,
                    Colaboradores: []
            });

            $scope.listCargo.push(infoOject);


        }
        else if (_actId ==4) {
            $scope.$eval(_cOrgIndx).splice(_nIndx, 1);
            //update listCargos...

            //removing "Cargo" from "scope.List..."
            if ($scope.listCargo.length > 0) {
                var _length = $scope.listCargo.length;
                for (var i = 0; i < _length; i++) {
                    if ($scope.listCargo[i].nCargoId == param.pnCargoId) {/*<<<<<<<< !Important "pnCargoId", not "nCargoId" */
                        $scope.listCargo.splice(i, 1);
                        i = _length;
                }
            }
        }
            }
        done = true;
        return done;
        }


            function actualizarOrganigrama_Colaborador(param) {
                var done = false;
                if (_actId == 2) {

                    $scope.ModalOrgTree_data.nCargoPersonaSuperiorId = param.pnCargoPersonaSuperiorId;
                    $scope.ModalOrgTree_data.cCargoPerSupNom = param.pcCargoPerSupNom;

                    $scope.ModalOrgTree_data.nPersonaSuplenteId = param.pnPersonaSuplenteId;
                    $scope.ModalOrgTree_data.cPersonaSuplNom = param.pcPersonaSuplNom;

                }
                else if (_actId == 3) {

                    //getting the "nCrgContrato"
                    

                    //seting to object..
                    //var p_pdtFechaInicio = param.pdtFechaInicio;
                    //console.log("p_pdtFechaInicio:", p_pdtFechaInicio);


                    //var month = param.pdtFechaInicio.getMonth() + 1; //months from 1-12
                    //var day = param.pdtFechaInicio.getDate();
                    //var year = param.pdtFechaInicio.getFullYear();

                    //var np_pdtFechaInicio = stringToDate(p_pdtFechaInicio, "dd-MM-yyyy", "/");
                    //var np_pdtFechaInicio = day + "/" + month + "/" + year;
                    //var np_pdtFechaInicio = $filter('date')(param.pdtFechaInicio, "dd/MM/yyyy");
                    //console.log("np_pdtFechaInicio", np_pdtFechaInicio);
                    var infoOject = {
                        cCargoPerSupNom: param.pcCargoPerSupNom
                            , cFechaInicio: param.pdtFechaInicio
                            , cPersonaNom: param.pcPersonaNom
                            , cPersonaSuplNom: param.pcPersonaSuplNom
                            , nAreaId: param.pnAreaId
                            , nCargoId: param.pnCargoId

                            , nCargoPersonaId: param.pnCargoPersonaId
                            , nCargoPersonaSuperiorId: param.pnCargoPersonaSuperiorId

                            , nCrgContrato: param.pnCrgContrato

                            , nIdSeguridad: param.pnIdSeguridad

                            , nPersonaId: param.pnPersonaId
                            , nPersonaSuplenteId: param.pnPersonaSuplenteId
                            , nRow: 11111 /* useless ?  */

                    }
                    //console.log("actualizar organigrama,infoOject:", infoOject);
                    //actualizar organigrama...
                    $scope.ModalOrgTree_data.push({ info: infoOject });



                }
                else if (_actId == 4) {
                    $scope.$eval(_cOrgIndx).splice(_nIndx, 1);

                    //update listCargos...

                    //removing "Persona" from "scope.CargoPersona..."
                    //if ($scope.list....length > 0) {
                    //    var _length = $scope.list....length;
                    //    for (var i = 0; i < _length; i++) {
                    //        if ($scope.listCargo[i].nCargoId == param.pnCargoId) {/*<<<<<<<< !Important "pnCargoId", not "nCargoId" */
                    //            console.error('item removed..!');
                    //            $scope.listCargo.splice(i, 1);
                    //            i = _length;
                    //        }
                    //    }
                    //}

                }
                done = true;
                return done;
            }

    $scope.btnEliminarEnt = function () {

        if ($scope.txtFechaFin_RE_Elim == undefined || $scope.txtFechaFin_RE_Elim == null) {
            alert("La fecha de Fin es obligatoria");
            return;
    }
        var datNow = new Date();
        if ($scope.txtFechaFin_RE_Elim > datNow) {
            alert("La fecha de inicio no puede ser mayor a la fecha actual");
            return;
    }

        var param = {
                pnAreaId: $scope.ModalOrgTree_data.nAreaId
            , pdtFechaFin: $filter('date')($scope.txtFechaFin_RE_Elim, "MM-dd-yyyy")
            , pnUsuarioModificaId: $scope.Usuario.nUsuId
    }

        serviceMantOrg.EliminarEntidad(param)
           .success(function (data) {
               alert(data.cMsj);
               if (data.nMsjCode == 200) {
                   if (actualizarOrganigrama_Entidad(param)) {
                       $scope.ModalOrgTree_data = undefined;// 'cause -> actualizarOrganigrama_Entidad - condition if ...
                       $("#ModalOrgTree_entidad").modal("hide");
                       SetValueToInputsForm_Entidad();
               }
           }
               //fILLIstarGrillaOrg(); //REFRESH JSON.Organigrama
        }).error(function (error) {
               console.error(error);
        });

        }


            function getCNivelIndex(_idNivel) {
        var index = -1;
        if ($scope.listaNivel.length >0) {
            $.each($scope.listaNivel, function (key, val) {
                if (val.nMaeItem == _idNivel) {
                    index = key;
            }
            })
            }
        return index;
        }

            function getSuperior_area(_nAreaSuperiorId) {
        var index = -1;

        if ($scope.listEntidad_RE_Filtered.length > 0) {
            $.each($scope.listEntidad_RE_Filtered, function (key, val) {
                if (val.nAreaId == _nAreaSuperiorId) {
                    index = key;
            }
            })
            }
        return index;
        }

            function getEntidad_Cargo(_nAreaId) {
        var index = -1;
        if ($scope.listEntidad_RC_Filtered.length > 0) {
            $.each($scope.listEntidad_RC_Filtered, function (key, val) {
                if (val.nAreaId == _nAreaId) {
                    index = key;
            }
            })
            }
        return index;
        }

            function getEntidad_Colab(_nAreaId) {
        var index = -1;
        if ($scope.listEntidad_AP_Filtered.length > 0) {
            $.each($scope.listEntidad_AP_Filtered, function (key, val) {
                if (val.nAreaId == _nAreaId) {
                    index = key;
            }
            })
            }
        return index;
        }


            function getNivelIndexCargo(_nAreaId) {
        var index = -1;
        if ($scope.listEntidad.length > 0) {
            $.each($scope.listEntidad, function (key, val) {
                if (val.nAreaId == _nAreaId) {
                    index = key;
            }
            })
            }
        return index;
        }

            function getSuperior_Cargo(_nCargoSuperiorId) {
        var index = -1;

        if ($scope.listCargo_RC_Filtered.length > 0) {

            $.each($scope.listCargo_RC_Filtered, function (key, val) {
                if (val.nCargoId == _nCargoSuperiorId) {
                    index = key;
            }
            })
            }
        return index;
        }

            function getCargoIndex_Colab(_nCargoId) {
        var index = -1;

        if ($scope.listCargo_AP_Filtered.length > 0) {

            $.each($scope.listCargo_AP_Filtered, function (key, val) {
                if (val.nCargoId == _nCargoId) {
                    index = key;
            }
            })
            }
        return index;
        }

            function getIndxPersona_colab(_nPersonaId) {
        var index = -1;

        if ($scope.listPersona.length > 0) {

            $.each($scope.listPersona, function (key, val) {
                if (val.nPersonaId == _nPersonaId) {
                    index = key;
            }
            })
            }
        return index;
        }

            function getIndxPersonaSuperior_colab(_nCargoPersonaSuperiorId) {
        var index = -1;

        if ($scope.listSuperior_AP_Filtered.length > 0) {

            $.each($scope.listSuperior_AP_Filtered, function (key, val) {
                if (val.nCargoPersonaId == _nCargoPersonaSuperiorId) {
                    index = key;
            }
            })
            }
        return index;
        }

            function SetValueToInputsForm_Colab(_edit) {


                //$scope.objSlcNivel_RE = $scope.listaNivel[0];

            $scope.objSlcNivel_AP = null;
            $scope.objSlcEntidad_AP = null;
            $scope.ddlPersonaCarReg_AP = null;
            $scope.txtPersona_AP = null;
                //$scope.listEntidad_RE_Filtered_edt = [];
            $scope.objSlcSuperior_AP = null;
            $scope.objSlcSuplente_AP = null;
            $scope.txtAP_FechaInicio = null;

            if (_edit) {

                //editar....
                $scope.txtPersona_AP = $scope.ModalOrgTree_data.cCargoNombre;
                //$scope.listEntidad_RE_Filtered = [];
                $scope.txtAP_FechaInicio = stringToDate($scope.ModalOrgTree_data.cFechaInicio, "dd/MM/yyyy", "/");

            }

                //btn "registrar Cargo" envia _data=null, pero las ramas del organigrama envian datos...
            if ($scope.ModalOrgTree_data != null) {

                //get Area info by Index of lista Area...
                var _indxArea = getNivelIndexCargo($scope.ramaPadre_Info.nAreaId);

                var _area = $scope.listEntidad[_indxArea];

                //get Nivel Id
                var _indxNivel = getCNivelIndex(_area.nNivelId)
                $scope.objSlcNivel_AP = $scope.listaNivel[_indxNivel];

                //refrescar lista Entidades..
                $scope.chng_objSlcNivel_AP($scope.listaNivel[_indxNivel]);

                var _indxEntidad = getEntidad_Colab(_area.nAreaId)
                $scope.objSlcEntidad_AP = $scope.listEntidad_AP_Filtered[_indxEntidad];

                //cargar la lista de Superior...
                $scope.chng_objSlcEntidad_AP($scope.listEntidad_AP_Filtered[_indxEntidad])


                //get index of cargo superior
                var _indxCargo = getCargoIndex_Colab($scope.ramaPadre_Info.nCargoId);
                var _cargoPersona = $scope.listCargo_AP_Filtered[_indxCargo];
                $scope.ddlPersonaCarReg_AP = _cargoPersona;



                var _indxPersona = getIndxPersona_colab($scope.ModalOrgTree_data.nPersonaId);
                $scope.txtPersona_AP = $scope.listPersona[_indxPersona];

                //carga lista superior, depende de Cargo Select
                $scope.chng_objSlcCargo_AP(_cargoPersona);

                //alert(JSON.stringify($scope.listSuperior_AP_Filtered[0]));

                var _indxPersonaSuperior = getIndxPersonaSuperior_colab($scope.ModalOrgTree_data.nCargoPersonaSuperiorId);
                $scope.objSlcSuperior_AP = $scope.listSuperior_AP_Filtered[_indxPersonaSuperior];

                var _indxPersonaSuplente = getIndxPersona_colab($scope.ModalOrgTree_data.nPersonaSuplenteId);
                $scope.objSlcSuplente_AP = $scope.listPersona[_indxPersonaSuplente];

            }

        }


            function SetValueToInputsForm_Cargo(_edit) {
                //function SetValueToInputsForm_Entidad(_clear, chg_objSlcNivel_RE, txtNombre_RE, txtAbrev_RE , objSlcNivelSup_RE, txtApoyo_RE, txtFechaInicio_RE) {

                //$scope.objSlcNivel_RE = $scope.listaNivel[0];

            $scope.objSlcNivel_RC = null;
            $scope.ddlCargoEntReg_RC = null;
            $scope.txtRC_Nombre = null;
            $scope.txtRC_Abrev = null;
                //$scope.listEntidad_RE_Filtered_edt = [];
            $scope.objSlcSuperior_RC = null;
            $scope.txtRC_Responsable = null;
            $scope.txtRC_FechaInicio = null;


            if (_edit) {

                $scope.txtRC_Nombre = $scope.ModalOrgTree_data.cCargoNombre;
                $scope.txtRC_Abrev = $scope.ModalOrgTree_data.cCargoAbreviatura;
                //$scope.listEntidad_RE_Filtered = [];
                $scope.txtRC_Responsable = ($scope.ModalOrgTree_data.cCargoResponsable == '1' ? true : false);
                $scope.txtRC_FechaInicio = stringToDate($scope.ModalOrgTree_data.cFechaInicio, "dd/MM/yyyy", "/");

            }

                //btn "registrar Cargo" envia _data=null, pero las ramas del organigrama envian datos...
            if ($scope.ModalOrgTree_data != null) {

                if (_actId == 2) {

                    //get Area info by Index of lista Area...
                    //var _indxArea = getNivelIndexCargo($scope.ramaPadre_Info.nAreaId);
                        var _indxArea = getNivelIndexCargo($scope.ModalOrgTree_data.nAreaId);
                        var _areaId = $scope.listEntidad[_indxArea];

                    //$scope.lblRC_CargoId = $scope.ramaPadre_Info.nCargoId;
                        $scope.lblRC_CargoId = $scope.ModalOrgTree_data.nCargoId;


                    //get Nivel Id
                        var _indxNivel = getCNivelIndex(_areaId.nNivelId)
                        $scope.objSlcNivel_RC = $scope.listaNivel[_indxNivel];

                    //refrescar lista Entidades..
                        $scope.chng_objSlcNivel_RC($scope.listaNivel[_indxNivel]);


                        var _indxEntidad = getEntidad_Cargo(_areaId.nAreaId)
                        $scope.ddlCargoEntReg_RC = $scope.listEntidad_RC_Filtered[_indxEntidad];

                    //cargar la lista de Superior...
                        $scope.chng_objSlcEntidad_RC($scope.listEntidad_RC_Filtered[_indxEntidad])

                    //get index of cargo superior
                    //var _indxCargoSuper = getSuperior_Cargo($scope.ramaPadre_Info.nCargoSuperiorId);
                        var _indxCargoSuper = getSuperior_Cargo($scope.ModalOrgTree_data.nCargoSuperiorId);

                        $scope.objSlcSuperior_RC = $scope.listCargo_RC_Filtered[_indxCargoSuper];

                }
                else if (_actId == 3) {

                    //get Area info by Index of lista Area...
                        var _indxArea = getNivelIndexCargo($scope.ramaPadre_Info.nAreaId);
                    //var _indxArea = getNivelIndexCargo($scope.ModalOrgTree_data.nAreaId);
                        var _areaId = $scope.listEntidad[_indxArea];

                            $scope.lblRC_CargoId = $scope.ramaPadre_Info.nCargoId;
                    //$scope.lblRC_CargoId = $scope.ModalOrgTree_data.nCargoId;


                    //get Nivel Id
                        var _indxNivel = getCNivelIndex(_areaId.nNivelId)
                        $scope.objSlcNivel_RC = $scope.listaNivel[_indxNivel];

                    //refrescar lista Entidades..
                        $scope.chng_objSlcNivel_RC($scope.listaNivel[_indxNivel]);


                        var _indxEntidad = getEntidad_Cargo(_areaId.nAreaId)
                        $scope.ddlCargoEntReg_RC = $scope.listEntidad_RC_Filtered[_indxEntidad];

                    //cargar la lista de Superior...
                        $scope.chng_objSlcEntidad_RC($scope.listEntidad_RC_Filtered[_indxEntidad])

                    //get index of cargo superior
                        var _indxCargoSuper = getSuperior_Cargo($scope.ramaPadre_Info.nCargoSuperiorId);
                    //var _indxCargoSuper = getSuperior_Cargo($scope.ModalOrgTree_data.nCargoSuperiorId);

                        $scope.objSlcSuperior_RC = $scope.listCargo_RC_Filtered[_indxCargoSuper];
            }

            }

        }


            function SetValueToInputsForm_Entidad(_edit) {
                //function SetValueToInputsForm_Entidad(_clear, chg_objSlcNivel_RE, txtNombre_RE, txtAbrev_RE , objSlcNivelSup_RE, txtApoyo_RE, txtFechaInicio_RE) {

                //$scope.objSlcNivel_RE = $scope.listaNivel[0];
                $scope.objSlcNivel_RE = null;
                $scope.txtNombre_RE = null;
                $scope.objSlcNivelSup_RE = null;
                $scope.txtAbrev_RE = null;
                //$scope.listEntidad_RE_Filtered_edt = [];
                $scope.txtApoyo_RE = null;
                $scope.txtFechaInicio_RE = null;

                $scope.lblEmpresa_Selected_RE = $scope.objSlcEmpresa;

                //btn "registrar entidad" envia _data=null, pero las ramas del organigrama envian datos...
                //if ($scope.ModalOrgTree_data!=undefined && $scope.ModalOrgTree_data != null) {

                if ($scope.ModalOrgTree_data == undefined) {
                    return;
                }

                if (_edit) {
                    $scope.txtNombre_RE = $scope.ModalOrgTree_data.cAreaNombre;
                    $scope.txtAbrev_RE = $scope.ModalOrgTree_data.cAreaAbreviatura;
                    $scope.txtApoyo_RE = ($scope.ModalOrgTree_data.cAreaApoyo == '1' ? true : false);
                    $scope.txtFechaInicio_RE = stringToDate($scope.ModalOrgTree_data.cFechaInicio, "dd/MM/yyyy", "/");


                    if ($scope.ModalOrgTree_data.nAreaSuperiorId == 0) {
                        //select Nivel
                        var _indx = getCNivelIndex("1");//<<<<<<<

                        //01 - Cargar Lista 
                        $scope.chg_objSlcNivel_RE($scope.listaNivel[_indx]);
                        //02 - obetener index Superior

                        $scope.objSlcNivel_RE = $scope.listaNivel[_indx];

                        var _indxSup = getSuperior_area($scope.ModalOrgTree_data.nAreaId);//<<<<<<<<<
                        $scope.objSlcNivelSup_RE = $scope.listEntidad_RE_Filtered[_indxSup];


                    }
                    else {
                        //select Nivel
                        var _indx = getCNivelIndex($scope.ModalOrgTree_data.nNivelId);

                        //01 - Cargar Lista 
                        $scope.chg_objSlcNivel_RE($scope.listaNivel[_indx]);
                        //02 - obetener index Superior

                        $scope.objSlcNivel_RE = $scope.listaNivel[_indx];

                        var _indxSup = getSuperior_area($scope.ModalOrgTree_data.nAreaSuperiorId);//<<<<<<<<<<<<
                        $scope.objSlcNivelSup_RE = $scope.listEntidad_RE_Filtered[_indxSup];
                    }




                }
                else {
                    if ($scope.ramaPadre_Info.nAreaSuperiorId == 0) {
                        //select Nivel
                        var _indx = getCNivelIndex("1");//<<<<<<<

                        //01 - Cargar Lista 
                        $scope.chg_objSlcNivel_RE($scope.listaNivel[_indx]);
                        //02 - obetener index Superior

                        $scope.objSlcNivel_RE = $scope.listaNivel[_indx];

                        var _indxSup = getSuperior_area($scope.ramaPadre_Info.nAreaId);//<<<<<<<<<
                        $scope.objSlcNivelSup_RE = $scope.listEntidad_RE_Filtered[_indxSup];

                    }
                    else {
                        //select Nivel
                        var _indx = getCNivelIndex($scope.ramaPadre_Info.nNivelId + 1); //(*) <<<<<<<<<
                        //01 - Cargar Lista 
                        $scope.chg_objSlcNivel_RE($scope.listaNivel[_indx]);
                        //02 - obetener index Superior

                        $scope.objSlcNivel_RE = $scope.listaNivel[_indx];

                        //var _indxSup = getSuperior_area($scope.ramaPadre_Info.nAreaSuperiorId);//<<<<<<<<<<<<
                        var _indxSup = getSuperior_area($scope.ramaPadre_Info.nAreaId);//<<<<<<<<<<<< (*)
                        $scope.objSlcNivelSup_RE = $scope.listEntidad_RE_Filtered[_indxSup];

                        /*END - Pendiente Testing - no se setea el valor de los campos, revisar (*) "nNivelId+1 "*/
                    }
                }


                //}


            }


                function stringToDate(_date, _format, _delimiter) {
        var formatLowerCase = _format.toLowerCase();
        var formatItems = formatLowerCase.split(_delimiter);
        var dateItems = _date.split(_delimiter);
        var monthIndex = formatItems.indexOf("mm");
        var dayIndex = formatItems.indexOf("dd");
        var yearIndex = formatItems.indexOf("yyyy");
        var month = parseInt(dateItems[monthIndex]);
        month -= 1;
        var formatedDate = new Date(dateItems[yearIndex], month, dateItems[dayIndex]);
        return formatedDate;
            }

                function fValidarUnicoCarSinSuperiorBL(nAreaId) {
            var out = 0;
            if (nAreaId != null) {
                $.each($scope.listEntidad, function (key, val) {
                    if (val.nAreaId == nAreaId) {
                        out = 1;
                        return out;
                }
                });
                }
            return out;
            }

                $scope.btnRegistrarCargo = function () {

                    if ($scope.ddlCargoEntReg_RC == undefined || $scope.ddlCargoEntReg_RC == null) {
                        alert("Entidad es un campo requerido");
                        return;
                    }
                    if ($scope.txtRC_Nombre == undefined || $scope.txtRC_Nombre == null) {
                        alert("Nombre es un campo requerido");
                        return;
                    }
                    if ($scope.txtRC_Abrev == undefined || $scope.txtRC_Abrev == null) {
                        alert("Abreviatura es un campo requerido");
                        return;
                    }
                    var nRespuesta;

                    nRespuesta = fValidarUnicoCarSinSuperiorBL($scope.ddlCargoEntReg_RC.nAreaId);
                    if ($scope.ddlCargoEntReg_RC == undefined && nRespuesta > 0) {
                        alert("Superior es un campo requerido");
                        return;
                    }

                    //DateTime dtFechaActual = DateTime.Now;
                    if ($scope.txtRC_FechaInicio == undefined || $scope.txtRC_FechaInicio == null) {
                        lblRegCarError.Text = "La fecha de inicio es obligatoria";
                        return;
                    }

                    //if (!IsDate(txtFchIniCarReg.Text))
                    //{
                    //    lblRegCarError.Text = "Ingrese una fecha de Inicio Correcta";
                    //    return;
                    //}

                    var datNow = new Date();

                    //if (Convert.ToDateTime(txtFchIniCarReg.Text) > dtFechaActual)
                    if ($scope.txtRC_FechaInicio > datNow) {
                        alert("La fecha de inicio no puede ser mayor a la fecha actual");
                        return;
                    }

                    var param = {
                        /*pnNivelId: $scope.objSlcNivel_RC.cMaeValor,*/
                        pcCargoNombre: $scope.txtRC_Nombre
                                , pnAreaId: $scope.ddlCargoEntReg_RC.nAreaId
                                , pcAreaNombre: $scope.ddlCargoEntReg_RC.cAreaNombre//useless for register, just for update and show the data...
                                , pcCargoAbreviatura: $scope.txtRC_Abrev
                                , pcCargoResponsable: ($scope.txtRC_Responsable == true ? '1' : '0')
                                , pnCargoSuperiorId: $scope.objSlcSuperior_RC.nCargoId
                                , pcCargoSuperiorNombre: $scope.objSlcSuperior_RC.cCargoNombre//useless for register, just for update and show the data...

                        /*, pdtFechaInicio: getDateStringFromInputDtVal($scope.txtRC_FechaInicio)*/
                                , pdtFechaInicio: $filter('date')($scope.txtRC_FechaInicio, "MM-dd-yyyy")
                                , pnUsuarioModificaId: $scope.Usuario.nUsuId
                    }
                    serviceMantOrg.RegistrarCargo(param)
                        .success(function (data) {
                            alert(data.cMsj);

                            if (data.nMsjCode == 200) {
                                param.nCargoId = data.nMsj;
                                //debugger;

                                if ($scope.ModalOrgTree_data == undefined) {//from the button "register entidad"
                                    filtrarOrganigrama_desdePadre_cargo(param);
                                }
                                else {
                                    if (!actualizarOrganigrama_Cargo(param)) {
                                        console.error('error', 'no se logro asignar los valores al conjunto de datos')
                                    }
                                }
                                SetValueToInputsForm_Cargo(null);
                            }
                            else {
                                console.error('error inesperado "serviceMantOrg.RegistrarCargo"', data.cMsj);
                            }
                            //fILLIstarGrillaOrg(); //REFRESH JSON.Organigrama
                        }).error(function (error) {
                            console.error(error);
                        });

                }

    $scope.btnEditarCargo = function () {

        if ($scope.txtRC_Nombre == undefined || $scope.txtRC_Nombre == null) {
            alert("Nombre es un campo requerido");
            return;
    }
        if ($scope.txtRC_Abrev == undefined || $scope.txtRC_Abrev == null) {
            alert("Abreviatura es un campo requerido");
            return;
    }
        var nRespuesta;

        nRespuesta = fValidarUnicoCarSinSuperiorBL($scope.ddlCargoEntReg_RC.nAreaId);
        if ($scope.ddlCargoEntReg_RC == undefined && nRespuesta > 0) {
            alert("Superior es un campo requerido");
            return;
    }

        var param = {
                pnCargoId: $scope.ModalOrgTree_data.nCargoId
            , pcCargoNombre: $scope.txtRC_Nombre
            , pcCargoAbreviatura: $scope.txtRC_Abrev
            , pcCargoResponsable: ($scope.txtRC_Responsable == true ? '1' : '0')
            , pnCargoSuperiorId: $scope.objSlcSuperior_RC.nCargoId
            , pcCargoSuperiorNombre: $scope.objSlcSuperior_RC.cCargoNombre/*no usable in Edit, it will be used in "update values" of organigrama(fronted)....*/
            , pnUsuarioModificaId: $scope.Usuario.nUsuId
    }
        serviceMantOrg.EditarCargo(param)
                    .success(function (data) {
                        alert(data.cMsj);
                        if (data.nMsjCode == 200) {

                            if (actualizarOrganigrama_Cargo(param)) {
                                $scope.ModalOrgTree_data = undefined;// 'cause -> actualizarOrganigrama_Cargo - condition if ...
                                SetValueToInputsForm_Entidad();
                                $("#ModalOrgTree_cargo").modal("hide");
                        }
                    }
                        //fILLIstarGrillaOrg(); //REFRESH JSON.Organigrama
        }).error(function (error) {
                        console.error(error);
        });

                }

    $scope.btnEliminarCargo = function () {

        if ($scope.txtRC_FechaFin_Elim == undefined || $scope.txtRC_FechaFin_Elim == null) {
            alert("La fecha de Fin es obligatoria");
            return;
    }
        var datNow = new Date();
        if ($scope.txtRC_FechaFin_Elim > datNow) {
            alert("La fecha de inicio no puede ser mayor a la fecha actual");
            return;
    }


        var param = {
                pnCargoId: $scope.ModalOrgTree_data.nCargoId
            , pdtFechaFin: $filter('date')($scope.txtRC_FechaFin_Elim, "MM-dd-yyyy")
            , pnUsuarioModificaId: $scope.Usuario.nUsuId
    }

        serviceMantOrg.EliminarCargo(param)
                    .success(function (data) {
                        alert(data.cMsj);
                        if (data.nMsjCode == 200) {

                            if (actualizarOrganigrama_Cargo(param)) {
                                $scope.ModalOrgTree_data = undefined;// 'cause -> actualizarOrganigrama_Cargo - condition if ...
                                SetValueToInputsForm_Entidad();
                                $("#ModalOrgTree_cargo").modal("hide");
                        }
                    }
                        //fILLIstarGrillaOrg(); //REFRESH JSON.Organigrama
        }).error(function (error) {
                        console.error(error);
        });

                }



                    function fValidarUnicoPerSinSuperiorBL(pnCargoId) {
        var out = 0;
        if (pnCargoId != null) {
            $.each($scope.listCargo, function (key, val) {
                if (val.nCargoId == pnCargoId) {
                    out = 1;
                    return out;
            }
            });

                    }
        return out;
                }


        $scope.btnAsocPersn = function () {

            //if (ddlPersonaCarReg.SelectedValue == "0") {
            if ($scope.ddlPersonaCarReg_AP == undefined || $scope.ddlPersonaCarReg_AP == null) {
                alert("Cargo es un campo requerido");
                return;
        }

            if ($scope.txtPersona_AP == undefined || $scope.txtPersona_AP == null) {
                alert("Persona debe ser Seleccionada");
                return;
        }

            var nRespuesta = fValidarUnicoPerSinSuperiorBL($scope.ddlPersonaCarReg_AP.nCargoId);


            //if (ddlSupPerReg.SelectedValue == "0" && nRespuesta > 0) {
            if ($scope.objSlcSuperior_AP == undefined && nRespuesta > 0) {
                alert("Superior es un campo requerido");
                return;
        }



            //INICIO JAG
            //if (hdnNomPerRegId.Value === ddlSuplenteReg.SelectedValue)
            if ($scope.txtPersona_AP.nPersonaId === $scope.objSlcSuplente_AP.nPersonaId) {
                alert("Persona a asociar no puede ser la misma al suplente");
                return;
        }
            //FIN JAG



            if ($scope.txtAP_FechaInicio == undefined || $scope.txtAP_FechaInicio == null) {
                alert("La fecha de inicio es obligatoria");
                return;
        }

            //if (!IsDate(txtFchIniPerReg.Text))
            //{
            //    lblRegPerError.Text = "Ingrese una fecha de Inicio Correcta";
            //    return;
            //}

            var datNow = new Date();
            //if (Convert.ToDateTime(txtFchIniPerReg.Text) > dtFechaActual)
            if ($scope.txtAP_FechaInicio > datNow) {
                alert("La fecha de inicio no puede ser mayor a la fecha actual");
                return;
        }
            if ($scope.Usuario == undefined || $scope.Usuario == null) {
                alert('No se logro obtener los datos del usuario actual');
        }

            var param = {

                    pnPersonaId: $scope.txtPersona_AP.nPersonaId //for Register
                , pcPersonaNom: $scope.txtPersona_AP.cPersonaNomCompleto

                , pnCargoId: $scope.ddlPersonaCarReg_AP.nCargoId  //FOR Register
                , pnAreaId: $scope.objSlcEntidad_AP.nAreaId

                , pnCargoPersonaSuperiorId: $scope.objSlcSuperior_AP.nCargoPersonaId //for register
                , pcCargoPerSupNom: $scope.objSlcSuperior_AP.cPersonaNom

                , pnPersonaSuplenteId: $scope.objSlcSuplente_AP.nPersonaId //for register
                , pcPersonaSuplNom: $scope.objSlcSuplente_AP.cPersonaNomCompleto

                , pdtFechaInicio: $filter('date')($scope.txtAP_FechaInicio, "MM-dd-yyyy")//for register
                , pnUsuarioModificaId: $scope.Usuario.nUsuId //for register
        }


            if ($scope.listCargoPersona.length > 0) {
                param.pnCrgContrato = -11;
                param.pnIdSeguridad = -22;
                for (var i = 0; i < $scope.listCargoPersona.length; i++) {

                    if ($scope.listCargoPersona[i].nPersonaId == param.pnPersonaId) {
                        param.pnCrgContrato = $scope.listCargoPersona[i].nCrgContrato;
                        param.pnIdSeguridad = $scope.listCargoPersona[i].nIdSeguridad;
                        break;
                }
            }
        }



            //console.log("AsociarPersona.param", param);
            serviceMantOrg.AsociarPersona(param)
              .success(function (data) {

                  alert(data.cMsj);
                  //debugger;

                  if (data.nMsjCode == 200) {
                      param.pnCargoPersonaId = data.nMsj;
                      if ($scope.ModalOrgTree_data == undefined) {
                          filtrarOrganigrama_desdePadre_colaborador(param);
                      }
                      else {
                          if (!actualizarOrganigrama_Colaborador(param)) {
                              console.error('no se logro asignar actualizar los datos de la asocicación...');
                      }
                  }
                      SetValueToInputsForm_Colab();

              }

            }).error(function (error) {
                  console.error(error);
            });
                }

    $scope.btnEditarAsocPersn = function () {

        if ($scope.ddlPersonaCarReg_AP == undefined || $scope.ddlPersonaCarReg_AP == null) {
            alert("Cargo es un campo requerido");
            return;
    }

        if ($scope.txtPersona_AP == undefined || $scope.txtPersona_AP == null) {
            alert("Persona debe ser Seleccionada");
            return;
    }

        var nRespuesta = fValidarUnicoPerSinSuperiorBL($scope.ddlPersonaCarReg_AP.nCargoId);

        if ($scope.objSlcSuperior_AP == undefined && nRespuesta > 0) {
            alert("Superior es un campo requerido");
            return;
    }

        //INICIO JAG
        if ($scope.txtPersona_AP.nPersonaId === $scope.objSlcSuplente_AP.nPersonaId) {
            alert("Persona a asociar no puede ser la misma al suplente");
            return;
    }
        //FIN JAG

        if ($scope.txtAP_FechaInicio == undefined || $scope.txtAP_FechaInicio == null) {
            alert("La fecha de inicio es obligatoria");
            return;
    }

        //if (!IsDate(txtFchIniPerReg.Text))
        //{
        //    lblRegPerError.Text = "Ingrese una fecha de Inicio Correcta";
        //    return;
        //}

        var datNow = new Date();
        //if (Convert.ToDateTime(txtFchIniPerReg.Text) > dtFechaActual)
        if ($scope.txtAP_FechaInicio > datNow) {
            alert("La fecha de inicio no puede ser mayor a la fecha actual");
            return;
    }

        var param = {

                pnCargoPersonaId: $scope.ModalOrgTree_data.nCargoPersonaId //for edit
            , pnCargoPersonaSuperiorId: $scope.objSlcSuperior_AP.nCargoPersonaId //for edit
            , pcCargoPerSupNom: $scope.objSlcSuperior_AP.cPersonaNom

            , pnPersonaSuplenteId: $scope.objSlcSuplente_AP.nPersonaId //for edit
            , pcPersonaSuplNom: $scope.objSlcSuplente_AP.cPersonaNomCompleto

            , pnUsuarioModificaId: $scope.Usuario.nUsuId //for edit

    }

        serviceMantOrg.EditarAsociarPersona(param)
          .success(function (data) {
              alert(data.cMsj);
              if (data.nMsjCode == 200) {

                  if (actualizarOrganigrama_Colaborador(param)) {
                      SetValueToInputsForm_Colab();
                      $("#ModalOrgTree_colab").modal("hide");
              }

          }
              //fILLIstarGrillaOrg(); //REFRESH JSON.Organigrama
        }).error(function (error) {
              console.error(error);
        });
                }

    $scope.btnEliminarAsociaPersona = function () {

        if ($scope.txtAP_FechaFin_Elim == undefined || $scope.txtAP_FechaFin_Elim == null) {
            alert("La fecha de Fin es obligatoria");
            return;
    }

       var datNow = new Date();
       if ($scope.txtAP_FechaFin_Elim > datNow) {
            alert("La fecha de inicio no puede ser mayor a la fecha actual");
            return;
    }
       var param = {
               pnCargoPersonaId: $scope.ModalOrgTree_data.nCargoPersonaId
            , pdtFechaFin: $filter('date')($scope.txtAP_FechaFin_Elim, "MM-dd-yyyy")
            , pnUsuarioModificaId: $scope.Usuario.nUsuId
    }

        serviceMantOrg.EliminarAsociaPersona(param)
        .success(function (data) {
            alert(data.cMsj);

            if (data.nMsjCode == 200) {

                if (actualizarOrganigrama_Colaborador(param)) {
                    SetValueToInputsForm_Colab();
                    $("#ModalOrgTree_colab").modal("hide");
            }

        }
            //fILLIstarGrillaOrg(); //REFRESH JSON.Organigrama
        }).error(function (error) {
            console.error(error);
        });

                }


                    function searchFilter(search, data, results) {

                        //for(let directory of directories) {
        $.each(data, function (key, val) {

            if (val.Cargos.info.nCargoId !== undefined && val.Cargos.length > 0) {

                var childsearch = searchFilter(search, val.Cargos)

                if (childsearch !== undefined) {
                    results.push(childsearch);
            }
        }
            return results;
        });
                }


                    function iniciar() {
         fListaNucleo();
                }
    iniciar();



    });

    app.directive('toggleClass', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                element.bind('click', function () {
                    element.toggleClass(attrs.toggleClass);
                    element.toggleClass('btnCollapse');
                });
            }
        };
    });

