﻿/*--  ------------------------------------------------------------------------
SISTEMA : NucleSES
SUBSISTEMA : NucleoSES
NOMBRE : app.js
DESCRIPCIÓN : archivo de configuracion de rutas.
AUTOR : Martin.delgado
FECHA CREACIÓN : 04/06/2018
------------------------------------------------------------------------
FECHA           EMPLEADO            MODIFICACIÓN  
04/06/2018      Martin Delgado      creacion y definicion de metodos, dependencias..

--------------------------------------------------------------------------*/
//var app = angular.module('appSES', ['ngRoute', 'ngCookies', 'ui.bootstrap', 'lr.upload', 'commonService', 'loadingMsgDirective', 'validadorNumerico', 'utils.autofocus']);
//var app = angular.module('appSES', ['ngRoute', 'ngCookies', 'ui.bootstrap', 'lr.upload', 'commonService']); --error


//2016.06.15:

//var app = angular.module('appSES', ['ngRoute', 'ngCookies', 'ui.bootstrap', 'lr.upload', 'servicio_Nucleo_General', 'servicioCargaOrg'  , 'servicioMantHistEdicOrg', 'servicioMantHistOrg', 'servicioMantOrg']);
//2016.06.15:
//var app = angular.module('appSES', ['ngRoute', 'ngCookies', 'ui.bootstrap', 'lr.upload',  'commonService', 'commonServiceUser', 'commonServiceLogin', 'loadingMsgDirective', 'validadorNumerico', 'utils.autofocus', 'datatables', 'servicio_Nucleo_General', 'servicioCargaOrg', 'servicioMantHistEdicOrg', 'servicioMantHistOrg', 'servicioMantOrg']);
var app = angular.module('appSES', ['ngRoute', 'ngCookies', 'ui.bootstrap', 'lr.upload', 'commonService', 'commonServiceUser', 'commonServiceLogin', 'loadingMsgDirective', 'validadorNumerico', 'utils.autofocus', 'datatables', 'commonServiceSistema', 'commonServiceMenu', 'servicio_Nucleo_General', 'servicioCargaOrg', 'servicioMantHistEdicOrg', 'servicioMantHistOrg', 'servicioMantOrg']);
app.config(function ($routeProvider, $httpProvider) {

    $httpProvider.defaults.headers["post"] = {
        'Content-Type': 'application/json;charset=utf-8'
    };

    $routeProvider
        .when('/', {
            templateUrl: 'app/modules/main/main.html'
        })
        .when('/home', {
            templateUrl: 'app/modules/main/main.html'
        })
        .when('/login', {
            templateUrl: 'app/modules/Login/login.html',
            controller: 'LoginController'
        })


        .when('/MntOrg', {
             templateUrl: 'app/modules/MntOrg/MantOrg.html',
             controller: 'MntOrganigramaController'
         })
        .when('/CargOrg', {
            templateUrl: 'app/modules/CargOrg/CargaOrg.html',
            controller: 'CargaOrganigramaController'
        })
        .when('/MntHistEdicOrg', {
            templateUrl: 'app/modules/MntHistEdicOrg/MantHistEdicOrg.html',
            controller: 'MntHistorialEdicionOrganigramaController'
        })
        .when('/MntHistOrg', {
            templateUrl: 'app/modules/MntHistOrg/MantHistOrg.html',
            controller: 'MntHistorialOrganigramaController'
        })


        .when('/ViewOrg', {
            templateUrl: 'app/modules/ViewOrg/ViewOrg.html',
            controller: 'ViewOrgController'
        })

    .otherwise({
        redirectTo: '/'
    });
})



var loadingMsgDirective = angular.module('loadingMsgDirective', []);

loadingMsgDirective.config(['$httpProvider', function ($httpProvider) {
    $httpProvider.interceptors.push(function ($q, $rootScope) {
        return {
            'request': function (config) {
                $rootScope.$broadcast('REQUEST_START');
                return config;
            },
            'response': function (response) {
                $rootScope.$broadcast('REQUEST_END');

                return response;
            },
            'responseError': function (rejection) {
                $rootScope.$broadcast('REQUEST_END');

                return $q.reject(rejection);
            }
        };
    });
}]);

loadingMsgDirective.directive('loadingMsg', [function () {
    return {
        template: '<div id="bloquea" class="cargando"  ng-show="pending" style="display:block">' +
        '<img style="margin-left: -2%;margin-top: 12%" alt="Espere..." src="src/css/images/_Loading_.gif" height="40" width="60" />' +
        '</div>',

        scope: {},
        link: function (scope, element, attrs) {
            scope.pending = 0;

            scope.$on('REQUEST_START', function () {
                scope.pending += 1;
            });

            scope.$on('REQUEST_END', function () {
                scope.pending -= 1;
            });
        }
    };
}]);

