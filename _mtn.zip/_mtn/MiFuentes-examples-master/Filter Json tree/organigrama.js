[
				{
					nombre:'FSW'
					,id:2313
					,Cargos:[{
  					  info:{	idCargo:23123
  				 			  ,nombreCargo:'Cargo-0'
  					    }
  					 ,colaboradores:[
					 			{idColab:1312,nombreColab:'martin dq'}
					 			,{idColab:3122,nombreColab:'Jose dq'}
				 			]
					},
					{
  					  info:{	idCargo:3111
  				 			  ,nombreCargo:'Cargo-0-1'
  					    }
  					 ,colaboradores:[
					 			{idColab:31233,nombreColab:'Snatos dq'}
				 			]
					}
					]
					,Subareas:[
					    {
					      info: {nAreaId:34123,nombre:'sub area'}
					      ,cargo:[]
					      ,Subareas:[]
					    }
					  ]
				}
				,{nombre:'gerencia'
				 ,id:2233
				 ,Cargos: [
				 	{
				 		info: {
				 			idCargo:23123
				 			,nombreCargo:'Cargo-1'
				 		}
				 		,colaboradores:[
					 			{idColab:31233,nombreColab:'martin dq'}
					 			,{idColab:31233,nombreColab:'Meramendi dq'}
				 			]

				 	}
				 	,{
				 		info: {
				 			idCargo:23123
				 			,nombreCargo:'Cargo-2'
				 		}
				 		,colaboradores:[
					 			{idColab:31233,nombreColab:'Peralta dq'}
					 			,{idColab:31233,nombreColab:'Quinto dq'}
				 			]

				 	}
				 ]
				 	
				 ,Subareas:[
				 	{
				 		Cargos:[]
				 		,Subareas:[]
				 		,info:{id:3123,nombre:'finanzas'}
				 	}
				 ]
				}
	]