treelistfilter
==============

Simple jQuery plugin support filtering on hirerarchy tree created by unordered list or ordered list

Documentation
=============

Please visit http://wiki.aiwsolutions.net/dOQKO for full demonstration and guidelines
