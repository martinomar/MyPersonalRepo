# Bootstrap-Form-Validation-HTML5
This is a simple plugin for validate form using html5 with bootstrap.<br>
<strong>Required:</strong> jQuery Library
  <h3>Usage</h3>
            <ol>
              <li>
                Paste the following code into the <head> section of your site's HTML.
                <pre>&lt;script src="scripts/form.validation.js"&gt;&lt;/script&gt;</pre>
              </li>
              <li>
                activate validation via JavaScript:
                <pre>$(&quot;form&quot;).html5validate();</pre>
              </li>
            </ol>
  <h4>Demo</h4>
  <a href="http://dev.jodacame.com/Bootstrap-Form-Validation-HTML5/example/">http://dev.jodacame.com/Bootstrap-Form-Validation-HTML5/example/</a>
  <h4>Author</h4>
  <a href="http://twitter.com/jodacame">@jodacame</a>
