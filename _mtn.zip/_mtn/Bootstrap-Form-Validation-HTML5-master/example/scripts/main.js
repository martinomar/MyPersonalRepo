$(function () {
	$("form").html5validate();
});