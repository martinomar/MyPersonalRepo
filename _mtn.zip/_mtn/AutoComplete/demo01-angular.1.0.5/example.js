angular.module('plunker',['ui.bootstrap']);
function TypeaheadCtrl($scope){
	$scope.selected = "";
	$scope.users = [
		{'id':1, 'first':'Martin','last':'DQ'},
		{'id':2, 'first':'2Martin','last':'2DQ'},
		{'id':3, 'first':'3Martin','last':'3DQ'},
		{'id':4, 'first':'4Martin','last':'4DQ'},
		{'id':5, 'first':'5Martin','last':'5DQ'},
		{'id':6, 'first':'6Martin','last':'6DQ'}
	]
	
}