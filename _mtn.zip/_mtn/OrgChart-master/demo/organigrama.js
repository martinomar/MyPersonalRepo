var organigrama = [
  {
    "info": {
      "nAreaId": 1243,
      "cAreaNombre": "FSW - SBU",
      "cAreaAbreviatura": null,
      "nEmpresaId": 2,
      "cEmpresaNombre": "SES",
      "nNivelId": 2,
      "cNivelNombre": "AREA",
      "nAreaSuperiorId": 0,
      "cAreaSuperiorNombre": "",
      "cAreaApoyo": "0",
      "cFechaInicio": "06/09/2017",
      "nRow": 34
    },
    "Cargos": [
      {
        "info": {
          "nCargoId": 2815,
          "cCargoNombre": "Ingeniero de Software",
          "cCargoAbreviatura": null,
          "nAreaId": 1243,
          "cAreaNombre": "FSW - SBU",
          "cAreaAbreviatura": null,
          "cCargoResponsable": "0",
          "cCargoSuperiorNombre": null,
          "nCargoSuperiorId": null,
          "cFechaInicio": "06/09/2017",
          "nRow": 62,
          "nPersonasDesg": 1
        },
        "Colaboradores": [
          {
            "info": {
              "nCargoPersonaId": 4216,
              "nPersonaId": 629,
              "nIdSeguridad": 159,
              "cPersonaNom": "LECAROS DE LA QUINTANA, FELIX STEVEN",
              "nCargoId": 2815,
              "nCargoPersonaSuperiorId": 0,
              "cCargoPerSupNom": null,
              "nPersonaSuplenteId": 0,
              "cPersonaSuplNom": null,
              "cFechaInicio": "06/09/2017",
              "nRow": 67,
              "nAreaId": 1243,
              "nCrgContrato": "0"
            }
          }
        ]
      }
    ],
    "Entidades": [
      {
        "info": {
          "nAreaId": 1283,
          "cAreaNombre": "ent-test-01",
          "cAreaAbreviatura": "e-test-01",
          "nEmpresaId": 2,
          "cEmpresaNombre": "SES",
          "nNivelId": 1,
          "cNivelNombre": "GERENCIA",
          "nAreaSuperiorId": 1243,
          "cAreaSuperiorNombre": "FSW - SBU",
          "cAreaApoyo": "0",
          "cFechaInicio": "15/06/2018",
          "nRow": 11
        },
        "Cargos": [
          {
            "info": {
              "nCargoId": 2855,
              "cCargoNombre": "Cargo-test-01",
              "cCargoAbreviatura": "crg-test-0",
              "nAreaId": 1283,
              "cAreaNombre": "ent-test-01",
              "cAreaAbreviatura": "e-test-01",
              "cCargoResponsable": "0",
              "cCargoSuperiorNombre": "Ingeniero de Software",
              "nCargoSuperiorId": 2815,
              "cFechaInicio": "15/06/2018",
              "nRow": 26,
              "nPersonasDesg": 1
            },
            "Colaboradores": [
              {
                "info": {
                  "nCargoPersonaId": 4448,
                  "nPersonaId": 7245,
                  "nIdSeguridad": 8633,
                  "cPersonaNom": "AAAAA AA, AA",
                  "nCargoId": 2855,
                  "nCargoPersonaSuperiorId": 4216,
                  "cCargoPerSupNom": "LECAROS DE LA QUINTANA, FELIX STEVEN",
                  "nPersonaSuplenteId": 5156,
                  "cPersonaSuplNom": "CABELLO AYRA, JHOEL",
                  "cFechaInicio": "15/06/2018",
                  "nRow": 181,
                  "nAreaId": 1283,
                  "nCrgContrato": "0"
                }
              }
            ]
          },
          {
            "info": {
              "nCargoId": 2856,
              "cCargoNombre": "cargo-tst-02",
              "cCargoAbreviatura": "crg-tst-02",
              "nAreaId": 1283,
              "cAreaNombre": "ent-test-01",
              "cAreaAbreviatura": "e-test-01",
              "cCargoResponsable": "1",
              "cCargoSuperiorNombre": "Cargo-test-01",
              "nCargoSuperiorId": 2855,
              "cFechaInicio": "15/06/2018",
              "nRow": 27,
              "nPersonasDesg": 0
            },
            "Colaboradores": []
          }
        ],
        "Entidades": [
          {
            "info": {
              "nAreaId": 1287,
              "cAreaNombre": "ent-test-01.1",
              "cAreaAbreviatura": "e-t-01.1",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 3,
              "cNivelNombre": "SECCION",
              "nAreaSuperiorId": 1283,
              "cAreaSuperiorNombre": "ent-test-01",
              "cAreaApoyo": "1",
              "cFechaInicio": "21/06/2018",
              "nRow": 12
            },
            "Cargos": [],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1295,
              "cAreaNombre": "ent-test-01.10",
              "cAreaAbreviatura": "e-t-01.10",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1283,
              "cAreaSuperiorNombre": "ent-test-01",
              "cAreaApoyo": "1",
              "cFechaInicio": "21/06/2018",
              "nRow": 13
            },
            "Cargos": [],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1288,
              "cAreaNombre": "ent-test-01.2",
              "cAreaAbreviatura": "e-t-1.2",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1283,
              "cAreaSuperiorNombre": "ent-test-01",
              "cAreaApoyo": "1",
              "cFechaInicio": "21/06/2018",
              "nRow": 14
            },
            "Cargos": [],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1289,
              "cAreaNombre": "ent-test-01.3",
              "cAreaAbreviatura": "e-t-01.3",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1283,
              "cAreaSuperiorNombre": "ent-test-01",
              "cAreaApoyo": "1",
              "cFechaInicio": "21/06/2018",
              "nRow": 15
            },
            "Cargos": [],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1290,
              "cAreaNombre": "ent-test-01.4",
              "cAreaAbreviatura": "e-t-01.4",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1283,
              "cAreaSuperiorNombre": "ent-test-01",
              "cAreaApoyo": "1",
              "cFechaInicio": "21/06/2018",
              "nRow": 16
            },
            "Cargos": [],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1291,
              "cAreaNombre": "ent-test-01.5",
              "cAreaAbreviatura": "e-t-01.5",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1283,
              "cAreaSuperiorNombre": "ent-test-01",
              "cAreaApoyo": "1",
              "cFechaInicio": "21/06/2018",
              "nRow": 17
            },
            "Cargos": [],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1292,
              "cAreaNombre": "ent-test-01.6",
              "cAreaAbreviatura": "e-t-01.6",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1283,
              "cAreaSuperiorNombre": "ent-test-01",
              "cAreaApoyo": "1",
              "cFechaInicio": "21/06/2018",
              "nRow": 18
            },
            "Cargos": [],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1293,
              "cAreaNombre": "ent-test-01.7",
              "cAreaAbreviatura": "e-t-01.7",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1283,
              "cAreaSuperiorNombre": "ent-test-01",
              "cAreaApoyo": "1",
              "cFechaInicio": "21/06/2018",
              "nRow": 19
            },
            "Cargos": [],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1294,
              "cAreaNombre": "ent-test-01.9",
              "cAreaAbreviatura": "e-t-01.9",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1283,
              "cAreaSuperiorNombre": "ent-test-01",
              "cAreaApoyo": "1",
              "cFechaInicio": "21/06/2018",
              "nRow": 20
            },
            "Cargos": [],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1284,
              "cAreaNombre": "test-area-003",
              "cAreaAbreviatura": "t-a-003",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1283,
              "cAreaSuperiorNombre": "ent-test-01",
              "cAreaApoyo": "1",
              "cFechaInicio": "21/06/2018",
              "nRow": 51
            },
            "Cargos": [],
            "Entidades": [
              {
                "info": {
                  "nAreaId": 1285,
                  "cAreaNombre": "test-sub-area-003--01",
                  "cAreaAbreviatura": "t-s-a-03-0",
                  "nEmpresaId": 2,
                  "cEmpresaNombre": "SES",
                  "nNivelId": 3,
                  "cNivelNombre": "SECCION",
                  "nAreaSuperiorId": 1284,
                  "cAreaSuperiorNombre": "test-area-003",
                  "cAreaApoyo": "1",
                  "cFechaInicio": "21/06/2018",
                  "nRow": 53
                },
                "Cargos": [],
                "Entidades": []
              }
            ]
          },
          {
            "info": {
              "nAreaId": 1286,
              "cAreaNombre": "test-area-01-01",
              "cAreaAbreviatura": "t-a-01-01",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1283,
              "cAreaSuperiorNombre": "ent-test-01",
              "cAreaApoyo": "1",
              "cFechaInicio": "21/06/2018",
              "nRow": 52
            },
            "Cargos": [],
            "Entidades": []
          }
        ]
      }
    ]
  },
  {
    "info": {
      "nAreaId": 1247,
      "cAreaNombre": "Gerencia General",
      "cAreaAbreviatura": null,
      "nEmpresaId": 2,
      "cEmpresaNombre": "SES",
      "nNivelId": 1,
      "cNivelNombre": "GERENCIA",
      "nAreaSuperiorId": 0,
      "cAreaSuperiorNombre": "",
      "cAreaApoyo": "0",
      "cFechaInicio": "06/09/2017",
      "nRow": 39
    },
    "Cargos": [
      {
        "info": {
          "nCargoId": 2798,
          "cCargoNombre": "Gerente General",
          "cCargoAbreviatura": null,
          "nAreaId": 1247,
          "cAreaNombre": "Gerencia General",
          "cAreaAbreviatura": null,
          "cCargoResponsable": "0",
          "cCargoSuperiorNombre": null,
          "nCargoSuperiorId": null,
          "cFechaInicio": "06/09/2017",
          "nRow": 41,
          "nPersonasDesg": 1
        },
        "Colaboradores": [
          {
            "info": {
              "nCargoPersonaId": 4184,
              "nPersonaId": 207,
              "nIdSeguridad": 107,
              "cPersonaNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
              "nCargoId": 2798,
              "nCargoPersonaSuperiorId": 0,
              "cCargoPerSupNom": null,
              "nPersonaSuplenteId": 207,
              "cPersonaSuplNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
              "cFechaInicio": "06/09/2017",
              "nRow": 8,
              "nAreaId": 1247,
              "nCrgContrato": "1"
            }
          }
        ]
      }
    ],
    "Entidades": [
      {
        "info": {
          "nAreaId": 1244,
          "cAreaNombre": "Gerencia Comercial",
          "cAreaAbreviatura": null,
          "nEmpresaId": 2,
          "cEmpresaNombre": "SES",
          "nNivelId": 1,
          "cNivelNombre": "GERENCIA",
          "nAreaSuperiorId": 1247,
          "cAreaSuperiorNombre": "Gerencia General",
          "cAreaApoyo": "0",
          "cFechaInicio": "06/09/2017",
          "nRow": 36
        },
        "Cargos": [
          {
            "info": {
              "nCargoId": 2794,
              "cCargoNombre": "Gerente  de Negocios",
              "cCargoAbreviatura": null,
              "nAreaId": 1244,
              "cAreaNombre": "Gerencia Comercial",
              "cAreaAbreviatura": null,
              "cCargoResponsable": "0",
              "cCargoSuperiorNombre": "Gerente General",
              "nCargoSuperiorId": 2798,
              "cFechaInicio": "06/09/2017",
              "nRow": 37,
              "nPersonasDesg": 1
            },
            "Colaboradores": [
              {
                "info": {
                  "nCargoPersonaId": 4273,
                  "nPersonaId": 527,
                  "nIdSeguridad": 122,
                  "cPersonaNom": "DIAZ CARPIO, JUAN ENRIQUE",
                  "nCargoId": 2794,
                  "nCargoPersonaSuperiorId": 4184,
                  "cCargoPerSupNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 43,
                  "nAreaId": 1244,
                  "nCrgContrato": "1"
                }
              }
            ]
          },
          {
            "info": {
              "nCargoId": 2796,
              "cCargoNombre": "Gerente de Desarrollo de Negocios",
              "cCargoAbreviatura": null,
              "nAreaId": 1244,
              "cAreaNombre": "Gerencia Comercial",
              "cAreaAbreviatura": null,
              "cCargoResponsable": "0",
              "cCargoSuperiorNombre": "Gerente General",
              "nCargoSuperiorId": 2798,
              "cFechaInicio": "06/09/2017",
              "nRow": 39,
              "nPersonasDesg": 0
            },
            "Colaboradores": []
          }
        ],
        "Entidades": []
      },
      {
        "info": {
          "nAreaId": 1245,
          "cAreaNombre": "Gerencia de Administraci�n y Finanzas",
          "cAreaAbreviatura": null,
          "nEmpresaId": 2,
          "cEmpresaNombre": "SES",
          "nNivelId": 1,
          "cNivelNombre": "GERENCIA",
          "nAreaSuperiorId": 1247,
          "cAreaSuperiorNombre": "Gerencia General",
          "cAreaApoyo": "0",
          "cFechaInicio": "06/09/2017",
          "nRow": 37
        },
        "Cargos": [
          {
            "info": {
              "nCargoId": 2795,
              "cCargoNombre": "Gerente de Administraci�n y Finanzas",
              "cCargoAbreviatura": null,
              "nAreaId": 1245,
              "cAreaNombre": "Gerencia de Administraci�n y Finanzas",
              "cAreaAbreviatura": null,
              "cCargoResponsable": "0",
              "cCargoSuperiorNombre": "Gerente General",
              "nCargoSuperiorId": 2798,
              "cFechaInicio": "06/09/2017",
              "nRow": 38,
              "nPersonasDesg": 1
            },
            "Colaboradores": [
              {
                "info": {
                  "nCargoPersonaId": 4387,
                  "nPersonaId": 829,
                  "nIdSeguridad": null,
                  "cPersonaNom": "HUAPAYA ALVARADO, JAVIER ALFREDO",
                  "nCargoId": 2795,
                  "nCargoPersonaSuperiorId": 4184,
                  "cCargoPerSupNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "16/02/2018",
                  "nRow": 107,
                  "nAreaId": 1245,
                  "nCrgContrato": "1"
                }
              }
            ]
          }
        ],
        "Entidades": [
          {
            "info": {
              "nAreaId": 1228,
              "cAreaNombre": "Administraci�n",
              "cAreaAbreviatura": "ADM",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1245,
              "cAreaSuperiorNombre": "Gerencia de Administraci�n y Finanzas",
              "cAreaApoyo": "0",
              "cFechaInicio": "06/09/2017",
              "nRow": 1
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2775,
                  "cCargoNombre": "Asistente de Administraci�n y Compras especiales",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1228,
                  "cAreaNombre": "Administraci�n",
                  "cAreaAbreviatura": "ADM",
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Administraci�n",
                  "nCargoSuperiorId": 2787,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 14,
                  "nPersonasDesg": 1
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4435,
                      "nPersonaId": 7259,
                      "nIdSeguridad": null,
                      "cPersonaNom": "CASTILLO CASTILLO, MARCO",
                      "nCargoId": 2775,
                      "nCargoPersonaSuperiorId": 4241,
                      "cCargoPerSupNom": "ASCUEZ VILLAR, LUIS ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/06/2018",
                      "nRow": 187,
                      "nAreaId": 1228,
                      "nCrgContrato": "1"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2776,
                  "cCargoNombre": "Asistente de Compras",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1228,
                  "cAreaNombre": "Administraci�n",
                  "cAreaAbreviatura": "ADM",
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Administraci�n",
                  "nCargoSuperiorId": 2787,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 15,
                  "nPersonasDesg": 3
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4360,
                      "nPersonaId": 923,
                      "nIdSeguridad": null,
                      "cPersonaNom": "CACERES VARGAS, ANDRES",
                      "nCargoId": 2776,
                      "nCargoPersonaSuperiorId": 4241,
                      "cCargoPerSupNom": "ASCUEZ VILLAR, LUIS ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "16/02/2018",
                      "nRow": 120,
                      "nAreaId": 1228,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4354,
                      "nPersonaId": 5187,
                      "nIdSeguridad": null,
                      "cPersonaNom": "RAMONES TOM, TOMAS",
                      "nCargoId": 2776,
                      "nCargoPersonaSuperiorId": 4241,
                      "cCargoPerSupNom": "ASCUEZ VILLAR, LUIS ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "14/02/2018",
                      "nRow": 138,
                      "nAreaId": 1228,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4436,
                      "nPersonaId": 7260,
                      "nIdSeguridad": null,
                      "cPersonaNom": "TORRES TORRES, ANTONY",
                      "nCargoId": 2776,
                      "nCargoPersonaSuperiorId": 4241,
                      "cCargoPerSupNom": "ASCUEZ VILLAR, LUIS ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/06/2018",
                      "nRow": 188,
                      "nAreaId": 1228,
                      "nCrgContrato": "1"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2780,
                  "cCargoNombre": "Asistente de Seguridad Patrimonial",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1228,
                  "cAreaNombre": "Administraci�n",
                  "cAreaAbreviatura": "ADM",
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Administraci�n",
                  "nCargoSuperiorId": 2787,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 19,
                  "nPersonasDesg": 3
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4384,
                      "nPersonaId": 468,
                      "nIdSeguridad": 142,
                      "cPersonaNom": "MITACC ROCA, EDGAR LUIS",
                      "nCargoId": 2780,
                      "nCargoPersonaSuperiorId": 4241,
                      "cCargoPerSupNom": "ASCUEZ VILLAR, LUIS ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "16/02/2018",
                      "nRow": 34,
                      "nAreaId": 1228,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4242,
                      "nPersonaId": 638,
                      "nIdSeguridad": null,
                      "cPersonaNom": "POLO CABALLERO, JOAN JULIO",
                      "nCargoId": 2780,
                      "nCargoPersonaSuperiorId": 4241,
                      "cCargoPerSupNom": "ASCUEZ VILLAR, LUIS ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 70,
                      "nAreaId": 1228,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4338,
                      "nPersonaId": 6219,
                      "nIdSeguridad": 8662,
                      "cPersonaNom": "MARADONA MARADONA, DIEGO ARMANDO",
                      "nCargoId": 2780,
                      "nCargoPersonaSuperiorId": 4241,
                      "cCargoPerSupNom": "ASCUEZ VILLAR, LUIS ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "12/02/2018",
                      "nRow": 153,
                      "nAreaId": 1228,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2781,
                  "cCargoNombre": "Asistente de Servicios",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1228,
                  "cAreaNombre": "Administraci�n",
                  "cAreaAbreviatura": "ADM",
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Administraci�n",
                  "nCargoSuperiorId": 2787,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 20,
                  "nPersonasDesg": 1
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4333,
                      "nPersonaId": 345,
                      "nIdSeguridad": 1251,
                      "cPersonaNom": "CORTEZ ZAVALETA, YTALO ALFONSO",
                      "nCargoId": 2781,
                      "nCargoPersonaSuperiorId": 4241,
                      "cCargoPerSupNom": "ASCUEZ VILLAR, LUIS ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "12/02/2018",
                      "nRow": 24,
                      "nAreaId": 1228,
                      "nCrgContrato": "1"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2786,
                  "cCargoNombre": "Auxiliar de Compras",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1228,
                  "cAreaNombre": "Administraci�n",
                  "cAreaAbreviatura": "ADM",
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Administraci�n",
                  "nCargoSuperiorId": 2787,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 25,
                  "nPersonasDesg": 0
                },
                "Colaboradores": []
              },
              {
                "info": {
                  "nCargoId": 2787,
                  "cCargoNombre": "Coordinador de Administraci�n",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1228,
                  "cAreaNombre": "Administraci�n",
                  "cAreaAbreviatura": "ADM",
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Gerente de Administraci�n y Finanzas",
                  "nCargoSuperiorId": 2795,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 28,
                  "nPersonasDesg": 1
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4241,
                      "nPersonaId": 555,
                      "nIdSeguridad": 1223,
                      "cPersonaNom": "ASCUEZ VILLAR, LUIS ENRIQUE",
                      "nCargoId": 2787,
                      "nCargoPersonaSuperiorId": 0,
                      "cCargoPerSupNom": null,
                      "nPersonaSuplenteId": 207,
                      "cPersonaSuplNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                      "cFechaInicio": "06/09/2017",
                      "nRow": 50,
                      "nAreaId": 1228,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              }
            ],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1267,
              "cAreaNombre": "ADQUISICIONES II",
              "cAreaAbreviatura": "ADQUIS",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 4,
              "cNivelNombre": "UNIDAD",
              "nAreaSuperiorId": 1245,
              "cAreaSuperiorNombre": "Gerencia de Administraci�n y Finanzas",
              "cAreaApoyo": "f",
              "cFechaInicio": "04/09/2017",
              "nRow": 2
            },
            "Cargos": [],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1273,
              "cAreaNombre": "CASOS PRIVADOS",
              "cAreaAbreviatura": "CAPRI",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1245,
              "cAreaSuperiorNombre": "Gerencia de Administraci�n y Finanzas",
              "cAreaApoyo": "1",
              "cFechaInicio": "04/09/2017",
              "nRow": 6
            },
            "Cargos": [],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1231,
              "cAreaNombre": "Finanzas",
              "cAreaAbreviatura": null,
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1245,
              "cAreaSuperiorNombre": "Gerencia de Administraci�n y Finanzas",
              "cAreaApoyo": "0",
              "cFechaInicio": "06/09/2017",
              "nRow": 21
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2777,
                  "cCargoNombre": "Asistente de Finanzas",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1231,
                  "cAreaNombre": "Finanzas",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Finanzas",
                  "nCargoSuperiorId": 2788,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 16,
                  "nPersonasDesg": 0
                },
                "Colaboradores": []
              },
              {
                "info": {
                  "nCargoId": 2788,
                  "cCargoNombre": "Coordinador de Finanzas",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1231,
                  "cAreaNombre": "Finanzas",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Gerente de Administraci�n y Finanzas",
                  "nCargoSuperiorId": 2795,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 29,
                  "nPersonasDesg": 1
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4386,
                      "nPersonaId": 2006,
                      "nIdSeguridad": 1394,
                      "cPersonaNom": "EDILBERTO BENITEZ, RAMIRO",
                      "nCargoId": 2788,
                      "nCargoPersonaSuperiorId": 4387,
                      "cCargoPerSupNom": "HUAPAYA ALVARADO, JAVIER ALFREDO",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "16/02/2018",
                      "nRow": 130,
                      "nAreaId": 1231,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2836,
                  "cCargoNombre": "Tramitador",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1231,
                  "cAreaNombre": "Finanzas",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Finanzas",
                  "nCargoSuperiorId": 2788,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 84,
                  "nPersonasDesg": 1
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4385,
                      "nPersonaId": 954,
                      "nIdSeguridad": 4498,
                      "cPersonaNom": "FABIAN ROJAS, ROMAN",
                      "nCargoId": 2836,
                      "nCargoPersonaSuperiorId": 0,
                      "cCargoPerSupNom": null,
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "16/02/2018",
                      "nRow": 122,
                      "nAreaId": 1231,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              }
            ],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1252,
              "cAreaNombre": "Marketing",
              "cAreaAbreviatura": null,
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1245,
              "cAreaSuperiorNombre": "Gerencia de Administraci�n y Finanzas",
              "cAreaApoyo": "0",
              "cFechaInicio": "06/09/2017",
              "nRow": 44
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2778,
                  "cCargoNombre": "Asistente de Marketing Externo",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1252,
                  "cAreaNombre": "Marketing",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Marketing",
                  "nCargoSuperiorId": 2791,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 17,
                  "nPersonasDesg": 0
                },
                "Colaboradores": []
              },
              {
                "info": {
                  "nCargoId": 2779,
                  "cCargoNombre": "Asistente de Marketing Interno",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1252,
                  "cAreaNombre": "Marketing",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Marketing",
                  "nCargoSuperiorId": 2791,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 18,
                  "nPersonasDesg": 1
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4351,
                      "nPersonaId": 6206,
                      "nIdSeguridad": null,
                      "cPersonaNom": "RAMIREZ RAMIREZ, JEAN",
                      "nCargoId": 2779,
                      "nCargoPersonaSuperiorId": 4243,
                      "cCargoPerSupNom": "ASCUEZ VILLAR, LUIS ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "14/02/2018",
                      "nRow": 145,
                      "nAreaId": 1252,
                      "nCrgContrato": "1"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2791,
                  "cCargoNombre": "Coordinador de Marketing",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1252,
                  "cAreaNombre": "Marketing",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Gerente de Administraci�n y Finanzas",
                  "nCargoSuperiorId": 2795,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 32,
                  "nPersonasDesg": 1
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4243,
                      "nPersonaId": 555,
                      "nIdSeguridad": 1223,
                      "cPersonaNom": "ASCUEZ VILLAR, LUIS ENRIQUE",
                      "nCargoId": 2791,
                      "nCargoPersonaSuperiorId": 0,
                      "cCargoPerSupNom": null,
                      "nPersonaSuplenteId": 207,
                      "cPersonaSuplNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                      "cFechaInicio": "06/09/2017",
                      "nRow": 49,
                      "nAreaId": 1252,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2827,
                  "cCargoNombre": "Trainee de Dise�o",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1252,
                  "cAreaNombre": "Marketing",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Marketing",
                  "nCargoSuperiorId": 2791,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 75,
                  "nPersonasDesg": 0
                },
                "Colaboradores": []
              }
            ],
            "Entidades": []
          }
        ]
      },
      {
        "info": {
          "nAreaId": 1246,
          "cAreaNombre": "Gerencia de Proyectos y Servicios",
          "cAreaAbreviatura": null,
          "nEmpresaId": 2,
          "cEmpresaNombre": "SES",
          "nNivelId": 1,
          "cNivelNombre": "GERENCIA",
          "nAreaSuperiorId": 1247,
          "cAreaSuperiorNombre": "Gerencia General",
          "cAreaApoyo": "0",
          "cFechaInicio": "06/09/2017",
          "nRow": 38
        },
        "Cargos": [
          {
            "info": {
              "nCargoId": 2797,
              "cCargoNombre": "Gerente de Proyectos y Servicios",
              "cCargoAbreviatura": null,
              "nAreaId": 1246,
              "cAreaNombre": "Gerencia de Proyectos y Servicios",
              "cAreaAbreviatura": null,
              "cCargoResponsable": "0",
              "cCargoSuperiorNombre": "Gerente General",
              "nCargoSuperiorId": 2798,
              "cFechaInicio": "06/09/2017",
              "nRow": 40,
              "nPersonasDesg": 1
            },
            "Colaboradores": [
              {
                "info": {
                  "nCargoPersonaId": 4316,
                  "nPersonaId": 10,
                  "nIdSeguridad": 68,
                  "cPersonaNom": "SILVA DIOS, MARYURI FABIOLA",
                  "nCargoId": 2797,
                  "nCargoPersonaSuperiorId": 4184,
                  "cCargoPerSupNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                  "nPersonaSuplenteId": 207,
                  "cPersonaSuplNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                  "cFechaInicio": "06/09/2017",
                  "nRow": 2,
                  "nAreaId": 1246,
                  "nCrgContrato": "0"
                }
              }
            ]
          }
        ],
        "Entidades": [
          {
            "info": {
              "nAreaId": 1272,
              "cAreaNombre": "CASOS PUBLICOS",
              "cAreaAbreviatura": "CAPU",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1246,
              "cAreaSuperiorNombre": "Gerencia de Proyectos y Servicios",
              "cAreaApoyo": "1",
              "cFechaInicio": "07/09/2017",
              "nRow": 7
            },
            "Cargos": [],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1279,
              "cAreaNombre": "Entidad Prueba",
              "cAreaAbreviatura": "SSF",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1246,
              "cAreaSuperiorNombre": "Gerencia de Proyectos y Servicios",
              "cAreaApoyo": "0",
              "cFechaInicio": "19/02/2018",
              "nRow": 10
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2850,
                  "cCargoNombre": "Ing. Software",
                  "cCargoAbreviatura": "IFS",
                  "nAreaId": 1279,
                  "cAreaNombre": "Entidad Prueba",
                  "cAreaAbreviatura": "SSF",
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Gerente de Proyectos y Servicios",
                  "nCargoSuperiorId": 2797,
                  "cFechaInicio": "14/02/2018",
                  "nRow": 50,
                  "nPersonasDesg": 0
                },
                "Colaboradores": []
              }
            ],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1232,
              "cAreaNombre": "FSW - ETL BI",
              "cAreaAbreviatura": null,
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1246,
              "cAreaSuperiorNombre": "Gerencia de Proyectos y Servicios",
              "cAreaApoyo": "0",
              "cFechaInicio": "06/09/2017",
              "nRow": 23
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2822,
                  "cCargoNombre": "Supervisor Fabrica ETL BI",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1232,
                  "cAreaNombre": "FSW - ETL BI",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Gerente de Proyectos y Servicios",
                  "nCargoSuperiorId": 2797,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 70,
                  "nPersonasDesg": 3
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4345,
                      "nPersonaId": 250,
                      "nIdSeguridad": 5,
                      "cPersonaNom": "LAGONES VALDEZ, CARLOS ALBERTO",
                      "nCargoId": 2822,
                      "nCargoPersonaSuperiorId": 4316,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "14/02/2018",
                      "nRow": 15,
                      "nAreaId": 1232,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4255,
                      "nPersonaId": 527,
                      "nIdSeguridad": 122,
                      "cPersonaNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nCargoId": 2822,
                      "nCargoPersonaSuperiorId": 0,
                      "cCargoPerSupNom": null,
                      "nPersonaSuplenteId": 207,
                      "cPersonaSuplNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                      "cFechaInicio": "06/09/2017",
                      "nRow": 42,
                      "nAreaId": 1232,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4332,
                      "nPersonaId": 6204,
                      "nIdSeguridad": null,
                      "cPersonaNom": "VALDERRAMA VALDERRAMA, CARLOS",
                      "nCargoId": 2822,
                      "nCargoPersonaSuperiorId": 4316,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "12/02/2018",
                      "nRow": 144,
                      "nAreaId": 1232,
                      "nCrgContrato": "1"
                    }
                  }
                ]
              }
            ],
            "Entidades": [
              {
                "info": {
                  "nAreaId": 1233,
                  "cAreaNombre": "FSW - ETL BI EQUIPO 1",
                  "cAreaAbreviatura": null,
                  "nEmpresaId": 2,
                  "cEmpresaNombre": "SES",
                  "nNivelId": 4,
                  "cNivelNombre": "UNIDAD",
                  "nAreaSuperiorId": 1232,
                  "cAreaSuperiorNombre": "FSW - ETL BI",
                  "cAreaApoyo": "0",
                  "cFechaInicio": "06/09/2017",
                  "nRow": 24
                },
                "Cargos": [
                  {
                    "info": {
                      "nCargoId": 2805,
                      "cCargoNombre": "Gestor de Proyectos",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1233,
                      "cAreaNombre": "FSW - ETL BI EQUIPO 1",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Supervisor Fabrica ETL BI",
                      "nCargoSuperiorId": 2822,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 48,
                      "nPersonasDesg": 1
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4256,
                          "nPersonaId": 543,
                          "nIdSeguridad": 1320,
                          "cPersonaNom": "MESTA FAILOC, JULIO CESAR",
                          "nCargoId": 2805,
                          "nCargoPersonaSuperiorId": 4255,
                          "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                          "nPersonaSuplenteId": 527,
                          "cPersonaSuplNom": "DIAZ CARPIO, JUAN ENRIQUE",
                          "cFechaInicio": "06/09/2017",
                          "nRow": 48,
                          "nAreaId": 1233,
                          "nCrgContrato": "1"
                        }
                      }
                    ]
                  },
                  {
                    "info": {
                      "nCargoId": 2808,
                      "cCargoNombre": "Ingeniero de Software",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1233,
                      "cAreaNombre": "FSW - ETL BI EQUIPO 1",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Gestor de Proyectos",
                      "nCargoSuperiorId": 2805,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 55,
                      "nPersonasDesg": 20
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4201,
                          "nPersonaId": 85,
                          "nIdSeguridad": null,
                          "cPersonaNom": "CORREA FLORES, JUAN CARLOS",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 3,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4208,
                          "nPersonaId": 128,
                          "nIdSeguridad": null,
                          "cPersonaNom": "PARODI CENZANO, ALEJANDRO",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 5,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4212,
                          "nPersonaId": 269,
                          "nIdSeguridad": 35,
                          "cPersonaNom": "REYNA JAIME, KAREN JANETH",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 16,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4257,
                          "nPersonaId": 289,
                          "nIdSeguridad": 17,
                          "cPersonaNom": "CALLAN AGUILAR, GINO RAUL",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 18,
                          "nAreaId": 1233,
                          "nCrgContrato": "1"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4402,
                          "nPersonaId": 298,
                          "nIdSeguridad": 0,
                          "cPersonaNom": "ABARCA MAITA, CHRISTOPHER",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "21/03/2018",
                          "nRow": 20,
                          "nAreaId": 1233,
                          "nCrgContrato": "1"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4209,
                          "nPersonaId": 369,
                          "nIdSeguridad": 39,
                          "cPersonaNom": "PEREZ PALMA PONCE, LUIS ALBERTO",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 26,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4203,
                          "nPersonaId": 491,
                          "nIdSeguridad": 82,
                          "cPersonaNom": "LOPEZ NOLE, MARIO",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 38,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4214,
                          "nPersonaId": 574,
                          "nIdSeguridad": 1321,
                          "cPersonaNom": "ROSILLO CASQUINO, HEBERTO",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 53,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4215,
                          "nPersonaId": 609,
                          "nIdSeguridad": null,
                          "cPersonaNom": "SAGASTEGUI SOTO, CARLOS MANUEL",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 61,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4205,
                          "nPersonaId": 626,
                          "nIdSeguridad": 1325,
                          "cPersonaNom": "MENDEZ ALBINAGORTA, LISBETH CRISANDY",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 66,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4207,
                          "nPersonaId": 630,
                          "nIdSeguridad": 153,
                          "cPersonaNom": "PALACIOS CHU, MELANIE CHRISTIE",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 68,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4202,
                          "nPersonaId": 722,
                          "nIdSeguridad": null,
                          "cPersonaNom": "HUAMAN AGUIRRE, WILDER",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 81,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4210,
                          "nPersonaId": 752,
                          "nIdSeguridad": 1263,
                          "cPersonaNom": "PEREZ PINILLOS, YANINA LISSET",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 84,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4211,
                          "nPersonaId": 784,
                          "nIdSeguridad": 1332,
                          "cPersonaNom": "PURISACA CORNEJO, NILSON SEIR",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 93,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4200,
                          "nPersonaId": 788,
                          "nIdSeguridad": 1330,
                          "cPersonaNom": "CAMPOS SALCEDO, VICTOR HUGO",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 94,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4206,
                          "nPersonaId": 804,
                          "nIdSeguridad": 1329,
                          "cPersonaNom": "NOBLECILLA MEDINA, LEANDRO MARTIN",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 102,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4204,
                          "nPersonaId": 808,
                          "nIdSeguridad": 1265,
                          "cPersonaNom": "MARTINEZ NORIEGA, ANGEL OMAR",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 103,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4213,
                          "nPersonaId": 831,
                          "nIdSeguridad": 1262,
                          "cPersonaNom": "ROJAS APUMAYTA, CHRISTIAN",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 108,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4400,
                          "nPersonaId": 902,
                          "nIdSeguridad": 0,
                          "cPersonaNom": "ABARCA TERRONES, FERNANDO",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "12/03/2018",
                          "nRow": 119,
                          "nAreaId": 1233,
                          "nCrgContrato": "1"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4388,
                          "nPersonaId": 966,
                          "nIdSeguridad": 4512,
                          "cPersonaNom": "MACHUCA POLO, ALFREDO",
                          "nCargoId": 2808,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "16/02/2018",
                          "nRow": 125,
                          "nAreaId": 1233,
                          "nCrgContrato": "1"
                        }
                      }
                    ]
                  },
                  {
                    "info": {
                      "nCargoId": 2829,
                      "cCargoNombre": "trainee de software",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1233,
                      "cAreaNombre": "FSW - ETL BI EQUIPO 1",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Gestor de Proyectos",
                      "nCargoSuperiorId": 2805,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 77,
                      "nPersonasDesg": 1
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4356,
                          "nPersonaId": 5192,
                          "nIdSeguridad": null,
                          "cPersonaNom": "MORAN MORAN, RICARDO",
                          "nCargoId": 2829,
                          "nCargoPersonaSuperiorId": 4256,
                          "cCargoPerSupNom": "MESTA FAILOC, JULIO CESAR",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "14/02/2018",
                          "nRow": 143,
                          "nAreaId": 1233,
                          "nCrgContrato": "0"
                        }
                      }
                    ]
                  }
                ],
                "Entidades": []
              }
            ]
          },
          {
            "info": {
              "nAreaId": 1234,
              "cAreaNombre": "FSW - SBK",
              "cAreaAbreviatura": null,
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1246,
              "cAreaSuperiorNombre": "Gerencia de Proyectos y Servicios",
              "cAreaApoyo": "0",
              "cFechaInicio": "06/09/2017",
              "nRow": 25
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2824,
                  "cCargoNombre": "Supervisor FSW - SBK",
                  "cCargoAbreviatura": "FSWSBK",
                  "nAreaId": 1234,
                  "cAreaNombre": "FSW - SBK",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "1",
                  "cCargoSuperiorNombre": "Gerente de Proyectos y Servicios",
                  "nCargoSuperiorId": 2797,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 72,
                  "nPersonasDesg": 7
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4312,
                      "nPersonaId": 599,
                      "nIdSeguridad": 1315,
                      "cPersonaNom": "MALLQUI BRIONES, ROBERT ARTURO",
                      "nCargoId": 2824,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/07/2015",
                      "nRow": 58,
                      "nAreaId": 1234,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4408,
                      "nPersonaId": 7237,
                      "nIdSeguridad": null,
                      "cPersonaNom": "HURTADO TORRES, PEDRO",
                      "nCargoId": 2824,
                      "nCargoPersonaSuperiorId": 4316,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/05/2018",
                      "nRow": 172,
                      "nAreaId": 1234,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4409,
                      "nPersonaId": 7238,
                      "nIdSeguridad": null,
                      "cPersonaNom": "JARA HUMBERTO, PEDRO",
                      "nCargoId": 2824,
                      "nCargoPersonaSuperiorId": 4316,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/05/2018",
                      "nRow": 173,
                      "nAreaId": 1234,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4410,
                      "nPersonaId": 7239,
                      "nIdSeguridad": null,
                      "cPersonaNom": "PALOMINO TERNERO, ANA",
                      "nCargoId": 2824,
                      "nCargoPersonaSuperiorId": 4316,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/05/2018",
                      "nRow": 174,
                      "nAreaId": 1234,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4411,
                      "nPersonaId": 7240,
                      "nIdSeguridad": null,
                      "cPersonaNom": "MAMANI CASAS, HUMBERTO",
                      "nCargoId": 2824,
                      "nCargoPersonaSuperiorId": 4316,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/05/2018",
                      "nRow": 175,
                      "nAreaId": 1234,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4412,
                      "nPersonaId": 7241,
                      "nIdSeguridad": null,
                      "cPersonaNom": "PALOMINO TORRES, LOPEZ",
                      "nCargoId": 2824,
                      "nCargoPersonaSuperiorId": 4316,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/05/2018",
                      "nRow": 176,
                      "nAreaId": 1234,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4414,
                      "nPersonaId": 7244,
                      "nIdSeguridad": null,
                      "cPersonaNom": "GARCIA PALOMINO, HERNESTO",
                      "nCargoId": 2824,
                      "nCargoPersonaSuperiorId": 4316,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/05/2018",
                      "nRow": 179,
                      "nAreaId": 1234,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              }
            ],
            "Entidades": [
              {
                "info": {
                  "nAreaId": 1235,
                  "cAreaNombre": "FSW - SBK EQUIPO 1",
                  "cAreaAbreviatura": null,
                  "nEmpresaId": 2,
                  "cEmpresaNombre": "SES",
                  "nNivelId": 4,
                  "cNivelNombre": "UNIDAD",
                  "nAreaSuperiorId": 1234,
                  "cAreaSuperiorNombre": "FSW - SBK",
                  "cAreaApoyo": "0",
                  "cFechaInicio": "06/09/2017",
                  "nRow": 26
                },
                "Cargos": [
                  {
                    "info": {
                      "nCargoId": 2806,
                      "cCargoNombre": "Gestor de Proyectos",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1235,
                      "cAreaNombre": "FSW - SBK EQUIPO 1",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Supervisor FSW - SBK",
                      "nCargoSuperiorId": 2824,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 49,
                      "nPersonasDesg": 1
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4353,
                          "nPersonaId": 541,
                          "nIdSeguridad": 1335,
                          "cPersonaNom": "GUILLEN ROSILLO, GUSTAVO ALBERTO",
                          "nCargoId": 2806,
                          "nCargoPersonaSuperiorId": 4244,
                          "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "14/02/2018",
                          "nRow": 46,
                          "nAreaId": 1235,
                          "nCrgContrato": "0"
                        }
                      }
                    ]
                  },
                  {
                    "info": {
                      "nCargoId": 2807,
                      "cCargoNombre": "Ingeniero de Software",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1235,
                      "cAreaNombre": "FSW - SBK EQUIPO 1",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Gestor de Proyectos",
                      "nCargoSuperiorId": 2806,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 54,
                      "nPersonasDesg": 4
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4248,
                          "nPersonaId": 541,
                          "nIdSeguridad": 1335,
                          "cPersonaNom": "GUILLEN ROSILLO, GUSTAVO ALBERTO",
                          "nCargoId": 2807,
                          "nCargoPersonaSuperiorId": 4353,
                          "cCargoPerSupNom": "GUILLEN ROSILLO, GUSTAVO ALBERTO",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 47,
                          "nAreaId": 1235,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4254,
                          "nPersonaId": 715,
                          "nIdSeguridad": 1326,
                          "cPersonaNom": "VARGAS MIRANDA, JORGE CLEMENTE",
                          "nCargoId": 2807,
                          "nCargoPersonaSuperiorId": 4353,
                          "cCargoPerSupNom": "GUILLEN ROSILLO, GUSTAVO ALBERTO",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 79,
                          "nAreaId": 1235,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4252,
                          "nPersonaId": 774,
                          "nIdSeguridad": 1254,
                          "cPersonaNom": "PACARA ACEVEDO, CHRISTIAN MIGUEL",
                          "nCargoId": 2807,
                          "nCargoPersonaSuperiorId": 4353,
                          "cCargoPerSupNom": "GUILLEN ROSILLO, GUSTAVO ALBERTO",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 92,
                          "nAreaId": 1235,
                          "nCrgContrato": "1"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4251,
                          "nPersonaId": 819,
                          "nIdSeguridad": null,
                          "cPersonaNom": "NU�EZ VILCHEZ, JORGE LUIS",
                          "nCargoId": 2807,
                          "nCargoPersonaSuperiorId": 4353,
                          "cCargoPerSupNom": "GUILLEN ROSILLO, GUSTAVO ALBERTO",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 104,
                          "nAreaId": 1235,
                          "nCrgContrato": "0"
                        }
                      }
                    ]
                  },
                  {
                    "info": {
                      "nCargoId": 2828,
                      "cCargoNombre": "trainee de software",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1235,
                      "cAreaNombre": "FSW - SBK EQUIPO 1",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Gestor de Proyectos",
                      "nCargoSuperiorId": 2806,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 76,
                      "nPersonasDesg": 0
                    },
                    "Colaboradores": []
                  }
                ],
                "Entidades": [
                  {
                    "info": {
                      "nAreaId": 1237,
                      "cAreaNombre": "FSW - SBK EQUIPO1",
                      "cAreaAbreviatura": null,
                      "nEmpresaId": 2,
                      "cEmpresaNombre": "SES",
                      "nNivelId": 4,
                      "cNivelNombre": "UNIDAD",
                      "nAreaSuperiorId": 1235,
                      "cAreaSuperiorNombre": "FSW - SBK EQUIPO 1",
                      "cAreaApoyo": "0",
                      "cFechaInicio": "06/09/2017",
                      "nRow": 28
                    },
                    "Cargos": [
                      {
                        "info": {
                          "nCargoId": 2813,
                          "cCargoNombre": "Ingeniero de Software",
                          "cCargoAbreviatura": null,
                          "nAreaId": 1237,
                          "cAreaNombre": "FSW - SBK EQUIPO1",
                          "cAreaAbreviatura": null,
                          "cCargoResponsable": "0",
                          "cCargoSuperiorNombre": "Gestor de Proyectos",
                          "nCargoSuperiorId": 2806,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 60,
                          "nPersonasDesg": 0
                        },
                        "Colaboradores": []
                      },
                      {
                        "info": {
                          "nCargoId": 2831,
                          "cCargoNombre": "trainee de software",
                          "cCargoAbreviatura": null,
                          "nAreaId": 1237,
                          "cAreaNombre": "FSW - SBK EQUIPO1",
                          "cAreaAbreviatura": null,
                          "cCargoResponsable": "0",
                          "cCargoSuperiorNombre": "Gestor de Proyectos",
                          "nCargoSuperiorId": 2806,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 79,
                          "nPersonasDesg": 0
                        },
                        "Colaboradores": []
                      }
                    ],
                    "Entidades": []
                  }
                ]
              },
              {
                "info": {
                  "nAreaId": 1236,
                  "cAreaNombre": "FSW - SBK EQUIPO 2",
                  "cAreaAbreviatura": null,
                  "nEmpresaId": 2,
                  "cEmpresaNombre": "SES",
                  "nNivelId": 4,
                  "cNivelNombre": "UNIDAD",
                  "nAreaSuperiorId": 1234,
                  "cAreaSuperiorNombre": "FSW - SBK",
                  "cAreaApoyo": "0",
                  "cFechaInicio": "06/09/2017",
                  "nRow": 27
                },
                "Cargos": [
                  {
                    "info": {
                      "nCargoId": 2802,
                      "cCargoNombre": "Gestor de Proyectos",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1236,
                      "cAreaNombre": "FSW - SBK EQUIPO 2",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Supervisor FSW - SBK",
                      "nCargoSuperiorId": 2824,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 45,
                      "nPersonasDesg": 1
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4245,
                          "nPersonaId": 605,
                          "nIdSeguridad": 1316,
                          "cPersonaNom": "CAUTI CAMPOS, ABRAHAM ARISTIDES",
                          "nCargoId": 2802,
                          "nCargoPersonaSuperiorId": 4244,
                          "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                          "nPersonaSuplenteId": 527,
                          "cPersonaSuplNom": "DIAZ CARPIO, JUAN ENRIQUE",
                          "cFechaInicio": "06/09/2017",
                          "nRow": 60,
                          "nAreaId": 1236,
                          "nCrgContrato": "0"
                        }
                      }
                    ]
                  },
                  {
                    "info": {
                      "nCargoId": 2812,
                      "cCargoNombre": "Ingeniero de Software",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1236,
                      "cAreaNombre": "FSW - SBK EQUIPO 2",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Gestor de Proyectos",
                      "nCargoSuperiorId": 2802,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 59,
                      "nPersonasDesg": 5
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4246,
                          "nPersonaId": 459,
                          "nIdSeguridad": 1313,
                          "cPersonaNom": "CORAS ALVAREZ, LUIS ANTONIO",
                          "nCargoId": 2812,
                          "nCargoPersonaSuperiorId": 4245,
                          "cCargoPerSupNom": "CAUTI CAMPOS, ABRAHAM ARISTIDES",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 32,
                          "nAreaId": 1236,
                          "nCrgContrato": "1"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4247,
                          "nPersonaId": 699,
                          "nIdSeguridad": 1318,
                          "cPersonaNom": "CORDERO VIZARRETA, MIGUEL ANGEL",
                          "nCargoId": 2812,
                          "nCargoPersonaSuperiorId": 4245,
                          "cCargoPerSupNom": "CAUTI CAMPOS, ABRAHAM ARISTIDES",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 77,
                          "nAreaId": 1236,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4249,
                          "nPersonaId": 721,
                          "nIdSeguridad": 1307,
                          "cPersonaNom": "LOZANO GUARNIZ, MILAGROS ELIZABETH",
                          "nCargoId": 2812,
                          "nCargoPersonaSuperiorId": 4245,
                          "cCargoPerSupNom": "CAUTI CAMPOS, ABRAHAM ARISTIDES",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 80,
                          "nAreaId": 1236,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4253,
                          "nPersonaId": 723,
                          "nIdSeguridad": 1328,
                          "cPersonaNom": "RIVAS JIBAJA, JOSE LUIS",
                          "nCargoId": 2812,
                          "nCargoPersonaSuperiorId": 4245,
                          "cCargoPerSupNom": "CAUTI CAMPOS, ABRAHAM ARISTIDES",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 82,
                          "nAreaId": 1236,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4398,
                          "nPersonaId": 6232,
                          "nIdSeguridad": null,
                          "cPersonaNom": "RODRIGUEZ DEL AGUILA, KARLA",
                          "nCargoId": 2812,
                          "nCargoPersonaSuperiorId": 4245,
                          "cCargoPerSupNom": "CAUTI CAMPOS, ABRAHAM ARISTIDES",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "01/01/2018",
                          "nRow": 165,
                          "nAreaId": 1236,
                          "nCrgContrato": "1"
                        }
                      }
                    ]
                  }
                ],
                "Entidades": []
              }
            ]
          },
          {
            "info": {
              "nAreaId": 1238,
              "cAreaNombre": "FSW - SBP",
              "cAreaAbreviatura": null,
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1246,
              "cAreaSuperiorNombre": "Gerencia de Proyectos y Servicios",
              "cAreaApoyo": "0",
              "cFechaInicio": "06/09/2017",
              "nRow": 29
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2823,
                  "cCargoNombre": "Supervisor F�brica SBP",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1238,
                  "cAreaNombre": "FSW - SBP",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Gerente de Proyectos y Servicios",
                  "nCargoSuperiorId": 2797,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 71,
                  "nPersonasDesg": 3
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4342,
                      "nPersonaId": 227,
                      "nIdSeguridad": 48,
                      "cPersonaNom": "ACOSTA TUMES, CARMEN NATALIA",
                      "nCargoId": 2823,
                      "nCargoPersonaSuperiorId": 4316,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "13/02/2018",
                      "nRow": 12,
                      "nAreaId": 1238,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4413,
                      "nPersonaId": 7242,
                      "nIdSeguridad": null,
                      "cPersonaNom": "AAAA AAA, AA",
                      "nCargoId": 2823,
                      "nCargoPersonaSuperiorId": 4316,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/05/2018",
                      "nRow": 177,
                      "nAreaId": 1238,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4415,
                      "nPersonaId": 7243,
                      "nIdSeguridad": null,
                      "cPersonaNom": "TORIBIO HUERTAS, LUCAS",
                      "nCargoId": 2823,
                      "nCargoPersonaSuperiorId": 4316,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/05/2018",
                      "nRow": 178,
                      "nAreaId": 1238,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              }
            ],
            "Entidades": [
              {
                "info": {
                  "nAreaId": 1277,
                  "cAreaNombre": "FSW - CLIENT",
                  "cAreaAbreviatura": "FSWCL",
                  "nEmpresaId": 2,
                  "cEmpresaNombre": "SES",
                  "nNivelId": 3,
                  "cNivelNombre": "SECCION",
                  "nAreaSuperiorId": 1238,
                  "cAreaSuperiorNombre": "FSW - SBP",
                  "cAreaApoyo": "0",
                  "cFechaInicio": "01/01/2018",
                  "nRow": 22
                },
                "Cargos": [
                  {
                    "info": {
                      "nCargoId": 2848,
                      "cCargoNombre": "FSW  CLIENT",
                      "cCargoAbreviatura": "FSW",
                      "nAreaId": 1277,
                      "cAreaNombre": "FSW - CLIENT",
                      "cAreaAbreviatura": "FSWCL",
                      "cCargoResponsable": "1",
                      "cCargoSuperiorNombre": "Supervisor F�brica SBP",
                      "nCargoSuperiorId": 2823,
                      "cFechaInicio": "01/01/2018",
                      "nRow": 36,
                      "nPersonasDesg": 1
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4374,
                          "nPersonaId": 6231,
                          "nIdSeguridad": 8666,
                          "cPersonaNom": "PANANA PANANA, PETER ERIVER",
                          "nCargoId": 2848,
                          "nCargoPersonaSuperiorId": 4342,
                          "cCargoPerSupNom": "ACOSTA TUMES, CARMEN NATALIA",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "16/02/2018",
                          "nRow": 163,
                          "nAreaId": 1277,
                          "nCrgContrato": "1"
                        }
                      }
                    ]
                  }
                ],
                "Entidades": [
                  {
                    "info": {
                      "nAreaId": 1278,
                      "cAreaNombre": "FSW CL - S",
                      "cAreaAbreviatura": "FSW CL - S",
                      "nEmpresaId": 2,
                      "cEmpresaNombre": "SES",
                      "nNivelId": 4,
                      "cNivelNombre": "UNIDAD",
                      "nAreaSuperiorId": 1277,
                      "cAreaSuperiorNombre": "FSW - CLIENT",
                      "cAreaApoyo": "0",
                      "cFechaInicio": "01/02/2018",
                      "nRow": 35
                    },
                    "Cargos": [
                      {
                        "info": {
                          "nCargoId": 2849,
                          "cCargoNombre": "Desarrollo",
                          "cCargoAbreviatura": "sf",
                          "nAreaId": 1278,
                          "cAreaNombre": "FSW CL - S",
                          "cAreaAbreviatura": "FSW CL - S",
                          "cCargoResponsable": "1",
                          "cCargoSuperiorNombre": "FSW  CLIENT",
                          "nCargoSuperiorId": 2848,
                          "cFechaInicio": "01/02/2018",
                          "nRow": 33,
                          "nPersonasDesg": 1
                        },
                        "Colaboradores": [
                          {
                            "info": {
                              "nCargoPersonaId": 4375,
                              "nPersonaId": 6228,
                              "nIdSeguridad": null,
                              "cPersonaNom": "RIVERA RIVERA, ANTHONY",
                              "nCargoId": 2849,
                              "nCargoPersonaSuperiorId": 4374,
                              "cCargoPerSupNom": "PANANA PANANA, PETER ERIVER",
                              "nPersonaSuplenteId": 0,
                              "cPersonaSuplNom": null,
                              "cFechaInicio": "16/02/2018",
                              "nRow": 162,
                              "nAreaId": 1278,
                              "nCrgContrato": "1"
                            }
                          }
                        ]
                      }
                    ],
                    "Entidades": []
                  }
                ]
              },
              {
                "info": {
                  "nAreaId": 1239,
                  "cAreaNombre": "FSW - SBP - EQUIPO 1",
                  "cAreaAbreviatura": null,
                  "nEmpresaId": 2,
                  "cEmpresaNombre": "SES",
                  "nNivelId": 4,
                  "cNivelNombre": "UNIDAD",
                  "nAreaSuperiorId": 1238,
                  "cAreaSuperiorNombre": "FSW - SBP",
                  "cAreaApoyo": "0",
                  "cFechaInicio": "06/09/2017",
                  "nRow": 30
                },
                "Cargos": [
                  {
                    "info": {
                      "nCargoId": 2803,
                      "cCargoNombre": "Gestor de Proyectos",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1239,
                      "cAreaNombre": "FSW - SBP - EQUIPO 1",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Supervisor F�brica SBP",
                      "nCargoSuperiorId": 2823,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 46,
                      "nPersonasDesg": 1
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4266,
                          "nPersonaId": 569,
                          "nIdSeguridad": 127,
                          "cPersonaNom": "VILLEGAS VALENZUELA, HUGO IVAN",
                          "nCargoId": 2803,
                          "nCargoPersonaSuperiorId": 4342,
                          "cCargoPerSupNom": "ACOSTA TUMES, CARMEN NATALIA",
                          "nPersonaSuplenteId": 227,
                          "cPersonaSuplNom": "ACOSTA TUMES, CARMEN NATALIA",
                          "cFechaInicio": "06/09/2017",
                          "nRow": 52,
                          "nAreaId": 1239,
                          "nCrgContrato": "1"
                        }
                      }
                    ]
                  },
                  {
                    "info": {
                      "nCargoId": 2811,
                      "cCargoNombre": "Ingeniero de Software",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1239,
                      "cAreaNombre": "FSW - SBP - EQUIPO 1",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Gestor de Proyectos",
                      "nCargoSuperiorId": 2803,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 58,
                      "nPersonasDesg": 8
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4222,
                          "nPersonaId": 211,
                          "nIdSeguridad": 28,
                          "cPersonaNom": "CHOLAN FARROMEQUE, JOHON MANUEL",
                          "nCargoId": 2811,
                          "nCargoPersonaSuperiorId": 4266,
                          "cCargoPerSupNom": "VILLEGAS VALENZUELA, HUGO IVAN",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 9,
                          "nAreaId": 1239,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4261,
                          "nPersonaId": 288,
                          "nIdSeguridad": 14,
                          "cPersonaNom": "MONTALVO PAREDES, ERIC CARLOS",
                          "nCargoId": 2811,
                          "nCargoPersonaSuperiorId": 4266,
                          "cCargoPerSupNom": "VILLEGAS VALENZUELA, HUGO IVAN",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 17,
                          "nAreaId": 1239,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4220,
                          "nPersonaId": 633,
                          "nIdSeguridad": 154,
                          "cPersonaNom": "CERGA GARCIA, DIEGO EDMUNDO",
                          "nCargoId": 2811,
                          "nCargoPersonaSuperiorId": 4266,
                          "cCargoPerSupNom": "VILLEGAS VALENZUELA, HUGO IVAN",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 69,
                          "nAreaId": 1239,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4264,
                          "nPersonaId": 796,
                          "nIdSeguridad": 1192,
                          "cPersonaNom": "PEREZ GUERRERO, CESAR DANIEL",
                          "nCargoId": 2811,
                          "nCargoPersonaSuperiorId": 4266,
                          "cCargoPerSupNom": "VILLEGAS VALENZUELA, HUGO IVAN",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 97,
                          "nAreaId": 1239,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4405,
                          "nPersonaId": 5191,
                          "nIdSeguridad": null,
                          "cPersonaNom": "FARFAN FARFAN, JEFFERSON",
                          "nCargoId": 2811,
                          "nCargoPersonaSuperiorId": 4266,
                          "cCargoPerSupNom": "VILLEGAS VALENZUELA, HUGO IVAN",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "13/03/2018",
                          "nRow": 142,
                          "nAreaId": 1239,
                          "nCrgContrato": "1"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4328,
                          "nPersonaId": 6222,
                          "nIdSeguridad": null,
                          "cPersonaNom": "DONAYRE DONAYRE, DAVID",
                          "nCargoId": 2811,
                          "nCargoPersonaSuperiorId": 4266,
                          "cCargoPerSupNom": "VILLEGAS VALENZUELA, HUGO IVAN",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "12/02/2018",
                          "nRow": 155,
                          "nAreaId": 1239,
                          "nCrgContrato": "1"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4376,
                          "nPersonaId": 6227,
                          "nIdSeguridad": null,
                          "cPersonaNom": "TUEROS TUEROS, DIEGO",
                          "nCargoId": 2811,
                          "nCargoPersonaSuperiorId": 4266,
                          "cCargoPerSupNom": "VILLEGAS VALENZUELA, HUGO IVAN",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "16/02/2018",
                          "nRow": 160,
                          "nAreaId": 1239,
                          "nCrgContrato": "0"
                        }
                      }
                    ]
                  },
                  {
                    "info": {
                      "nCargoId": 2832,
                      "cCargoNombre": "trainee de software",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1239,
                      "cAreaNombre": "FSW - SBP - EQUIPO 1",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Gestor de Proyectos",
                      "nCargoSuperiorId": 2803,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 80,
                      "nPersonasDesg": 1
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4373,
                          "nPersonaId": 6227,
                          "nIdSeguridad": null,
                          "cPersonaNom": "TUEROS TUEROS, DIEGO",
                          "nCargoId": 2832,
                          "nCargoPersonaSuperiorId": 4266,
                          "cCargoPerSupNom": "VILLEGAS VALENZUELA, HUGO IVAN",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "16/02/2018",
                          "nRow": 161,
                          "nAreaId": 1239,
                          "nCrgContrato": "0"
                        }
                      }
                    ]
                  }
                ],
                "Entidades": []
              },
              {
                "info": {
                  "nAreaId": 1240,
                  "cAreaNombre": "FSW - SBP - EQUIPO 2",
                  "cAreaAbreviatura": null,
                  "nEmpresaId": 2,
                  "cEmpresaNombre": "SES",
                  "nNivelId": 4,
                  "cNivelNombre": "UNIDAD",
                  "nAreaSuperiorId": 1238,
                  "cAreaSuperiorNombre": "FSW - SBP",
                  "cAreaApoyo": "0",
                  "cFechaInicio": "06/09/2017",
                  "nRow": 31
                },
                "Cargos": [
                  {
                    "info": {
                      "nCargoId": 2804,
                      "cCargoNombre": "Gestor de Proyectos",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1240,
                      "cAreaNombre": "FSW - SBP - EQUIPO 2",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Supervisor F�brica SBP",
                      "nCargoSuperiorId": 2823,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 47,
                      "nPersonasDesg": 1
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4362,
                          "nPersonaId": 838,
                          "nIdSeguridad": 1214,
                          "cPersonaNom": "MONTIVEROS TORIBIO, LIZETH PAOLA",
                          "nCargoId": 2804,
                          "nCargoPersonaSuperiorId": 0,
                          "cCargoPerSupNom": null,
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "16/02/2018",
                          "nRow": 110,
                          "nAreaId": 1240,
                          "nCrgContrato": "1"
                        }
                      }
                    ]
                  },
                  {
                    "info": {
                      "nCargoId": 2810,
                      "cCargoNombre": "Ingeniero de Software",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1240,
                      "cAreaNombre": "FSW - SBP - EQUIPO 2",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Gestor de Proyectos",
                      "nCargoSuperiorId": 2804,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 57,
                      "nPersonasDesg": 5
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4263,
                          "nPersonaId": 838,
                          "nIdSeguridad": 1214,
                          "cPersonaNom": "MONTIVEROS TORIBIO, LIZETH PAOLA",
                          "nCargoId": 2810,
                          "nCargoPersonaSuperiorId": 0,
                          "cCargoPerSupNom": null,
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 109,
                          "nAreaId": 1240,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4403,
                          "nPersonaId": 952,
                          "nIdSeguridad": null,
                          "cPersonaNom": "ACU�A BOY, DAVID",
                          "nCargoId": 2810,
                          "nCargoPersonaSuperiorId": 4362,
                          "cCargoPerSupNom": "MONTIVEROS TORIBIO, LIZETH PAOLA",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "25/03/2018",
                          "nRow": 121,
                          "nAreaId": 1240,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4361,
                          "nPersonaId": 5160,
                          "nIdSeguridad": 8669,
                          "cPersonaNom": "CARRANZA PERES, ALDRICHKIOSHI",
                          "nCargoId": 2810,
                          "nCargoPersonaSuperiorId": 0,
                          "cCargoPerSupNom": null,
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "16/02/2018",
                          "nRow": 133,
                          "nAreaId": 1240,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4363,
                          "nPersonaId": 5161,
                          "nIdSeguridad": null,
                          "cPersonaNom": "CARRANZA PEREZ, MARIA",
                          "nCargoId": 2810,
                          "nCargoPersonaSuperiorId": 4362,
                          "cCargoPerSupNom": "MONTIVEROS TORIBIO, LIZETH PAOLA",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "16/02/2018",
                          "nRow": 134,
                          "nAreaId": 1240,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4364,
                          "nPersonaId": 6217,
                          "nIdSeguridad": null,
                          "cPersonaNom": "PEREZ PEREZ, ARELIZ",
                          "nCargoId": 2810,
                          "nCargoPersonaSuperiorId": 4362,
                          "cCargoPerSupNom": "MONTIVEROS TORIBIO, LIZETH PAOLA",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "16/02/2018",
                          "nRow": 152,
                          "nAreaId": 1240,
                          "nCrgContrato": "0"
                        }
                      }
                    ]
                  },
                  {
                    "info": {
                      "nCargoId": 2833,
                      "cCargoNombre": "trainee de software",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1240,
                      "cAreaNombre": "FSW - SBP - EQUIPO 2",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Gestor de Proyectos",
                      "nCargoSuperiorId": 2804,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 81,
                      "nPersonasDesg": 0
                    },
                    "Colaboradores": []
                  }
                ],
                "Entidades": []
              },
              {
                "info": {
                  "nAreaId": 1241,
                  "cAreaNombre": "FSW - SBP - EQUIPO 3",
                  "cAreaAbreviatura": null,
                  "nEmpresaId": 2,
                  "cEmpresaNombre": "SES",
                  "nNivelId": 4,
                  "cNivelNombre": "UNIDAD",
                  "nAreaSuperiorId": 1238,
                  "cAreaSuperiorNombre": "FSW - SBP",
                  "cAreaApoyo": "0",
                  "cFechaInicio": "06/09/2017",
                  "nRow": 32
                },
                "Cargos": [
                  {
                    "info": {
                      "nCargoId": 2800,
                      "cCargoNombre": "Gestor de Proyectos",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1241,
                      "cAreaNombre": "FSW - SBP - EQUIPO 3",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Supervisor F�brica SBP",
                      "nCargoSuperiorId": 2823,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 43,
                      "nPersonasDesg": 1
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4382,
                          "nPersonaId": 957,
                          "nIdSeguridad": null,
                          "cPersonaNom": "MACHUCA POLO, DANTE",
                          "nCargoId": 2800,
                          "nCargoPersonaSuperiorId": 4342,
                          "cCargoPerSupNom": "ACOSTA TUMES, CARMEN NATALIA",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "16/02/2018",
                          "nRow": 124,
                          "nAreaId": 1241,
                          "nCrgContrato": "0"
                        }
                      }
                    ]
                  },
                  {
                    "info": {
                      "nCargoId": 2816,
                      "cCargoNombre": "Ingeniero de Software",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1241,
                      "cAreaNombre": "FSW - SBP - EQUIPO 3",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Gestor de Proyectos",
                      "nCargoSuperiorId": 2800,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 63,
                      "nPersonasDesg": 6
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4218,
                          "nPersonaId": 340,
                          "nIdSeguridad": 41,
                          "cPersonaNom": "CARDENAS OCHOA, MANUEL",
                          "nCargoId": 2816,
                          "nCargoPersonaSuperiorId": 4382,
                          "cCargoPerSupNom": "MACHUCA POLO, DANTE",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 21,
                          "nAreaId": 1241,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4265,
                          "nPersonaId": 486,
                          "nIdSeguridad": 74,
                          "cPersonaNom": "TAYA GRANARA, KATHERINE",
                          "nCargoId": 2816,
                          "nCargoPersonaSuperiorId": 4382,
                          "cCargoPerSupNom": "MACHUCA POLO, DANTE",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 36,
                          "nAreaId": 1241,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4221,
                          "nPersonaId": 580,
                          "nIdSeguridad": 134,
                          "cPersonaNom": "CHICLLA SAENZ, BEATRIZ LORENZA",
                          "nCargoId": 2816,
                          "nCargoPersonaSuperiorId": 4382,
                          "cCargoPerSupNom": "MACHUCA POLO, DANTE",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 55,
                          "nAreaId": 1241,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4219,
                          "nPersonaId": 682,
                          "nIdSeguridad": 1167,
                          "cPersonaNom": "CASA MACHUCA, ROSA PAMELA",
                          "nCargoId": 2816,
                          "nCargoPersonaSuperiorId": 4382,
                          "cCargoPerSupNom": "MACHUCA POLO, DANTE",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 76,
                          "nAreaId": 1241,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4365,
                          "nPersonaId": 5183,
                          "nIdSeguridad": null,
                          "cPersonaNom": "PEREZ PEREZ, JAVIER",
                          "nCargoId": 2816,
                          "nCargoPersonaSuperiorId": 4382,
                          "cCargoPerSupNom": "MACHUCA POLO, DANTE",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "16/02/2018",
                          "nRow": 136,
                          "nAreaId": 1241,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4399,
                          "nPersonaId": 6235,
                          "nIdSeguridad": 8670,
                          "cPersonaNom": "VARGAS ALVARADO, CARLOS",
                          "nCargoId": 2816,
                          "nCargoPersonaSuperiorId": 4382,
                          "cCargoPerSupNom": "MACHUCA POLO, DANTE",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "01/03/2018",
                          "nRow": 169,
                          "nAreaId": 1241,
                          "nCrgContrato": "1"
                        }
                      }
                    ]
                  },
                  {
                    "info": {
                      "nCargoId": 2830,
                      "cCargoNombre": "trainee de software",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1241,
                      "cAreaNombre": "FSW - SBP - EQUIPO 3",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Gestor de Proyectos",
                      "nCargoSuperiorId": 2800,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 78,
                      "nPersonasDesg": 0
                    },
                    "Colaboradores": []
                  }
                ],
                "Entidades": []
              },
              {
                "info": {
                  "nAreaId": 1242,
                  "cAreaNombre": "FSW - SBP - EQUIPO 4",
                  "cAreaAbreviatura": null,
                  "nEmpresaId": 2,
                  "cEmpresaNombre": "SES",
                  "nNivelId": 4,
                  "cNivelNombre": "UNIDAD",
                  "nAreaSuperiorId": 1238,
                  "cAreaSuperiorNombre": "FSW - SBP",
                  "cAreaApoyo": "0",
                  "cFechaInicio": "06/09/2017",
                  "nRow": 33
                },
                "Cargos": [
                  {
                    "info": {
                      "nCargoId": 2801,
                      "cCargoNombre": "Gestor de Proyectos",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1242,
                      "cAreaNombre": "FSW - SBP - EQUIPO 4",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Supervisor F�brica SBP",
                      "nCargoSuperiorId": 2823,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 44,
                      "nPersonasDesg": 0
                    },
                    "Colaboradores": []
                  },
                  {
                    "info": {
                      "nCargoId": 2814,
                      "cCargoNombre": "Ingeniero de Software",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1242,
                      "cAreaNombre": "FSW - SBP - EQUIPO 4",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Gestor de Proyectos",
                      "nCargoSuperiorId": 2801,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 61,
                      "nPersonasDesg": 3
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4259,
                          "nPersonaId": 362,
                          "nIdSeguridad": 4,
                          "cPersonaNom": "GARCIA MONTERO, CARLOS ALEJANDRO",
                          "nCargoId": 2814,
                          "nCargoPersonaSuperiorId": 0,
                          "cCargoPerSupNom": null,
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 25,
                          "nAreaId": 1242,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4262,
                          "nPersonaId": 799,
                          "nIdSeguridad": 1194,
                          "cPersonaNom": "MONTENEGRO CORALES, JOSE FRANCO",
                          "nCargoId": 2814,
                          "nCargoPersonaSuperiorId": 0,
                          "cCargoPerSupNom": null,
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 99,
                          "nAreaId": 1242,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4260,
                          "nPersonaId": 839,
                          "nIdSeguridad": 1209,
                          "cPersonaNom": "HUERTA PADILLA, WALDO ROLANDO",
                          "nCargoId": 2814,
                          "nCargoPersonaSuperiorId": 0,
                          "cCargoPerSupNom": null,
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 111,
                          "nAreaId": 1242,
                          "nCrgContrato": "0"
                        }
                      }
                    ]
                  }
                ],
                "Entidades": []
              }
            ]
          },
          {
            "info": {
              "nAreaId": 1255,
              "cAreaNombre": "QA & QC",
              "cAreaAbreviatura": null,
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1246,
              "cAreaSuperiorNombre": "Gerencia de Proyectos y Servicios",
              "cAreaApoyo": "0",
              "cFechaInicio": "06/09/2017",
              "nRow": 47
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2821,
                  "cCargoNombre": "Supervisor de QA & QC",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1255,
                  "cAreaNombre": "QA & QC",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Gerente de Proyectos y Servicios",
                  "nCargoSuperiorId": 2797,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 69,
                  "nPersonasDesg": 1
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4267,
                      "nPersonaId": 527,
                      "nIdSeguridad": 122,
                      "cPersonaNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nCargoId": 2821,
                      "nCargoPersonaSuperiorId": 4316,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 207,
                      "cPersonaSuplNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                      "cFechaInicio": "06/09/2017",
                      "nRow": 45,
                      "nAreaId": 1255,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              }
            ],
            "Entidades": [
              {
                "info": {
                  "nAreaId": 1256,
                  "cAreaNombre": "QA & QC EQUIPO 1",
                  "cAreaAbreviatura": null,
                  "nEmpresaId": 2,
                  "cEmpresaNombre": "SES",
                  "nNivelId": 4,
                  "cNivelNombre": "UNIDAD",
                  "nAreaSuperiorId": 1255,
                  "cAreaSuperiorNombre": "QA & QC",
                  "cAreaApoyo": "0",
                  "cFechaInicio": "06/09/2017",
                  "nRow": 48
                },
                "Cargos": [
                  {
                    "info": {
                      "nCargoId": 2767,
                      "cCargoNombre": "Analista de Calidad",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1256,
                      "cAreaNombre": "QA & QC EQUIPO 1",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Gestor de Calidad",
                      "nCargoSuperiorId": 2799,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 5,
                      "nPersonasDesg": 6
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4272,
                          "nPersonaId": 485,
                          "nIdSeguridad": 79,
                          "cPersonaNom": "RAMIREZ REVILLA, LUIS ANGEL",
                          "nCargoId": 2767,
                          "nCargoPersonaSuperiorId": 4268,
                          "cCargoPerSupNom": "BALDOCEDA PAREDES, YESSENIA FIORELA",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 35,
                          "nAreaId": 1256,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4269,
                          "nPersonaId": 488,
                          "nIdSeguridad": 72,
                          "cPersonaNom": "MAYORGA PATRONI, CESAR AUGUSTO",
                          "nCargoId": 2767,
                          "nCargoPersonaSuperiorId": 4268,
                          "cCargoPerSupNom": "BALDOCEDA PAREDES, YESSENIA FIORELA",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 37,
                          "nAreaId": 1256,
                          "nCrgContrato": "1"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4271,
                          "nPersonaId": 579,
                          "nIdSeguridad": 145,
                          "cPersonaNom": "URSUA FLORES, RAFAEL ISAAC",
                          "nCargoId": 2767,
                          "nCargoPersonaSuperiorId": 4268,
                          "cCargoPerSupNom": "BALDOCEDA PAREDES, YESSENIA FIORELA",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 54,
                          "nAreaId": 1256,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4270,
                          "nPersonaId": 851,
                          "nIdSeguridad": null,
                          "cPersonaNom": "NU�EZ HUARANGA, MACKS MIGUEL",
                          "nCargoId": 2767,
                          "nCargoPersonaSuperiorId": 4268,
                          "cCargoPerSupNom": "BALDOCEDA PAREDES, YESSENIA FIORELA",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "06/09/2017",
                          "nRow": 113,
                          "nAreaId": 1256,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4380,
                          "nPersonaId": 862,
                          "nIdSeguridad": null,
                          "cPersonaNom": "CASTRO LAYNES, EDISON EDUARDO",
                          "nCargoId": 2767,
                          "nCargoPersonaSuperiorId": 4268,
                          "cCargoPerSupNom": "BALDOCEDA PAREDES, YESSENIA FIORELA",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "16/02/2018",
                          "nRow": 114,
                          "nAreaId": 1256,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4371,
                          "nPersonaId": 6212,
                          "nIdSeguridad": null,
                          "cPersonaNom": "DELGADO PEREZ, RONNY",
                          "nCargoId": 2767,
                          "nCargoPersonaSuperiorId": 4268,
                          "cCargoPerSupNom": "BALDOCEDA PAREDES, YESSENIA FIORELA",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "16/02/2018",
                          "nRow": 148,
                          "nAreaId": 1256,
                          "nCrgContrato": "0"
                        }
                      }
                    ]
                  },
                  {
                    "info": {
                      "nCargoId": 2799,
                      "cCargoNombre": "Gestor de Calidad",
                      "cCargoAbreviatura": null,
                      "nAreaId": 1256,
                      "cAreaNombre": "QA & QC EQUIPO 1",
                      "cAreaAbreviatura": null,
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Supervisor de QA & QC",
                      "nCargoSuperiorId": 2821,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 42,
                      "nPersonasDesg": 1
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4268,
                          "nPersonaId": 618,
                          "nIdSeguridad": 149,
                          "cPersonaNom": "BALDOCEDA PAREDES, YESSENIA FIORELA",
                          "nCargoId": 2799,
                          "nCargoPersonaSuperiorId": 4267,
                          "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                          "nPersonaSuplenteId": 527,
                          "cPersonaSuplNom": "DIAZ CARPIO, JUAN ENRIQUE",
                          "cFechaInicio": "06/09/2017",
                          "nRow": 64,
                          "nAreaId": 1256,
                          "nCrgContrato": "1"
                        }
                      }
                    ]
                  }
                ],
                "Entidades": []
              }
            ]
          },
          {
            "info": {
              "nAreaId": 1257,
              "cAreaNombre": "Sourcing Services",
              "cAreaAbreviatura": null,
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1246,
              "cAreaSuperiorNombre": "Gerencia de Proyectos y Servicios",
              "cAreaApoyo": "0",
              "cFechaInicio": "06/09/2017",
              "nRow": 50
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2792,
                  "cCargoNombre": "Ejecutivo de Cuentas",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1257,
                  "cAreaNombre": "Sourcing Services",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Supervisor Sourcing Services",
                  "nCargoSuperiorId": 2825,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 34,
                  "nPersonasDesg": 0
                },
                "Colaboradores": []
              },
              {
                "info": {
                  "nCargoId": 2793,
                  "cCargoNombre": "Ejecutivo de Servicios",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1257,
                  "cAreaNombre": "Sourcing Services",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Supervisor Sourcing Services",
                  "nCargoSuperiorId": 2825,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 35,
                  "nPersonasDesg": 1
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4352,
                      "nPersonaId": 1995,
                      "nIdSeguridad": null,
                      "cPersonaNom": "MARX MARX, KARL",
                      "nCargoId": 2793,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "14/02/2018",
                      "nRow": 128,
                      "nAreaId": 1257,
                      "nCrgContrato": "1"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2817,
                  "cCargoNombre": "Ingeniero de Software",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1257,
                  "cAreaNombre": "Sourcing Services",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Supervisor Sourcing Services",
                  "nCargoSuperiorId": 2825,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 64,
                  "nPersonasDesg": 33
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4278,
                      "nPersonaId": 89,
                      "nIdSeguridad": 36,
                      "cPersonaNom": "TENORIO UTURUNCO, KAROL GERALDINE",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 4,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4232,
                      "nPersonaId": 213,
                      "nIdSeguridad": 1243,
                      "cPersonaNom": "GONZALES RUIZ, GEOVANNY EDSON",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 10,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4228,
                      "nPersonaId": 215,
                      "nIdSeguridad": 26,
                      "cPersonaNom": "ESCOBAR HUAMAN, JIOVANNA VANESSA",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 11,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4224,
                      "nPersonaId": 246,
                      "nIdSeguridad": 108,
                      "cPersonaNom": "CHAVEZ MESTANZA, JHANSEN DEIBY",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 13,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4225,
                      "nPersonaId": 249,
                      "nIdSeguridad": null,
                      "cPersonaNom": "HUAMAN AGUILAR, VANESA ROSARIO",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 14,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4281,
                      "nPersonaId": 343,
                      "nIdSeguridad": 15,
                      "cPersonaNom": "CORDOVA GARCIA, EVELYN MELISA",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 23,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4229,
                      "nPersonaId": 392,
                      "nIdSeguridad": 1168,
                      "cPersonaNom": "GALLARDO RUEDA, LUIS MIGUEL",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 27,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4275,
                      "nPersonaId": 412,
                      "nIdSeguridad": 1163,
                      "cPersonaNom": "ROBLES GUERRERO, ROMILY HERNAN",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 29,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4230,
                      "nPersonaId": 449,
                      "nIdSeguridad": null,
                      "cPersonaNom": "GARCIA VARGAS, HECTOR DAVID",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 31,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4234,
                      "nPersonaId": 499,
                      "nIdSeguridad": null,
                      "cPersonaNom": "MEJIA FIGUEROA, JORGE FRANCISCO",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 39,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4276,
                      "nPersonaId": 513,
                      "nIdSeguridad": null,
                      "cPersonaNom": "RODAS HERRERA, MOISES SEGUNDO",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 40,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4223,
                      "nPersonaId": 518,
                      "nIdSeguridad": null,
                      "cPersonaNom": "CASTRO CALLE, DANTE GERARDO",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 41,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4277,
                      "nPersonaId": 564,
                      "nIdSeguridad": 1245,
                      "cPersonaNom": "SULLUCHUCO ABARCA, JONATHAN WILLIANS",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 51,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4280,
                      "nPersonaId": 582,
                      "nIdSeguridad": 131,
                      "cPersonaNom": "VEGA ENRIQUEZ, JUNIOR ALEXANDER",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 56,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4396,
                      "nPersonaId": 585,
                      "nIdSeguridad": 1177,
                      "cPersonaNom": "GONZALES ZEBALLOS, GIULIANO REMY",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "16/02/2018",
                      "nRow": 57,
                      "nAreaId": 1257,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4231,
                      "nPersonaId": 604,
                      "nIdSeguridad": null,
                      "cPersonaNom": "GHERSI REYES, CESAR AUGUSTO",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 59,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4240,
                      "nPersonaId": 623,
                      "nIdSeguridad": null,
                      "cPersonaNom": "MEJIA BAZAN, JORGE LUIS",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 65,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4282,
                      "nPersonaId": 668,
                      "nIdSeguridad": 1250,
                      "cPersonaNom": "VILLAR AYALA, OMAR MILCO",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 73,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4233,
                      "nPersonaId": 669,
                      "nIdSeguridad": null,
                      "cPersonaNom": "FLORES RUIZ, ERIKHA PATRICIA",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 74,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4226,
                      "nPersonaId": 671,
                      "nIdSeguridad": 1166,
                      "cPersonaNom": "AVILA ZAPATA, JACQUELINE TERESA",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 75,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4239,
                      "nPersonaId": 714,
                      "nIdSeguridad": 8615,
                      "cPersonaNom": "TUPI�O ASENCIOS, JOSE LUIS",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 78,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4236,
                      "nPersonaId": 746,
                      "nIdSeguridad": 1297,
                      "cPersonaNom": "FERNANDEZ JAVIER, GISELLA EDITH",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 83,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4235,
                      "nPersonaId": 759,
                      "nIdSeguridad": null,
                      "cPersonaNom": "QUINECHE RODRIGUEZ, DIEGO ROBERTO",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 88,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4238,
                      "nPersonaId": 761,
                      "nIdSeguridad": 1299,
                      "cPersonaNom": "SANCHEZ CALDERON, CHRISTOPHER GUSTAVO",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 89,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4286,
                      "nPersonaId": 764,
                      "nIdSeguridad": null,
                      "cPersonaNom": "VARELA GARCIA, MARCOS JORGE",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 0,
                      "cCargoPerSupNom": null,
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 90,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4279,
                      "nPersonaId": 772,
                      "nIdSeguridad": 1258,
                      "cPersonaNom": "TORRES LAZARO, LUIS",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 0,
                      "cCargoPerSupNom": null,
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 91,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4284,
                      "nPersonaId": 793,
                      "nIdSeguridad": 1259,
                      "cPersonaNom": "MAGALLANES ACOSTA, JORGE ANDERSON",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 0,
                      "cCargoPerSupNom": null,
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 96,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4283,
                      "nPersonaId": 797,
                      "nIdSeguridad": 1246,
                      "cPersonaNom": "LEIVA AGUILAR, FRANCISCO JOEL",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 0,
                      "cCargoPerSupNom": null,
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 98,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4285,
                      "nPersonaId": 803,
                      "nIdSeguridad": 1201,
                      "cPersonaNom": "TELLO CARBAJAL, KARLA ESTEPHANIE",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 0,
                      "cCargoPerSupNom": null,
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 101,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4237,
                      "nPersonaId": 897,
                      "nIdSeguridad": 1295,
                      "cPersonaNom": "RIVAS FUENTES RIVERA, FERNANDO MARTIN",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 117,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4227,
                      "nPersonaId": 899,
                      "nIdSeguridad": null,
                      "cPersonaNom": "DIAZ MARTINEZ, ANGELA MARIA",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 0,
                      "cCargoPerSupNom": null,
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 118,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4359,
                      "nPersonaId": 5188,
                      "nIdSeguridad": null,
                      "cPersonaNom": "CABELLO CABELLO, JOEL",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "16/02/2018",
                      "nRow": 139,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4331,
                      "nPersonaId": 5190,
                      "nIdSeguridad": null,
                      "cPersonaNom": "CONDE RAMOS, JORGE ANDERSON",
                      "nCargoId": 2817,
                      "nCargoPersonaSuperiorId": 4274,
                      "cCargoPerSupNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "12/02/2018",
                      "nRow": 141,
                      "nAreaId": 1257,
                      "nCrgContrato": "1"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2825,
                  "cCargoNombre": "Supervisor Sourcing Services",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1257,
                  "cAreaNombre": "Sourcing Services",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Gerente de Proyectos y Servicios",
                  "nCargoSuperiorId": 2797,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 73,
                  "nPersonasDesg": 1
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4274,
                      "nPersonaId": 527,
                      "nIdSeguridad": 122,
                      "cPersonaNom": "DIAZ CARPIO, JUAN ENRIQUE",
                      "nCargoId": 2825,
                      "nCargoPersonaSuperiorId": 4316,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 207,
                      "cPersonaSuplNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                      "cFechaInicio": "06/09/2017",
                      "nRow": 44,
                      "nAreaId": 1257,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              }
            ],
            "Entidades": []
          }
        ]
      },
      {
        "info": {
          "nAreaId": 1248,
          "cAreaNombre": "Gesti�n de Capital Humano",
          "cAreaAbreviatura": "GCH",
          "nEmpresaId": 2,
          "cEmpresaNombre": "SES",
          "nNivelId": 2,
          "cNivelNombre": "AREA",
          "nAreaSuperiorId": 1247,
          "cAreaSuperiorNombre": "Gerencia General",
          "cAreaApoyo": "0",
          "cFechaInicio": "06/09/2017",
          "nRow": 40
        },
        "Cargos": [
          {
            "info": {
              "nCargoId": 2763,
              "cCargoNombre": "Abogado Laboralista",
              "cCargoAbreviatura": null,
              "nAreaId": 1248,
              "cAreaNombre": "Gesti�n de Capital Humano",
              "cAreaAbreviatura": "GCH",
              "cCargoResponsable": "0",
              "cCargoSuperiorNombre": "Coordinador de Gesti�n de Capital Humano",
              "nCargoSuperiorId": 2789,
              "cFechaInicio": "06/09/2017",
              "nRow": 1,
              "nPersonasDesg": 0
            },
            "Colaboradores": []
          },
          {
            "info": {
              "nCargoId": 2769,
              "cCargoNombre": "Analista de Desarrollo Humano",
              "cCargoAbreviatura": null,
              "nAreaId": 1248,
              "cAreaNombre": "Gesti�n de Capital Humano",
              "cAreaAbreviatura": "GCH",
              "cCargoResponsable": "0",
              "cCargoSuperiorNombre": "Coordinador de Gesti�n de Capital Humano",
              "nCargoSuperiorId": 2789,
              "cFechaInicio": "06/09/2017",
              "nRow": 7,
              "nPersonasDesg": 3
            },
            "Colaboradores": [
              {
                "info": {
                  "nCargoPersonaId": 4290,
                  "nPersonaId": 419,
                  "nIdSeguridad": 1183,
                  "cPersonaNom": "MIRANDA MALAGA, MARIA DEL CARMEN",
                  "nCargoId": 2769,
                  "nCargoPersonaSuperiorId": 4287,
                  "cCargoPerSupNom": "MAGUI�A AGUILAR, JESSICA CARMEN",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 30,
                  "nAreaId": 1248,
                  "nCrgContrato": "1"
                }
              },
              {
                "info": {
                  "nCargoPersonaId": 4355,
                  "nPersonaId": 611,
                  "nIdSeguridad": 1180,
                  "cPersonaNom": "ANDRADE QUIJAITE, GLORIA MARIA",
                  "nCargoId": 2769,
                  "nCargoPersonaSuperiorId": 4287,
                  "cCargoPerSupNom": "MAGUI�A AGUILAR, JESSICA CARMEN",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "14/02/2018",
                  "nRow": 62,
                  "nAreaId": 1248,
                  "nCrgContrato": "1"
                }
              },
              {
                "info": {
                  "nCargoPersonaId": 4341,
                  "nPersonaId": 5156,
                  "nIdSeguridad": 8668,
                  "cPersonaNom": "CABELLO AYRA, JHOEL",
                  "nCargoId": 2769,
                  "nCargoPersonaSuperiorId": 4287,
                  "cCargoPerSupNom": "MAGUI�A AGUILAR, JESSICA CARMEN",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "12/02/2018",
                  "nRow": 132,
                  "nAreaId": 1248,
                  "nCrgContrato": "1"
                }
              }
            ]
          },
          {
            "info": {
              "nCargoId": 2770,
              "cCargoNombre": "Analista de Reclutamiento y Selecci�n",
              "cCargoAbreviatura": null,
              "nAreaId": 1248,
              "cAreaNombre": "Gesti�n de Capital Humano",
              "cAreaAbreviatura": "GCH",
              "cCargoResponsable": "0",
              "cCargoSuperiorNombre": "Coordinador de Gesti�n de Capital Humano",
              "nCargoSuperiorId": 2789,
              "cFechaInicio": "06/09/2017",
              "nRow": 8,
              "nPersonasDesg": 3
            },
            "Colaboradores": [
              {
                "info": {
                  "nCargoPersonaId": 4444,
                  "nPersonaId": 7268,
                  "nIdSeguridad": 8686,
                  "cPersonaNom": "CHIRE ACON, NELLY",
                  "nCargoId": 2770,
                  "nCargoPersonaSuperiorId": 4287,
                  "cCargoPerSupNom": "MAGUI�A AGUILAR, JESSICA CARMEN",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "01/02/2018",
                  "nRow": 196,
                  "nAreaId": 1248,
                  "nCrgContrato": "1"
                }
              },
              {
                "info": {
                  "nCargoPersonaId": 4445,
                  "nPersonaId": 7269,
                  "nIdSeguridad": 8687,
                  "cPersonaNom": "ROCA BERMUDEZ, JOSELINE",
                  "nCargoId": 2770,
                  "nCargoPersonaSuperiorId": 4287,
                  "cCargoPerSupNom": "MAGUI�A AGUILAR, JESSICA CARMEN",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "01/04/2018",
                  "nRow": 197,
                  "nAreaId": 1248,
                  "nCrgContrato": "1"
                }
              },
              {
                "info": {
                  "nCargoPersonaId": 4446,
                  "nPersonaId": 7270,
                  "nIdSeguridad": 8688,
                  "cPersonaNom": "ROCCA BELEN, JOSSY",
                  "nCargoId": 2770,
                  "nCargoPersonaSuperiorId": 4287,
                  "cCargoPerSupNom": "MAGUI�A AGUILAR, JESSICA CARMEN",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "01/05/2018",
                  "nRow": 198,
                  "nAreaId": 1248,
                  "nCrgContrato": "1"
                }
              }
            ]
          },
          {
            "info": {
              "nCargoId": 2774,
              "cCargoNombre": "Asistente de Administraci�n de Personal",
              "cCargoAbreviatura": null,
              "nAreaId": 1248,
              "cAreaNombre": "Gesti�n de Capital Humano",
              "cAreaAbreviatura": "GCH",
              "cCargoResponsable": "0",
              "cCargoSuperiorNombre": "Coordinador de Gesti�n de Capital Humano",
              "nCargoSuperiorId": 2789,
              "cFechaInicio": "06/09/2017",
              "nRow": 13,
              "nPersonasDesg": 2
            },
            "Colaboradores": [
              {
                "info": {
                  "nCargoPersonaId": 4288,
                  "nPersonaId": 611,
                  "nIdSeguridad": 1180,
                  "cPersonaNom": "ANDRADE QUIJAITE, GLORIA MARIA",
                  "nCargoId": 2774,
                  "nCargoPersonaSuperiorId": 4287,
                  "cCargoPerSupNom": "MAGUI�A AGUILAR, JESSICA CARMEN",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 63,
                  "nAreaId": 1248,
                  "nCrgContrato": "0"
                }
              },
              {
                "info": {
                  "nCargoPersonaId": 4289,
                  "nPersonaId": 666,
                  "nIdSeguridad": 1216,
                  "cPersonaNom": "LAURENTE HUAM�N, FABIOLA NICOLE",
                  "nCargoId": 2774,
                  "nCargoPersonaSuperiorId": 4287,
                  "cCargoPerSupNom": "MAGUI�A AGUILAR, JESSICA CARMEN",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 71,
                  "nAreaId": 1248,
                  "nCrgContrato": "0"
                }
              }
            ]
          },
          {
            "info": {
              "nCargoId": 2784,
              "cCargoNombre": "Asistente Social",
              "cCargoAbreviatura": null,
              "nAreaId": 1248,
              "cAreaNombre": "Gesti�n de Capital Humano",
              "cAreaAbreviatura": "GCH",
              "cCargoResponsable": "0",
              "cCargoSuperiorNombre": "Coordinador de Gesti�n de Capital Humano",
              "nCargoSuperiorId": 2789,
              "cFechaInicio": "06/09/2017",
              "nRow": 23,
              "nPersonasDesg": 2
            },
            "Colaboradores": [
              {
                "info": {
                  "nCargoPersonaId": 4395,
                  "nPersonaId": 666,
                  "nIdSeguridad": 1216,
                  "cPersonaNom": "LAURENTE HUAM�N, FABIOLA NICOLE",
                  "nCargoId": 2784,
                  "nCargoPersonaSuperiorId": 4287,
                  "cCargoPerSupNom": "MAGUI�A AGUILAR, JESSICA CARMEN",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "16/02/2018",
                  "nRow": 72,
                  "nAreaId": 1248,
                  "nCrgContrato": "0"
                }
              },
              {
                "info": {
                  "nCargoPersonaId": 4349,
                  "nPersonaId": 6216,
                  "nIdSeguridad": null,
                  "cPersonaNom": "PEREZ DONGO, JUANA",
                  "nCargoId": 2784,
                  "nCargoPersonaSuperiorId": 4287,
                  "cCargoPerSupNom": "MAGUI�A AGUILAR, JESSICA CARMEN",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "14/02/2018",
                  "nRow": 151,
                  "nAreaId": 1248,
                  "nCrgContrato": "1"
                }
              }
            ]
          },
          {
            "info": {
              "nCargoId": 2785,
              "cCargoNombre": "Auxiliar de Administraci�n de Personal",
              "cCargoAbreviatura": null,
              "nAreaId": 1248,
              "cAreaNombre": "Gesti�n de Capital Humano",
              "cAreaAbreviatura": "GCH",
              "cCargoResponsable": "0",
              "cCargoSuperiorNombre": "Coordinador de Gesti�n de Capital Humano",
              "nCargoSuperiorId": 2789,
              "cFechaInicio": "06/09/2017",
              "nRow": 24,
              "nPersonasDesg": 0
            },
            "Colaboradores": []
          },
          {
            "info": {
              "nCargoId": 2789,
              "cCargoNombre": "Coordinador de Gesti�n de Capital Humano",
              "cCargoAbreviatura": null,
              "nAreaId": 1248,
              "cAreaNombre": "Gesti�n de Capital Humano",
              "cAreaAbreviatura": "GCH",
              "cCargoResponsable": "0",
              "cCargoSuperiorNombre": "Gerente General",
              "nCargoSuperiorId": 2798,
              "cFechaInicio": "06/09/2017",
              "nRow": 30,
              "nPersonasDesg": 1
            },
            "Colaboradores": [
              {
                "info": {
                  "nCargoPersonaId": 4287,
                  "nPersonaId": 866,
                  "nIdSeguridad": 3416,
                  "cPersonaNom": "MAGUI�A AGUILAR, JESSICA CARMEN",
                  "nCargoId": 2789,
                  "nCargoPersonaSuperiorId": 4184,
                  "cCargoPerSupNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                  "nPersonaSuplenteId": 207,
                  "cPersonaSuplNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                  "cFechaInicio": "06/09/2017",
                  "nRow": 115,
                  "nAreaId": 1248,
                  "nCrgContrato": "1"
                }
              }
            ]
          }
        ],
        "Entidades": []
      },
      {
        "info": {
          "nAreaId": 1250,
          "cAreaNombre": "Infraestructura & PMO",
          "cAreaAbreviatura": "IFP",
          "nEmpresaId": 2,
          "cEmpresaNombre": "SES",
          "nNivelId": 1,
          "cNivelNombre": "GERENCIA",
          "nAreaSuperiorId": 1247,
          "cAreaSuperiorNombre": "Gerencia General",
          "cAreaApoyo": "0",
          "cFechaInicio": "06/09/2017",
          "nRow": 42
        },
        "Cargos": [
          {
            "info": {
              "nCargoId": 2790,
              "cCargoNombre": "Coordinador de Infraestructura y PMO",
              "cCargoAbreviatura": "CIP",
              "nAreaId": 1250,
              "cAreaNombre": "Infraestructura & PMO",
              "cAreaAbreviatura": "IFP",
              "cCargoResponsable": "1",
              "cCargoSuperiorNombre": "Gerente General",
              "nCargoSuperiorId": 2798,
              "cFechaInicio": "06/09/2017",
              "nRow": 31,
              "nPersonasDesg": 3
            },
            "Colaboradores": [
              {
                "info": {
                  "nCargoPersonaId": 4187,
                  "nPersonaId": 10,
                  "nIdSeguridad": 68,
                  "cPersonaNom": "SILVA DIOS, MARYURI FABIOLA",
                  "nCargoId": 2790,
                  "nCargoPersonaSuperiorId": 4184,
                  "cCargoPerSupNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                  "nPersonaSuplenteId": 207,
                  "cPersonaSuplNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                  "cFechaInicio": "06/09/2017",
                  "nRow": 1,
                  "nAreaId": 1250,
                  "nCrgContrato": "1"
                }
              },
              {
                "info": {
                  "nCargoPersonaId": 4406,
                  "nPersonaId": 6233,
                  "nIdSeguridad": null,
                  "cPersonaNom": "DDD DDDD, DDDD",
                  "nCargoId": 2790,
                  "nCargoPersonaSuperiorId": 4184,
                  "cCargoPerSupNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "01/04/2018",
                  "nRow": 166,
                  "nAreaId": 1250,
                  "nCrgContrato": "1"
                }
              },
              {
                "info": {
                  "nCargoPersonaId": 4407,
                  "nPersonaId": 7236,
                  "nIdSeguridad": 8680,
                  "cPersonaNom": "HUACHANI CHUG, JOSE DIEGO",
                  "nCargoId": 2790,
                  "nCargoPersonaSuperiorId": 4184,
                  "cCargoPerSupNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "01/01/2018",
                  "nRow": 171,
                  "nAreaId": 1250,
                  "nCrgContrato": "1"
                }
              }
            ]
          }
        ],
        "Entidades": [
          {
            "info": {
              "nAreaId": 1280,
              "cAreaNombre": "Aplicaciones de Servicio",
              "cAreaAbreviatura": "APS1",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 4,
              "cNivelNombre": "UNIDAD",
              "nAreaSuperiorId": 1250,
              "cAreaSuperiorNombre": "Infraestructura & PMO",
              "cAreaApoyo": "0",
              "cFechaInicio": "03/05/2018",
              "nRow": 3
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2851,
                  "cCargoNombre": "Ing. Software",
                  "cCargoAbreviatura": "IFW",
                  "nAreaId": 1280,
                  "cAreaNombre": "Aplicaciones de Servicio",
                  "cAreaAbreviatura": "APS1",
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Infraestructura y PMO",
                  "nCargoSuperiorId": 2790,
                  "cFechaInicio": "03/05/2018",
                  "nRow": 51,
                  "nPersonasDesg": 10
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4422,
                      "nPersonaId": 843,
                      "nIdSeguridad": 0,
                      "cPersonaNom": "AGAPITO SANDOVAL, MARTIN ALEJANDRO",
                      "nCargoId": 2851,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "03/05/2018",
                      "nRow": 112,
                      "nAreaId": 1280,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4421,
                      "nPersonaId": 887,
                      "nIdSeguridad": 1366,
                      "cPersonaNom": "ACU�A BUSTAMANTE, ALDRISH KIOSHI",
                      "nCargoId": 2851,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "03/05/2018",
                      "nRow": 116,
                      "nAreaId": 1280,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4423,
                      "nPersonaId": 1976,
                      "nIdSeguridad": 1376,
                      "cPersonaNom": "BOY CASTILLA, JOSE SEGUNDO",
                      "nCargoId": 2851,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "03/05/2018",
                      "nRow": 127,
                      "nAreaId": 1280,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4424,
                      "nPersonaId": 4008,
                      "nIdSeguridad": 3426,
                      "cPersonaNom": "DONAYRE DONAYRES, DAVID RICARDO",
                      "nCargoId": 2851,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "03/05/2018",
                      "nRow": 131,
                      "nAreaId": 1280,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4429,
                      "nPersonaId": 6223,
                      "nIdSeguridad": 8633,
                      "cPersonaNom": "DE LA CRUZ ALVAREZ, CARLOS",
                      "nCargoId": 2851,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "08/05/2018",
                      "nRow": 156,
                      "nAreaId": 1280,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4431,
                      "nPersonaId": 7255,
                      "nIdSeguridad": null,
                      "cPersonaNom": "CASTILLO ROJAS, CARLOS",
                      "nCargoId": 2851,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/05/2018",
                      "nRow": 183,
                      "nAreaId": 1280,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4432,
                      "nPersonaId": 7256,
                      "nIdSeguridad": null,
                      "cPersonaNom": "TORRES TORRES, MARCOS",
                      "nCargoId": 2851,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/05/2018",
                      "nRow": 184,
                      "nAreaId": 1280,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4433,
                      "nPersonaId": 7257,
                      "nIdSeguridad": null,
                      "cPersonaNom": "ROJAS ROJAS, CARLOS",
                      "nCargoId": 2851,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/05/2018",
                      "nRow": 185,
                      "nAreaId": 1280,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4434,
                      "nPersonaId": 7258,
                      "nIdSeguridad": 8684,
                      "cPersonaNom": "TORRES TORRES, PEDRO",
                      "nCargoId": 2851,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/05/2018",
                      "nRow": 186,
                      "nAreaId": 1280,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4437,
                      "nPersonaId": 7261,
                      "nIdSeguridad": null,
                      "cPersonaNom": "ROJAS ROJAS, RONALD",
                      "nCargoId": 2851,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/06/2018",
                      "nRow": 189,
                      "nAreaId": 1280,
                      "nCrgContrato": "1"
                    }
                  }
                ]
              }
            ],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1229,
              "cAreaNombre": "Aplicaciones de Servicios",
              "cAreaAbreviatura": null,
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 4,
              "cNivelNombre": "UNIDAD",
              "nAreaSuperiorId": 1250,
              "cAreaSuperiorNombre": "Infraestructura & PMO",
              "cAreaApoyo": "0",
              "cFechaInicio": "06/09/2017",
              "nRow": 4
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2764,
                  "cCargoNombre": "Administrador de Aplicaciones de Servicios",
                  "cCargoAbreviatura": "ADS",
                  "nAreaId": 1229,
                  "cAreaNombre": "Aplicaciones de Servicios",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Infraestructura y PMO",
                  "nCargoSuperiorId": 2790,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 2,
                  "nPersonasDesg": 7
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4318,
                      "nPersonaId": 827,
                      "nIdSeguridad": 1230,
                      "cPersonaNom": "AGUIRRE PABLO, LUCIANA PAMELA",
                      "nCargoId": 2764,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "31/01/2018",
                      "nRow": 106,
                      "nAreaId": 1229,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4438,
                      "nPersonaId": 7262,
                      "nIdSeguridad": null,
                      "cPersonaNom": "CASTRI CASTRI, TOM",
                      "nCargoId": 2764,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/06/2018",
                      "nRow": 190,
                      "nAreaId": 1229,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4439,
                      "nPersonaId": 7263,
                      "nIdSeguridad": null,
                      "cPersonaNom": "TOR TOR, TOMAS",
                      "nCargoId": 2764,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/06/2018",
                      "nRow": 191,
                      "nAreaId": 1229,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4440,
                      "nPersonaId": 7264,
                      "nIdSeguridad": null,
                      "cPersonaNom": "LAB LAB, LAB",
                      "nCargoId": 2764,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/06/2018",
                      "nRow": 192,
                      "nAreaId": 1229,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4441,
                      "nPersonaId": 7265,
                      "nIdSeguridad": null,
                      "cPersonaNom": "TAR TAR, TAR",
                      "nCargoId": 2764,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/06/2018",
                      "nRow": 193,
                      "nAreaId": 1229,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4442,
                      "nPersonaId": 7266,
                      "nIdSeguridad": null,
                      "cPersonaNom": "TORR TORR, CARLOS",
                      "nCargoId": 2764,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/06/2018",
                      "nRow": 194,
                      "nAreaId": 1229,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4443,
                      "nPersonaId": 7267,
                      "nIdSeguridad": null,
                      "cPersonaNom": "GAT GAT, GAT",
                      "nCargoId": 2764,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/06/2018",
                      "nRow": 195,
                      "nAreaId": 1229,
                      "nCrgContrato": "1"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2809,
                  "cCargoNombre": "Ingeniero de Software",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1229,
                  "cAreaNombre": "Aplicaciones de Servicios",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Administrador de Aplicaciones de Servicios",
                  "nCargoSuperiorId": 2764,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 56,
                  "nPersonasDesg": 5
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4300,
                      "nPersonaId": 6224,
                      "nIdSeguridad": 8633,
                      "cPersonaNom": "SALAZAR DIAZ, JUAN",
                      "nCargoId": 2809,
                      "nCargoPersonaSuperiorId": 4318,
                      "cCargoPerSupNom": "AGUIRRE PABLO, LUCIANA PAMELA",
                      "nPersonaSuplenteId": 10,
                      "cPersonaSuplNom": "SILVA DIOS, MARYURI FABIOLA",
                      "cFechaInicio": "01/09/2017",
                      "nRow": 158,
                      "nAreaId": 1229,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4308,
                      "nPersonaId": 6226,
                      "nIdSeguridad": null,
                      "cPersonaNom": "QUISPE MAMANI, JOSE",
                      "nCargoId": 2809,
                      "nCargoPersonaSuperiorId": 4318,
                      "cCargoPerSupNom": "AGUIRRE PABLO, LUCIANA PAMELA",
                      "nPersonaSuplenteId": 10,
                      "cPersonaSuplNom": "SILVA DIOS, MARYURI FABIOLA",
                      "cFechaInicio": "17/01/2018",
                      "nRow": 159,
                      "nAreaId": 1229,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4449,
                      "nPersonaId": 7271,
                      "nIdSeguridad": null,
                      "cPersonaNom": "TORRES TORRES, ANDY",
                      "nCargoId": 2809,
                      "nCargoPersonaSuperiorId": 4318,
                      "cCargoPerSupNom": "AGUIRRE PABLO, LUCIANA PAMELA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/06/2018",
                      "nRow": 199,
                      "nAreaId": 1229,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4450,
                      "nPersonaId": 7272,
                      "nIdSeguridad": null,
                      "cPersonaNom": "TORRES TORRES, ANDYDY",
                      "nCargoId": 2809,
                      "nCargoPersonaSuperiorId": 4318,
                      "cCargoPerSupNom": "AGUIRRE PABLO, LUCIANA PAMELA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/06/2018",
                      "nRow": 200,
                      "nAreaId": 1229,
                      "nCrgContrato": "1"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2834,
                  "cCargoNombre": "Trainee de SW",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1229,
                  "cAreaNombre": "Aplicaciones de Servicios",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Administrador de Aplicaciones de Servicios",
                  "nCargoSuperiorId": 2764,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 82,
                  "nPersonasDesg": 3
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4416,
                      "nPersonaId": 7245,
                      "nIdSeguridad": 8633,
                      "cPersonaNom": "AAAAA AA, AA",
                      "nCargoId": 2834,
                      "nCargoPersonaSuperiorId": 4318,
                      "cCargoPerSupNom": "AGUIRRE PABLO, LUCIANA PAMELA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/05/2018",
                      "nRow": 180,
                      "nAreaId": 1229,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4418,
                      "nPersonaId": 7248,
                      "nIdSeguridad": null,
                      "cPersonaNom": "DIAZ CASTILLO, CARLOS",
                      "nCargoId": 2834,
                      "nCargoPersonaSuperiorId": 4318,
                      "cCargoPerSupNom": "AGUIRRE PABLO, LUCIANA PAMELA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "01/05/2018",
                      "nRow": 182,
                      "nAreaId": 1229,
                      "nCrgContrato": "1"
                    }
                  }
                ]
              }
            ],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1282,
              "cAreaNombre": "Area Prueba",
              "cAreaAbreviatura": "AP",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 4,
              "cNivelNombre": "UNIDAD",
              "nAreaSuperiorId": 1250,
              "cAreaSuperiorNombre": "Infraestructura & PMO",
              "cAreaApoyo": "0",
              "cFechaInicio": "03/05/2018",
              "nRow": 5
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2854,
                  "cCargoNombre": "Ing. Software",
                  "cCargoAbreviatura": "IS",
                  "nAreaId": 1282,
                  "cAreaNombre": "Area Prueba",
                  "cAreaAbreviatura": "AP",
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Infraestructura y PMO",
                  "nCargoSuperiorId": 2790,
                  "cFechaInicio": "03/05/2018",
                  "nRow": 52,
                  "nPersonasDesg": 2
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4428,
                      "nPersonaId": 6220,
                      "nIdSeguridad": null,
                      "cPersonaNom": "REYES REYES, ARTURO",
                      "nCargoId": 2854,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "03/05/2018",
                      "nRow": 154,
                      "nAreaId": 1282,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4430,
                      "nPersonaId": 6224,
                      "nIdSeguridad": 8633,
                      "cPersonaNom": "SALAZAR DIAZ, JUAN",
                      "nCargoId": 2854,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "08/05/2018",
                      "nRow": 157,
                      "nAreaId": 1282,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              }
            ],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1230,
              "cAreaNombre": "End User Support",
              "cAreaAbreviatura": "EUS",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 3,
              "cNivelNombre": "SECCION",
              "nAreaSuperiorId": 1250,
              "cAreaSuperiorNombre": "Infraestructura & PMO",
              "cAreaApoyo": "0",
              "cFechaInicio": "06/09/2017",
              "nRow": 8
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2772,
                  "cCargoNombre": "Analista EUS",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1230,
                  "cAreaNombre": "End User Support",
                  "cAreaAbreviatura": "EUS",
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Administrador de Help Desk",
                  "nCargoSuperiorId": 2766,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 10,
                  "nPersonasDesg": 3
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4381,
                      "nPersonaId": 972,
                      "nIdSeguridad": 4511,
                      "cPersonaNom": "FERNANDEZ GOMERO, RAUL",
                      "nCargoId": 2772,
                      "nCargoPersonaSuperiorId": 4350,
                      "cCargoPerSupNom": "CERNA AGUIRRE, DEYNIS WILLIAM",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "16/02/2018",
                      "nRow": 126,
                      "nAreaId": 1230,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4368,
                      "nPersonaId": 5179,
                      "nIdSeguridad": 8628,
                      "cPersonaNom": "GOMEZ BOLA�O, ROBERTO",
                      "nCargoId": 2772,
                      "nCargoPersonaSuperiorId": 4350,
                      "cCargoPerSupNom": "CERNA AGUIRRE, DEYNIS WILLIAM",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "16/02/2018",
                      "nRow": 135,
                      "nAreaId": 1230,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4404,
                      "nPersonaId": 7235,
                      "nIdSeguridad": null,
                      "cPersonaNom": "PEREZ ARRIETA, LUIS",
                      "nCargoId": 2772,
                      "nCargoPersonaSuperiorId": 4350,
                      "cCargoPerSupNom": "CERNA AGUIRRE, DEYNIS WILLIAM",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "14/03/2018",
                      "nRow": 170,
                      "nAreaId": 1230,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2782,
                  "cCargoNombre": "Asistente EUS",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1230,
                  "cAreaNombre": "End User Support",
                  "cAreaAbreviatura": "EUS",
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Administrador de Help Desk",
                  "nCargoSuperiorId": 2766,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 21,
                  "nPersonasDesg": 2
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4367,
                      "nPersonaId": 5189,
                      "nIdSeguridad": null,
                      "cPersonaNom": "LLEPEZ CARTAGENA, JULIAN",
                      "nCargoId": 2782,
                      "nCargoPersonaSuperiorId": 4350,
                      "cCargoPerSupNom": "CERNA AGUIRRE, DEYNIS WILLIAM",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "16/02/2018",
                      "nRow": 140,
                      "nAreaId": 1230,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4391,
                      "nPersonaId": 6207,
                      "nIdSeguridad": null,
                      "cPersonaNom": "PAJOY RAMIREZ, EDER",
                      "nCargoId": 2782,
                      "nCargoPersonaSuperiorId": 4350,
                      "cCargoPerSupNom": "CERNA AGUIRRE, DEYNIS WILLIAM",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "16/02/2018",
                      "nRow": 146,
                      "nAreaId": 1230,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2835,
                  "cCargoNombre": "Trainee EUS",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1230,
                  "cAreaNombre": "End User Support",
                  "cAreaAbreviatura": "EUS",
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Administrador de Help Desk",
                  "nCargoSuperiorId": 2766,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 83,
                  "nPersonasDesg": 0
                },
                "Colaboradores": []
              }
            ],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1249,
              "cAreaNombre": "Help Desk",
              "cAreaAbreviatura": null,
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 3,
              "cNivelNombre": "SECCION",
              "nAreaSuperiorId": 1250,
              "cAreaSuperiorNombre": "Infraestructura & PMO",
              "cAreaApoyo": "0",
              "cFechaInicio": "06/09/2017",
              "nRow": 41
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2766,
                  "cCargoNombre": "Administrador de Help Desk",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1249,
                  "cAreaNombre": "Help Desk",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Infraestructura y PMO",
                  "nCargoSuperiorId": 2790,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 4,
                  "nPersonasDesg": 2
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4350,
                      "nPersonaId": 755,
                      "nIdSeguridad": 1205,
                      "cPersonaNom": "CERNA AGUIRRE, DEYNIS WILLIAM",
                      "nCargoId": 2766,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "14/02/2018",
                      "nRow": 87,
                      "nAreaId": 1249,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4447,
                      "nPersonaId": 6234,
                      "nIdSeguridad": 1359,
                      "cPersonaNom": "VELASQUEZ MAGINO, NANCY RAQUEL",
                      "nCargoId": 2766,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "14/06/2018",
                      "nRow": 167,
                      "nAreaId": 1249,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2783,
                  "cCargoNombre": "Asistente Help Desk",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1249,
                  "cAreaNombre": "Help Desk",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Administrador de Help Desk",
                  "nCargoSuperiorId": 2766,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 22,
                  "nPersonasDesg": 3
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4193,
                      "nPersonaId": 400,
                      "nIdSeguridad": null,
                      "cPersonaNom": "TAPIA NEYRA, EVELYN ELIANA",
                      "nCargoId": 2783,
                      "nCargoPersonaSuperiorId": 4350,
                      "cCargoPerSupNom": "CERNA AGUIRRE, DEYNIS WILLIAM",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 28,
                      "nAreaId": 1249,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4194,
                      "nPersonaId": 800,
                      "nIdSeguridad": 1220,
                      "cPersonaNom": "ZARATE FELIX, JOSE SAMUEL",
                      "nCargoId": 2783,
                      "nCargoPersonaSuperiorId": 4350,
                      "cCargoPerSupNom": "CERNA AGUIRRE, DEYNIS WILLIAM",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 100,
                      "nAreaId": 1249,
                      "nCrgContrato": "1"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4369,
                      "nPersonaId": 825,
                      "nIdSeguridad": 1206,
                      "cPersonaNom": "SANTALLA SANCHEZ, LUIS ALBERTO",
                      "nCargoId": 2783,
                      "nCargoPersonaSuperiorId": 4350,
                      "cCargoPerSupNom": "CERNA AGUIRRE, DEYNIS WILLIAM",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "16/02/2018",
                      "nRow": 105,
                      "nAreaId": 1249,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              }
            ],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1251,
              "cAreaNombre": "ISSTI",
              "cAreaAbreviatura": null,
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 4,
              "cNivelNombre": "UNIDAD",
              "nAreaSuperiorId": 1250,
              "cAreaSuperiorNombre": "Infraestructura & PMO",
              "cAreaApoyo": "0",
              "cFechaInicio": "06/09/2017",
              "nRow": 43
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2765,
                  "cCargoNombre": "Administrador de Datacenter y Networking",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1251,
                  "cAreaNombre": "ISSTI",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Supervisor de ISSTI",
                  "nCargoSuperiorId": 2820,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 3,
                  "nPersonasDesg": 1
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4189,
                      "nPersonaId": 755,
                      "nIdSeguridad": 1205,
                      "cPersonaNom": "CERNA AGUIRRE, DEYNIS WILLIAM",
                      "nCargoId": 2765,
                      "nCargoPersonaSuperiorId": 4188,
                      "cCargoPerSupNom": "PABLO MARTINEZ, VICTOR RAUL",
                      "nPersonaSuplenteId": 754,
                      "cPersonaSuplNom": "PABLO MARTINEZ, VICTOR RAUL",
                      "cFechaInicio": "06/09/2017",
                      "nRow": 86,
                      "nAreaId": 1251,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2768,
                  "cCargoNombre": "Analista de Datacenter y Networking",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1251,
                  "cAreaNombre": "ISSTI",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Administrador de Datacenter y Networking",
                  "nCargoSuperiorId": 2765,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 6,
                  "nPersonasDesg": 2
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4191,
                      "nPersonaId": 296,
                      "nIdSeguridad": 1203,
                      "cPersonaNom": "PABLO ALMONTE, MAYRA LISSET",
                      "nCargoId": 2768,
                      "nCargoPersonaSuperiorId": 4189,
                      "cCargoPerSupNom": "CERNA AGUIRRE, DEYNIS WILLIAM",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 19,
                      "nAreaId": 1251,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4390,
                      "nPersonaId": 955,
                      "nIdSeguridad": 4499,
                      "cPersonaNom": "MACHUCA POLO, AMELIA LORETTA",
                      "nCargoId": 2768,
                      "nCargoPersonaSuperiorId": 4189,
                      "cCargoPerSupNom": "CERNA AGUIRRE, DEYNIS WILLIAM",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "16/02/2018",
                      "nRow": 123,
                      "nAreaId": 1251,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2771,
                  "cCargoNombre": "Analista de Servicios TI",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1251,
                  "cAreaNombre": "ISSTI",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Supervisor de ISSTI",
                  "nCargoSuperiorId": 2820,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 9,
                  "nPersonasDesg": 3
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4302,
                      "nPersonaId": 137,
                      "nIdSeguridad": 58,
                      "cPersonaNom": "GONZALES DE LOS RIOS, RICHARD",
                      "nCargoId": 2771,
                      "nCargoPersonaSuperiorId": 4188,
                      "cCargoPerSupNom": "PABLO MARTINEZ, VICTOR RAUL",
                      "nPersonaSuplenteId": 1976,
                      "cPersonaSuplNom": "BOY CASTILLA, JOSE SEGUNDO",
                      "cFechaInicio": "11/09/2017",
                      "nRow": 6,
                      "nAreaId": 1251,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4190,
                      "nPersonaId": 468,
                      "nIdSeguridad": 142,
                      "cPersonaNom": "MITACC ROCA, EDGAR LUIS",
                      "nCargoId": 2771,
                      "nCargoPersonaSuperiorId": 4188,
                      "cCargoPerSupNom": "PABLO MARTINEZ, VICTOR RAUL",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "06/09/2017",
                      "nRow": 33,
                      "nAreaId": 1251,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4348,
                      "nPersonaId": 6211,
                      "nIdSeguridad": null,
                      "cPersonaNom": "BONILLA GRADOS, YANINA MAYRA",
                      "nCargoId": 2771,
                      "nCargoPersonaSuperiorId": 4188,
                      "cCargoPerSupNom": "PABLO MARTINEZ, VICTOR RAUL",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "14/02/2018",
                      "nRow": 147,
                      "nAreaId": 1251,
                      "nCrgContrato": "1"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2820,
                  "cCargoNombre": "Supervisor de ISSTI",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1251,
                  "cAreaNombre": "ISSTI",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Infraestructura y PMO",
                  "nCargoSuperiorId": 2790,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 68,
                  "nPersonasDesg": 1
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4188,
                      "nPersonaId": 754,
                      "nIdSeguridad": 1271,
                      "cPersonaNom": "PABLO MARTINEZ, VICTOR RAUL",
                      "nCargoId": 2820,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 10,
                      "cPersonaSuplNom": "SILVA DIOS, MARYURI FABIOLA",
                      "cFechaInicio": "06/09/2017",
                      "nRow": 85,
                      "nAreaId": 1251,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              },
              {
                "info": {
                  "nCargoId": 2826,
                  "cCargoNombre": "Trainee Datacenter y Networking",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1251,
                  "cAreaNombre": "ISSTI",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Administrador de Datacenter y Networking",
                  "nCargoSuperiorId": 2765,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 74,
                  "nPersonasDesg": 1
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4347,
                      "nPersonaId": 6214,
                      "nIdSeguridad": null,
                      "cPersonaNom": "DE LA ROSA DEL PINO, ANA MARIA",
                      "nCargoId": 2826,
                      "nCargoPersonaSuperiorId": 4189,
                      "cCargoPerSupNom": "CERNA AGUIRRE, DEYNIS WILLIAM",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "14/02/2018",
                      "nRow": 150,
                      "nAreaId": 1251,
                      "nCrgContrato": "1"
                    }
                  }
                ]
              }
            ],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1253,
              "cAreaNombre": "PMO",
              "cAreaAbreviatura": null,
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 4,
              "cNivelNombre": "UNIDAD",
              "nAreaSuperiorId": 1250,
              "cAreaSuperiorNombre": "Infraestructura & PMO",
              "cAreaApoyo": "0",
              "cFechaInicio": "06/09/2017",
              "nRow": 45
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2773,
                  "cCargoNombre": "Analista PMO",
                  "cCargoAbreviatura": null,
                  "nAreaId": 1253,
                  "cAreaNombre": "PMO",
                  "cAreaAbreviatura": null,
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Infraestructura y PMO",
                  "nCargoSuperiorId": 2790,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 12,
                  "nPersonasDesg": 2
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4378,
                      "nPersonaId": 2000,
                      "nIdSeguridad": 0,
                      "cPersonaNom": "BAUDELAIRE BAUDELAIRE, VIOLET",
                      "nCargoId": 2773,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "16/02/2018",
                      "nRow": 129,
                      "nAreaId": 1253,
                      "nCrgContrato": "0"
                    }
                  },
                  {
                    "info": {
                      "nCargoPersonaId": 4394,
                      "nPersonaId": 5186,
                      "nIdSeguridad": null,
                      "cPersonaNom": "PIZARRO FARFAN, RONALDO",
                      "nCargoId": 2773,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "16/02/2018",
                      "nRow": 137,
                      "nAreaId": 1253,
                      "nCrgContrato": "0"
                    }
                  }
                ]
              }
            ],
            "Entidades": []
          },
          {
            "info": {
              "nAreaId": 1274,
              "cAreaNombre": "Service Desk",
              "cAreaAbreviatura": "SD",
              "nEmpresaId": 2,
              "cEmpresaNombre": "SES",
              "nNivelId": 2,
              "cNivelNombre": "AREA",
              "nAreaSuperiorId": 1250,
              "cAreaSuperiorNombre": "Infraestructura & PMO",
              "cAreaApoyo": "0",
              "cFechaInicio": "15/02/2018",
              "nRow": 49
            },
            "Cargos": [
              {
                "info": {
                  "nCargoId": 2845,
                  "cCargoNombre": "Lider Services Desk",
                  "cCargoAbreviatura": "LSD",
                  "nAreaId": 1274,
                  "cAreaNombre": "Service Desk",
                  "cAreaAbreviatura": "SD",
                  "cCargoResponsable": "0",
                  "cCargoSuperiorNombre": "Coordinador de Infraestructura y PMO",
                  "nCargoSuperiorId": 2790,
                  "cFechaInicio": "15/02/2018",
                  "nRow": 66,
                  "nPersonasDesg": 1
                },
                "Colaboradores": [
                  {
                    "info": {
                      "nCargoPersonaId": 4358,
                      "nPersonaId": 6234,
                      "nIdSeguridad": 1359,
                      "cPersonaNom": "VELASQUEZ MAGINO, NANCY RAQUEL",
                      "nCargoId": 2845,
                      "nCargoPersonaSuperiorId": 4187,
                      "cCargoPerSupNom": "SILVA DIOS, MARYURI FABIOLA",
                      "nPersonaSuplenteId": 0,
                      "cPersonaSuplNom": null,
                      "cFechaInicio": "15/02/2018",
                      "nRow": 168,
                      "nAreaId": 1274,
                      "nCrgContrato": "1"
                    }
                  }
                ]
              }
            ],
            "Entidades": [
              {
                "info": {
                  "nAreaId": 1275,
                  "cAreaNombre": "End User Support D",
                  "cAreaAbreviatura": "EUSD",
                  "nEmpresaId": 2,
                  "cEmpresaNombre": "SES",
                  "nNivelId": 3,
                  "cNivelNombre": "SECCION",
                  "nAreaSuperiorId": 1274,
                  "cAreaSuperiorNombre": "Service Desk",
                  "cAreaApoyo": "0",
                  "cFechaInicio": "15/02/2018",
                  "nRow": 9
                },
                "Cargos": [
                  {
                    "info": {
                      "nCargoId": 2846,
                      "cCargoNombre": "Analista EUS",
                      "cCargoAbreviatura": "AEUS",
                      "nAreaId": 1275,
                      "cAreaNombre": "End User Support D",
                      "cAreaAbreviatura": "EUSD",
                      "cCargoResponsable": "0",
                      "cCargoSuperiorNombre": "Lider Services Desk",
                      "nCargoSuperiorId": 2845,
                      "cFechaInicio": "15/02/2018",
                      "nRow": 11,
                      "nPersonasDesg": 2
                    },
                    "Colaboradores": [
                      {
                        "info": {
                          "nCargoPersonaId": 4366,
                          "nPersonaId": 341,
                          "nIdSeguridad": 63,
                          "cPersonaNom": "CASTILLO ALFARO, VLADIMIR SANDINO",
                          "nCargoId": 2846,
                          "nCargoPersonaSuperiorId": 4358,
                          "cCargoPerSupNom": "VELASQUEZ MAGINO, NANCY RAQUEL",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "16/02/2018",
                          "nRow": 22,
                          "nAreaId": 1275,
                          "nCrgContrato": "0"
                        }
                      },
                      {
                        "info": {
                          "nCargoPersonaId": 4419,
                          "nPersonaId": 6231,
                          "nIdSeguridad": 8666,
                          "cPersonaNom": "PANANA PANANA, PETER ERIVER",
                          "nCargoId": 2846,
                          "nCargoPersonaSuperiorId": 4358,
                          "cCargoPerSupNom": "VELASQUEZ MAGINO, NANCY RAQUEL",
                          "nPersonaSuplenteId": 0,
                          "cPersonaSuplNom": null,
                          "cFechaInicio": "03/05/2018",
                          "nRow": 164,
                          "nAreaId": 1275,
                          "nCrgContrato": "0"
                        }
                      }
                    ]
                  }
                ],
                "Entidades": []
              }
            ]
          }
        ]
      },
      {
        "info": {
          "nAreaId": 1254,
          "cAreaNombre": "Proyectos Estrat�gicos",
          "cAreaAbreviatura": "PRES",
          "nEmpresaId": 2,
          "cEmpresaNombre": "SES",
          "nNivelId": 2,
          "cNivelNombre": "AREA",
          "nAreaSuperiorId": 1247,
          "cAreaSuperiorNombre": "Gerencia General",
          "cAreaApoyo": "0",
          "cFechaInicio": "06/09/2017",
          "nRow": 46
        },
        "Cargos": [
          {
            "info": {
              "nCargoId": 2818,
              "cCargoNombre": "L�der de Proyecto CMMI",
              "cCargoAbreviatura": null,
              "nAreaId": 1254,
              "cAreaNombre": "Proyectos Estrat�gicos",
              "cAreaAbreviatura": "PRES",
              "cCargoResponsable": "0",
              "cCargoSuperiorNombre": "Gerente General",
              "nCargoSuperiorId": 2798,
              "cFechaInicio": "06/09/2017",
              "nRow": 65,
              "nPersonasDesg": 1
            },
            "Colaboradores": [
              {
                "info": {
                  "nCargoPersonaId": 4377,
                  "nPersonaId": 6213,
                  "nIdSeguridad": 8667,
                  "cPersonaNom": "VIGIL VIGIL, JOSE",
                  "nCargoId": 2818,
                  "nCargoPersonaSuperiorId": 4184,
                  "cCargoPerSupNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "16/02/2018",
                  "nRow": 149,
                  "nAreaId": 1254,
                  "nCrgContrato": "0"
                }
              }
            ]
          },
          {
            "info": {
              "nCargoId": 2819,
              "cCargoNombre": "RED",
              "cCargoAbreviatura": null,
              "nAreaId": 1254,
              "cAreaNombre": "Proyectos Estrat�gicos",
              "cAreaAbreviatura": "PRES",
              "cCargoResponsable": "0",
              "cCargoSuperiorNombre": "Gerente General",
              "nCargoSuperiorId": 2798,
              "cFechaInicio": "06/09/2017",
              "nRow": 67,
              "nPersonasDesg": 2
            },
            "Colaboradores": [
              {
                "info": {
                  "nCargoPersonaId": 4185,
                  "nPersonaId": 199,
                  "nIdSeguridad": 1184,
                  "cPersonaNom": "BEZADA RAMOS, JANFRANCO",
                  "nCargoId": 2819,
                  "nCargoPersonaSuperiorId": 4184,
                  "cCargoPerSupNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "06/09/2017",
                  "nRow": 7,
                  "nAreaId": 1254,
                  "nCrgContrato": "1"
                }
              },
              {
                "info": {
                  "nCargoPersonaId": 4379,
                  "nPersonaId": 788,
                  "nIdSeguridad": 1330,
                  "cPersonaNom": "CAMPOS SALCEDO, VICTOR HUGO",
                  "nCargoId": 2819,
                  "nCargoPersonaSuperiorId": 4184,
                  "cCargoPerSupNom": "HUAPAYA ALCAZAR, JUAN DANIEL",
                  "nPersonaSuplenteId": 0,
                  "cPersonaSuplNom": null,
                  "cFechaInicio": "16/02/2018",
                  "nRow": 95,
                  "nAreaId": 1254,
                  "nCrgContrato": "0"
                }
              }
            ]
          }
        ],
        "Entidades": []
      }
    ]
  }
]
	