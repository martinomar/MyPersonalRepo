var app = angular.module("myApp",[]);
app.controller("mySuperController",function($scope,$http){
	$scope.organigrama = organigrama;
	
})