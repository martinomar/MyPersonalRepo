var app = angular.module("MyApp",[]);

app.controller("mySuperController",function($scope,$http){
	
	$scope.datasource = {
      'name': 'SES',
      'title': 'Empresa',
      'office': '',
	  'children': [
		{ 'name': 'FSW - SBU', 'title': '', 'office': '',
			'children': [
				{ 'name': 'Entidades', 'office': 'ofc'},
				{ 'name': 'Cargos', 'office': 'ofc'}
			]
		},
        { 'name': 'Gerencia General', 'title': '', 'office': '',
			'children': [
				{ 'name': 'Entidades', 'title': '', 'office': 'ofc'},
				{ 'name': 'Cargos', 'title': '', 'office': 'ofc'}
			]
		}
      ]
    };
	var vdatasource = $scope.datasource;
	
});