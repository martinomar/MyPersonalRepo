(function () {
    angular.module('zt.angular-loading', []);
    require('./loading.provider.js');
    require('./loading.directive.js');
})();