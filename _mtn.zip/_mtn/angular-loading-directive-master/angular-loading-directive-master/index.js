require('./dist/loading.js');
module.exports = 'zt.angular-loading';