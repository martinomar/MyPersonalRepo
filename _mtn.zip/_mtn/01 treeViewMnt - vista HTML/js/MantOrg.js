
$(function () {
    $("#txtFilter").treeListFilter("#treeView_ul_Org", 0);
    //$('[data-toggleee="tooltip"]').tooltip()



    $(".glyphicon-fullscreen-btn").click(function () {

        $(".cls-titulo-opcion").toggleClass('hide_');
        $(".cls-nav").toggleClass('hide_');
        $(".dvBtnFiltrosCollapse").toggleClass('topSet');
        $(".text-description").toggleClass('hide_');
        $(".viewTitle").toggleClass('viewTitle_font');
        $(".divOrgContainer").toggleClass('divOrgContainer_NoPaddng');
      
        $(this).toggleClass('glyphicon-fullscreen');
        $(this).toggleClass('glyphicon-resize-small');

        if ($(".cls-titulo-opcion").hasClass('hide_')) {
            heightPrct = .80;/*the percent when the user make click in "maximize" */
        }
        else {
            heightPrct = .62;
        }

        resizeContent();
        fnactivemenu('out');

    });

    $(".btnClickbs").click(function () {

        $(".div_btnSHW").toggleClass('show_');
        $(".div_btnSHW_inpt").toggleClass('show_');
        $(".div_btnSHW").toggleClass('hide_');
        $(".div_btnSHW_inpt").toggleClass('hide_');

        $("#txtFilter").val('');
        $("#txtFilter").keydown();
        $("#txtFilter").focus();
    });

    $('[data-toggle="tooltip"]').tooltip();

    $(".spanToogle").click(function () {
        $(this).toggleClass("active");
        $(this).toggleClass("btnCollapse");
    });

    $(".expandAll").click(function () {
        $(".divContainerList").find(".collapse").toggleClass("in");
    });


    var heightPrct = .62;
    $(".divContainerList").css("min-height", $(window).height() * heightPrct);
    $("#dv-panel-body").css("min-height", $(window).height());
    $(window).resize(function () {
        resizeContent();
    });
    function resizeContent() {
        $(".divContainerList").css("min-height", $(window).height() * heightPrct);
        $("#dv-panel-body").css("min-height", $(window).height());
    }

});