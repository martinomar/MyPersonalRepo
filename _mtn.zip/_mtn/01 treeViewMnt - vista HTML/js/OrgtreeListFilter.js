//$(function () {

    jQuery.fn.treeListFilter = function (list, timeout) {
        var list = jQuery(list);
        var input = this;
        var KeyTimeout;
        var lastFilter = '';

        function filterList(ulObject, filterValue) {
            if (!ulObject.is('ul') && !ulObject.is("ol")) {
                return false;
            }
            var children = ulObject.children();
            var result = false;
            for (var i = 0; i < children.length; i++) {
                var liObject = jQuery(children[i]);
                if (liObject.is('li')) {
                    var display = false;
                    if (liObject.children().length > 0) {
                        for (var j = 0; j < liObject.children().length; j++) {
                            var subDisplay = filterList(jQuery(liObject.children()[j]), filterValue);
                            display = display || subDisplay;
                        }
                    }
                    if (!display) {
                        var text = liObject.text();
                        display = text.toLowerCase().indexOf(filterValue) >= 0;
                    }
                    //liObject.css('display', display ? '' : 'none');
                    //liObject.toggleClass(display ? '' : 'filter_hiden');
                    if (display) {
                        liObject.removeClass('filter_hidden');
                    }
                    else {
                        liObject.addClass('filter_hidden');
                    }

                    result = result || display;
                }
            }
            return result;
        }
        var toggled = false;
        input.change(function () {
            var filter = input.val().toLowerCase();
            if (filter.length > 0 && toggled == false) {
                $(".divContainerList").find(".collapse").addClass("in");
                toggled = true;
            }
            if (filter.length == 0 && toggled == true) {
                $(".divContainerList").find(".collapse").removeClass("in");
                toggled = false;
            }

            filterList(list, filter);
            return false;
        }).keydown(function () {
            clearTimeout(KeyTimeout);
            KeyTimeout = setTimeout(function () {
                if (input.val() === lastFilter) return;
                lastFilter = input.val();
                input.change();

            }, timeout);
        });
        return this;
    }

//});